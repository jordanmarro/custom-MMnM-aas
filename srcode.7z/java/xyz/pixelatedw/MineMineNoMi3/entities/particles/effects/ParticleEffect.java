package xyz.pixelatedw.MineMineNoMi3.entities.particles.effects;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public abstract class ParticleEffect
{

	public abstract void spawn(EntityPlayer player, double posX, double posY, double posZ);
	
}
