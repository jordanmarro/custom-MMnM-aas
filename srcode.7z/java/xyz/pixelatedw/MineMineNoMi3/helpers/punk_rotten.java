package xyz.pixelatedw.MineMineNoMi3.helpers;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.ModelZoanMorph;

public class punk_rotten extends ModelZoanMorph
{
    private final ModelRenderer mainbody;
    private final ModelRenderer armconnection_r1;
    private final ModelRenderer armconnection_r2;
    private final ModelRenderer bottomspiral;
    private final ModelRenderer maintorso3_r1;
    private final ModelRenderer maintorso3_r2;
    private final ModelRenderer maintorso2_r1;
    private final ModelRenderer maintorso2_r2;
    private final ModelRenderer maintorso4_r1;
    private final ModelRenderer maintorso4_r2;
    private final ModelRenderer maintorso_r1;
    private final ModelRenderer maintorso_r2;
    private final ModelRenderer spiralthing2_r1;
    private final ModelRenderer spiralthing1_r1;
    private final ModelRenderer wheelthing;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer spike1_r1;
    private final ModelRenderer spike1_r2;
    private final ModelRenderer spike1_r3;
    private final ModelRenderer spike1_r4;
    private final ModelRenderer frontchest;
    private final ModelRenderer nails_r1;
    private final ModelRenderer nails_r2;
    private final ModelRenderer nails_r3;
    private final ModelRenderer nails_r4;
    private final ModelRenderer nails_r5;
    private final ModelRenderer metalcover_r1;
    private final ModelRenderer topnails_r1;
    private final ModelRenderer topnails_r2;
    private final ModelRenderer topnails_r3;
    private final ModelRenderer topnails_r4;
    private final ModelRenderer shoulderthings;
    private final ModelRenderer armconnection_r3;
    private final ModelRenderer armconnection_r4;
    private final ModelRenderer armconnection_r5;
    private final ModelRenderer armconnection_r6;
    private final ModelRenderer armconnection_r7;
    private final ModelRenderer armconnection_r8;
    private final ModelRenderer shoulderright;
    private final ModelRenderer armconnection_r9;
    private final ModelRenderer armconnection_r10;
    private final ModelRenderer armconnection_r11;
    private final ModelRenderer armconnection_r12;
    private final ModelRenderer armconnection_r13;
    private final ModelRenderer armconnection_r14;
    private final ModelRenderer shoulderspikes;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer bone;
    private final ModelRenderer leftwrist;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer lefthand;
    private final ModelRenderer thumn1_r1;
    private final ModelRenderer thumn1_r2;
    private final ModelRenderer finger1_r1;
    private final ModelRenderer finger1_r2;
    private final ModelRenderer rightwrist;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer righthand;
    private final ModelRenderer thumn1_r3;
    private final ModelRenderer thumn1_r4;
    private final ModelRenderer finger1_r3;
    private final ModelRenderer finger1_r4;
    private final ModelRenderer leftforearm;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer leftforearm2;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;

    public punk_rotten() {
        textureWidth = 512;
        textureHeight = 512;

        mainbody = new ModelRenderer(this);
        mainbody.setRotationPoint(-2.0F, -18.0F, -15.0F);
        mainbody.cubeList.add(new ModelBox(mainbody, 0, 0, -19.0F, -38.0F, 0.0F, 42, 28, 33, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 0, 61, -15.0F, -10.0F, 0.0F, 34, 4, 33, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 199, 20, -16.0F, -58.0F, 27.0F, 36, 8, 4, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 222, 35, -11.0F, -50.0F, 23.0F, 26, 12, 10, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 218, 146, -11.0F, -50.0F, 1.0F, 26, 12, 10, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 182, 110, 14.0F, -54.0F, 1.0F, 1, 4, 10, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 76, 147, -11.0F, -54.0F, 1.0F, 1, 4, 10, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 117, 29, -10.0F, -53.0F, 1.0F, 24, 3, 0, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 150, 0, 15.0F, -50.0F, 0.0F, 8, 12, 33, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 0, 147, -19.0F, -50.0F, 0.0F, 8, 12, 33, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 98, 137, -18.0F, -47.0F, -4.0F, 39, 44, 5, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 151, 280, 21.0F, -45.0F, -3.0F, 5, 39, 4, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 133, 280, -22.0F, -45.0F, -3.0F, 5, 39, 4, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 152, 0, 21.0F, -45.0F, 34.0F, 5, 22, 2, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 117, 0, -22.0F, -45.0F, 33.0F, 5, 22, 3, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 140, 61, -17.0F, -47.0F, 33.0F, 38, 45, 4, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 82, 187, -15.0F, -45.0F, 36.0F, 34, 33, 4, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 0, 192, -14.0F, -43.0F, 36.0F, 32, 21, 9, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 0, 222, -24.0F, -45.0F, 4.0F, 5, 21, 25, 0.0F));
        mainbody.cubeList.add(new ModelBox(mainbody, 205, 214, 23.0F, -45.0F, 4.0F, 5, 21, 25, 0.0F));

        armconnection_r1 = new ModelRenderer(this);
        armconnection_r1.setRotationPoint(-3.0F, -6.0F, 0.0F);
        mainbody.addChild(armconnection_r1);
        setRotationAngle(armconnection_r1, 0.0F, 0.0F, 0.2182F);
        armconnection_r1.cubeList.add(new ModelBox(armconnection_r1, 52, 98, 23.0F, -43.0F, 7.0F, 22, 17, 19, 0.0F));

        armconnection_r2 = new ModelRenderer(this);
        armconnection_r2.setRotationPoint(-58.0F, 8.0F, 0.0F);
        mainbody.addChild(armconnection_r2);
        setRotationAngle(armconnection_r2, 0.0F, 0.0F, -0.2182F);
        armconnection_r2.cubeList.add(new ModelBox(armconnection_r2, 186, 110, 23.0F, -43.0F, 7.0F, 22, 17, 19, 0.0F));

        bottomspiral = new ModelRenderer(this);
        bottomspiral.setRotationPoint(0.0F, 1.0F, 0.0F);
        mainbody.addChild(bottomspiral);
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 0, 98, 1.0F, -3.0F, -6.0F, 3, 3, 46, 0.0F));
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 0, 27, -2.0F, -3.0F, 40.0F, 9, 3, 3, 0.0F));
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 186, 155, -2.0F, -4.0F, -9.0F, 9, 4, 3, 0.0F));
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 286, 127, -19.0F, -3.0F, 9.0F, 3, 3, 7, 0.0F));
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 234, 287, 20.0F, -3.0F, 18.0F, 3, 3, 7, 0.0F));
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 119, 77, -19.0F, -3.0F, 18.0F, 3, 3, 7, 0.0F));
        bottomspiral.cubeList.add(new ModelBox(bottomspiral, 274, 289, 20.0F, -3.0F, 9.0F, 3, 3, 7, 0.0F));

        maintorso3_r1 = new ModelRenderer(this);
        maintorso3_r1.setRotationPoint(-1.0F, 0.0F, -9.0F);
        bottomspiral.addChild(maintorso3_r1);
        setRotationAngle(maintorso3_r1, 0.0F, 0.829F, 0.0F);
        maintorso3_r1.cubeList.add(new ModelBox(maintorso3_r1, 22, 277, 0.0F, -3.0F, 12.0F, 3, 3, 18, 0.0F));

        maintorso3_r2 = new ModelRenderer(this);
        maintorso3_r2.setRotationPoint(23.0F, 0.0F, -3.0F);
        bottomspiral.addChild(maintorso3_r2);
        setRotationAngle(maintorso3_r2, 0.0F, -1.5708F, 0.0F);
        maintorso3_r2.cubeList.add(new ModelBox(maintorso3_r2, 14, 78, 0.0F, -3.0F, 13.0F, 3, 3, 6, 0.0F));

        maintorso2_r1 = new ModelRenderer(this);
        maintorso2_r1.setRotationPoint(13.0F, 0.0F, 34.0F);
        bottomspiral.addChild(maintorso2_r1);
        setRotationAngle(maintorso2_r1, 0.0F, -1.5708F, 0.0F);
        maintorso2_r1.cubeList.add(new ModelBox(maintorso2_r1, 46, 277, 0.0F, -3.0F, 12.0F, 3, 3, 7, 0.0F));

        maintorso2_r2 = new ModelRenderer(this);
        maintorso2_r2.setRotationPoint(-28.0F, 0.0F, 17.0F);
        bottomspiral.addChild(maintorso2_r2);
        setRotationAngle(maintorso2_r2, 0.0F, 0.829F, 0.0F);
        maintorso2_r2.cubeList.add(new ModelBox(maintorso2_r2, 260, 268, 0.0F, -3.0F, 12.0F, 3, 3, 18, 0.0F));

        maintorso4_r1 = new ModelRenderer(this);
        maintorso4_r1.setRotationPoint(23.0F, 0.0F, 34.0F);
        bottomspiral.addChild(maintorso4_r1);
        setRotationAngle(maintorso4_r1, 0.0F, -1.5708F, 0.0F);
        maintorso4_r1.cubeList.add(new ModelBox(maintorso4_r1, 254, 289, 0.0F, -3.0F, 12.0F, 3, 3, 7, 0.0F));

        maintorso4_r2 = new ModelRenderer(this);
        maintorso4_r2.setRotationPoint(30.0F, 0.0F, 15.0F);
        bottomspiral.addChild(maintorso4_r2);
        setRotationAngle(maintorso4_r2, 0.0F, -0.8203F, 0.0F);
        maintorso4_r2.cubeList.add(new ModelBox(maintorso4_r2, 277, 78, 0.0F, -3.0F, 12.0F, 3, 3, 17, 0.0F));

        maintorso_r1 = new ModelRenderer(this);
        maintorso_r1.setRotationPoint(13.0F, 0.0F, -3.0F);
        bottomspiral.addChild(maintorso_r1);
        setRotationAngle(maintorso_r1, 0.0F, -1.5708F, 0.0F);
        maintorso_r1.cubeList.add(new ModelBox(maintorso_r1, 214, 287, 0.0F, -3.0F, 12.0F, 3, 3, 7, 0.0F));

        maintorso_r2 = new ModelRenderer(this);
        maintorso_r2.setRotationPoint(3.0F, 0.0F, -11.0F);
        bottomspiral.addChild(maintorso_r2);
        setRotationAngle(maintorso_r2, 0.0F, -0.829F, 0.0F);
        maintorso_r2.cubeList.add(new ModelBox(maintorso_r2, 275, 235, 0.0F, -3.0F, 12.0F, 3, 3, 18, 0.0F));

        spiralthing2_r1 = new ModelRenderer(this);
        spiralthing2_r1.setRotationPoint(68.0F, 0.0F, 16.0F);
        bottomspiral.addChild(spiralthing2_r1);
        setRotationAngle(spiralthing2_r1, 0.0F, -1.5708F, 0.0F);
        spiralthing2_r1.cubeList.add(new ModelBox(spiralthing2_r1, 150, 55, -3.0F, -3.0F, 40.0F, 9, 3, 3, 0.0F));

        spiralthing1_r1 = new ModelRenderer(this);
        spiralthing1_r1.setRotationPoint(19.0F, 0.0F, 16.0F);
        bottomspiral.addChild(spiralthing1_r1);
        setRotationAngle(spiralthing1_r1, 0.0F, -1.5708F, 0.0F);
        spiralthing1_r1.cubeList.add(new ModelBox(spiralthing1_r1, 190, 45, -3.0F, -3.0F, 40.0F, 9, 3, 3, 0.0F));
        spiralthing1_r1.cubeList.add(new ModelBox(spiralthing1_r1, 88, 88, 0.0F, -3.0F, -6.0F, 3, 3, 46, 0.0F));

        wheelthing = new ModelRenderer(this);
        wheelthing.setRotationPoint(2.0F, 41.0F, 8.0F);
        mainbody.addChild(wheelthing);
        wheelthing.cubeList.add(new ModelBox(wheelthing, 111, 280, -2.0F, -48.0F, 7.0F, 6, 34, 5, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 125, 239, -9.0F, -33.0F, 2.0F, 19, 5, 15, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 224, 86, -9.0F, -23.0F, 2.0F, 19, 5, 15, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 199, 0, -10.0F, -22.0F, 1.0F, 21, 3, 17, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 0, 78, -26.0F, -32.0F, 8.0F, 3, 1, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 24, 90, -25.0F, -31.0F, 8.0F, 2, 1, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 0, 17, 10.0F, -32.0F, 8.0F, 14, 3, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 21, 27, 24.0F, -32.0F, 8.0F, 3, 1, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 25, 69, 24.0F, -31.0F, 8.0F, 2, 1, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 169, 284, 0.0F, -32.0F, 17.0F, 2, 3, 14, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 0, 69, 0.0F, -32.0F, 31.0F, 2, 1, 3, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 0, 84, 0.0F, -31.0F, 31.0F, 2, 1, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 268, 127, 0.0F, -32.0F, -12.0F, 2, 3, 14, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 18, 61, 0.0F, -32.0F, -15.0F, 2, 1, 3, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 25, 61, 0.0F, -31.0F, -14.0F, 2, 1, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 0, 22, -23.0F, -32.0F, 8.0F, 14, 3, 2, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 140, 110, -6.0F, -14.0F, 5.0F, 13, 15, 8, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 278, 192, -6.0F, -11.0F, 13.0F, 13, 8, 4, 0.0F));
        wheelthing.cubeList.add(new ModelBox(wheelthing, 115, 224, -6.0F, -11.0F, 1.0F, 13, 8, 4, 0.0F));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(3.0F, -15.0F, 4.0F);
        wheelthing.addChild(cube_r1);
        setRotationAngle(cube_r1, 2.3126F, 0.0F, 0.0F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 275, 256, -9.0F, -5.0F, -5.0F, 13, 5, 4, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(3.0F, -10.0F, 10.0F);
        wheelthing.addChild(cube_r2);
        setRotationAngle(cube_r2, -2.2253F, 0.0F, 0.0F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 187, 284, -9.0F, -5.0F, -5.0F, 13, 5, 4, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(3.0F, 1.0F, 14.0F);
        wheelthing.addChild(cube_r3);
        setRotationAngle(cube_r3, -0.829F, 0.0F, 0.0F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 280, 144, -9.0F, -5.0F, -5.0F, 13, 6, 4, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(3.0F, -4.0F, 7.0F);
        wheelthing.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.829F, 0.0F, 0.0F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 241, 268, -9.0F, -4.0F, -5.0F, 13, 6, 4, 0.0F));

        spike1_r1 = new ModelRenderer(this);
        spike1_r1.setRotationPoint(-2.0F, -12.0F, 9.0F);
        wheelthing.addChild(spike1_r1);
        setRotationAngle(spike1_r1, 0.0F, -0.829F, 0.0F);
        spike1_r1.cubeList.add(new ModelBox(spike1_r1, 24, 87, 0.0F, -19.0F, 23.0F, 2, 1, 2, 0.0F));
        spike1_r1.cubeList.add(new ModelBox(spike1_r1, 18, 69, 0.0F, -20.0F, 23.0F, 2, 1, 3, 0.0F));
        spike1_r1.cubeList.add(new ModelBox(spike1_r1, 101, 77, 0.0F, -20.0F, 9.0F, 2, 3, 14, 0.0F));

        spike1_r2 = new ModelRenderer(this);
        spike1_r2.setRotationPoint(-24.0F, -12.0F, -12.0F);
        wheelthing.addChild(spike1_r2);
        setRotationAngle(spike1_r2, 0.0F, 0.7854F, 0.0F);
        spike1_r2.cubeList.add(new ModelBox(spike1_r2, 24, 30, 0.0F, -19.0F, 7.0F, 2, 1, 2, 0.0F));
        spike1_r2.cubeList.add(new ModelBox(spike1_r2, 0, 61, 0.0F, -20.0F, 6.0F, 2, 1, 3, 0.0F));
        spike1_r2.cubeList.add(new ModelBox(spike1_r2, 0, 0, 0.0F, -20.0F, 9.0F, 2, 3, 14, 0.0F));

        spike1_r3 = new ModelRenderer(this);
        spike1_r3.setRotationPoint(2.0F, -12.0F, 10.0F);
        wheelthing.addChild(spike1_r3);
        setRotationAngle(spike1_r3, 0.0F, 0.7854F, 0.0F);
        spike1_r3.cubeList.add(new ModelBox(spike1_r3, 0, 81, 0.0F, -19.0F, 23.0F, 2, 1, 2, 0.0F));
        spike1_r3.cubeList.add(new ModelBox(spike1_r3, 18, 65, 0.0F, -20.0F, 23.0F, 2, 1, 3, 0.0F));
        spike1_r3.cubeList.add(new ModelBox(spike1_r3, 0, 61, 0.0F, -20.0F, 9.0F, 2, 3, 14, 0.0F));

        spike1_r4 = new ModelRenderer(this);
        spike1_r4.setRotationPoint(24.0F, -12.0F, -14.0F);
        wheelthing.addChild(spike1_r4);
        setRotationAngle(spike1_r4, 0.0F, -0.7854F, 0.0F);
        spike1_r4.cubeList.add(new ModelBox(spike1_r4, 25, 65, 0.0F, -19.0F, 7.0F, 2, 1, 2, 0.0F));
        spike1_r4.cubeList.add(new ModelBox(spike1_r4, 0, 65, 0.0F, -20.0F, 6.0F, 2, 1, 3, 0.0F));
        spike1_r4.cubeList.add(new ModelBox(spike1_r4, 0, 147, 0.0F, -20.0F, 9.0F, 2, 3, 14, 0.0F));

        frontchest = new ModelRenderer(this);
        frontchest.setRotationPoint(0.0F, 0.0F, 0.0F);
        mainbody.addChild(frontchest);
        frontchest.cubeList.add(new ModelBox(frontchest, 35, 224, -14.0F, -42.0F, -6.0F, 32, 19, 3, 0.0F));
        frontchest.cubeList.add(new ModelBox(frontchest, 101, 61, -6.0F, -23.0F, -6.0F, 16, 13, 3, 0.0F));

        nails_r1 = new ModelRenderer(this);
        nails_r1.setRotationPoint(6.0F, -18.0F, 15.0F);
        frontchest.addChild(nails_r1);
        setRotationAngle(nails_r1, 1.0472F, 0.0F, 1.5708F);
        nails_r1.cubeList.add(new ModelBox(nails_r1, 207, 293, -12.0F, -39.0F, -2.0F, 2, 14, 1, 0.0F));

        nails_r2 = new ModelRenderer(this);
        nails_r2.setRotationPoint(-34.0F, -18.0F, -41.0F);
        frontchest.addChild(nails_r2);
        setRotationAngle(nails_r2, -1.0472F, 0.0F, 1.5708F);
        nails_r2.cubeList.add(new ModelBox(nails_r2, 294, 294, -12.0F, -39.0F, -2.0F, 2, 14, 1, 0.0F));

        nails_r3 = new ModelRenderer(this);
        nails_r3.setRotationPoint(9.0F, -18.0F, 18.0F);
        frontchest.addChild(nails_r3);
        setRotationAngle(nails_r3, 1.4835F, 0.0F, 1.5708F);
        nails_r3.cubeList.add(new ModelBox(nails_r3, 184, 239, -12.0F, -39.0F, -2.0F, 2, 14, 1, 0.0F));

        nails_r4 = new ModelRenderer(this);
        nails_r4.setRotationPoint(-11.0F, -18.0F, -46.0F);
        frontchest.addChild(nails_r4);
        setRotationAngle(nails_r4, -1.4835F, 0.0F, 1.5708F);
        nails_r4.cubeList.add(new ModelBox(nails_r4, 201, 293, -12.0F, -39.0F, -2.0F, 2, 14, 1, 0.0F));

        nails_r5 = new ModelRenderer(this);
        nails_r5.setRotationPoint(0.0F, -18.0F, -47.0F);
        frontchest.addChild(nails_r5);
        setRotationAngle(nails_r5, -1.5708F, 0.0F, 1.5708F);
        nails_r5.cubeList.add(new ModelBox(nails_r5, 0, 295, -12.0F, -39.0F, -2.0F, 2, 14, 1, 0.0F));

        metalcover_r1 = new ModelRenderer(this);
        metalcover_r1.setRotationPoint(-34.0F, -17.0F, -1.0F);
        frontchest.addChild(metalcover_r1);
        setRotationAngle(metalcover_r1, 0.0F, 0.0F, 1.5708F);
        metalcover_r1.cubeList.add(new ModelBox(metalcover_r1, 64, 281, -14.0F, -53.0F, -7.0F, 4, 34, 6, 0.0F));

        topnails_r1 = new ModelRenderer(this);
        topnails_r1.setRotationPoint(13.0F, -13.0F, 7.0F);
        frontchest.addChild(topnails_r1);
        setRotationAngle(topnails_r1, 0.3054F, 0.0F, 0.5672F);
        topnails_r1.cubeList.add(new ModelBox(topnails_r1, 92, 293, -12.0F, -44.0F, -5.0F, 2, 19, 2, 0.0F));

        topnails_r2 = new ModelRenderer(this);
        topnails_r2.setRotationPoint(9.0F, -14.0F, 7.0F);
        frontchest.addChild(topnails_r2);
        setRotationAngle(topnails_r2, 0.3054F, 0.0F, 0.4363F);
        topnails_r2.cubeList.add(new ModelBox(topnails_r2, 289, 9, -12.0F, -44.0F, -5.0F, 2, 19, 2, 0.0F));

        topnails_r3 = new ModelRenderer(this);
        topnails_r3.setRotationPoint(15.0F, -23.0F, 7.0F);
        frontchest.addChild(topnails_r3);
        setRotationAngle(topnails_r3, 0.3054F, 0.0F, -0.4363F);
        topnails_r3.cubeList.add(new ModelBox(topnails_r3, 84, 293, -12.0F, -44.0F, -5.0F, 2, 19, 2, 0.0F));

        topnails_r4 = new ModelRenderer(this);
        topnails_r4.setRotationPoint(11.0F, -23.0F, 8.0F);
        frontchest.addChild(topnails_r4);
        setRotationAngle(topnails_r4, 0.3054F, 0.0F, -0.5672F);
        topnails_r4.cubeList.add(new ModelBox(topnails_r4, 100, 293, -12.0F, -44.0F, -5.0F, 2, 19, 2, 0.0F));

        shoulderthings = new ModelRenderer(this);
        shoulderthings.setRotationPoint(0.0F, 0.0F, 0.0F);
        mainbody.addChild(shoulderthings);
        shoulderthings.cubeList.add(new ModelBox(shoulderthings, 224, 57, 28.0F, -49.0F, 4.0F, 5, 4, 25, 0.0F));
        shoulderthings.cubeList.add(new ModelBox(shoulderthings, 80, 224, 28.0F, -24.0F, 4.0F, 5, 4, 25, 0.0F));

        armconnection_r3 = new ModelRenderer(this);
        armconnection_r3.setRotationPoint(5.0F, -66.0F, 67.0F);
        shoulderthings.addChild(armconnection_r3);
        setRotationAngle(armconnection_r3, 2.1817F, 0.0F, 0.0F);
        armconnection_r3.cubeList.add(new ModelBox(armconnection_r3, 284, 268, 23.0F, -44.0F, 2.0F, 5, 3, 6, 0.0F));

        armconnection_r4 = new ModelRenderer(this);
        armconnection_r4.setRotationPoint(56.0F, 5.0F, -28.0F);
        shoulderthings.addChild(armconnection_r4);
        setRotationAngle(armconnection_r4, -2.1817F, 0.0F, -3.1416F);
        armconnection_r4.cubeList.add(new ModelBox(armconnection_r4, 284, 171, 23.0F, -44.0F, 2.0F, 5, 3, 6, 0.0F));

        armconnection_r5 = new ModelRenderer(this);
        armconnection_r5.setRotationPoint(56.0F, -3.0F, 67.0F);
        shoulderthings.addChild(armconnection_r5);
        setRotationAngle(armconnection_r5, 2.1817F, 0.0F, -3.1416F);
        armconnection_r5.cubeList.add(new ModelBox(armconnection_r5, 284, 180, 23.0F, -44.0F, 2.0F, 5, 3, 6, 0.0F));

        armconnection_r6 = new ModelRenderer(this);
        armconnection_r6.setRotationPoint(5.0F, -75.0F, -27.0F);
        shoulderthings.addChild(armconnection_r6);
        setRotationAngle(armconnection_r6, -2.1817F, 0.0F, 0.0F);
        armconnection_r6.cubeList.add(new ModelBox(armconnection_r6, 290, 154, 23.0F, -43.0F, 4.0F, 5, 3, 5, 0.0F));

        armconnection_r7 = new ModelRenderer(this);
        armconnection_r7.setRotationPoint(5.0F, -49.0F, -41.0F);
        shoulderthings.addChild(armconnection_r7);
        setRotationAngle(armconnection_r7, -1.5708F, 0.0F, 0.0F);
        armconnection_r7.cubeList.add(new ModelBox(armconnection_r7, 253, 168, 23.0F, -45.0F, 4.0F, 5, 3, 21, 0.0F));

        armconnection_r8 = new ModelRenderer(this);
        armconnection_r8.setRotationPoint(5.0F, -49.0F, -12.0F);
        shoulderthings.addChild(armconnection_r8);
        setRotationAngle(armconnection_r8, -1.5708F, 0.0F, 0.0F);
        armconnection_r8.cubeList.add(new ModelBox(armconnection_r8, 258, 11, 23.0F, -44.0F, 4.0F, 5, 3, 21, 0.0F));

        shoulderright = new ModelRenderer(this);
        shoulderright.setRotationPoint(-57.0F, 0.0F, 0.0F);
        shoulderthings.addChild(shoulderright);
        shoulderright.cubeList.add(new ModelBox(shoulderright, 218, 178, 28.0F, -49.0F, 4.0F, 5, 4, 25, 0.0F));
        shoulderright.cubeList.add(new ModelBox(shoulderright, 117, 0, 28.0F, -24.0F, 4.0F, 5, 4, 25, 0.0F));

        armconnection_r9 = new ModelRenderer(this);
        armconnection_r9.setRotationPoint(5.0F, -66.0F, 67.0F);
        shoulderright.addChild(armconnection_r9);
        setRotationAngle(armconnection_r9, 2.1817F, 0.0F, 0.0F);
        armconnection_r9.cubeList.add(new ModelBox(armconnection_r9, 218, 177, 23.0F, -44.0F, 2.0F, 5, 3, 6, 0.0F));

        armconnection_r10 = new ModelRenderer(this);
        armconnection_r10.setRotationPoint(56.0F, 5.0F, -28.0F);
        shoulderright.addChild(armconnection_r10);
        setRotationAngle(armconnection_r10, -2.1817F, 0.0F, -3.1416F);
        armconnection_r10.cubeList.add(new ModelBox(armconnection_r10, 253, 192, 23.0F, -44.0F, 2.0F, 5, 3, 6, 0.0F));

        armconnection_r11 = new ModelRenderer(this);
        armconnection_r11.setRotationPoint(56.0F, -3.0F, 67.0F);
        shoulderright.addChild(armconnection_r11);
        setRotationAngle(armconnection_r11, 2.1817F, 0.0F, -3.1416F);
        armconnection_r11.cubeList.add(new ModelBox(armconnection_r11, 265, 235, 23.0F, -44.0F, 2.0F, 5, 3, 6, 0.0F));

        armconnection_r12 = new ModelRenderer(this);
        armconnection_r12.setRotationPoint(5.0F, -75.0F, -27.0F);
        shoulderright.addChild(armconnection_r12);
        setRotationAngle(armconnection_r12, -2.1817F, 0.0F, 0.0F);
        armconnection_r12.cubeList.add(new ModelBox(armconnection_r12, 258, 9, 23.0F, -43.0F, 4.0F, 5, 3, 5, 0.0F));

        armconnection_r13 = new ModelRenderer(this);
        armconnection_r13.setRotationPoint(5.0F, -49.0F, -41.0F);
        shoulderright.addChild(armconnection_r13);
        setRotationAngle(armconnection_r13, -1.5708F, 0.0F, 0.0F);
        armconnection_r13.cubeList.add(new ModelBox(armconnection_r13, 172, 239, 23.0F, -45.0F, 4.0F, 5, 3, 21, 0.0F));

        armconnection_r14 = new ModelRenderer(this);
        armconnection_r14.setRotationPoint(5.0F, -49.0F, -12.0F);
        shoulderright.addChild(armconnection_r14);
        setRotationAngle(armconnection_r14, -1.5708F, 0.0F, 0.0F);
        armconnection_r14.cubeList.add(new ModelBox(armconnection_r14, 244, 244, 23.0F, -44.0F, 4.0F, 5, 3, 21, 0.0F));

        shoulderspikes = new ModelRenderer(this);
        shoulderspikes.setRotationPoint(0.0F, 0.0F, 0.0F);
        shoulderthings.addChild(shoulderspikes);
        shoulderspikes.cubeList.add(new ModelBox(shoulderspikes, 66, 246, 30.0F, -64.0F, 15.0F, 1, 15, 2, 0.0F));
        shoulderspikes.cubeList.add(new ModelBox(shoulderspikes, 60, 246, -27.0F, -64.0F, 15.0F, 1, 15, 2, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(31.0F, -46.0F, 30.0F);
        shoulderspikes.addChild(cube_r5);
        setRotationAngle(cube_r5, -1.0472F, 0.0F, 0.0F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 18, 0, -1.0F, -12.0F, -1.0F, 1, 12, 2, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 0, 0, -58.0F, -12.0F, -1.0F, 1, 12, 2, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(31.0F, -46.0F, 2.0F);
        shoulderspikes.addChild(cube_r6);
        setRotationAngle(cube_r6, 1.0472F, 0.0F, 0.0F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 24, 0, -1.0F, -12.0F, -1.0F, 1, 12, 2, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 6, 0, -58.0F, -12.0F, -1.0F, 1, 12, 2, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(31.0F, -48.0F, 8.0F);
        shoulderspikes.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.3491F, 0.0F, 0.0F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 230, 86, -1.0F, -13.0F, -1.0F, 1, 13, 2, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 149, 224, -58.0F, -13.0F, -1.0F, 1, 13, 2, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(31.0F, -48.0F, 25.0F);
        shoulderspikes.addChild(cube_r8);
        setRotationAngle(cube_r8, -0.3491F, 0.0F, 0.0F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 178, 239, -1.0F, -13.0F, -1.0F, 1, 13, 2, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 224, 86, -58.0F, -13.0F, -1.0F, 1, 13, 2, 0.0F));

        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 0.0F, 0.0F);
        shoulderspikes.addChild(bone);


        leftwrist = new ModelRenderer(this);
        leftwrist.setRotationPoint(70.0F, -19.0F, -37.0F);
        setRotationAngle(leftwrist, 0.0F, 0.0F, -0.3054F);


        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(4.0F, 12.0F, 14.0F);
        leftwrist.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.829F, 0.0F, 0.0F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 161, 162, -19.0F, -16.0F, 5.0F, 16, 16, 20, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 250, 168, -31.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 259, 78, 0.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 168, 263, -21.0F, -16.0F, 0.0F, 21, 16, 5, 0.0F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(1.0F, 12.0F, 14.0F);
        leftwrist.addChild(cube_r10);
        setRotationAngle(cube_r10, -0.7418F, 0.0F, 0.0F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 150, 45, -16.0F, -5.0F, 0.0F, 16, 6, 4, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(0.0F, -1.0F, -1.0F);
        leftwrist.addChild(cube_r11);
        setRotationAngle(cube_r11, -0.7418F, 0.0F, 0.0F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 234, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 21, 268, -14.0F, -5.0F, 0.0F, 14, 5, 4, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(1.0F, 22.0F, 23.0F);
        leftwrist.addChild(cube_r12);
        setRotationAngle(cube_r12, -0.7418F, 0.0F, 0.0F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 84, 281, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));

        lefthand = new ModelRenderer(this);
        lefthand.setRotationPoint(-55.0F, -1.0F, 22.0F);
        leftwrist.addChild(lefthand);
        setRotationAngle(lefthand, -0.6981F, 0.0F, 0.0F);
        lefthand.cubeList.add(new ModelBox(lefthand, 49, 147, 47.0F, 14.4734F, -17.0078F, 4, 14, 19, 0.0F));
        lefthand.cubeList.add(new ModelBox(lefthand, 0, 268, 46.0F, 14.4734F, -17.0078F, 1, 8, 19, 0.0F));

        thumn1_r1 = new ModelRenderer(this);
        thumn1_r1.setRotationPoint(49.0F, 5.0F, 7.0F);
        lefthand.addChild(thumn1_r1);
        setRotationAngle(thumn1_r1, -0.7418F, 0.0F, -0.0436F);
        thumn1_r1.cubeList.add(new ModelBox(thumn1_r1, 166, 0, -2.5005F, 22.9949F, -11.2192F, 4, 10, 4, 0.0F));

        thumn1_r2 = new ModelRenderer(this);
        thumn1_r2.setRotationPoint(49.0F, 12.0F, 2.0F);
        lefthand.addChild(thumn1_r2);
        setRotationAngle(thumn1_r2, 0.0436F, 0.0F, -0.0436F);
        thumn1_r2.cubeList.add(new ModelBox(thumn1_r2, 104, 253, -2.5005F, 9.448F, -25.4859F, 4, 7, 4, 0.0F));

        finger1_r1 = new ModelRenderer(this);
        finger1_r1.setRotationPoint(51.0F, 19.0F, 23.0F);
        lefthand.addChild(finger1_r1);
        setRotationAngle(finger1_r1, 0.0F, 0.0F, 0.0436F);
        finger1_r1.cubeList.add(new ModelBox(finger1_r1, 277, 86, -1.4995F, 19.4625F, -25.0078F, 4, 4, 4, 0.0F));
        finger1_r1.cubeList.add(new ModelBox(finger1_r1, 0, 276, -1.4995F, 19.4625F, -35.0078F, 4, 4, 4, 0.0F));
        finger1_r1.cubeList.add(new ModelBox(finger1_r1, 275, 244, -1.4995F, 19.4625F, -40.0078F, 4, 4, 4, 0.0F));
        finger1_r1.cubeList.add(new ModelBox(finger1_r1, 21, 277, -1.4995F, 19.4625F, -30.0078F, 4, 4, 4, 0.0F));

        finger1_r2 = new ModelRenderer(this);
        finger1_r2.setRotationPoint(49.0F, 18.0F, 18.0F);
        lefthand.addChild(finger1_r2);
        setRotationAngle(finger1_r2, 0.0F, 0.0F, -0.1745F);
        finger1_r2.cubeList.add(new ModelBox(finger1_r2, 210, 207, -3.9923F, 10.2991F, -25.0078F, 4, 10, 4, 0.0F));
        finger1_r2.cubeList.add(new ModelBox(finger1_r2, 199, 0, -3.9923F, 10.2991F, -35.0078F, 4, 10, 4, 0.0F));
        finger1_r2.cubeList.add(new ModelBox(finger1_r2, 158, 203, -3.9923F, 10.2991F, -30.0078F, 4, 10, 4, 0.0F));
        finger1_r2.cubeList.add(new ModelBox(finger1_r2, 253, 173, -3.9923F, 10.2991F, -20.0078F, 4, 10, 4, 0.0F));

        rightwrist = new ModelRenderer(this);
        rightwrist.setRotationPoint(-57.0F, -19.0F, -37.0F);


        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(8.0F, 12.0F, 14.0F);
        rightwrist.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.829F, 0.0F, 0.0F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 90, 2.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 90, -29.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));
        cube_r13.cubeList.add(new ModelBox(cube_r13, 259, 57, -19.0F, -16.0F, 0.0F, 21, 16, 5, 0.0F));
        cube_r13.cubeList.add(new ModelBox(cube_r13, 158, 203, -17.0F, -16.0F, 5.0F, 16, 16, 20, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(6.0F, -1.0F, -1.0F);
        rightwrist.addChild(cube_r14);
        setRotationAngle(cube_r14, -0.7418F, 0.0F, 0.0F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 258, 0, -14.0F, -5.0F, 0.0F, 14, 5, 4, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 224, 69, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(7.0F, 12.0F, 14.0F);
        rightwrist.addChild(cube_r15);
        setRotationAngle(cube_r15, -0.7418F, 0.0F, 0.0F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 186, 51, -14.0F, -5.0F, 0.0F, 14, 6, 4, 0.0F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(7.0F, 22.0F, 23.0F);
        rightwrist.addChild(cube_r16);
        setRotationAngle(cube_r16, -0.7418F, 0.0F, 0.0F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 115, 236, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));

        righthand = new ModelRenderer(this);
        righthand.setRotationPoint(-72.0F, 11.0F, 40.0F);
        setRotationAngle(righthand, 0.6981F, 3.1416F, 0.0F);
        righthand.cubeList.add(new ModelBox(righthand, 0, 98, -16.0F, 26.4734F, 60.0078F, 4, 14, 19, 0.0F));
        righthand.cubeList.add(new ModelBox(righthand, 220, 260, -17.0F, 26.4734F, 60.0078F, 1, 8, 19, 0.0F));

        thumn1_r3 = new ModelRenderer(this);
        thumn1_r3.setRotationPoint(-8.0F, 17.0F, 38.0F);
        righthand.addChild(thumn1_r3);
        setRotationAngle(thumn1_r3, 0.7418F, 0.0F, 0.0436F);
        thumn1_r3.cubeList.add(new ModelBox(thumn1_r3, 0, 98, -8.0972F, 34.2099F, 19.4418F, 4, 10, 4, 0.0F));

        thumn1_r4 = new ModelRenderer(this);
        thumn1_r4.setRotationPoint(-8.0F, 24.0F, 33.0F);
        righthand.addChild(thumn1_r4);
        setRotationAngle(thumn1_r4, -0.0436F, 0.0F, 0.0436F);
        thumn1_r4.cubeList.add(new ModelBox(thumn1_r4, 166, 14, -8.3695F, 8.5641F, 48.7723F, 4, 7, 4, 0.0F));

        finger1_r3 = new ModelRenderer(this);
        finger1_r3.setRotationPoint(-6.0F, 31.0F, 54.0F);
        righthand.addChild(finger1_r3);
        setRotationAngle(finger1_r3, 0.0F, 0.0F, 0.0436F);
        finger1_r3.cubeList.add(new ModelBox(finger1_r3, 14, 164, -7.4938F, 19.7242F, 21.0078F, 4, 4, 4, 0.0F));
        finger1_r3.cubeList.add(new ModelBox(finger1_r3, 174, 110, -7.4938F, 19.7242F, 11.0078F, 4, 4, 4, 0.0F));
        finger1_r3.cubeList.add(new ModelBox(finger1_r3, 0, 268, -7.4938F, 19.7242F, 6.0078F, 4, 4, 4, 0.0F));
        finger1_r3.cubeList.add(new ModelBox(finger1_r3, 220, 268, -7.4938F, 19.7242F, 16.0078F, 4, 4, 4, 0.0F));

        finger1_r4 = new ModelRenderer(this);
        finger1_r4.setRotationPoint(-8.0F, 30.0F, 49.0F);
        righthand.addChild(finger1_r4);
        setRotationAngle(finger1_r4, 0.0F, 0.0F, -0.1745F);
        finger1_r4.cubeList.add(new ModelBox(finger1_r4, 27, 98, -9.9012F, 9.2572F, 21.0078F, 4, 10, 4, 0.0F));
        finger1_r4.cubeList.add(new ModelBox(finger1_r4, 52, 98, -9.9012F, 9.2572F, 11.0078F, 4, 10, 4, 0.0F));
        finger1_r4.cubeList.add(new ModelBox(finger1_r4, 115, 98, -9.9012F, 9.2572F, 16.0078F, 4, 10, 4, 0.0F));
        finger1_r4.cubeList.add(new ModelBox(finger1_r4, 49, 147, -9.9012F, 9.2572F, 26.0078F, 4, 10, 4, 0.0F));

        leftforearm = new ModelRenderer(this);
        leftforearm.setRotationPoint(69.0F, -43.0F, -11.0F);
        setRotationAngle(leftforearm, 0.2182F, -0.5672F, -0.2182F);


        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(0.0F, 0.0F, 0.0F);
        leftforearm.addChild(cube_r17);
        setRotationAngle(cube_r17, -0.7418F, 0.0F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 222, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 218, 168, -14.0F, -5.0F, 0.0F, 14, 5, 4, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(7.0F, 13.0F, 15.0F);
        leftforearm.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.829F, 0.0F, 0.0F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 224, 106, -3.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 60, 253, -22.0F, -16.0F, -2.0F, 16, 16, 12, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 116, 259, -24.0F, -16.0F, 0.0F, 21, 16, 5, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 240, 235, -34.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(1.0F, 23.0F, 24.0F);
        leftforearm.addChild(cube_r19);
        setRotationAngle(cube_r19, -0.7418F, 0.0F, 0.0F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 224, 57, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(1.0F, 13.0F, 15.0F);
        leftforearm.addChild(cube_r20);
        setRotationAngle(cube_r20, -0.7418F, 0.0F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 52, 134, -16.0F, -5.0F, 0.0F, 16, 6, 4, 0.0F));

        leftforearm2 = new ModelRenderer(this);
        leftforearm2.setRotationPoint(-54.0F, -43.0F, -15.0F);
        setRotationAngle(leftforearm2, -0.2182F, 0.5672F, -0.2182F);


        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(0.0F, 0.0F, 0.0F);
        leftforearm2.addChild(cube_r21);
        setRotationAngle(cube_r21, -0.7418F, 0.0F, 0.0F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 0, 78, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 186, 146, -14.0F, -5.0F, 0.0F, 14, 5, 4, 0.0F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(7.0F, 13.0F, 15.0F);
        leftforearm2.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.829F, 0.0F, 0.0F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 0, 176, -3.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 240, 207, -22.0F, -16.0F, -2.0F, 16, 16, 12, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 249, 106, -24.0F, -16.0F, 0.0F, 21, 16, 5, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 222, 207, -34.0F, -9.0F, 1.0F, 10, 2, 2, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(1.0F, 23.0F, 24.0F);
        leftforearm2.addChild(cube_r23);
        setRotationAngle(cube_r23, -0.7418F, 0.0F, 0.0F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 164, -8.0F, -3.0F, -10.0F, 2, 2, 10, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(1.0F, 13.0F, 15.0F);
        leftforearm2.addChild(cube_r24);
        setRotationAngle(cube_r24, -0.7418F, 0.0F, 0.0F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 0, 131, -16.0F, -5.0F, 0.0F, 16, 6, 4, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        mainbody.render(f5);
        leftwrist.render(f5);
        rightwrist.render(f5);
        righthand.render(f5);
        leftforearm.render(f5);
        leftforearm2.render(f5);
    }
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch, float scaleFactor, Entity ent) {
        EntityLivingBase entity = ((EntityLivingBase) ent);

        if (entity.isSwingInProgress) {
            //    this.rightarm.rotateAngleX = MathHelper.sin(entity.swingProgress * 30 + (float) Math.PI) * 1.2F;
            this.righthand.rotateAngleY = MathHelper.sin(entity.swingProgress * 30 + (float) Math.PI) * -0.2F;
            //       this.rightarm.rotateAngleZ = -MathHelper.cos(entity.swingProgress * 40 + (float) Math.PI) * 0.5F;
        }
    }
    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public ModelRenderer getHandRenderer() {
        return righthand;
    }
}
