package xyz.pixelatedw.MineMineNoMi3.helpers;

import java.util.HashMap;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import xyz.pixelatedw.MineMineNoMi3.entities.zoan.EntityRendererZoanEyes;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.*;
import xyz.pixelatedw.MineMineNoMi3.renderers.entities.zoans.RenderMorphYomi;
import xyz.pixelatedw.MineMineNoMi3.renderers.entities.zoans.RenderZoanMorph;

public class MorphsHelper
{
	
	private static HashMap<String, Object[][]> morphsMap = new HashMap<String, Object[][]>();
	
	public static HashMap<String, Object[][]> getMorphsMap()
	{
		return morphsMap;
	}

	static
	{

		morphsMap.put("ushiushibison", new Object[][]
				{
						{
								"power",
								new RenderZoanMorph(new ModelBisonPower(), "bisonpower", 1.4, new float[] { 0, 0.7f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.6),
								null
						},
						{
								"speed",
								new RenderZoanMorph(new ModelBisonSpeed(), "bisonspeed", 1.4, new float[] { 0, 0.8f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), -0.3),
								null
						}
				});
		morphsMap.put("toritoriphoenix", new Object[][]
				{
						{
								"full",
								new RenderZoanMorph(new ModelPhoenixFull(), "phoenixfull", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
						{
								"hybrid",
								new RenderZoanMorph(new ModelPhoenixHybrid(), "phoenixhybrid", 1, new float[] { 0, 0.2f, 0 }),
								null,
								null
						}
				});

		morphsMap.put("ryuryu", new Object[][]
				{
						{
								"dragon",
								new RenderZoanMorph(new dragon(), "dragon", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("pteranodonryuryunomi", new Object[][]
				{
						{
								"ptera",
								new RenderZoanMorph(new smilodon(), "smilodon_male", 1.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});
		morphsMap.put("pteranodonryuryu", new Object[][]
				{
						{
								"ptera",
								new RenderZoanMorph(new smilodon(), "smilodon_male", 1.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("ryuryunomi", new Object[][]
				{
						{
								"dragon",
								new RenderZoanMorph(new dragon(), "dragon", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("budhabudhanomi", new Object[][]
				{
						{
								"buddha",
								new RenderZoanMorph(new buddha(), "goldensengoku", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("budhabudha", new Object[][]
				{
						{
								"buddha",
								new RenderZoanMorph(new buddha(), "goldensengoku", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});




		morphsMap.put("mochimochi", new Object[][]
				{
						{
								"wheel",
								new RenderZoanMorph(new mochi_wheel(), "mochi_wheel", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("mochimochinomi", new Object[][]
				{
						{
								"wheel",
								new RenderZoanMorph(new mochi_wheel(), "mochi_wheel", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("gomugomunomi", new Object[][]
				{
						{
								"luffy",
								new RenderZoanMorph(new luffy(), "luffy", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("gomugomu", new Object[][]
				{
						{
								"luffy",
								new RenderZoanMorph(new luffy(), "luffy", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});
		morphsMap.put("zouzou", new Object[][]
				{
						{
								"full",
								new RenderZoanMorph(new ModelZouFull(), "zoufull", 1.3, new float[] { 0, 0.65f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.3),
								null
						},
						{
								"hybrid",
								new RenderZoanMorph(new ModelZouHybrid(), "zouhybrid", 1.0, new float[] { 0, 0.2f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.8),
								null
						},
				});





		morphsMap.put("mamouthmamouth", new Object[][]
				{
						{
								"mamouth",
								new RenderZoanMorph(new ModelMammoth(), "mammothMale1", 1.3, new float[] { 0, 0.65f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.3),
								null
						},

				});

		morphsMap.put("bisubisunomi", new Object[][]
				{
						{
								"bisupoint",
								new RenderZoanMorph(new soldier(), "soldier1", 0.8, new float[] { 0, 0.65f, 0 }),
								null
						},

				});

		morphsMap.put("bisubisu", new Object[][]
				{
						{
								"bisupoint",
								new RenderZoanMorph(new soldier(), "soldier1", 0.8, new float[] { 0, 0.65f, 0 }),
								null
						},

				});

		morphsMap.put("mamouthmamouthnomi", new Object[][]
				{
						{
								"mamouth",
								new RenderZoanMorph(new ModelMammoth(), "mammothMale1", 1.3, new float[] { 0, 0.65f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.3),
								null
						},

				});

		morphsMap.put("dokudoku", new Object[][]
				{
						{
								"venomDemon",
								new RenderZoanMorph(new ModelVenomDemon(), "venomdemon", 1.1, new float[] { 0, 0.5f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 1.6),
								null
						},
				});
		morphsMap.put("yomiyomi", new Object[][]
				{
						{
								"yomi",
								new RenderMorphYomi(new ModelYomi(), "skeleton", 1.1, new float[] { 0, 0.3f, 0 }),
								null,
								new float[] {-0.25F, 0.6F, -0.05F}
						},
				});
		morphsMap.put("mogumogu", new Object[][]
				{
						{
								"power",
								new RenderZoanMorph(new ModelMoguPower(), "mogu", 0.9, new float[] { 0, 0.1f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), -0.2),
								null
						},
				});
		morphsMap.put("ushiushigiraffe", new Object[][]
				{
						{
								"power",
								new RenderZoanMorph(new ModelGiraffePower(), "giraffehybrid", 1.4, new float[] { 0, 0.7f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 1.8),
								null
						},
						{
								"speed",
								new RenderZoanMorph(new ModelGiraffeSpeed(), "giraffefull", 1.55, new float[] { 0, 0.95f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 1.9),
								null
						},
				});
		morphsMap.put("minimini", new Object[][]
				{
						{
								"mini",
								new RenderZoanMorph(new ModelBiped(), "$playerskin", 0.15, new float[] { 0, -0.9f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), -0.8),
								null
						},
				});

		morphsMap.put("nunu", new Object[][]
				{
						{
								"nue",
								new RenderZoanMorph(new nue(), "nue", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("hebihebinomi", new Object[][]
				{
						{
								"hebi",
								new RenderZoanMorph(new hdragon(), "hdragon", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("hebihebi", new Object[][]
				{
						{
								"hebi",
								new RenderZoanMorph(new hdragon(), "hdragon", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("santoryunomi", new Object[][]
				{
						{
								"pirate",
								new RenderZoanMorph(new Biped3swords(), "3sword", 1.0, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});



		morphsMap.put("smilodonryuryu", new Object[][]
				{
						{
								"pp",
								new RenderZoanMorph(new pteranodon(), "pteranodon", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("leopardleopard", new Object[][]
				{
						{
								"leopard",
								new RenderZoanMorph(new leopard(), "leopard", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
						{
								"hybridleopard",
								new RenderZoanMorph(new hybridleopard(), "leopardhybrid", 1, new float[] { 0, 0.2f, 0 }),
								null,
								null
						}
				});

		morphsMap.put("ushiushibisonawakened", new Object[][]
				{
						{
								"power",
								new RenderZoanMorph(new ModelBisonPower(), "bisonpower", 1.4, new float[] { 0, 0.7f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.6),
								null
						},
						{
								"speed",
								new RenderZoanMorph(new ModelBisonSpeed(), "bisonspeed", 1.4, new float[] { 0, 0.8f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), -0.3),
								null
						}
				});
		morphsMap.put("toritoriphoenixawakened", new Object[][]
				{
						{
								"full",
								new RenderZoanMorph(new ModelPhoenixFull(), "phoenixfull", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
						{
								"hybrid",
								new RenderZoanMorph(new ModelPhoenixHybrid(), "phoenixhybrid", 1, new float[] { 0, 0.2f, 0 }),
								null,
								null
						}
				});

		morphsMap.put("ryuryuawakened", new Object[][]
				{
						{
								"dragon",
								new RenderZoanMorph(new dragon(), "dragon", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("pteranodonryuryunomiawakened", new Object[][]
				{
						{
								"ptera",
								new RenderZoanMorph(new smilodon(), "smilodon_male", 1.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});
		morphsMap.put("pteranodonryuryuawakened", new Object[][]
				{
						{
								"ptera",
								new RenderZoanMorph(new smilodon(), "smilodon_male", 1.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("ryuryunomiawakened", new Object[][]
				{
						{
								"dragon",
								new RenderZoanMorph(new dragon(), "dragon", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("budhabudhanomiawakened", new Object[][]
				{
						{
								"buddha",
								new RenderZoanMorph(new buddha(), "goldensengoku", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("budhabudhaawakened", new Object[][]
				{
						{
								"buddha",
								new RenderZoanMorph(new buddha(), "goldensengoku", 0.7, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});




		morphsMap.put("mochimochiawakened", new Object[][]
				{
						{
								"wheel",
								new RenderZoanMorph(new mochi_wheel(), "mochi_wheel", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("mochimochinomiawakened", new Object[][]
				{
						{
								"wheel",
								new RenderZoanMorph(new mochi_wheel(), "mochi_wheel", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("gomugomunomiawakened", new Object[][]
				{
						{
								"luffy",
								new RenderZoanMorph(new luffy(), "luffy", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("gomugomuawakened", new Object[][]
				{
						{
								"luffy",
								new RenderZoanMorph(new luffy(), "luffy", 0.5, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});
		morphsMap.put("zouzouawakened", new Object[][]
				{
						{
								"full",
								new RenderZoanMorph(new ModelZouFull(), "zoufull", 1.3, new float[] { 0, 0.65f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.3),
								null
						},
						{
								"hybrid",
								new RenderZoanMorph(new ModelZouHybrid(), "zouhybrid", 1.0, new float[] { 0, 0.2f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.8),
								null
						},
				});





		morphsMap.put("mamouthmamouthawakened", new Object[][]
				{
						{
								"mamouth",
								new RenderZoanMorph(new ModelMammoth(), "mammothMale1", 1.3, new float[] { 0, 0.65f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.3),
								null
						},

				});

		morphsMap.put("bisubisunomiawakened", new Object[][]
				{
						{
								"bisupoint",
								new RenderZoanMorph(new soldier(), "soldier1", 0.8, new float[] { 0, 0.65f, 0 }),
								null
						},

				});

		morphsMap.put("bisubisuawakened", new Object[][]
				{
						{
								"bisupoint",
								new RenderZoanMorph(new soldier(), "soldier1", 0.8, new float[] { 0, 0.65f, 0 }),
								null
						},

				});

		morphsMap.put("mamouthmamouthnomiawakened", new Object[][]
				{
						{
								"mamouth",
								new RenderZoanMorph(new ModelMammoth(), "mammothMale1", 1.3, new float[] { 0, 0.65f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 0.3),
								null
						},

				});

		morphsMap.put("dokudokuawakened", new Object[][]
				{
						{
								"venomDemon",
								new RenderZoanMorph(new ModelVenomDemon(), "venomdemon", 1.1, new float[] { 0, 0.5f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 1.6),
								null
						},
				});
		morphsMap.put("yomiyomiawakened", new Object[][]
				{
						{
								"yomi",
								new RenderMorphYomi(new ModelYomi(), "skeleton", 1.1, new float[] { 0, 0.3f, 0 }),
								null,
								new float[] {-0.25F, 0.6F, -0.05F}
						},
				});
		morphsMap.put("mogumoguawakened", new Object[][]
				{
						{
								"power",
								new RenderZoanMorph(new ModelMoguPower(), "mogu", 0.9, new float[] { 0, 0.1f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), -0.2),
								null
						},
				});
		morphsMap.put("ushiushigiraffeawakened", new Object[][]
				{
						{
								"power",
								new RenderZoanMorph(new ModelGiraffePower(), "giraffehybrid", 1.4, new float[] { 0, 0.7f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 1.8),
								null
						},
						{
								"speed",
								new RenderZoanMorph(new ModelGiraffeSpeed(), "giraffefull", 1.55, new float[] { 0, 0.95f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), 1.9),
								null
						},
				});
		morphsMap.put("miniminiawakened", new Object[][]
				{
						{
								"mini",
								new RenderZoanMorph(new ModelBiped(), "$playerskin", 0.15, new float[] { 0, -0.9f, 0 }),
								new EntityRendererZoanEyes(Minecraft.getMinecraft(), -0.8),
								null
						},
				});

		morphsMap.put("nunuawakened", new Object[][]
				{
						{
								"nue",
								new RenderZoanMorph(new nue(), "nue", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("hebihebinomiawakened", new Object[][]
				{
						{
								"hebi",
								new RenderZoanMorph(new hdragon(), "hdragon", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("hebihebiawakened", new Object[][]
				{
						{
								"hebi",
								new RenderZoanMorph(new hdragon(), "hdragon", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("santoryunomiawakened", new Object[][]
				{
						{
								"pirate",
								new RenderZoanMorph(new Biped3swords(), "3sword", 1.0, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});



		morphsMap.put("smilodonryuryuawakened", new Object[][]
				{
						{
								"pp",
								new RenderZoanMorph(new pteranodon(), "pteranodon", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("leopardleopardawakened", new Object[][]
				{
						{
								"leopard",
								new RenderZoanMorph(new leopard(), "leopard", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
						{
								"hybridleopard",
								new RenderZoanMorph(new hybridleopard(), "leopardhybrid", 1, new float[] { 0, 0.2f, 0 }),
								null,
								null
						}
				});

		morphsMap.put("gorogoroawakened", new Object[][]
				{
						{
								"amaru",
								new RenderZoanMorph(new goro_amaru(), "goro_amaru", 0.9, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

		morphsMap.put("jishakujishakuawakened", new Object[][]
				{
						{
								"punk",
								new RenderZoanMorph(new punk_rotten(), "punk_rotten", 1.3, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});



		morphsMap.put("warawara", new Object[][]
				{
						{
								"goma",
								new RenderZoanMorph(new straw_man(), "straw_man", 1.0, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});
		morphsMap.put("warawaraawakened", new Object[][]
				{
						{
								"goma",
								new RenderZoanMorph(new straw_man(), "straw_man", 1.0, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});


		morphsMap.put("shiroshiro", new Object[][]
				{
						{
								"tank",
								new RenderZoanMorph(new tankmanfanal(), "tankmanfanal", 0.9, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});
		morphsMap.put("shiroshiroawakened", new Object[][]
				{
						{
								"tank",
								new RenderZoanMorph(new tankmanfanal(), "tankmanfanal", 0.9, new float[] { 0, 0.3f, 0 }),
								null,
								null
						},
				});

	}


	
}
