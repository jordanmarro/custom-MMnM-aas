package xyz.pixelatedw.MineMineNoMi3.helpers;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.ModelZoanMorph;

public class straw_man extends ModelZoanMorph {
    private final ModelRenderer group;
    private final ModelRenderer head;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer leg;
    private final ModelRenderer leftleg;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer rightleg;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer cube_r25;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer body;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer bone9;
    private final ModelRenderer arm;
    private final ModelRenderer rightarm;
    private final ModelRenderer cube_r36;
    private final ModelRenderer bone;
    private final ModelRenderer cube_r37;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer cube_r45;
    private final ModelRenderer cube_r46;
    private final ModelRenderer leftarm;
    private final ModelRenderer cube_r47;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r48;
    private final ModelRenderer cube_r49;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer cube_r52;
    private final ModelRenderer cube_r53;
    private final ModelRenderer cube_r54;
    private final ModelRenderer cube_r55;
    private final ModelRenderer cube_r56;
    private final ModelRenderer cube_r57;
    private final ModelRenderer bone3;
    private final ModelRenderer leftarm4;
    private final ModelRenderer cube_r58;
    private final ModelRenderer bone8;
    private final ModelRenderer cube_r59;
    private final ModelRenderer cube_r60;
    private final ModelRenderer cube_r61;
    private final ModelRenderer cube_r62;
    private final ModelRenderer cube_r63;
    private final ModelRenderer cube_r64;
    private final ModelRenderer cube_r65;
    private final ModelRenderer cube_r66;
    private final ModelRenderer cube_r67;
    private final ModelRenderer cube_r68;
    private final ModelRenderer leftarm2;
    private final ModelRenderer cube_r69;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r70;
    private final ModelRenderer cube_r71;
    private final ModelRenderer cube_r72;
    private final ModelRenderer cube_r73;
    private final ModelRenderer cube_r74;
    private final ModelRenderer cube_r75;
    private final ModelRenderer cube_r76;
    private final ModelRenderer cube_r77;
    private final ModelRenderer cube_r78;
    private final ModelRenderer cube_r79;
    private final ModelRenderer leftarm3;
    private final ModelRenderer cube_r80;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r81;
    private final ModelRenderer cube_r82;
    private final ModelRenderer cube_r83;
    private final ModelRenderer cube_r84;
    private final ModelRenderer cube_r85;
    private final ModelRenderer cube_r86;
    private final ModelRenderer cube_r87;
    private final ModelRenderer cube_r88;
    private final ModelRenderer cube_r89;
    private final ModelRenderer cube_r90;
    private final ModelRenderer bone6;
    private final ModelRenderer rightarm5;
    private final ModelRenderer cube_r91;
    private final ModelRenderer bone7;
    private final ModelRenderer cube_r92;
    private final ModelRenderer cube_r93;
    private final ModelRenderer cube_r94;
    private final ModelRenderer cube_r95;
    private final ModelRenderer cube_r96;
    private final ModelRenderer cube_r97;
    private final ModelRenderer cube_r98;
    private final ModelRenderer cube_r99;
    private final ModelRenderer cube_r100;
    private final ModelRenderer cube_r101;
    private final ModelRenderer rightarm6;
    private final ModelRenderer cube_r102;
    private final ModelRenderer bone10;
    private final ModelRenderer cube_r103;
    private final ModelRenderer cube_r104;
    private final ModelRenderer cube_r105;
    private final ModelRenderer cube_r106;
    private final ModelRenderer cube_r107;
    private final ModelRenderer cube_r108;
    private final ModelRenderer cube_r109;
    private final ModelRenderer cube_r110;
    private final ModelRenderer cube_r111;
    private final ModelRenderer cube_r112;
    private final ModelRenderer rightarm7;
    private final ModelRenderer cube_r113;
    private final ModelRenderer bone11;
    private final ModelRenderer cube_r114;
    private final ModelRenderer cube_r115;
    private final ModelRenderer cube_r116;
    private final ModelRenderer cube_r117;
    private final ModelRenderer cube_r118;
    private final ModelRenderer cube_r119;
    private final ModelRenderer cube_r120;
    private final ModelRenderer cube_r121;
    private final ModelRenderer cube_r122;
    private final ModelRenderer cube_r123;

    public straw_man() {
        textureWidth = 192;
        textureHeight = 192;

        group = new ModelRenderer(this);
        group.setRotationPoint(0.0F, 24.0F, 0.0F);


        head = new ModelRenderer(this);
        head.setRotationPoint(7.5F, -31.0F, -0.6F);
        group.addChild(head);
        head.cubeList.add(new ModelBox(head, 0, 121, -12.0F, -66.0F, -3.0F, 9, 11, 8, 0.02F));
        head.cubeList.add(new ModelBox(head, 34, 121, -12.0F, -65.0F, -3.0F, 9, 10, 8, 0.0F));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-2.3748F, -56.1666F, 0.8569F);
        head.addChild(cube_r1);
        setRotationAngle(cube_r1, -1.5708F, -0.2618F, 0.6981F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 77, -2.0F, -3.0F, 0.0F, 4, 6, 0, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(-12.6252F, -56.1666F, 0.8569F);
        head.addChild(cube_r2);
        setRotationAngle(cube_r2, -1.5708F, 0.2618F, -0.6981F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 79, 77, -2.0F, -3.0F, 0.0F, 4, 6, 0, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(-7.5F, -36.0F, -1.4F);
        head.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.0F, 0.0F, -0.0436F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 138, 111, 4.0F, -20.0F, 0.0F, 4, 20, 0, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(-7.5F, -36.0F, -1.4F);
        head.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.0F, 0.0F, 0.0436F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 20, 140, -8.0F, -20.0F, 0.0F, 4, 20, 0, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(0.0F, -1.5658F, 24.3937F);
        head.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.6109F, 0.0F, 0.0F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 0, 52, -32.0F, -14.0F, 5.0F, 49, 25, 0, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(0.0F, -2.0F, 19.6F);
        head.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.3054F, 0.0F, 0.0F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 0, -32.0F, -65.0F, 5.0F, 49, 52, 0, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(-7.5F, -61.542F, 6.4096F);
        head.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.3491F, 0.0F, 0.0F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 153, 70, -4.5F, -4.5F, -4.0F, 9, 10, 4, 0.0F));

        leg = new ModelRenderer(this);
        leg.setRotationPoint(0.0F, 0.0F, 6.0F);
        group.addChild(leg);


        leftleg = new ModelRenderer(this);
        leftleg.setRotationPoint(7.5F, -5.8882F, -7.7508F);
        leg.addChild(leftleg);
        setRotationAngle(leftleg, 0.0F, -0.4363F, 0.0F);
        leftleg.cubeList.add(new ModelBox(leftleg, 148, 138, -1.45F, 3.8882F, -0.2492F, 5, 2, 7, 0.0F));
        leftleg.cubeList.add(new ModelBox(leftleg, 168, 168, 0.55F, 5.0882F, -4.4492F, 1, 1, 5, 0.0F));
        leftleg.cubeList.add(new ModelBox(leftleg, 69, 163, -1.45F, 3.6882F, 1.7508F, 5, 2, 5, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(0.55F, -26.4118F, -0.3492F);
        leftleg.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.0873F, 0.0F, 0.0F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 123, 162, -2.0F, 9.3F, -0.6F, 5, 2, 5, -0.2F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(0.55F, 0.5882F, 3.4508F);
        leftleg.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.0873F, 0.0F, 0.0F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 163, 105, -2.0F, 1.5F, -2.0F, 5, 2, 5, -0.2F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 49, 158, -2.0F, -16.5F, -2.0F, 5, 19, 5, -0.1F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(1.05F, 6.0882F, -2.3302F);
        leftleg.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.0F, -0.0426F, 0.0F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 23, 168, 0.4764F, -1.0F, -2.0622F, 1, 1, 5, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(1.05F, 5.5882F, -2.3302F);
        leftleg.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.2184F, -0.0426F, -0.0094F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 14, 162, 0.4764F, -1.0F, -3.0622F, 1, 1, 6, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(1.05F, 6.0882F, -2.3302F);
        leftleg.addChild(cube_r12);
        setRotationAngle(cube_r12, 0.0F, -0.0852F, 0.0F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 35, 168, 1.4559F, -1.0F, -2.0918F, 1, 1, 5, 0.0F));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(1.05F, 5.5882F, -2.3302F);
        leftleg.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.219F, -0.0852F, -0.0189F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 89, 163, 1.4559F, -1.0F, -3.0918F, 1, 1, 6, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(1.05F, 5.5882F, -2.3302F);
        leftleg.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.2182F, 0.0F, 0.0F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 164, 40, -0.5F, -1.0F, -3.119F, 1, 1, 6, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(1.05F, 6.0882F, -2.3302F);
        leftleg.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.0F, 0.0426F, 0.0F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 168, 118, -1.4764F, -1.0F, -2.0622F, 1, 1, 5, 0.0F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(1.05F, 5.5882F, -2.3302F);
        leftleg.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.2184F, 0.0426F, 0.0094F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 164, 47, -1.4764F, -1.0F, -3.0622F, 1, 1, 6, 0.0F));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(1.05F, 6.0882F, -2.3302F);
        leftleg.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.0F, 0.0852F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 168, 112, -2.4559F, -1.0F, -2.0918F, 1, 1, 5, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(1.05F, 5.5882F, -2.3302F);
        leftleg.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.219F, 0.0852F, 0.0189F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 165, 132, -2.4559F, -1.0F, -3.0918F, 1, 1, 6, 0.0F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(0.55F, -12.0118F, 1.8508F);
        leftleg.addChild(cube_r19);
        setRotationAngle(cube_r19, -0.0873F, 0.0F, 0.0F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 29, 139, -1.9889F, -29.4641F, -2.4106F, 5, 24, 5, 0.0F));
        cube_r19.cubeList.add(new ModelBox(cube_r19, 128, 132, -1.9889F, -29.4641F, -2.4106F, 5, 25, 5, -0.1F));

        rightleg = new ModelRenderer(this);
        rightleg.setRotationPoint(-7.5F, -5.8882F, -7.7508F);
        leg.addChild(rightleg);
        setRotationAngle(rightleg, 0.0F, 0.4363F, 0.0F);
        rightleg.cubeList.add(new ModelBox(rightleg, 154, 24, -3.55F, 3.8882F, -0.2492F, 5, 2, 7, 0.0F));
        rightleg.cubeList.add(new ModelBox(rightleg, 163, 147, -1.55F, 5.0882F, -4.4492F, 1, 1, 5, 0.0F));
        rightleg.cubeList.add(new ModelBox(rightleg, 103, 162, -3.55F, 3.6882F, 1.7508F, 5, 2, 5, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(-0.55F, -26.4118F, -0.3492F);
        rightleg.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.0873F, 0.0F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 158, 91, -3.0F, 9.3F, -0.6F, 5, 2, 5, -0.2F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(-0.55F, 0.5882F, 3.4508F);
        rightleg.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.0873F, 0.0F, 0.0F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 158, 98, -3.0F, 1.5F, -2.0F, 5, 2, 5, -0.2F));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 154, 0, -3.0F, -16.5F, -2.0F, 5, 19, 5, -0.1F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(-1.05F, 6.0882F, -2.3302F);
        rightleg.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.0F, 0.0426F, 0.0F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 68, 126, -1.4764F, -1.0F, -2.0622F, 1, 1, 5, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(-1.05F, 5.5882F, -2.3302F);
        rightleg.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.2184F, 0.0426F, 0.0094F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 71, 77, -1.4764F, -1.0F, -3.0622F, 1, 1, 6, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(-1.05F, 6.0882F, -2.3302F);
        rightleg.addChild(cube_r24);
        setRotationAngle(cube_r24, 0.0F, 0.0852F, 0.0F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 154, 40, -2.4559F, -1.0F, -2.0918F, 1, 1, 5, 0.0F));

        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(-1.05F, 5.5882F, -2.3302F);
        rightleg.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.219F, 0.0852F, 0.0189F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 26, 121, -2.4559F, -1.0F, -3.0918F, 1, 1, 6, 0.0F));

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(-1.05F, 5.5882F, -2.3302F);
        rightleg.addChild(cube_r26);
        setRotationAngle(cube_r26, 0.2182F, 0.0F, 0.0F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 138, 70, -0.5F, -1.0F, -3.119F, 1, 1, 6, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(-1.05F, 6.0882F, -2.3302F);
        rightleg.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.0F, -0.0426F, 0.0F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 165, 139, 0.4764F, -1.0F, -2.0622F, 1, 1, 5, 0.0F));

        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(-1.05F, 5.5882F, -2.3302F);
        rightleg.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.2184F, -0.0426F, -0.0094F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 49, 139, 0.4764F, -1.0F, -3.0622F, 1, 1, 6, 0.0F));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(-1.05F, 6.0882F, -2.3302F);
        rightleg.addChild(cube_r29);
        setRotationAngle(cube_r29, 0.0F, -0.0852F, 0.0F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 0, 168, 1.4559F, -1.0F, -2.0918F, 1, 1, 5, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(-1.05F, 5.5882F, -2.3302F);
        rightleg.addChild(cube_r30);
        setRotationAngle(cube_r30, 0.219F, -0.0852F, -0.0189F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 49, 146, 1.4559F, -1.0F, -3.0918F, 1, 1, 6, 0.0F));

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(-0.55F, -12.0118F, 1.8508F);
        rightleg.addChild(cube_r31);
        setRotationAngle(cube_r31, -0.0873F, 0.0F, 0.0F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 138, 82, -3.0111F, -29.4641F, -2.4106F, 5, 24, 5, 0.0F));
        cube_r31.cubeList.add(new ModelBox(cube_r31, 108, 132, -3.0111F, -29.4641F, -2.4106F, 5, 25, 5, -0.1F));

        body = new ModelRenderer(this);
        body.setRotationPoint(0.0F, 0.0F, 0.0F);
        group.addChild(body);
        body.cubeList.add(new ModelBox(body, 98, 0, -10.0F, -86.0F, -1.6F, 20, 38, 8, 0.0F));
        body.cubeList.add(new ModelBox(body, 82, 82, -10.0F, -86.0F, -1.6F, 20, 42, 8, 0.5F));
        body.cubeList.add(new ModelBox(body, 90, 70, -10.0F, -48.0F, -1.6F, 20, 4, 8, 0.1F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(0.0F, -37.5F, -2.3F);
        body.addChild(cube_r32);
        setRotationAngle(cube_r32, -0.0873F, 0.0F, 0.0F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 66, 102, -4.0F, -11.5F, 0.0F, 8, 24, 0, 0.0F));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(0.5F, -14.0F, 28.4F);
        body.addChild(cube_r33);
        setRotationAngle(cube_r33, 0.2618F, 0.0F, 0.0F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 0, 77, -15.5F, -23.0F, -17.0F, 30, 14, 11, 0.5F));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(0.5F, -28.0F, 24.4F);
        body.addChild(cube_r34);
        setRotationAngle(cube_r34, 0.2618F, 0.0F, 0.0F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 98, 46, -14.5F, -23.0F, -17.0F, 28, 14, 10, 0.5F));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0.5F, -38.0F, 13.4F);
        body.addChild(cube_r35);
        setRotationAngle(cube_r35, 0.2618F, 0.0F, 0.0F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 0, 102, -12.5F, -21.0F, -9.0F, 24, 10, 9, 0.5F));

        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(19.3726F, -32.8997F, 23.0532F);
        body.addChild(bone9);


        arm = new ModelRenderer(this);
        arm.setRotationPoint(0.0F, 0.0F, 6.0F);
        group.addChild(arm);
        setRotationAngle(arm, 0.0873F, 0.0F, 0.0F);


        rightarm = new ModelRenderer(this);
        rightarm.setRotationPoint(-15.2F, -73.1399F, 4.9734F);
        arm.addChild(rightarm);


        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(0.0F, 0.0F, 0.0F);
        rightarm.addChild(cube_r36);
        setRotationAngle(cube_r36, 0.1309F, 0.0F, 0.48F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 0, 140, -2.0F, -12.25F, -3.0F, 5, 23, 5, 0.0F));
        cube_r36.cubeList.add(new ModelBox(cube_r36, 88, 132, -2.0F, -12.25F, -3.0F, 5, 26, 5, -0.1F));

        bone = new ModelRenderer(this);
        bone.setRotationPoint(-4.1913F, 33.5791F, -7.2758F);
        rightarm.addChild(bone);


        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.2261F, -0.0945F, -0.0873F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 4, 102, -3.0357F, 0.2673F, -1.7881F, 1, 4, 1, -0.1F));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.3131F, -0.0869F, 0.0876F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 26, 121, -2.818F, 0.7647F, -1.2481F, 1, 1, 1, -0.05F));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 61, 106, -2.7832F, -1.8252F, -1.2236F, 1, 3, 1, 0.0F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r39);
        setRotationAngle(cube_r39, -0.3054F, -0.0873F, 0.0F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 4, 121, -1.5926F, 0.6227F, -1.2928F, 1, 1, 1, -0.05F));
        cube_r39.cubeList.add(new ModelBox(cube_r39, 57, 106, -1.5926F, -1.9657F, -1.2679F, 1, 3, 1, 0.0F));
        cube_r39.cubeList.add(new ModelBox(cube_r39, 158, 84, -2.7285F, -3.4246F, -1.3078F, 5, 2, 5, -0.2F));
        cube_r39.cubeList.add(new ModelBox(cube_r39, 148, 111, -2.7285F, -25.013F, -1.2829F, 5, 22, 5, -0.1F));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r40);
        setRotationAngle(cube_r40, -0.3016F, -0.0872F, -0.0438F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 0, 121, -0.4175F, 0.6252F, -1.2921F, 1, 1, 1, -0.05F));
        cube_r40.cubeList.add(new ModelBox(cube_r40, 102, 50, -0.435F, -1.9636F, -1.2673F, 1, 3, 1, 0.0F));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r41);
        setRotationAngle(cube_r41, -0.2978F, -0.0869F, -0.0876F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 4, 109, 0.7651F, 0.6769F, -1.2758F, 1, 1, 1, -0.05F));
        cube_r41.cubeList.add(new ModelBox(cube_r41, 102, 46, 0.7302F, -1.913F, -1.2513F, 1, 3, 1, 0.0F));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r42);
        setRotationAngle(cube_r42, 0.2144F, -0.0834F, 0.0436F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 98, 51, -0.304F, 0.5174F, -1.8579F, 1, 4, 1, -0.1F));

        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r43);
        setRotationAngle(cube_r43, 0.2109F, -0.0793F, 0.0872F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 98, 46, 0.9827F, 0.3551F, -1.8158F, 1, 4, 1, -0.1F));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r44);
        setRotationAngle(cube_r44, 0.2182F, -0.0873F, 0.0F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 0, 102, -1.5926F, 0.5243F, -1.86F, 1, 4, 1, -0.1F));

        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r45);
        setRotationAngle(cube_r45, -0.0152F, -0.0859F, 0.1752F);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 98, 0, 2.2053F, 0.6312F, 0.3758F, 1, 4, 1, -0.1F));

        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone.addChild(cube_r46);
        setRotationAngle(cube_r46, 0.0263F, -0.0832F, -0.3065F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 0, 109, 1.5468F, 1.1651F, 0.3683F, 1, 1, 1, -0.05F));
        cube_r46.cubeList.add(new ModelBox(cube_r46, 102, 0, 1.55F, -1.2912F, 0.3928F, 1, 3, 1, 0.0F));

        leftarm = new ModelRenderer(this);
        leftarm.setRotationPoint(15.2F, -73.1399F, 4.9734F);
        arm.addChild(leftarm);


        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0.0F, 0.0F, 0.0F);
        leftarm.addChild(cube_r47);
        setRotationAngle(cube_r47, 0.1309F, 0.0F, -0.48F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 71, 172, -3.3548F, -5.4331F, -3.9759F, 6, 13, 7, -0.3F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 28, 184, -3.5322F, 6.4753F, -3.9638F, 6, 1, 7, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 28, 184, -3.4435F, 2.5211F, -3.9699F, 6, 1, 7, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 28, 184, -3.4435F, 0.5211F, -3.9699F, 6, 1, 7, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 28, 184, -3.4435F, -2.4789F, -3.9699F, 6, 1, 7, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 0, 177, -3.0F, -12.25F, -4.0F, 6, 8, 7, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 0, 140, -3.0F, -12.25F, -3.0F, 5, 23, 5, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 88, 132, -3.0F, -12.25F, -3.0F, 5, 26, 5, -0.1F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(4.1913F, 33.5791F, -7.2758F);
        leftarm.addChild(bone2);


        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r48);
        setRotationAngle(cube_r48, 0.2261F, 0.0945F, 0.0873F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 4, 102, 2.0357F, 0.2673F, -1.7881F, 1, 4, 1, -0.1F));

        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r49);
        setRotationAngle(cube_r49, -0.3131F, 0.0869F, -0.0876F);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 26, 121, 1.818F, 0.7647F, -1.2481F, 1, 1, 1, -0.05F));
        cube_r49.cubeList.add(new ModelBox(cube_r49, 61, 106, 1.7832F, -1.8252F, -1.2236F, 1, 3, 1, 0.0F));

        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r50);
        setRotationAngle(cube_r50, -0.3054F, 0.0873F, 0.0F);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 4, 121, 0.5926F, 0.6227F, -1.2928F, 1, 1, 1, -0.05F));
        cube_r50.cubeList.add(new ModelBox(cube_r50, 57, 106, 0.5926F, -1.9657F, -1.2679F, 1, 3, 1, 0.0F));
        cube_r50.cubeList.add(new ModelBox(cube_r50, 158, 84, -2.2715F, -3.4246F, -1.3078F, 5, 2, 5, -0.2F));
        cube_r50.cubeList.add(new ModelBox(cube_r50, 148, 111, -2.2715F, -25.013F, -1.2829F, 5, 22, 5, -0.1F));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r51);
        setRotationAngle(cube_r51, -0.3016F, 0.0872F, 0.0438F);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 0, 121, -0.5825F, 0.6252F, -1.2921F, 1, 1, 1, -0.05F));
        cube_r51.cubeList.add(new ModelBox(cube_r51, 102, 50, -0.565F, -1.9636F, -1.2673F, 1, 3, 1, 0.0F));

        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r52);
        setRotationAngle(cube_r52, -0.2978F, 0.0869F, 0.0876F);
        cube_r52.cubeList.add(new ModelBox(cube_r52, 4, 109, -1.7651F, 0.6769F, -1.2758F, 1, 1, 1, -0.05F));
        cube_r52.cubeList.add(new ModelBox(cube_r52, 102, 46, -1.7302F, -1.913F, -1.2513F, 1, 3, 1, 0.0F));

        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r53);
        setRotationAngle(cube_r53, 0.2144F, 0.0834F, -0.0436F);
        cube_r53.cubeList.add(new ModelBox(cube_r53, 98, 51, -0.696F, 0.5174F, -1.8579F, 1, 4, 1, -0.1F));

        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r54);
        setRotationAngle(cube_r54, 0.2109F, 0.0793F, -0.0872F);
        cube_r54.cubeList.add(new ModelBox(cube_r54, 98, 46, -1.9827F, 0.3551F, -1.8158F, 1, 4, 1, -0.1F));

        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r55);
        setRotationAngle(cube_r55, 0.2182F, 0.0873F, 0.0F);
        cube_r55.cubeList.add(new ModelBox(cube_r55, 0, 102, 0.5926F, 0.5243F, -1.86F, 1, 4, 1, -0.1F));

        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r56);
        setRotationAngle(cube_r56, -0.0152F, 0.0859F, -0.1752F);
        cube_r56.cubeList.add(new ModelBox(cube_r56, 98, 0, -3.2053F, 0.6312F, 0.3758F, 1, 4, 1, -0.1F));

        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r57);
        setRotationAngle(cube_r57, 0.0263F, 0.0832F, 0.3065F);
        cube_r57.cubeList.add(new ModelBox(cube_r57, 0, 109, -2.5468F, 1.1651F, 0.3683F, 1, 1, 1, -0.05F));
        cube_r57.cubeList.add(new ModelBox(cube_r57, 102, 0, -2.55F, -1.2912F, 0.3928F, 1, 3, 1, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(0.0F, 0.0F, 0.0F);
        arm.addChild(bone3);


        leftarm4 = new ModelRenderer(this);
        leftarm4.setRotationPoint(-3.7F, -50.5F, -2.3333F);
        bone3.addChild(leftarm4);
        setRotationAngle(leftarm4, 0.0F, 0.2618F, 2.0071F);


        cube_r58 = new ModelRenderer(this);
        cube_r58.setRotationPoint(18.717F, -40.0918F, 9.0642F);
        leftarm4.addChild(cube_r58);
        setRotationAngle(cube_r58, -0.3483F, -0.0114F, 0.9168F);
        cube_r58.cubeList.add(new ModelBox(cube_r58, 68, 132, 13.8013F, 9.7555F, 8.6793F, 5, 26, 5, -0.1F));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(21.6366F, -39.9152F, 9.1853F);
        leftarm4.addChild(bone8);
        setRotationAngle(bone8, 0.5672F, 0.0F, 0.3491F);


        cube_r59 = new ModelRenderer(this);
        cube_r59.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r59);
        setRotationAngle(cube_r59, 0.1584F, 0.0347F, 0.1971F);
        cube_r59.cubeList.add(new ModelBox(cube_r59, 71, 77, 14.2341F, -5.4082F, 5.7507F, 1, 4, 1, -0.1F));

        cube_r60 = new ModelRenderer(this);
        cube_r60.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r60);
        setRotationAngle(cube_r60, -0.3573F, 0.052F, 0.3707F);
        cube_r60.cubeList.add(new ModelBox(cube_r60, 4, 86, 13.4176F, -7.2421F, 3.4384F, 1, 1, 1, -0.05F));
        cube_r60.cubeList.add(new ModelBox(cube_r60, 61, 102, 13.3827F, -6.6522F, 3.414F, 1, 3, 1, 0.0F));

        cube_r61 = new ModelRenderer(this);
        cube_r61.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r61);
        setRotationAngle(cube_r61, -0.3616F, 0.0473F, 0.2835F);
        cube_r61.cubeList.add(new ModelBox(cube_r61, 86, 87, 12.5197F, -6.1204F, 3.7921F, 1, 1, 1, -0.05F));
        cube_r61.cubeList.add(new ModelBox(cube_r61, 57, 102, 12.5197F, -5.5319F, 3.7672F, 1, 3, 1, 0.0F));
        cube_r61.cubeList.add(new ModelBox(cube_r61, 154, 33, 9.6556F, -3.0731F, -0.193F, 5, 2, 5, -0.2F));
        cube_r61.cubeList.add(new ModelBox(cube_r61, 148, 148, 9.6556F, -1.4846F, -0.2179F, 5, 22, 5, -0.1F));

        cube_r62 = new ModelRenderer(this);
        cube_r62.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r62);
        setRotationAngle(cube_r62, -0.3636F, 0.0448F, 0.2399F);
        cube_r62.cubeList.add(new ModelBox(cube_r62, 102, 54, 11.4745F, -5.6237F, 3.9487F, 1, 1, 1, -0.05F));
        cube_r62.cubeList.add(new ModelBox(cube_r62, 101, 4, 11.4919F, -5.0349F, 3.9239F, 1, 3, 1, 0.0F));

        cube_r63 = new ModelRenderer(this);
        cube_r63.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r63);
        setRotationAngle(cube_r63, -0.3655F, 0.0422F, 0.1963F);
        cube_r63.cubeList.add(new ModelBox(cube_r63, 0, 107, 10.3988F, -5.1714F, 4.0913F, 1, 1, 1, -0.05F));
        cube_r63.cubeList.add(new ModelBox(cube_r63, 75, 84, 10.4336F, -4.5815F, 4.0668F, 1, 3, 1, 0.0F));

        cube_r64 = new ModelRenderer(this);
        cube_r64.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r64);
        setRotationAngle(cube_r64, 0.1642F, 0.0535F, 0.3267F);
        cube_r64.cubeList.add(new ModelBox(cube_r64, 7, 82, 11.0613F, -7.1558F, 6.2925F, 1, 4, 1, -0.1F));

        cube_r65 = new ModelRenderer(this);
        cube_r65.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r65);
        setRotationAngle(cube_r65, 0.1666F, 0.0596F, 0.37F);
        cube_r65.cubeList.add(new ModelBox(cube_r65, 0, 83, 9.5823F, -7.4788F, 6.4035F, 1, 4, 1, -0.1F));

        cube_r66 = new ModelRenderer(this);
        cube_r66.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r66);
        setRotationAngle(cube_r66, 0.162F, 0.0473F, 0.2835F);
        cube_r66.cubeList.add(new ModelBox(cube_r66, 82, 84, 12.5197F, -6.6698F, 6.1393F, 1, 4, 1, -0.1F));

        cube_r67 = new ModelRenderer(this);
        cube_r67.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r67);
        setRotationAngle(cube_r67, -0.0471F, 0.0563F, 0.458F);
        cube_r67.cubeList.add(new ModelBox(cube_r67, 86, 82, 7.9784F, -9.8904F, 3.314F, 1, 4, 1, -0.1F));

        cube_r68 = new ModelRenderer(this);
        cube_r68.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone8.addChild(cube_r68);
        setRotationAngle(cube_r68, -0.0678F, 0.0282F, -0.0216F);
        cube_r68.cubeList.add(new ModelBox(cube_r68, 4, 107, 9.8018F, -1.666F, 3.3214F, 1, 1, 1, -0.05F));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 71, 84, 9.7985F, -1.2097F, 3.297F, 1, 3, 1, 0.0F));

        leftarm2 = new ModelRenderer(this);
        leftarm2.setRotationPoint(-3.7F, -49.8899F, 4.64F);
        bone3.addChild(leftarm2);
        setRotationAngle(leftarm2, 0.829F, 0.2618F, 1.7453F);


        cube_r69 = new ModelRenderer(this);
        cube_r69.setRotationPoint(18.717F, -40.0918F, 9.0642F);
        leftarm2.addChild(cube_r69);
        setRotationAngle(cube_r69, -0.3483F, -0.0114F, 0.9168F);
        cube_r69.cubeList.add(new ModelBox(cube_r69, 68, 132, 13.8013F, 9.7555F, 8.6793F, 5, 26, 5, -0.1F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(21.6366F, -39.9152F, 9.1853F);
        leftarm2.addChild(bone4);
        setRotationAngle(bone4, 0.5672F, 0.0F, 0.3491F);


        cube_r70 = new ModelRenderer(this);
        cube_r70.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r70);
        setRotationAngle(cube_r70, 0.1584F, 0.0347F, 0.1971F);
        cube_r70.cubeList.add(new ModelBox(cube_r70, 71, 77, 14.2341F, -5.4082F, 5.7507F, 1, 4, 1, -0.1F));

        cube_r71 = new ModelRenderer(this);
        cube_r71.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r71);
        setRotationAngle(cube_r71, -0.3573F, 0.052F, 0.3707F);
        cube_r71.cubeList.add(new ModelBox(cube_r71, 4, 86, 13.4176F, -7.2421F, 3.4384F, 1, 1, 1, -0.05F));
        cube_r71.cubeList.add(new ModelBox(cube_r71, 61, 102, 13.3827F, -6.6522F, 3.414F, 1, 3, 1, 0.0F));

        cube_r72 = new ModelRenderer(this);
        cube_r72.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r72);
        setRotationAngle(cube_r72, -0.3616F, 0.0473F, 0.2835F);
        cube_r72.cubeList.add(new ModelBox(cube_r72, 86, 87, 12.5197F, -6.1204F, 3.7921F, 1, 1, 1, -0.05F));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 57, 102, 12.5197F, -5.5319F, 3.7672F, 1, 3, 1, 0.0F));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 154, 33, 9.6556F, -3.0731F, -0.193F, 5, 2, 5, -0.2F));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 148, 148, 9.6556F, -1.4846F, -0.2179F, 5, 22, 5, -0.1F));

        cube_r73 = new ModelRenderer(this);
        cube_r73.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r73);
        setRotationAngle(cube_r73, -0.3636F, 0.0448F, 0.2399F);
        cube_r73.cubeList.add(new ModelBox(cube_r73, 102, 54, 11.4745F, -5.6237F, 3.9487F, 1, 1, 1, -0.05F));
        cube_r73.cubeList.add(new ModelBox(cube_r73, 101, 4, 11.4919F, -5.0349F, 3.9239F, 1, 3, 1, 0.0F));

        cube_r74 = new ModelRenderer(this);
        cube_r74.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r74);
        setRotationAngle(cube_r74, -0.3655F, 0.0422F, 0.1963F);
        cube_r74.cubeList.add(new ModelBox(cube_r74, 0, 107, 10.3988F, -5.1714F, 4.0913F, 1, 1, 1, -0.05F));
        cube_r74.cubeList.add(new ModelBox(cube_r74, 75, 84, 10.4336F, -4.5815F, 4.0668F, 1, 3, 1, 0.0F));

        cube_r75 = new ModelRenderer(this);
        cube_r75.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r75);
        setRotationAngle(cube_r75, 0.1642F, 0.0535F, 0.3267F);
        cube_r75.cubeList.add(new ModelBox(cube_r75, 7, 82, 11.0613F, -7.1558F, 6.2925F, 1, 4, 1, -0.1F));

        cube_r76 = new ModelRenderer(this);
        cube_r76.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r76);
        setRotationAngle(cube_r76, 0.1666F, 0.0596F, 0.37F);
        cube_r76.cubeList.add(new ModelBox(cube_r76, 0, 83, 9.5823F, -7.4788F, 6.4035F, 1, 4, 1, -0.1F));

        cube_r77 = new ModelRenderer(this);
        cube_r77.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r77);
        setRotationAngle(cube_r77, 0.162F, 0.0473F, 0.2835F);
        cube_r77.cubeList.add(new ModelBox(cube_r77, 82, 84, 12.5197F, -6.6698F, 6.1393F, 1, 4, 1, -0.1F));

        cube_r78 = new ModelRenderer(this);
        cube_r78.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r78);
        setRotationAngle(cube_r78, -0.0471F, 0.0563F, 0.458F);
        cube_r78.cubeList.add(new ModelBox(cube_r78, 86, 82, 7.9784F, -9.8904F, 3.314F, 1, 4, 1, -0.1F));

        cube_r79 = new ModelRenderer(this);
        cube_r79.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone4.addChild(cube_r79);
        setRotationAngle(cube_r79, -0.0678F, 0.0282F, -0.0216F);
        cube_r79.cubeList.add(new ModelBox(cube_r79, 4, 107, 9.8018F, -1.666F, 3.3214F, 1, 1, 1, -0.05F));
        cube_r79.cubeList.add(new ModelBox(cube_r79, 71, 84, 9.7985F, -1.2097F, 3.297F, 1, 3, 1, 0.0F));

        leftarm3 = new ModelRenderer(this);
        leftarm3.setRotationPoint(-3.7F, -46.9013F, 4.3786F);
        bone3.addChild(leftarm3);
        setRotationAngle(leftarm3, 0.6109F, 0.2618F, 1.9199F);


        cube_r80 = new ModelRenderer(this);
        cube_r80.setRotationPoint(18.717F, -40.0918F, 9.0642F);
        leftarm3.addChild(cube_r80);
        setRotationAngle(cube_r80, -0.3483F, -0.0114F, 0.9168F);
        cube_r80.cubeList.add(new ModelBox(cube_r80, 68, 132, 13.8013F, 9.7555F, 8.6793F, 5, 26, 5, -0.1F));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(21.6366F, -39.9152F, 9.1853F);
        leftarm3.addChild(bone5);
        setRotationAngle(bone5, 0.5672F, 0.0F, 0.3491F);


        cube_r81 = new ModelRenderer(this);
        cube_r81.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r81);
        setRotationAngle(cube_r81, 0.1584F, 0.0347F, 0.1971F);
        cube_r81.cubeList.add(new ModelBox(cube_r81, 71, 77, 14.2341F, -5.4082F, 5.7507F, 1, 4, 1, -0.1F));

        cube_r82 = new ModelRenderer(this);
        cube_r82.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r82);
        setRotationAngle(cube_r82, -0.3573F, 0.052F, 0.3707F);
        cube_r82.cubeList.add(new ModelBox(cube_r82, 4, 86, 13.4176F, -7.2421F, 3.4384F, 1, 1, 1, -0.05F));
        cube_r82.cubeList.add(new ModelBox(cube_r82, 61, 102, 13.3827F, -6.6522F, 3.414F, 1, 3, 1, 0.0F));

        cube_r83 = new ModelRenderer(this);
        cube_r83.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r83);
        setRotationAngle(cube_r83, -0.3616F, 0.0473F, 0.2835F);
        cube_r83.cubeList.add(new ModelBox(cube_r83, 86, 87, 12.5197F, -6.1204F, 3.7921F, 1, 1, 1, -0.05F));
        cube_r83.cubeList.add(new ModelBox(cube_r83, 57, 102, 12.5197F, -5.5319F, 3.7672F, 1, 3, 1, 0.0F));
        cube_r83.cubeList.add(new ModelBox(cube_r83, 154, 33, 9.6556F, -3.0731F, -0.193F, 5, 2, 5, -0.2F));
        cube_r83.cubeList.add(new ModelBox(cube_r83, 148, 148, 9.6556F, -1.4846F, -0.2179F, 5, 22, 5, -0.1F));

        cube_r84 = new ModelRenderer(this);
        cube_r84.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r84);
        setRotationAngle(cube_r84, -0.3636F, 0.0448F, 0.2399F);
        cube_r84.cubeList.add(new ModelBox(cube_r84, 102, 54, 11.4745F, -5.6237F, 3.9487F, 1, 1, 1, -0.05F));
        cube_r84.cubeList.add(new ModelBox(cube_r84, 101, 4, 11.4919F, -5.0349F, 3.9239F, 1, 3, 1, 0.0F));

        cube_r85 = new ModelRenderer(this);
        cube_r85.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r85);
        setRotationAngle(cube_r85, -0.3655F, 0.0422F, 0.1963F);
        cube_r85.cubeList.add(new ModelBox(cube_r85, 0, 107, 10.3988F, -5.1714F, 4.0913F, 1, 1, 1, -0.05F));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 75, 84, 10.4336F, -4.5815F, 4.0668F, 1, 3, 1, 0.0F));

        cube_r86 = new ModelRenderer(this);
        cube_r86.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r86);
        setRotationAngle(cube_r86, 0.1642F, 0.0535F, 0.3267F);
        cube_r86.cubeList.add(new ModelBox(cube_r86, 7, 82, 11.0613F, -7.1558F, 6.2925F, 1, 4, 1, -0.1F));

        cube_r87 = new ModelRenderer(this);
        cube_r87.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r87);
        setRotationAngle(cube_r87, 0.1666F, 0.0596F, 0.37F);
        cube_r87.cubeList.add(new ModelBox(cube_r87, 0, 83, 9.5823F, -7.4788F, 6.4035F, 1, 4, 1, -0.1F));

        cube_r88 = new ModelRenderer(this);
        cube_r88.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r88);
        setRotationAngle(cube_r88, 0.162F, 0.0473F, 0.2835F);
        cube_r88.cubeList.add(new ModelBox(cube_r88, 82, 84, 12.5197F, -6.6698F, 6.1393F, 1, 4, 1, -0.1F));

        cube_r89 = new ModelRenderer(this);
        cube_r89.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r89);
        setRotationAngle(cube_r89, -0.0471F, 0.0563F, 0.458F);
        cube_r89.cubeList.add(new ModelBox(cube_r89, 86, 82, 7.9784F, -9.8904F, 3.314F, 1, 4, 1, -0.1F));

        cube_r90 = new ModelRenderer(this);
        cube_r90.setRotationPoint(-2.8039F, 0.6371F, -0.5495F);
        bone5.addChild(cube_r90);
        setRotationAngle(cube_r90, -0.0678F, 0.0282F, -0.0216F);
        cube_r90.cubeList.add(new ModelBox(cube_r90, 4, 107, 9.8018F, -1.666F, 3.3214F, 1, 1, 1, -0.05F));
        cube_r90.cubeList.add(new ModelBox(cube_r90, 71, 84, 9.7985F, -1.2097F, 3.297F, 1, 3, 1, 0.0F));

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(0.0F, 0.0F, 0.0F);
        arm.addChild(bone6);


        rightarm5 = new ModelRenderer(this);
        rightarm5.setRotationPoint(3.7F, -50.5F, -2.3333F);
        bone6.addChild(rightarm5);
        setRotationAngle(rightarm5, 0.0F, -0.2618F, -2.0071F);


        cube_r91 = new ModelRenderer(this);
        cube_r91.setRotationPoint(-18.717F, -40.0918F, 9.0642F);
        rightarm5.addChild(cube_r91);
        setRotationAngle(cube_r91, -0.3483F, 0.0114F, -0.9168F);
        cube_r91.cubeList.add(new ModelBox(cube_r91, 68, 132, -18.8013F, 9.7555F, 8.6793F, 5, 26, 5, -0.1F));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(-21.6366F, -39.9152F, 9.1853F);
        rightarm5.addChild(bone7);
        setRotationAngle(bone7, 0.5672F, 0.0F, -0.3491F);


        cube_r92 = new ModelRenderer(this);
        cube_r92.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r92);
        setRotationAngle(cube_r92, 0.1584F, -0.0347F, -0.1971F);
        cube_r92.cubeList.add(new ModelBox(cube_r92, 71, 77, -15.2341F, -5.4082F, 5.7507F, 1, 4, 1, -0.1F));

        cube_r93 = new ModelRenderer(this);
        cube_r93.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r93);
        setRotationAngle(cube_r93, -0.3573F, -0.052F, -0.3707F);
        cube_r93.cubeList.add(new ModelBox(cube_r93, 4, 86, -14.4176F, -7.2421F, 3.4384F, 1, 1, 1, -0.05F));
        cube_r93.cubeList.add(new ModelBox(cube_r93, 61, 102, -14.3827F, -6.6522F, 3.414F, 1, 3, 1, 0.0F));

        cube_r94 = new ModelRenderer(this);
        cube_r94.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r94);
        setRotationAngle(cube_r94, -0.3616F, -0.0473F, -0.2835F);
        cube_r94.cubeList.add(new ModelBox(cube_r94, 86, 87, -13.5197F, -6.1204F, 3.7921F, 1, 1, 1, -0.05F));
        cube_r94.cubeList.add(new ModelBox(cube_r94, 57, 102, -13.5197F, -5.5319F, 3.7672F, 1, 3, 1, 0.0F));
        cube_r94.cubeList.add(new ModelBox(cube_r94, 154, 33, -14.6556F, -3.0731F, -0.193F, 5, 2, 5, -0.2F));
        cube_r94.cubeList.add(new ModelBox(cube_r94, 148, 148, -14.6556F, -1.4846F, -0.2179F, 5, 22, 5, -0.1F));

        cube_r95 = new ModelRenderer(this);
        cube_r95.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r95);
        setRotationAngle(cube_r95, -0.3636F, -0.0448F, -0.2399F);
        cube_r95.cubeList.add(new ModelBox(cube_r95, 102, 54, -12.4745F, -5.6237F, 3.9487F, 1, 1, 1, -0.05F));
        cube_r95.cubeList.add(new ModelBox(cube_r95, 101, 4, -12.4919F, -5.0349F, 3.9239F, 1, 3, 1, 0.0F));

        cube_r96 = new ModelRenderer(this);
        cube_r96.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r96);
        setRotationAngle(cube_r96, -0.3655F, -0.0422F, -0.1963F);
        cube_r96.cubeList.add(new ModelBox(cube_r96, 0, 107, -11.3988F, -5.1714F, 4.0913F, 1, 1, 1, -0.05F));
        cube_r96.cubeList.add(new ModelBox(cube_r96, 75, 84, -11.4336F, -4.5815F, 4.0668F, 1, 3, 1, 0.0F));

        cube_r97 = new ModelRenderer(this);
        cube_r97.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r97);
        setRotationAngle(cube_r97, 0.1642F, -0.0535F, -0.3267F);
        cube_r97.cubeList.add(new ModelBox(cube_r97, 7, 82, -12.0613F, -7.1558F, 6.2925F, 1, 4, 1, -0.1F));

        cube_r98 = new ModelRenderer(this);
        cube_r98.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r98);
        setRotationAngle(cube_r98, 0.1666F, -0.0596F, -0.37F);
        cube_r98.cubeList.add(new ModelBox(cube_r98, 0, 83, -10.5823F, -7.4788F, 6.4035F, 1, 4, 1, -0.1F));

        cube_r99 = new ModelRenderer(this);
        cube_r99.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r99);
        setRotationAngle(cube_r99, 0.162F, -0.0473F, -0.2835F);
        cube_r99.cubeList.add(new ModelBox(cube_r99, 82, 84, -13.5197F, -6.6698F, 6.1393F, 1, 4, 1, -0.1F));

        cube_r100 = new ModelRenderer(this);
        cube_r100.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r100);
        setRotationAngle(cube_r100, -0.0471F, -0.0563F, -0.458F);
        cube_r100.cubeList.add(new ModelBox(cube_r100, 86, 82, -8.9784F, -9.8904F, 3.314F, 1, 4, 1, -0.1F));

        cube_r101 = new ModelRenderer(this);
        cube_r101.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone7.addChild(cube_r101);
        setRotationAngle(cube_r101, -0.0678F, -0.0282F, 0.0216F);
        cube_r101.cubeList.add(new ModelBox(cube_r101, 4, 107, -10.8018F, -1.666F, 3.3214F, 1, 1, 1, -0.05F));
        cube_r101.cubeList.add(new ModelBox(cube_r101, 71, 84, -10.7985F, -1.2097F, 3.297F, 1, 3, 1, 0.0F));

        rightarm6 = new ModelRenderer(this);
        rightarm6.setRotationPoint(3.7F, -48.8937F, 4.5529F);
        bone6.addChild(rightarm6);
        setRotationAngle(rightarm6, 0.829F, -0.2618F, -1.7453F);


        cube_r102 = new ModelRenderer(this);
        cube_r102.setRotationPoint(-18.717F, -40.0918F, 9.0642F);
        rightarm6.addChild(cube_r102);
        setRotationAngle(cube_r102, -0.3483F, 0.0114F, -0.9168F);
        cube_r102.cubeList.add(new ModelBox(cube_r102, 68, 132, -18.8013F, 9.7555F, 8.6793F, 5, 26, 5, -0.1F));

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(-21.6366F, -39.9152F, 9.1853F);
        rightarm6.addChild(bone10);
        setRotationAngle(bone10, 0.5672F, 0.0F, -0.3491F);


        cube_r103 = new ModelRenderer(this);
        cube_r103.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r103);
        setRotationAngle(cube_r103, 0.1584F, -0.0347F, -0.1971F);
        cube_r103.cubeList.add(new ModelBox(cube_r103, 71, 77, -15.2341F, -5.4082F, 5.7507F, 1, 4, 1, -0.1F));

        cube_r104 = new ModelRenderer(this);
        cube_r104.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r104);
        setRotationAngle(cube_r104, -0.3573F, -0.052F, -0.3707F);
        cube_r104.cubeList.add(new ModelBox(cube_r104, 4, 86, -14.4176F, -7.2421F, 3.4384F, 1, 1, 1, -0.05F));
        cube_r104.cubeList.add(new ModelBox(cube_r104, 61, 102, -14.3827F, -6.6522F, 3.414F, 1, 3, 1, 0.0F));

        cube_r105 = new ModelRenderer(this);
        cube_r105.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r105);
        setRotationAngle(cube_r105, -0.3616F, -0.0473F, -0.2835F);
        cube_r105.cubeList.add(new ModelBox(cube_r105, 86, 87, -13.5197F, -6.1204F, 3.7921F, 1, 1, 1, -0.05F));
        cube_r105.cubeList.add(new ModelBox(cube_r105, 57, 102, -13.5197F, -5.5319F, 3.7672F, 1, 3, 1, 0.0F));
        cube_r105.cubeList.add(new ModelBox(cube_r105, 154, 33, -14.6556F, -3.0731F, -0.193F, 5, 2, 5, -0.2F));
        cube_r105.cubeList.add(new ModelBox(cube_r105, 148, 148, -14.6556F, -1.4846F, -0.2179F, 5, 22, 5, -0.1F));

        cube_r106 = new ModelRenderer(this);
        cube_r106.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r106);
        setRotationAngle(cube_r106, -0.3636F, -0.0448F, -0.2399F);
        cube_r106.cubeList.add(new ModelBox(cube_r106, 102, 54, -12.4745F, -5.6237F, 3.9487F, 1, 1, 1, -0.05F));
        cube_r106.cubeList.add(new ModelBox(cube_r106, 101, 4, -12.4919F, -5.0349F, 3.9239F, 1, 3, 1, 0.0F));

        cube_r107 = new ModelRenderer(this);
        cube_r107.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r107);
        setRotationAngle(cube_r107, -0.3655F, -0.0422F, -0.1963F);
        cube_r107.cubeList.add(new ModelBox(cube_r107, 0, 107, -11.3988F, -5.1714F, 4.0913F, 1, 1, 1, -0.05F));
        cube_r107.cubeList.add(new ModelBox(cube_r107, 75, 84, -11.4336F, -4.5815F, 4.0668F, 1, 3, 1, 0.0F));

        cube_r108 = new ModelRenderer(this);
        cube_r108.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r108);
        setRotationAngle(cube_r108, 0.1642F, -0.0535F, -0.3267F);
        cube_r108.cubeList.add(new ModelBox(cube_r108, 7, 82, -12.0613F, -7.1558F, 6.2925F, 1, 4, 1, -0.1F));

        cube_r109 = new ModelRenderer(this);
        cube_r109.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r109);
        setRotationAngle(cube_r109, 0.1666F, -0.0596F, -0.37F);
        cube_r109.cubeList.add(new ModelBox(cube_r109, 0, 83, -10.5823F, -7.4788F, 6.4035F, 1, 4, 1, -0.1F));

        cube_r110 = new ModelRenderer(this);
        cube_r110.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r110);
        setRotationAngle(cube_r110, 0.162F, -0.0473F, -0.2835F);
        cube_r110.cubeList.add(new ModelBox(cube_r110, 82, 84, -13.5197F, -6.6698F, 6.1393F, 1, 4, 1, -0.1F));

        cube_r111 = new ModelRenderer(this);
        cube_r111.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r111);
        setRotationAngle(cube_r111, -0.0471F, -0.0563F, -0.458F);
        cube_r111.cubeList.add(new ModelBox(cube_r111, 86, 82, -8.9784F, -9.8904F, 3.314F, 1, 4, 1, -0.1F));

        cube_r112 = new ModelRenderer(this);
        cube_r112.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone10.addChild(cube_r112);
        setRotationAngle(cube_r112, -0.0678F, -0.0282F, 0.0216F);
        cube_r112.cubeList.add(new ModelBox(cube_r112, 4, 107, -10.8018F, -1.666F, 3.3214F, 1, 1, 1, -0.05F));
        cube_r112.cubeList.add(new ModelBox(cube_r112, 71, 84, -10.7985F, -1.2097F, 3.297F, 1, 3, 1, 0.0F));

        rightarm7 = new ModelRenderer(this);
        rightarm7.setRotationPoint(3.7F, -46.9013F, 4.3786F);
        bone6.addChild(rightarm7);
        setRotationAngle(rightarm7, 0.6109F, -0.2618F, -1.9199F);


        cube_r113 = new ModelRenderer(this);
        cube_r113.setRotationPoint(-18.717F, -40.0918F, 9.0642F);
        rightarm7.addChild(cube_r113);
        setRotationAngle(cube_r113, -0.3483F, 0.0114F, -0.9168F);
        cube_r113.cubeList.add(new ModelBox(cube_r113, 68, 132, -18.8013F, 9.7555F, 8.6793F, 5, 26, 5, -0.1F));

        bone11 = new ModelRenderer(this);
        bone11.setRotationPoint(-21.6366F, -39.9152F, 9.1853F);
        rightarm7.addChild(bone11);
        setRotationAngle(bone11, 0.5672F, 0.0F, -0.3491F);


        cube_r114 = new ModelRenderer(this);
        cube_r114.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r114);
        setRotationAngle(cube_r114, 0.1584F, -0.0347F, -0.1971F);
        cube_r114.cubeList.add(new ModelBox(cube_r114, 71, 77, -15.2341F, -5.4082F, 5.7507F, 1, 4, 1, -0.1F));

        cube_r115 = new ModelRenderer(this);
        cube_r115.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r115);
        setRotationAngle(cube_r115, -0.3573F, -0.052F, -0.3707F);
        cube_r115.cubeList.add(new ModelBox(cube_r115, 4, 86, -14.4176F, -7.2421F, 3.4384F, 1, 1, 1, -0.05F));
        cube_r115.cubeList.add(new ModelBox(cube_r115, 61, 102, -14.3827F, -6.6522F, 3.414F, 1, 3, 1, 0.0F));

        cube_r116 = new ModelRenderer(this);
        cube_r116.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r116);
        setRotationAngle(cube_r116, -0.3616F, -0.0473F, -0.2835F);
        cube_r116.cubeList.add(new ModelBox(cube_r116, 86, 87, -13.5197F, -6.1204F, 3.7921F, 1, 1, 1, -0.05F));
        cube_r116.cubeList.add(new ModelBox(cube_r116, 57, 102, -13.5197F, -5.5319F, 3.7672F, 1, 3, 1, 0.0F));
        cube_r116.cubeList.add(new ModelBox(cube_r116, 154, 33, -14.6556F, -3.0731F, -0.193F, 5, 2, 5, -0.2F));
        cube_r116.cubeList.add(new ModelBox(cube_r116, 148, 148, -14.6556F, -1.4846F, -0.2179F, 5, 22, 5, -0.1F));

        cube_r117 = new ModelRenderer(this);
        cube_r117.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r117);
        setRotationAngle(cube_r117, -0.3636F, -0.0448F, -0.2399F);
        cube_r117.cubeList.add(new ModelBox(cube_r117, 102, 54, -12.4745F, -5.6237F, 3.9487F, 1, 1, 1, -0.05F));
        cube_r117.cubeList.add(new ModelBox(cube_r117, 101, 4, -12.4919F, -5.0349F, 3.9239F, 1, 3, 1, 0.0F));

        cube_r118 = new ModelRenderer(this);
        cube_r118.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r118);
        setRotationAngle(cube_r118, -0.3655F, -0.0422F, -0.1963F);
        cube_r118.cubeList.add(new ModelBox(cube_r118, 0, 107, -11.3988F, -5.1714F, 4.0913F, 1, 1, 1, -0.05F));
        cube_r118.cubeList.add(new ModelBox(cube_r118, 75, 84, -11.4336F, -4.5815F, 4.0668F, 1, 3, 1, 0.0F));

        cube_r119 = new ModelRenderer(this);
        cube_r119.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r119);
        setRotationAngle(cube_r119, 0.1642F, -0.0535F, -0.3267F);
        cube_r119.cubeList.add(new ModelBox(cube_r119, 7, 82, -12.0613F, -7.1558F, 6.2925F, 1, 4, 1, -0.1F));

        cube_r120 = new ModelRenderer(this);
        cube_r120.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r120);
        setRotationAngle(cube_r120, 0.1666F, -0.0596F, -0.37F);
        cube_r120.cubeList.add(new ModelBox(cube_r120, 0, 83, -10.5823F, -7.4788F, 6.4035F, 1, 4, 1, -0.1F));

        cube_r121 = new ModelRenderer(this);
        cube_r121.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r121);
        setRotationAngle(cube_r121, 0.162F, -0.0473F, -0.2835F);
        cube_r121.cubeList.add(new ModelBox(cube_r121, 82, 84, -13.5197F, -6.6698F, 6.1393F, 1, 4, 1, -0.1F));

        cube_r122 = new ModelRenderer(this);
        cube_r122.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r122);
        setRotationAngle(cube_r122, -0.0471F, -0.0563F, -0.458F);
        cube_r122.cubeList.add(new ModelBox(cube_r122, 86, 82, -8.9784F, -9.8904F, 3.314F, 1, 4, 1, -0.1F));

        cube_r123 = new ModelRenderer(this);
        cube_r123.setRotationPoint(2.8039F, 0.6371F, -0.5495F);
        bone11.addChild(cube_r123);
        setRotationAngle(cube_r123, -0.0678F, -0.0282F, 0.0216F);
        cube_r123.cubeList.add(new ModelBox(cube_r123, 4, 107, -10.8018F, -1.666F, 3.3214F, 1, 1, 1, -0.05F));
        cube_r123.cubeList.add(new ModelBox(cube_r123, 71, 84, -10.7985F, -1.2097F, 3.297F, 1, 3, 1, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        setRotationAngles(f,f1,f2,f3,f4,f5,entity);
        group.render(f5);

    }
    public boolean isMoving() {
        return Minecraft.getMinecraft().gameSettings.keyBindForward.isPressed() ||
                Minecraft.getMinecraft().gameSettings.keyBindBack.isPressed() ||
                Minecraft.getMinecraft().gameSettings.keyBindLeft.isPressed() ||
                Minecraft.getMinecraft().gameSettings.keyBindRight.isPressed() ||
                Minecraft.getMinecraft().thePlayer.movementInput.moveForward != 0.0f ||
                Minecraft.getMinecraft().thePlayer.movementInput.moveStrafe != 0.0f;

    }

    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw,
                                  float headPitch, float scaleFactor, Entity ent)
    {

     /*
        {
          leftleg.rotateAngleX = MathHelper.cos(limbSwing * 0.6F) * 0.8F * limbSwingAmount;
            rightleg.rotateAngleX = MathHelper.cos(limbSwing * 0.6F + (float) Math.PI) * 0.8F * limbSwingAmount;

            leftarm.rotateAngleX = (float) degToRad(65);
            rightarm.rotateAngleX = (float) degToRad(65);

            leftarm.rotateAngleZ = (float) degToRad(57);
            rightarm.rotateAngleZ = (float) degToRad(-57);


            rightarm.rotateAngleY = MathHelper.cos(limbSwing * 0.6662F) * 0.4F * limbSwingAmount;
            leftarm.rotateAngleY = -MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.4F * limbSwingAmount;
        }

        if (entity.isSwingInProgress)
        {
            rightarm.rotateAngleY = MathHelper.sin(entity.swingProgress * 3.0F + (float) Math.PI) * 1.2F;
            rightarm.rotateAngleZ = -MathHelper.cos(entity.swingProgress * 4.0F + (float) Math.PI) * 0.2F;
        }

        if (ent.getDistance(ent.prevPosX, ent.prevPosY, ent.prevPosZ) <= 0.1F && !entity.isSwingInProgress && ent.onGround)
        {
            rightarm.rotateAngleX = 1.134F;
            rightarm.rotateAngleY = -0.261F;
            rightarm.rotateAngleZ = -0.994F;
        }

     */
    }
    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    protected float degToRad(double degrees)
    {
        return (float) (degrees * (double) Math.PI / 180);
    }
    public ModelRenderer getHandRenderer() {
        return rightarm;
    }
}
