package xyz.pixelatedw.MineMineNoMi3.helpers;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.ModelZoanMorph;

public class tankmanfanal extends ModelZoanMorph {
    private final ModelRenderer bone;
    private final ModelRenderer body;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r16;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer cube_r25;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer cube_r28;
    private final ModelRenderer bone6;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer bone8;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer bone7;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer cube_r37;
    private final ModelRenderer bone9;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer wheels2;
    private final ModelRenderer wheels3;

    public tankmanfanal() {
        textureWidth = 208;
        textureHeight = 208;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 24.0F, 0.0F);


        body = new ModelRenderer(this);
        body.setRotationPoint(0.0F, 0.0F, 5.0F);
        bone.addChild(body);
        body.cubeList.add(new ModelBox(body, 118, 21, -13.0F, -19.0F, 1.0F, 26, 5, 12, 0.0F));
        body.cubeList.add(new ModelBox(body, 98, 50, -12.0F, -32.0F, 0.0F, 24, 13, 13, 0.0F));
        body.cubeList.add(new ModelBox(body, 118, 0, -12.0F, -41.0F, 1.0F, 24, 9, 12, 0.0F));
        body.cubeList.add(new ModelBox(body, 0, 43, -14.5F, -42.0F, -2.0F, 29, 28, 16, 0.0F));
        body.cubeList.add(new ModelBox(body, 102, 0, -5.5F, -47.75F, 10.9F, 11, 6, 1, 0.0F));
        body.cubeList.add(new ModelBox(body, 0, 87, -14.0F, -32.0F, 1.0F, 2, 13, 12, 0.0F));
        body.cubeList.add(new ModelBox(body, 0, 0, 12.0F, -32.0F, 1.0F, 2, 13, 12, 0.0F));
        body.cubeList.add(new ModelBox(body, 0, 126, -4.5F, -53.0F, 1.0F, 9, 9, 10, 0.0F));
        body.cubeList.add(new ModelBox(body, 27, 27, -1.5F, -44.0F, 1.0F, 3, 1, 0, 0.0F));
        body.cubeList.add(new ModelBox(body, 0, 112, -4.5F, -44.0F, 2.0F, 9, 3, 8, 0.0F));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-3.0F, -42.5F, 5.0F);
        body.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0F, 0.2618F, 0.0F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 64, 87, -1.5F, -0.5F, -3.5F, 4, 2, 0, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(3.0F, -42.5F, 5.0F);
        body.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.0F, -0.2618F, 0.0F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 64, 87, -2.5F, -0.5F, -3.5F, 4, 2, 0, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(0.7F, -46.0F, -0.2F);
        body.addChild(cube_r3);
        setRotationAngle(cube_r3, -0.2618F, -0.3927F, 0.0F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 80, 54, -0.5F, -0.5F, -2.0F, 1, 1, 4, -0.1F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(-7.1497F, -42.1018F, 6.0F);
        body.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.0F, 0.0F, 0.2182F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 145, -0.5F, -5.5F, -8.0F, 1, 4, 14, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(7.1497F, -42.1018F, 6.0F);
        body.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.0F, 0.0F, -0.2182F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 103, 150, -0.5F, -5.5F, -8.0F, 1, 4, 14, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(-5.0F, -42.25F, 6.0F);
        body.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.0F, 0.0F, -0.1745F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 57, 144, -0.5F, -5.5F, -8.0F, 1, 6, 14, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(-5.5946F, -41.1892F, -1.55F);
        body.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.0F, 0.0F, -0.3054F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 85, 30, -1.5F, -1.5F, -0.5F, 3, 3, 1, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(5.5946F, -41.1892F, -1.55F);
        body.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.0F, 0.0F, 0.3054F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 90, 50, -1.5F, -1.5F, -0.5F, 3, 3, 1, 0.0F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(5.0F, -42.25F, 6.0F);
        body.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.0F, 0.0F, 0.1745F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 87, 144, -0.5F, -5.5F, -8.0F, 1, 6, 14, 0.0F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(8.5F, 2.0F, 13.0F);
        body.addChild(cube_r10);
        setRotationAngle(cube_r10, 1.3963F, 0.0F, 0.0F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 120, 124, -29.0F, -15.0F, 9.0F, 16, 28, 8, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 120, 124, -4.0F, -15.0F, 9.0F, 16, 28, 8, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(5.6338F, -33.3477F, 1.3313F);
        body.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.0F, 0.0436F, 0.2618F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 74, 50, -10.5F, -2.0F, -2.0F, 1, 4, 4, 0.1F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 62, 22, -9.5F, -2.0F, -2.0F, 16, 4, 4, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(11.0F, -33.0F, 1.0F);
        body.addChild(cube_r12);
        setRotationAngle(cube_r12, 0.0F, 0.0F, 0.48F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 28, 126, -2.0F, -3.0F, -2.0F, 4, 6, 4, 0.0F));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(12.0303F, -37.6474F, 1.0F);
        body.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.0F, 0.0F, -0.0436F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 43, -2.0F, -3.0F, -2.0F, 4, 6, 4, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(-12.0303F, -37.6474F, 1.0F);
        body.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.0F, 0.0F, 0.0436F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 62, 0, -2.0F, -3.0F, -2.0F, 4, 6, 4, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(-11.0F, -33.0F, 1.0F);
        body.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.0F, 0.0F, -0.48F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 68, 128, -2.0F, -3.0F, -2.0F, 4, 6, 4, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(-5.7181F, -33.0055F, 0.7816F);
        body.addChild(bone3);
        setRotationAngle(bone3, 0.0F, 0.1309F, 0.0F);


        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone3.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.0F, -0.0436F, -0.2618F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 150, 42, -6.5F, -2.0F, -2.0F, 16, 4, 4, 0.0F));
        cube_r16.cubeList.add(new ModelBox(cube_r16, 0, 87, 9.5F, -2.0F, -2.0F, 1, 4, 4, 0.1F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(6.6496F, -1.754F, 0.4283F);
        bone3.addChild(bone2);
        setRotationAngle(bone2, 0.0F, -0.2618F, 0.0F);


        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(-2.7733F, 3.3135F, -0.025F);
        bone2.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.0F, 0.0F, -0.2182F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 28, 16, 9.5F, -5.0F, -2.0F, 1, 4, 2, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(4.2369F, 0.0463F, -0.025F);
        bone2.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.0F, 0.0F, -0.1309F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 58, 87, 0.0F, -0.5F, -2.0F, 2, 1, 2, 0.0F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(-3.4226F, 0.3846F, -0.025F);
        bone2.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.0F, 0.0F, -0.2182F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 27, 87, 7.5F, -2.0F, -2.0F, 2, 3, 2, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(3.0076F, -1.1203F, -0.025F);
        bone2.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.0F, 0.0F, -0.5672F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 83, 15, -1.5F, -1.5F, -2.0F, 3, 1, 2, 0.0F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(-2.3766F, -0.0037F, -0.025F);
        bone2.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.0F, 0.0F, -0.2182F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 44, 103, 3.5F, -1.0F, -2.0F, 3, 3, 2, 0.0F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(4.6534F, -2.535F, -0.6685F);
        bone3.addChild(bone4);
        setRotationAngle(bone4, 0.0F, 0.0F, 2.9583F);


        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(4.2369F, -0.0463F, 0.025F);
        bone4.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.0F, 0.0F, 0.1309F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 50, 87, 0.0F, -0.5F, 0.0F, 2, 1, 2, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(-3.4226F, -0.3846F, 0.025F);
        bone4.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.0F, 0.0F, 0.2182F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 28, 10, 9.5F, -2.0F, 0.0F, 1, 4, 2, 0.0F));
        cube_r23.cubeList.add(new ModelBox(cube_r23, 16, 87, 7.5F, -1.0F, 0.0F, 2, 3, 2, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(3.0076F, 1.1203F, 0.025F);
        bone4.addChild(cube_r24);
        setRotationAngle(cube_r24, 0.0F, 0.0F, 0.5672F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 80, 50, -1.5F, 0.5F, 0.0F, 3, 1, 2, 0.0F));

        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(-2.3766F, 0.0037F, 0.025F);
        bone4.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.0F, 0.0F, 0.2182F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 65, 101, 3.5F, -2.0F, 0.0F, 3, 3, 2, 0.0F));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(17.7118F, -39.0658F, 3.25F);
        body.addChild(bone5);


        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(3.7637F, 3.7436F, 3.25F);
        bone5.addChild(cube_r26);
        setRotationAngle(cube_r26, 0.0F, 0.0F, -1.1781F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 159, 50, -3.5F, -9.0F, -3.5F, 7, 6, 7, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(-0.7726F, 8.506F, 2.25F);
        bone5.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.0F, 0.0F, -0.0436F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 31, 144, -2.5F, -9.0F, -2.5F, 6, 18, 7, 0.0F));

        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(2.5482F, 19.8371F, 7.8175F);
        bone5.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.6981F, 0.1309F, -0.5236F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 76, 164, -2.5F, -1.0F, -3.5F, 6, 4, 7, 0.1F));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 126, 161, -2.5F, -9.0F, -3.5F, 6, 8, 7, 0.0F));

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(-17.7118F, -39.0658F, 3.25F);
        body.addChild(bone6);


        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(-3.7637F, 3.7436F, 3.25F);
        bone6.addChild(cube_r29);
        setRotationAngle(cube_r29, 0.0F, 0.0F, 1.1781F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 73, 144, -3.5F, -9.0F, -3.5F, 7, 6, 7, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(0.7726F, 8.506F, 2.25F);
        bone6.addChild(cube_r30);
        setRotationAngle(cube_r30, 0.0F, 0.0F, 0.0436F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 94, 94, -3.5F, -9.0F, -2.5F, 6, 18, 7, 0.0F));

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(-2.5482F, 19.8371F, 7.8175F);
        bone6.addChild(cube_r31);
        setRotationAngle(cube_r31, 0.6981F, -0.1309F, 0.5236F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 50, 164, -3.5F, -1.0F, -3.5F, 6, 4, 7, 0.1F));
        cube_r31.cubeList.add(new ModelBox(cube_r31, 83, 0, -3.5F, -9.0F, -3.5F, 6, 8, 7, 0.0F));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(8.5F, -42.4F, 12.0F);
        body.addChild(bone8);
        bone8.cubeList.add(new ModelBox(bone8, 75, 14, -0.5F, -0.8F, -5.0F, 2, 1, 1, 0.0F));
        bone8.cubeList.add(new ModelBox(bone8, 98, 58, 1.5F, -0.8F, -8.0F, 1, 1, 4, 0.0F));
        bone8.cubeList.add(new ModelBox(bone8, 44, 109, -3.5F, -0.6F, -11.0F, 7, 1, 10, 0.0F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone8.addChild(cube_r32);
        setRotationAngle(cube_r32, -0.3927F, 0.0F, 0.0F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 57, -1.5F, 0.0F, -1.0F, 5, 0, 2, 0.0F));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(0.0F, 0.0F, -12.0F);
        bone8.addChild(cube_r33);
        setRotationAngle(cube_r33, 0.3927F, 0.0F, 0.0F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 73, 30, -1.5F, 0.0F, -1.0F, 5, 0, 2, 0.0F));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(4.8854F, 0.0749F, -2.0F);
        bone8.addChild(cube_r34);
        setRotationAngle(cube_r34, 0.0F, 0.0F, 0.2618F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 14, 0, -1.5F, 0.0F, -9.0F, 4, 0, 10, 0.0F));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(-8.5F, -42.4F, 12.0F);
        body.addChild(bone7);
        bone7.cubeList.add(new ModelBox(bone7, 98, 76, -3.5F, -0.6F, -11.0F, 7, 1, 10, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 96, 38, -2.5F, -0.8F, -8.0F, 1, 1, 4, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 75, 10, -1.5F, -0.8F, -5.0F, 2, 1, 1, 0.0F));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone7.addChild(cube_r35);
        setRotationAngle(cube_r35, -0.3927F, 0.0F, 0.0F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 0, 10, -3.5F, 0.0F, -1.0F, 5, 0, 2, 0.0F));

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(-4.8854F, 0.0749F, -2.0F);
        bone7.addChild(cube_r36);
        setRotationAngle(cube_r36, 0.0F, 0.0F, -0.2618F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 6, 0, -2.5F, 0.0F, -9.0F, 4, 0, 10, 0.0F));

        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(0.0F, 0.0F, -12.0F);
        bone7.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.3927F, 0.0F, 0.0F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 14, 10, -3.5F, 0.0F, -1.0F, 5, 0, 2, 0.0F));

        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(0.2308F, -53.7923F, 5.1877F);
        body.addChild(bone9);
        setRotationAngle(bone9, 0.1745F, 0.0F, 0.0F);
        bone9.cubeList.add(new ModelBox(bone9, 38, 128, -5.2308F, -4.3077F, -4.7877F, 10, 6, 10, 0.0F));
        bone9.cubeList.add(new ModelBox(bone9, 0, 163, 1.7692F, -6.0077F, -4.7877F, 3, 2, 10, 0.0F));
        bone9.cubeList.add(new ModelBox(bone9, 16, 87, 0.7692F, -5.5077F, -4.2877F, 1, 2, 9, 0.0F));
        bone9.cubeList.add(new ModelBox(bone9, 158, 158, -5.2308F, -6.3077F, -4.7877F, 6, 2, 10, 0.0F));
        bone9.cubeList.add(new ModelBox(bone9, 118, 77, -7.7308F, 1.2923F, -7.7877F, 15, 1, 16, -0.3F));
        bone9.cubeList.add(new ModelBox(bone9, 44, 93, 6.3513F, 1.2923F, -7.6327F, 3, 1, 15, -0.3F));
        bone9.cubeList.add(new ModelBox(bone9, 0, 29, -6.2308F, 1.2923F, -10.1877F, 12, 1, 3, -0.3F));
        bone9.cubeList.add(new ModelBox(bone9, 78, 128, -9.8129F, 1.2923F, -7.6327F, 3, 1, 15, -0.3F));
        bone9.cubeList.add(new ModelBox(bone9, 0, 25, -6.2308F, 1.2923F, 6.9224F, 12, 1, 3, -0.3F));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(5.7493F, 1.7923F, 7.9487F);
        bone9.addChild(cube_r38);
        setRotationAngle(cube_r38, 0.0F, 0.6196F, 0.0F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 62, 10, -1.5F, -0.5F, -1.5F, 5, 1, 3, -0.3F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(-6.2109F, 1.7923F, 7.9487F);
        bone9.addChild(cube_r39);
        setRotationAngle(cube_r39, 0.0F, -0.6196F, 0.0F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 0, 53, -3.5F, -0.5F, -1.5F, 5, 1, 3, -0.3F));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(-6.2109F, 1.7923F, -8.214F);
        bone9.addChild(cube_r40);
        setRotationAngle(cube_r40, 0.0F, 0.6196F, 0.0F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 62, 30, -3.5F, -0.5F, -1.5F, 5, 1, 3, -0.3F));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(5.7493F, 1.7923F, -8.214F);
        bone9.addChild(cube_r41);
        setRotationAngle(cube_r41, 0.0F, -0.6196F, 0.0F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 62, 14, -1.5F, -0.5F, -1.5F, 5, 1, 3, -0.3F));

        wheels2 = new ModelRenderer(this);
        wheels2.setRotationPoint(20.2F, 3.0F, -7.75F);
        bone.addChild(wheels2);
        wheels2.cubeList.add(new ModelBox(wheels2, 152, 104, -15.2F, -14.0F, -0.25F, 15, 6, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 46, 93, -11.2F, -15.0F, 0.75F, 7, 1, 34, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 0, 87, -4.2F, -17.0F, -0.25F, 4, 3, 36, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 74, 7, -15.2F, -17.0F, -0.25F, 4, 3, 36, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 54, 54, -9.55F, -17.0F, -0.25F, 4, 3, 36, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 94, 94, -15.2F, -14.0F, 3.75F, 15, 2, 28, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 0, 0, -14.7F, -12.0F, 1.0F, 14, 9, 34, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 152, 94, -15.2F, -14.0F, 31.75F, 15, 6, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 74, 12, -0.25F, -12.25F, 1.0F, 0, 4, 34, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 0, 95, -1.2F, -11.25F, 23.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 94, 94, -1.2F, -11.25F, 10.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 0, 0, -1.45F, -12.0F, 2.0F, 1, 6, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 118, 21, -1.45F, -8.0F, 7.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 68, 109, -1.45F, -8.0F, 13.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 44, 109, -1.45F, -8.0F, 18.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 26, 108, -1.45F, -8.0F, 24.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 98, 76, -1.45F, -10.0F, 30.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 62, 0, -15.2F, -11.75F, 7.75F, 1, 3, 19, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 0, 2, -15.3F, -10.75F, 12.75F, 1, 1, 1, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 0, 0, -15.3F, -10.75F, 21.75F, 1, 1, 1, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 98, 50, -14.95F, -10.0F, 2.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 98, 18, -14.95F, -8.0F, 7.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 96, 30, -14.95F, -8.0F, 13.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 44, 95, -14.95F, -8.0F, 18.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 65, 93, -14.95F, -8.0F, 24.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 44, 87, -14.95F, -10.0F, 30.0F, 1, 4, 4, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 93, 30, -1.4F, -9.0F, 31.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 93, 15, -1.4F, -9.0F, 3.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 71, 93, -1.4F, -7.0F, 8.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 52, 93, -1.4F, -7.0F, 14.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 27, 92, -1.4F, -7.0F, 19.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 16, 92, -1.4F, -7.0F, 25.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 6, 87, -15.0F, -7.0F, 25.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 83, 0, -15.0F, -9.0F, 31.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 74, 0, -15.0F, -7.0F, 19.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 28, 28, -15.0F, -7.0F, 14.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 27, 23, -15.0F, -7.0F, 8.0F, 1, 2, 2, 0.0F));
        wheels2.cubeList.add(new ModelBox(wheels2, 6, 0, -15.0F, -9.0F, 3.0F, 1, 2, 2, 0.0F));

        wheels3 = new ModelRenderer(this);
        wheels3.setRotationPoint(-20.2F, 3.0F, -7.75F);
        bone.addChild(wheels3);
        wheels3.cubeList.add(new ModelBox(wheels3, 152, 104, 0.2F, -14.0F, -0.25F, 15, 6, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 46, 93, 4.2F, -15.0F, 0.75F, 7, 1, 34, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 0, 87, 0.2F, -17.0F, -0.25F, 4, 3, 36, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 74, 7, 11.2F, -17.0F, -0.25F, 4, 3, 36, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 54, 54, 5.55F, -17.0F, -0.25F, 4, 3, 36, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 94, 94, 0.2F, -14.0F, 3.75F, 15, 2, 28, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 0, 0, 0.7F, -12.0F, 1.0F, 14, 9, 34, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 152, 94, 0.2F, -14.0F, 31.75F, 15, 6, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 74, 12, 0.25F, -12.25F, 1.0F, 0, 4, 34, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 0, 95, 0.2F, -11.25F, 23.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 94, 94, 0.2F, -11.25F, 10.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 0, 0, 0.45F, -12.0F, 2.0F, 1, 6, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 118, 21, 0.45F, -8.0F, 7.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 68, 109, 0.45F, -8.0F, 13.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 44, 109, 0.45F, -8.0F, 18.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 26, 108, 0.45F, -8.0F, 24.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 98, 76, 0.45F, -10.0F, 30.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 62, 0, 14.2F, -11.75F, 7.75F, 1, 3, 19, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 0, 2, 14.3F, -10.75F, 12.75F, 1, 1, 1, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 0, 0, 14.3F, -10.75F, 21.75F, 1, 1, 1, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 98, 50, 13.95F, -10.0F, 2.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 98, 18, 13.95F, -8.0F, 7.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 96, 30, 13.95F, -8.0F, 13.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 44, 95, 13.95F, -8.0F, 18.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 65, 93, 13.95F, -8.0F, 24.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 44, 87, 13.95F, -10.0F, 30.0F, 1, 4, 4, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 93, 30, 0.4F, -9.0F, 31.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 93, 15, 0.4F, -9.0F, 3.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 71, 93, 0.4F, -7.0F, 8.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 52, 93, 0.4F, -7.0F, 14.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 27, 92, 0.4F, -7.0F, 19.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 16, 92, 0.4F, -7.0F, 25.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 6, 87, 14.0F, -7.0F, 25.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 83, 0, 14.0F, -9.0F, 31.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 74, 0, 14.0F, -7.0F, 19.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 28, 28, 14.0F, -7.0F, 14.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 27, 23, 14.0F, -7.0F, 8.0F, 1, 2, 2, 0.0F));
        wheels3.cubeList.add(new ModelBox(wheels3, 6, 0, 14.0F, -9.0F, 3.0F, 1, 2, 2, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}
