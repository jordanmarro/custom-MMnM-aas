package xyz.pixelatedw.MineMineNoMi3.soros.soro;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainMod;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.entities.particles.EntityParticleFX;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;
import java.util.Random;

public class SoruSoruNoMiProjo {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static
    {
        abilitiesClassesArray.add(new Object[] {Trunk.class, ListAttributes.SolarLauncher});
        abilitiesClassesArray.add(new Object[] {Fire.class, ListAttributes.FireSpit});
        abilitiesClassesArray.add(new Object[] {Light.class, ListAttributes.LightningEngulfment});

    }


    public static class Trunk extends AbilityProjectile {

        private Random r = new Random();

        public Trunk(World world)
        {super(world);}

        public Trunk(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Trunk(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        @Override
        protected void onImpact(MovingObjectPosition hit) {
            if(hit.entityHit != null) {
                if(hit.entityHit.isEntityAlive()) {
                    hit.entityHit.setFire(10);
                }
            }
            super.onImpact(hit);
        }


    }


    public static class Fire extends AbilityProjectile {

        private Random r = new Random();

        public Fire(World world)
        {super(world);}

        public Fire(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Fire(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        @Override
        protected void onImpact(MovingObjectPosition hit) {
            if(hit.entityHit != null) {
                if(hit.entityHit.isEntityAlive()) {
                    hit.entityHit.setFire(5);
                }
            }
            super.onImpact(hit);
        }


    }

    public static class Light extends AbilityProjectile {
        private Random r = new Random();

        public Light(World world)
        {super(world);}

        public Light(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Light(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        @Override
        protected void onImpact(MovingObjectPosition hit) {
            if(hit.entityHit != null) {
                if(hit.entityHit.isEntityAlive()) {
                    if(hit.entityHit instanceof EntityLivingBase) {
                        ((EntityLivingBase) hit.entityHit).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id,6,10*20));
                    }
                }
            }
            super.onImpact(hit);
        }


    }
}




/*package xyz.pixelatedw.MineMineNoMi3.soros.mam;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.soros.MochiMochiNoMiProjectiles;

import java.util.ArrayList;

public class MamouthProjectiles {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MamouthProjectiles.AncientTrunkShot.class,
                ListAttributes.AncientTrunkShot});


    }

    public static class AncientTrunkShot extends AbilityProjectile {
        public AncientTrunkShot(World world) {
            super(world);
        }

        public AncientTrunkShot(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public AncientTrunkShot(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }
}


 */