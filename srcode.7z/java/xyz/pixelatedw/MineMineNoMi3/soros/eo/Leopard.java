package xyz.pixelatedw.MineMineNoMi3.soros.eo;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.entities.abilityprojectiles.RokushikiProjectiles;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.*;
import xyz.pixelatedw.MineMineNoMi3.soros.mam.MamouthProjo;

public class Leopard {
    static {
        Values.abilityWebAppExtraParams.put("Leopard Point", new String[]
                {"desc", "Turns you into a leopard."});
        Values.abilityWebAppExtraParams.put("Hybrid Leopard Point", new String[]
                {"desc", " Turns you into the hybrid"});
        Values.abilityWebAppExtraParams.put("Rankyaku Hyobi", new String[]
                {"desc", "Basically a spam of the already existing Rankyaku"});
        Values.abilityWebAppExtraParams.put("Sai Dai Rin: Rokuogan ", new String[]
                {"desc", "does Huge knock back "});
        Values.abilityWebAppExtraParams.put("Leopard Mawl", new String[]
                {"desc", "Send a projectile to entity"});

        Values.abilityWebAppExtraParams.put("Leopard Spring Jump", new String[]
                {"desc", "Just a copy of spring hopper from bane bane no mi but less height on the jump like 8 blocks less"});

    }

    public static Ability[] abilitiesArray = new Ability[] {new LeopardPoint(),new HybridPoint(),
         new Rankyaku(), new Sai(),new Mawl(),new LSpringHopper()};


    public static class LSpringHopper extends Ability
    {
        public LSpringHopper()
        {
            super(ListAttributes.LEOPARD_SPRING_HOPPER);
        }

        @Override
        public void endCharging(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            WyHelper.Direction dir = WyHelper.get8Directions(player);
            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("leopard")|| props.getZoanPoint().equals("hybridleopard")  && !this.isOnCooldown) {

                if (player.onGround)
                    motion("+", 0, 1.2 + (double) 1 / 3, 0, player);
                else
                    motion("+", 0, 1.36 + (double) 1 / 8, 0, player);

                if (dir == WyHelper.Direction.NORTH) motion("-", 0, 0, 1.4 + (double) 1 / 2, player);
                if (dir == WyHelper.Direction.NORTH_WEST) {
                    motion("-", 1.4 + (double) 1 / 2, 0, 1.4 + (double) 1 / 2, player);
                }
                if (dir == WyHelper.Direction.SOUTH) motion("+", 0, 0, 1.4 + (double) 1 / 2, player);
                if (dir == WyHelper.Direction.NORTH_EAST) {
                    motion("-", 0, 0, 1.4 + (double) 1 / 2, player);
                    motion("+", 1.4 + (double) 1 / 2, 0, 0, player);
                }
                if (dir == WyHelper.Direction.WEST) motion("-", 1.4 + (double) 1 / 2, 0, 0, player);
                if (dir == WyHelper.Direction.SOUTH_WEST) {
                    motion("+", 0, 0, 1.4 + (double) 1 / 2, player);
                    motion("-", 1.4 + (double) 1 / 2, 0, 0, player);
                }
                if (dir == WyHelper.Direction.EAST) motion("+", 1.4 + (double) 1 / 2, 0, 0, player);
                if (dir == WyHelper.Direction.SOUTH_EAST) {
                    motion("+", 1.4 + (double) 1 / 2, 0, 1.4 + (double) 1 / 2, player);
                }
            }
            super.endCharging(player);
        }
    }

    public static class LeopardPoint extends Ability
    {
        public LeopardPoint()
        {
            super(ListAttributes.LeopardPoint);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("leopard")))
            {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            props.setZoanPoint("leopard");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            props.setZoanPoint("n/a");
            player.capabilities.allowFlying = false;
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

    }

    public static class HybridPoint extends Ability
    {

        public HybridPoint()
        {
            super(ListAttributes.LeopardHybridPoint);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("hybridleopard")))
            {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            props.setZoanPoint("hybridleopard");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            props.setZoanPoint("n/a");
            player.capabilities.allowFlying = false;
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }
    }



    public static class Rankyaku extends Ability
    {
        public Rankyaku()
        {
            super(ListAttributes.RankyakuHyobi);
        }

        @Override
        public void use(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("leopard")|| props.getZoanPoint().equals("hybridleopard")  && !this.isOnCooldown) {
                this.projectile = new LeopardProjo.Rankyaku(player.worldObj, player, ListAttributes.RankyakuHyobi);
            }
            super.use(player);
        }
    }



    public static class Sai extends Ability {
        public Sai() {
            super(ListAttributes.SaiDaiRinRokuogan);
        }

        @Override
        public void hitEntity(EntityPlayer player, EntityLivingBase target)
        {
            super.hitEntity(player, target);
            target.attackEntityFrom(DamageSource.causePlayerDamage(player), 60);
            target.knockBack(target,20,20,20);
        }
    }

    public static class Mawl extends Ability  {
        private int initialY;
        public Mawl() {
            super(ListAttributes.LeopardMawl);

        }
        @Override
        public void use(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("leopard")|| props.getZoanPoint().equals("hybridleopard")  && !this.isOnCooldown) {

                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 4;
                mZ *= 4;

                motion("=", mX, player.motionY, mZ, player);

                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(currentCooldown > 180 && player.posY >= this.initialY)
            {
                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 3))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 50);

                for(int[] location : WyHelper.getBlockLocationsNearby(player, 5))
                {
                    if(location[1] >= player.posY)
                    {
                        if(DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage"))
                        {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }
    }
        private static void motion(String c, double x, double y, double z, EntityPlayer p)
        {
            WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
        }
}


