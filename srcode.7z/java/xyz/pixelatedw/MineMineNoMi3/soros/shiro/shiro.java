package xyz.pixelatedw.MineMineNoMi3.soros.shiro;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.MovingObjectPosition;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSync;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSyncInfo;
import xyz.pixelatedw.MineMineNoMi3.soros.wara.waraProjo;

public class shiro {
    /*Shiro Shiro no Mi- Paramecia




 */
    public static Ability[] abilitiesArray = new Ability[]{
            new CastleTank(), new BigDaddyCannonBall(), new CannonFiring(), new CastleArtillery()};

//new Clutch(), new Rope()
public static class CastleTank extends Ability {
    public CastleTank() {
        super(ListAttributes.castletank);
    }

    @Override
    public void passive(EntityPlayer player) {
        ExtendedEntityData props = ExtendedEntityData.get(player);

        if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                || props.getZoanPoint().equalsIgnoreCase("tank"))) {
            super.passive(player);
        }
    }

    @Override
    public void startPassive(EntityPlayer player) {
        ExtendedEntityData props = ExtendedEntityData.get(player);

        if (props.getZoanPoint().isEmpty())
            props.setZoanPoint("n/a");
        props.setZoanPoint("tank");
        WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
        WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
    }

    @Override
    public void endPassive(EntityPlayer player) {
        ExtendedEntityData props = ExtendedEntityData.get(player);
        props.setZoanPoint("n/a");
        WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
        WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
    }
}
    public static class CannonFiring extends Ability {
        public CannonFiring() {
            super(ListAttributes.CannonFiring);
        }
            public void use(EntityPlayer player)
            {
                ExtendedEntityData props = ExtendedEntityData.get(player);
                if(!props.getZoanPoint().equals("tank")) {
                    return;
                }
                this.projectile = new shiroProjo.Spank(player.worldObj, player, attr);
                super.use(player);
            }
    }


    public static class BigDaddyCannonBall extends Ability {
        public BigDaddyCannonBall() {
            super(ListAttributes.BigDaddyCannonBall);
        }

        public void use(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if(!props.getZoanPoint().equals("tank")) {
                return;
            }
            this.projectile = new shiroProjo.iceblock(player.worldObj, player, attr);
            super.use(player);
        }
    }

    public static class CastleArtillery extends Ability {
        public CastleArtillery() {
            super(ListAttributes.CastleArtillery);
        }

        public void use(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if(!props.getZoanPoint().equals("tank")) {
                return;
            }
            this.projectile = new shiroProjo.SpankBarage(player.worldObj, player, attr);
            super.use(player);
        }
    }


    public static class Stomp extends Ability {
        public Stomp() {
            super(ListAttributes.Stomp);
        }

        @Override
        public void use(EntityPlayer player) {
            if (!this.isOnCooldown) {
                ExtendedEntityData props = ExtendedEntityData.get(player);
                if(!props.getZoanPoint().equals("tank")) {
                    return;
                }
                MovingObjectPosition mop = WyHelper.rayTraceBlocks(player);

                if (mop != null) {
                    double x = mop.blockX;
                    double y = mop.blockY;
                    double z = mop.blockZ;

                    AbilityProjectile proj = new waraProjo.Stomp(player.worldObj, player, ListAttributes.Stomp);
                    proj.setLocationAndAngles(x, (y + 90), z, 0, 0);
                    proj.motionX = 0;
                    proj.motionZ = 0;
                    proj.motionY = -2.4;
                    player.worldObj.spawnEntityInWorld(proj);
                }
            }
            super.use(player);
        }
    }




    private static void motion(String c, double x, double y, double z, EntityPlayer p) {
        WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
    }
}

