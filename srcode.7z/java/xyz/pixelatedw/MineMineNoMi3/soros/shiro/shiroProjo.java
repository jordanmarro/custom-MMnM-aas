package xyz.pixelatedw.MineMineNoMi3.soros.shiro;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.soros.hana.EffectClutch;

import java.util.ArrayList;

public class shiroProjo {

    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {
        abilitiesClassesArray.add(new Object[] {Clutch.class, ListAttributes.Clutch});
        abilitiesClassesArray.add(new Object[] {Spank.class, ListAttributes.CannonFiring});
        abilitiesClassesArray.add(new Object[] {Stomp.class, ListAttributes.Stomp});
        abilitiesClassesArray.add(new Object[] {iceblock.class, ListAttributes.BigDaddyCannonBall});
        abilitiesClassesArray.add(new Object[] {magma.class, ListAttributes.magmadownpour});
        abilitiesClassesArray.add(new Object[] {mochianemone.class, ListAttributes.mochianemone});

        abilitiesClassesArray.add(new Object[] {zushim.class, ListAttributes.zushim});

        abilitiesClassesArray.add(new Object[] {tsunami.class, ListAttributes.tsunami});
        abilitiesClassesArray.add(new Object[] {punkrottenprojo.class, ListAttributes.punkrottenprojo});

        abilitiesClassesArray.add(new Object[] {SpankBarage.class, ListAttributes.CastleArtillery});
        abilitiesClassesArray.add(new Object[] {Rope.class, ListAttributes.Rope});

    }
    public static class Rope extends AbilityProjectile
    {
        public Rope(World world)
        {super(world);}

        public Rope(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Rope(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


        @Override
        public void tasksImapct(MovingObjectPosition hit)
        {
            if(hit.entityHit != null && !hit.entityHit.isDead)
                ((EntityLivingBase) hit.entityHit).setPosition(this.getThrower().posX, this.getThrower().posY, this.getThrower().posZ);
        }
    }

    public static class Clutch extends AbilityProjectile
    {
        public Clutch(World world)
        {super(world);}

        public Clutch(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Clutch(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        public void tasksImapct(MovingObjectPosition hit)
        {
            if(hit.entityHit != null && hit.entityHit instanceof EntityLivingBase)
            {
                EntityLivingBase target = ((EntityLivingBase)hit.entityHit);

                new EffectClutch(target, 400);
            }
        }
    }

    public static class SpankBarage extends AbilityProjectile
    {
        public SpankBarage(World world)
        {super(world);}

        public SpankBarage(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public SpankBarage(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


    }
    public static class Spank extends AbilityProjectile
    {
        public Spank(World world)
        {super(world);}

        public Spank(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Spank(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }



    }

    public static class Stomp extends AbilityProjectile
    {
        public Stomp(World world)
        {super(world);}

        public Stomp(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Stomp(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


    }

    public static class punkrottenprojo extends AbilityProjectile
    {
        public punkrottenprojo(World world)
        {super(world);}

        public punkrottenprojo(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public punkrottenprojo(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


    }

    public static class iceblock extends AbilityProjectile {
        public iceblock(World world)
        {super(world);}

        public iceblock(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public iceblock(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

    }

    public static class zushim extends AbilityProjectile {
        public zushim(World world)
        {super(world);}

        public zushim(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public zushim(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

    }
    public static class mochianemone extends AbilityProjectile {
        public mochianemone(World world)
        {super(world);}

        public mochianemone(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public mochianemone(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

    }

    public static class tsunami extends AbilityProjectile {
        public tsunami(World world)
        {super(world);}

        public tsunami(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public tsunami(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

    }


    public static class magma extends AbilityProjectile {
        public magma(World world)
        {super(world);}

        public magma(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public magma(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        @Override
        public void tasksImapct(MovingObjectPosition hit) {
            if(hit.entityHit != null && hit.entityHit instanceof EntityLivingBase) {
                EntityLivingBase target = ((EntityLivingBase) hit.entityHit);
                target.setFire(10);
            }
        }
    }
}
