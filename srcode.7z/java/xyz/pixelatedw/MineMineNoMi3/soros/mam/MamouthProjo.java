package xyz.pixelatedw.MineMineNoMi3.soros.mam;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class MamouthProjo {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MamouthProjo.Trunk.class,
                ListAttributes.AncientTrunkShot});

    }

    public static class Trunk extends AbilityProjectile {
        public Trunk(World world) {
            super(world);
        }

        public Trunk(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public Trunk(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }


}


/*package xyz.pixelatedw.MineMineNoMi3.soros.mam;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.soros.MochiMochiNoMiProjectiles;

import java.util.ArrayList;

public class MamouthProjectiles {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MamouthProjectiles.AncientTrunkShot.class,
                ListAttributes.AncientTrunkShot});


    }

    public static class AncientTrunkShot extends AbilityProjectile {
        public AncientTrunkShot(World world) {
            super(world);
        }

        public AncientTrunkShot(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public AncientTrunkShot(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }
}


 */