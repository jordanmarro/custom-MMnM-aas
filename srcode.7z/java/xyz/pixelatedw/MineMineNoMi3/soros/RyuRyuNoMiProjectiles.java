package xyz.pixelatedw.MineMineNoMi3.soros;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainMod;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.entities.particles.EntityParticleFX;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;
import java.util.Random;

public class RyuRyuNoMiProjectiles {

    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{RyuRyuNoMiProjectiles.FireBall.class,
                ListAttributes.FIRE_BREATH});
        abilitiesClassesArray.add(new Object[]{RyuRyuNoMiProjectiles.BoroBreath.class,
                ListAttributes.BOROBREATH});
        abilitiesClassesArray.add(new Object[]{RyuRyuNoMiProjectiles.ThunderStorm.class,
                ListAttributes.ThunderStorm});
        abilitiesClassesArray.add(new Object[]{RyuRyuNoMiProjectiles.kamaitachi.class,
                ListAttributes.kamaitachi});

    }
    public static class kamaitachi extends AbilityProjectile {
        public kamaitachi(World world) {
            super(world);
        }

        public kamaitachi(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public kamaitachi(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }

    public static class FireBall extends AbilityProjectile {
        public FireBall(World world) {
            super(world);
        }

        public FireBall(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public FireBall(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }


        public static class BoroBreath extends AbilityProjectile {
            public BoroBreath(World world) {
                super(world);
            }

            public BoroBreath(World world, double x, double y, double z) {
                super(world, x, y, z);
            }

            public BoroBreath(World world, EntityLivingBase player, AbilityAttribute attr) {
                super(world, player, attr);
            }
        }

    public static class ThunderStorm extends AbilityProjectile {

        public ThunderStorm(World world) {
            super(world);
        }

        public ThunderStorm(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public ThunderStorm(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
}

