package xyz.pixelatedw.MineMineNoMi3.soros.nu;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSync;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSyncInfo;

public class Nu {
    static {



        Values.abilityWebAppExtraParams.put("Nue Point", new String[]
                {"desc", "Turns you into a Nue."});
        Values.abilityWebAppExtraParams.put("Nue Curse", new String[]
                {"desc", "gives everyone in 10 block radius poison 2  and slowness 5 for 10 seconds"});
        Values.abilityWebAppExtraParams.put("Nue Claw Slash", new String[]
                {"desc", "Projectile with a model I’d make"});
        Values.abilityWebAppExtraParams.put("Nue Slice And Dice", new String[]
                {"desc", "Copy of Pounce from Smilodon fruit but with 70 Damage"});
        Values.abilityWebAppExtraParams.put("Fang Sting", new String[]
                {"desc", "A Punch move like Shigan that does 60 damage and poison 2 for 8 seconds"});

    }

    public static Ability[] abilitiesArray = new Ability[] {new NuePoint(),
            new NUECLAWSLASH(), new FangSting(),new NuesCurse(),new Slice()};


    public static class Slice extends Ability
    {   private int initialY;

        public Slice() {
            super(ListAttributes.Slice);

        }
        @Override
        public void use(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("nue")
            ) {

                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 6;
                mZ *= 6;

                motion("=", mX, player.motionY, mZ, player);

                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(currentCooldown > 180 && player.posY >= this.initialY)
            {
                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 3))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 70);

                for(int[] location : WyHelper.getBlockLocationsNearby(player, 5))
                {
                    if(location[1] >= player.posY)
                    {
                        if(DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage"))
                        {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }
    }

    public static class NuePoint extends Ability
    {
        public NuePoint()
        {
            super(ListAttributes.NuePoint);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("nue")))
            {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            props.setZoanPoint("nue");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            props.setZoanPoint("n/a");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

    }



    public static class NUECLAWSLASH extends Ability
    {
        public NUECLAWSLASH()
        {
            super(ListAttributes.NUECLAWSLASH);
        }
        @Override
        public void use(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("nue")) {
                this.projectile = new NuProjo.Rankyaku(player.worldObj, player, ListAttributes.NUECLAWSLASH);
            }
            super.use(player);
        }
    }



    public static class FangSting extends Ability {
        public FangSting() {
            super(ListAttributes.FangSting);
        }

            @Override
            public void hitEntity(EntityPlayer player, EntityLivingBase target)
            {
                super.hitEntity(player, target);
                target.attackEntityFrom(DamageSource.causePlayerDamage(player), 60);
            }
        }

    public static class NuesCurse extends Ability  {

        public NuesCurse() {
            super(ListAttributes.NuesCurse);
        }
        @Override
        public void use(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("nue")) {
                for(Entity entity : WyHelper.getEntitiesNear(player,10)) {
                    if(entity instanceof EntityLivingBase) {
                        if(!entity.isDead) {
                                ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(Potion.poison.id,10*20,1));
                            ((EntityLivingBase) entity).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id,10*20,4));
                        }
                    }
                }
            }
            super.use(player);
        }
    }
        private static void motion(String c, double x, double y, double z, EntityPlayer p)
        {
            WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
        }
}


