package xyz.pixelatedw.MineMineNoMi3.soros.buddha;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainMod;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.abilities.SupaAbilities;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.entities.particles.EntityParticleFX;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketNewAABB;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSync;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSyncInfo;

public class BudhaBudha {
    static {
        Values.abilityWebAppExtraParams.put("Buddha Point", new String[]
                {"desc", "Turns you into a Buddha."});
        Values.abilityWebAppExtraParams.put("Impact Wave", new String[]
                {"desc", "send a big Golden Ball"});
        Values.abilityWebAppExtraParams.put("Impact Wave barrage", new String[]
                {"desc", "sends 3 impact wave ."});
        Values.abilityWebAppExtraParams.put("Buddha Punch", new String[]
                {"desc", " a punch move "});
    }


    public static Ability[] abilitiesArray = new Ability[] {new BuddhaPoint(),
            new ImpactWave(), new ImpactWaveBarage(), new BuddhaPunch()};

    public static class BuddhaPoint extends Ability {
        public BuddhaPoint() {
            super(ListAttributes.BUDDHAPOINT);
        }

        @Override
        public void use(EntityPlayer player)  {
            super.use(player);

        }

        @Override
        public void passive(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("buddha"))) {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            WyNetworkHelper.sendTo(new PacketNewAABB(1.5F, 2.5F), (EntityPlayerMP) player);

            props.setZoanPoint("buddha");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player) {
            player.removePotionEffect(Potion.resistance.id);
            player.removePotionEffect(Potion.moveSlowdown.id);
            ExtendedEntityData props = ExtendedEntityData.get(player);
            WyNetworkHelper.sendTo(new PacketNewAABB(0.6F, 1.8F), (EntityPlayerMP) player);
            props.setZoanPoint("n/a");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

    }

    public static class ImpactWave extends Ability {

        public ImpactWave() {
            super(ListAttributes.ImpactWaveA);
        }


        public void startCharging(EntityPlayer player) {
            super.startCharging(player);
        }


        public void endCharging(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if (props.getZoanPoint().equals("buddha") && !this.isOnCooldown) {
                this.projectile = new BudhaBudhaProjo.ImpactWaveA(player.worldObj, player, ListAttributes.ImpactWaveA);
                super.endCharging(player);
            }
        }
    }


    public static class ImpactWaveBarage extends Ability {
        public ImpactWaveBarage() {
            super(ListAttributes.ImpactWaveB);
        }

        public void startCharging(EntityPlayer player) {
            super.startCharging(player);
        }


        public void endCharging(EntityPlayer player) {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if (props.getZoanPoint().equals("buddha") && !this.isOnCooldown) {
                this.projectile = new BudhaBudhaProjo.ImpactWaveB(player.worldObj, player, ListAttributes.ImpactWaveB);
                super.endCharging(player);
            }
        }
    }

    public static class BuddhaPunch extends Ability {
        public BuddhaPunch() {
            super(ListAttributes.BuddhaPunch);
        }


        @Override
        public void hitEntity(EntityPlayer player, EntityLivingBase target)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            super.hitEntity(player, target);
            target.attackEntityFrom(DamageSource.causePlayerDamage(player), 100 * props.getDamageMultiplier());
            AbilityExplosion explosion = WyHelper.newExplosion(player, target.posX, target.posY, target.posZ, 3);
            explosion.setDamageOwner(false);
            explosion.setSmokeParticles("");
            explosion.doExplosion();
            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BUDHA, player), player.dimension, player.posX, player.posY, player.posZ, ID.GENERIC_PARTICLES_RENDER_DISTANCE);

        }
    }

}


