package xyz.pixelatedw.MineMineNoMi3.soros;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainMod;
import xyz.pixelatedw.MineMineNoMi3.abilities.effects.DFEffectHieSlowness;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.entities.abilityprojectiles.GoeProjectiles;
import xyz.pixelatedw.MineMineNoMi3.entities.abilityprojectiles.WeatherProjectiles;
import xyz.pixelatedw.MineMineNoMi3.entities.particles.EntityParticleFX;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.lists.ListExtraAttributes;

import java.util.ArrayList;
import java.util.Random;

public class MochiMochiNoMiProjectiles {

    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MochiMochiNoMiProjectiles.MochiBall.class,
                ListAttributes.MOCHIBALL});

        abilitiesClassesArray.add(new Object[]{MochiMochiNoMiProjectiles.BuzzMochi.class,
                ListAttributes.BuzzMochi});


        abilitiesClassesArray.add(new Object[]{MochiMochiNoMiProjectiles.MochiRocket.class,
                ListAttributes.MOCHIROCKET});

        abilitiesClassesArray.add(new Object[]{MochiMochiNoMiProjectiles.MochiGatling.class,
                ListExtraAttributes.MOCHIGATLING});

        abilitiesClassesArray.add(new Object[]{MochiMochiNoMiProjectiles.ChikaraMochi.class,
                ListAttributes.ChikaraMochi});

        abilitiesClassesArray.add(new Object[]{MochiMochiNoMiProjectiles.YAKI.class,
                ListAttributes.YakiMochi});
    }
    public static class YAKI extends AbilityProjectile {
        public YAKI(World world) {
            super(world);
        }

        public YAKI(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public YAKI(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


        public void tasksImapct(MovingObjectPosition hit) {
            if (hit.entityHit instanceof EntityLivingBase) {
                hit.entityHit.setFire(10);
            }

        }
    }

    public static class MochiBall extends AbilityProjectile {
        public MochiBall(World world) {
            super(world);
        }

        public MochiBall(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public MochiBall(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


        public void tasksImapct(MovingObjectPosition hit) {
            if (hit.entityHit instanceof EntityLivingBase) {
                ((EntityLivingBase) hit.entityHit).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 600));
                ((EntityLivingBase) hit.entityHit).addPotionEffect(new PotionEffect(Potion.digSlowdown.id, 600));
            }

        }
    }


    public static class BuzzMochi extends AbilityProjectile {
        public BuzzMochi(World world) {
            super(world);
        }

        public BuzzMochi(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public BuzzMochi(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }

    public static class MochiGatling extends AbilityProjectile {
        public MochiGatling(World world) {
            super(world);
        }

        public MochiGatling(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public MochiGatling(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }

    public static class MochiRocket extends AbilityProjectile {
        public MochiRocket(World world) {
            super(world);
        }

        public MochiRocket(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public MochiRocket(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }

        public void tasksImapct(MovingObjectPosition hit) {
            if (hit.entityHit instanceof EntityLivingBase) {
                ((EntityLivingBase) hit.entityHit).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 600));
                ((EntityLivingBase) hit.entityHit).addPotionEffect(new PotionEffect(Potion.digSlowdown.id, 600));
            }

        }
    }

    public static class ChikaraMochi extends AbilityProjectile {
        private Random r = new Random();

        public ChikaraMochi(World world) {
            super(world);
        }

        public ChikaraMochi(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public ChikaraMochi(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


            @Override
            public void onUpdate()
            {
                if(this.worldObj.isRemote)
                {
                    for (int i = 0; i < DevilFruitsHelper.getParticleSettingModifier(25); i++)
                    {
                        double offsetX = (new Random().nextInt(50) + 1.0D - 25.0D) / 30.0D;
                        double offsetY = (new Random().nextInt(50) + 1.0D - 25.0D) / 30.0D;
                        double offsetZ = (new Random().nextInt(50) + 1.0D - 25.0D) / 30.0D;

                        EntityParticleFX particle = new EntityParticleFX(this.worldObj, ID.PARTICLE_ICON_MOCHI,
                                posX + offsetX,
                                posY + offsetY,
                                posZ + offsetZ,
                                0, 0, 0)
                                .setParticleAge(10).setParticleScale(1.3F);

                        MainMod.proxy.spawnCustomParticles(this, particle);
                    }

                    for (int i = 0; i < DevilFruitsHelper.getParticleSettingModifier(2); i++)
                    {
                        double offsetX = (new Random().nextInt(50) + 1.0D - 25.0D) / 30.0D;
                        double offsetY = (new Random().nextInt(50) + 1.0D - 25.0D) / 30.0D;
                        double offsetZ = (new Random().nextInt(50) + 1.0D - 25.0D) / 30.0D;

                        EntityParticleFX particle = new EntityParticleFX(this.worldObj, ID.PARTICLE_ICON_MOCHI,
                                posX + offsetX,
                                posY + offsetY,
                                posZ + offsetZ,
                                0, 0, 0)
                                .setParticleAge(7).setParticleScale(1.2F);

                        MainMod.proxy.spawnCustomParticles(this, particle);
                    }
                }
                super.onUpdate();
            }

        }
}



