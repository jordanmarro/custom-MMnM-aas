package xyz.pixelatedw.MineMineNoMi3.soros.hebi;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.WorldServer;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.*;
import xyz.pixelatedw.MineMineNoMi3.soros.RyuRyuNoMiProjectiles;
import xyz.pixelatedw.MineMineNoMi3.soros.ptera.SmilodonProjo;

public class Hebi {
    static {
        Values.abilityWebAppExtraParams.put("YamataNoOrochi Point", new String[]
                {"desc", "turns you into a pteranodon "});
        Values.abilityWebAppExtraParams.put("Pounce", new String[]
                {"desc", "possible make you go farther"});
        Values.abilityWebAppExtraParams.put("Smilodon Chomp", new String[]
                {"desc", "shigan"});
        Values.abilityWebAppExtraParams.put("Smilodon Stalk", new String[]
                {"desc", "akes everyone in a 20 block radius slow 3 for 10 seconds  "});
        Values.abilityWebAppExtraParams.put("Smilodon Leap", new String[]
                {"desc", "Make you jump"});
        Values.abilityWebAppExtraParams.put("Smilodon Claw Slash", new String[]
                {"desc", "Sends slash projectiles at enemies that does 20 damage each"});


    }



    public static Ability[] abilitiesArray = new Ability[]
            {new YamataNoOrochi(),
                    new FireBallSpam(), new Bite(),new
                    Constrict(),  new Head(),new hebiHeal()};
    public static class Head extends Ability
    {
        public Head()
        {
            super(ListAttributes.head);
        }

 public void use(EntityPlayer player) {
     ExtendedEntityData props = ExtendedEntityData.get(player);
     if(props.getZoanPoint().equals("hebi")) {
         this.projectile = new HebiProjo.head(player.worldObj, player, ListAttributes.head);
     }
     super.use(player);
 }

    }
    public static class FireBallSpam extends Ability
    {
        public FireBallSpam()
        {
            super(ListAttributes.fireball);
        }

        public void startCharging(EntityPlayer player)
        {
            super.startCharging(player);
        }


        public void endCharging(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            if(props.getZoanPoint().equals("hebi") && !this.isOnCooldown) {
                this.projectile = new HebiProjo.FireBall(player.worldObj, player, ListAttributes.fireball);
                super.endCharging(player);
            }
        }
    }
    public static class Constrict extends Ability {
        public Constrict() {

            super(ListAttributes.Constrict);
        }
        @Override
        public void use(EntityPlayer player)
        {
            if(isOnCooldown()) {
                return;
            }
            for (EntityLivingBase ent : WyHelper.getEntitiesNear(player, 3)) {
                ent.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 4*20, 85));

                ent.addPotionEffect(new PotionEffect(Potion.confusion.id, 4*20, 50));


            }

            super.use(player);
        }
    }



    public static class YamataNoOrochi extends Ability
    {
        public YamataNoOrochi()
        {
            super(ListAttributes.YamataNoOrochi);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("hebi")))
            {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            props.setZoanPoint("hebi");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            props.setZoanPoint("n/a");
            player.capabilities.allowFlying = false;
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

    }




    public static class hebiHeal extends Ability {
        public hebiHeal()
        {
            super(ListAttributes.hebiHeal);
        }
        @Override
        public void use(EntityPlayer p ) {
            if(!this.isOnCooldown)
                p.heal(100);
            super.use(p);
        }
    }



    public static class Bite extends Ability {
        public Bite()
        {
            super(ListAttributes.Bite);
        }
        @Override
        public void hitEntity(EntityPlayer player, EntityLivingBase target)
        {
            super.hitEntity(player, target);

            target.attackEntityFrom(DamageSource.causePlayerDamage(player), 80);
            target.addPotionEffect(new PotionEffect(Potion.poison.id,8*20, 1));

        }
    }



}

/*- Mochi wheel speed upped by a little bit (very little)
- Leopard point speed upped by 1
- anti knockback to mammoth point (75% knockback resistance)

 */
