package xyz.pixelatedw.MineMineNoMi3.soros.hebi;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class HebiProjo {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static
    {
        abilitiesClassesArray.add(new Object[] {FireBall.class, ListAttributes.fireball});
        abilitiesClassesArray.add(new Object[] {head.class, ListAttributes.head});

    }

    public static class FireBall extends AbilityProjectile {
        public FireBall(World world) {
            super(world);
        }

        public FireBall(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public FireBall(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }


    public static class head extends AbilityProjectile {
        public head(World world) {
            super(world);
        }

        public head(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public head(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
    }




/*package xyz.pixelatedw.MineMineNoMi3.soros.mam;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.soros.MochiMochiNoMiProjectiles;

import java.util.ArrayList;

public class MamouthProjectiles {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MamouthProjectiles.AncientTrunkShot.class,
                ListAttributes.AncientTrunkShot});


    }

    public static class AncientTrunkShot extends AbilityProjectile {
        public AncientTrunkShot(World world) {
            super(world);
        }

        public AncientTrunkShot(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public AncientTrunkShot(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }
}


 */