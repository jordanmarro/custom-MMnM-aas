package xyz.pixelatedw.MineMineNoMi3.soros;

import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class psword  extends Item {
    public psword()
    {

    }
}
