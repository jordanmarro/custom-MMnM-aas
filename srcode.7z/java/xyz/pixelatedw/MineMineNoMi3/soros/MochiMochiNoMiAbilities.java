package xyz.pixelatedw.MineMineNoMi3.soros;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainConfig;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.abilities.FishKarateAbilities;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.math.WyMathHelper;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.entities.abilityprojectiles.GomuProjectiles;
import xyz.pixelatedw.MineMineNoMi3.entities.abilityprojectiles.MeraProjectiles;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.lists.ListExtraAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSync;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSyncInfo;

public class MochiMochiNoMiAbilities {
    static
    {
        Values.abilityWebAppExtraParams.put("Mochi Boru", new String[]
                {"desc", "Give slowness to the target."});
        Values.abilityWebAppExtraParams.put("Mochi San-Boru", new String[]
                {"desc", "Same as Mochi ball but send 3 balls."});
        Values.abilityWebAppExtraParams.put("Sutorimu Mochi", new String[]
                {"desc", "sends a continuous line of mochi balls for 4-5 seconds."});
        Values.abilityWebAppExtraParams.put("Kaku Mochi", new String[]
                {"desc", "Sends 1 large white mochi balls into the opponent."});
        Values.abilityWebAppExtraParams.put("Mochi Gatling", new String[]
                {"desc", "Sends 1 large white mochi balls into the opponent."});
        Values.abilityWebAppExtraParams.put("Chikara Mochi", new String[]
                {"desc", "Sends 1 large mochif fist."});

        Values.abilityWebAppExtraParams.put("Wheel Dash", new String[]
                {"desc", "Turn to a wheel and dash"});



    }

    public static final Ability MochiBall = new MochiMochiNoMiAbilities.MochiBall();
    public static final Ability MochiStream = new MochiMochiNoMiAbilities.MochiStream();
    public static final Ability Rocket = new MochiMochiNoMiAbilities.Rocket();
    public static final Ability Gatling = new MochiMochiNoMiAbilities.MochiNoGatling();
    public static final Ability Chikara = new MochiMochiNoMiAbilities.ChikaraMochi();
    public static final Ability Wheel = new MochiMochiNoMiAbilities.WheelDash();
    public static final Ability YakiMochi = new MochiMochiNoMiAbilities.YakiMochi();
    public static Ability[] abilitiesArray = new Ability[] {
            Wheel, MochiBall, MochiStream, Rocket, Gatling,Chikara,YakiMochi
    };
    public static class YakiMochi extends Ability
    {
        public YakiMochi()
        {
            super(ListAttributes.YakiMochi);
        }

        public void use(EntityPlayer player)
        {
            this.projectile = new MochiMochiNoMiProjectiles.YAKI(player.worldObj, player, ListAttributes.YakiMochi);
            super.use(player);
        }
    }
    public static class MochiBall extends Ability
    {
        public MochiBall()
        {
            super(ListAttributes.MOCHIBALL);
        }

        public void use(EntityPlayer player)
        {
            this.projectile = new MochiMochiNoMiProjectiles.MochiBall(player.worldObj, player, ListAttributes.MOCHIBALL);
            super.use(player);
        }
    }

    public static class Barrage extends Ability
    {
        public int repeater = 0;
        public Barrage()
        {
            super(ListAttributes.MOCHIBARAGE);
        }
        @Override
        public void duringRepeater(EntityPlayer player) {
            super.duringRepeater(player);
            if(repeater % 2 == 0) {
                player.rotationYaw += 10;
            } else {
                player.rotationYaw -= 20;
            }
            repeater++;
        }

        public void use(EntityPlayer player)
        {

            this.projectile = new MochiMochiNoMiProjectiles.MochiBall(player.worldObj, player.posX,player.posY,player.posZ );
            this.projectile = new MochiMochiNoMiProjectiles.MochiBall(player.worldObj, player.posX + 7,player.posY,player.posZ + 7 );
            this.projectile = new MochiMochiNoMiProjectiles.MochiBall(player.worldObj, player.posX - 7,player.posY,player.posZ -7 );
            super.use(player);
        }
    }

    public static class MochiStream extends Ability
    {

        public MochiStream()
        {
            super(ListAttributes.BuzzMochi);
        }


        public void use(EntityPlayer player)
        {
            this.projectile = new MochiMochiNoMiProjectiles.BuzzMochi(player.worldObj,
                        player, ListAttributes.BuzzMochi);

            super.use(player);
        }
    }

    public static class Rocket extends Ability
    {
        public Rocket()
        {
            super(ListAttributes.MOCHIROCKET);
        }
        public void use(EntityPlayer player)
        {
            this.projectile = new MochiMochiNoMiProjectiles.MochiRocket(player.worldObj, player, ListAttributes.MOCHIROCKET);
            super.use(player);
        }
    }

    public static class MochiNoGatling extends Ability {
        public MochiNoGatling()
        {
            super(ListAttributes.MOCHIGATLING);
        }

        @Override
        public void use(EntityPlayer player)
        {
            if(!this.isOnCooldown)
            {
                ExtendedEntityData props = ExtendedEntityData.get(player);
                int type = 1;
                int projectileSpace = 3;


                        if(MainConfig.enableAnimeScreaming) this.attr.setAbilityDisplayName("Mochi Gatling");
                        this.attr.setAbilityCooldown(2);


                for(int j = 0; j < 25; j++)
                {
                    AbilityProjectile proj  = new MochiMochiNoMiProjectiles.MochiGatling(player.worldObj, player, ListExtraAttributes.MOCHIGATLING);

                    proj.setLocationAndAngles(
                            player.posX + WyMathHelper.randomWithRange(-projectileSpace, projectileSpace) + player.worldObj.rand.nextDouble(),
                            (player.posY + 0.3) + WyMathHelper.randomWithRange(0, projectileSpace) + player.worldObj.rand.nextDouble(),
                            player.posZ + WyMathHelper.randomWithRange(-projectileSpace, projectileSpace) + player.worldObj.rand.nextDouble(),
                            0, 0);
                    player.worldObj.spawnEntityInWorld(proj);
                }

                super.use(player);
            }
        }
    }

   public static class WheelDash extends Ability
   {
       public WheelDash()
       {
           super(ListAttributes.WHEELDASH);
       }


       @Override
       public void passive(EntityPlayer player)
       {
           ExtendedEntityData props = ExtendedEntityData.get(player);

           if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                   || props.getZoanPoint().equalsIgnoreCase("wheel")))
           {

               super.passive(player);
           }
       }

       @Override
       public void startPassive(EntityPlayer player)
       {
           ExtendedEntityData props = ExtendedEntityData.get(player);

           if (props.getZoanPoint().isEmpty())
               props.setZoanPoint("n/a");
           props.setZoanPoint("wheel");
           WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
           WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));

       }


       public void endPassive(EntityPlayer player) {
           ExtendedEntityData props = ExtendedEntityData.get(player);
           props.setZoanPoint("n/a");
           WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
           WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
       }


   }



    public static class ChikaraMochi extends Ability {
        public ChikaraMochi()
        {
            super(ListAttributes.ChikaraMochi);
        }
        public void use(EntityPlayer player)
        {
            this.projectile = new MochiMochiNoMiProjectiles.ChikaraMochi(player.worldObj, player, ListAttributes.ChikaraMochi);
            super.use(player);
        }
    }
}


