package xyz.pixelatedw.MineMineNoMi3.soros;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainMod;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.math.WyMathHelper;
import xyz.pixelatedw.MineMineNoMi3.entities.particles.EntityParticleFX;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class JishakuJishakuNoMiProjectiles {

    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static
    {

        abilitiesClassesArray.add(new Object[] {JishakuJishakuNoMiProjectiles.MetalPieces.class,
                ListAttributes.JISHAKUMETAL});

        abilitiesClassesArray.add(new Object[] {JishakuJishakuNoMiProjectiles.PULL.class,
                ListAttributes.MagnetPUll});

        abilitiesClassesArray.add(new Object[] {JishakuJishakuNoMiProjectiles.REPELL.class,
                ListAttributes.Repell});

        abilitiesClassesArray.add(new Object[] {JishakuJishakuNoMiProjectiles.HREPELL.class,
                ListAttributes.HeavyRepell});



    }

    public static class MetalPieces extends AbilityProjectile
    {
        public MetalPieces(World world)
        {super(world);}

        public MetalPieces(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public MetalPieces(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        public void tasksImapct(MovingObjectPosition hit)
        {

        }
    }

    public static class PULL extends AbilityProjectile
    {
        public PULL(World world)
        {super(world);}

        public PULL(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public PULL(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }
        @Override
        public void onUpdate()
        {
            if(this.worldObj.isRemote)
            {
                for(int i = 0; i < DevilFruitsHelper.getParticleSettingModifier(5); i++)
                {
                    double offsetX = WyMathHelper.randomDouble();
                    double offsetY = WyMathHelper.randomDouble();
                    double offsetZ = WyMathHelper.randomDouble();

                    EntityParticleFX particle = new EntityParticleFX(this.worldObj, ID.PARTICLE_PULL,
                            posX + offsetX,
                            posY + offsetY,
                            posZ + offsetZ,
                            0, 0, 0)
                            .setParticleAge(15).setParticleScale(3F);

                    MainMod.proxy.spawnCustomParticles(this, particle);
                }
            }

            super.onUpdate();
        }

        @Override
        public void tasksImapct(MovingObjectPosition hit)
        {
            if(hit.entityHit != null && !hit.entityHit.isDead)
                ((EntityLivingBase) hit.entityHit).setPosition(this.getThrower().posX, this.getThrower().posY, this.getThrower().posZ);
        }
    }

    public static class REPELL  extends AbilityProjectile
    {
        public REPELL(World world)
        {super(world);}

        public REPELL(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public REPELL(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


        @Override
        public void tasksImapct(MovingObjectPosition hit)
        {
            if(hit.entityHit != null && !hit.entityHit.isDead)
                ((EntityLivingBase) hit.entityHit).setPosition(hit.entityHit.posX + 10, hit.entityHit.posY + 5, hit.entityHit.posZ + 10);
        }

    }

    public static class HREPELL extends AbilityProjectile
    {
        public HREPELL(World world)
        {super(world);}

        public HREPELL(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public HREPELL(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }



    }
}
