package xyz.pixelatedw.MineMineNoMi3.blocks.tileentities;

import net.minecraft.tileentity.TileEntity;

public class TileEntityImpactDial extends TileEntity
{

}
