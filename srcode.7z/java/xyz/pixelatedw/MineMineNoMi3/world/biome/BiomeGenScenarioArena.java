package xyz.pixelatedw.MineMineNoMi3.world.biome;

import net.minecraft.world.biome.BiomeGenBase;

public class BiomeGenScenarioArena extends BiomeGenBase
{

	public BiomeGenScenarioArena(int id) 
	{
		super(id);
	}

}
