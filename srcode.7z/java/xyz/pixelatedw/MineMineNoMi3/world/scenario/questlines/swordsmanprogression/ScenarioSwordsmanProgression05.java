package xyz.pixelatedw.MineMineNoMi3.world.scenario.questlines.swordsmanprogression;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.world.scenario.Scenario;

public class ScenarioSwordsmanProgression05 extends Scenario
{

	public void load(EntityPlayer player, World world)
	{
		
	}

	public void unload(EntityPlayer player, World world)
	{
		
	}

}
