package xyz.pixelatedw.MineMineNoMi3.packets;

import xyz.pixelatedw.MineMineNoMi3.items.AkumaNoMi;
import xyz.pixelatedw.MineMineNoMi3.lists.ListDevilFruits;

public class Helper {

    public static float getFactor(AkumaNoMi usedFruit) {
        if (ListDevilFruits.cent.contains(usedFruit) && ListDevilFruits.centstr.contains(usedFruit.getUnlocalizedName())) {
            return 2F;
        } else if (ListDevilFruits.six.contains(usedFruit) && ListDevilFruits.sixstr.contains(usedFruit.getUnlocalizedName())) {
            return 1.6F;
        } else if (!ListDevilFruits.six.contains(usedFruit) && !ListDevilFruits.cent.contains(usedFruit)) {
            return 1.8F;
        }
        return 1.0f;
    }

    public static float getFactors(String unlocalizedName) {
        if (ListDevilFruits.centstr.contains(unlocalizedName)) {
            return 2F;
        } else if (ListDevilFruits.sixstr.contains(unlocalizedName)) {
            return 1.6F;
        } else if (!ListDevilFruits.sixstr.contains(unlocalizedName) && !ListDevilFruits.centstr.contains(unlocalizedName)) {
            return 1.8F;
        }
        return 1.0f;
    }
}
