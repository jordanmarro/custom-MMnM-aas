package xyz.pixelatedw.MineMineNoMi3.abilities.effects;

import org.lwjgl.opengl.GL11;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import xyz.pixelatedw.MineMineNoMi3.ID;

public class DFEffectZushiAbareHimatsuri extends DFEffect
{

	public DFEffectZushiAbareHimatsuri(EntityLivingBase entity, int timer)
	{
		super(entity, timer, ID.EXTRAEFFECT_ABAREHIMATSURI);
	}

	public void onEffectStart(EntityLivingBase entity)
	{

	}

	public void onEffectEnd(EntityLivingBase entity)
	{

	}

}
