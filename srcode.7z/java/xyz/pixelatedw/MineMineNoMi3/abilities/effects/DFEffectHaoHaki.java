package xyz.pixelatedw.MineMineNoMi3.abilities.effects;

import net.minecraft.entity.EntityLivingBase;
import xyz.pixelatedw.MineMineNoMi3.ID;

public class DFEffectHaoHaki extends DFEffect
{

	public DFEffectHaoHaki(EntityLivingBase entity, int timer)
	{
		super(entity, timer, ID.EXTRAEFFECT_HAO);
	}

	@Override
	public void onEffectStart(EntityLivingBase entity)
	{

	}

	@Override
	public void onEffectEnd(EntityLivingBase entity)
	{
		
	}
		
}