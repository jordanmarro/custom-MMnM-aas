package xyz.pixelatedw.MineMineNoMi3.events.devilfruits;

import java.util.ArrayList;
import java.util.Arrays;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.MainConfig;
import xyz.pixelatedw.MineMineNoMi3.MainMod;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityProperties;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.entities.particles.EntityParticleFX;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.items.AkumaNoMi;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSpecialFlying;

public class EventsSpecialFlying
{

	public static ArrayList<AkumaNoMi> fly = new ArrayList<AkumaNoMi>();


	@SubscribeEvent
	public void onEntityUpdate(LivingUpdateEvent event)
	{
		if (event.entityLiving instanceof EntityPlayer)
		{
			EntityPlayer player = (EntityPlayer) event.entityLiving;
			ExtendedEntityData props = ExtendedEntityData.get(player);
			AbilityProperties abilityProps = AbilityProperties.get(player);

			Ability abareHimatsuri = abilityProps.getAbilityFromName(ListAttributes.ABARE_HIMATSURI.getAttributeName());
			boolean hasAbareHimatsuri = props.getUsedFruit().equalsIgnoreCase("zushizushi") && abareHimatsuri != null && abareHimatsuri.isPassiveActive();


			Ability ride = abilityProps.getAbilityFromName(ListAttributes.LightningRide.getAttributeName());
			boolean hasRide = ride != null && ride.isPassiveActive();


			Ability ptera = abilityProps.getAbilityFromName(ListAttributes.PteraPoint.getAttributeName());
			boolean hasptera =
					ptera != null && ptera.isPassiveActive();


			Ability nupoint = abilityProps.getAbilityFromName(ListAttributes.NuePoint.getAttributeName());
			boolean hasNu = nupoint != null && nupoint.isPassiveActive();

			boolean hasToriFruit = props.getUsedFruit().equalsIgnoreCase("toritoriphoenix") && !props.getZoanPoint().toLowerCase().equals("n/a");
			boolean hasRyuFruit  = props.getUsedFruit().equalsIgnoreCase("ryuryunomi") && !props.getZoanPoint().toLowerCase().equals("n/a") || props.getZoanPoint().equalsIgnoreCase("dragon");

			boolean hasMera = props.getUsedFruit().equalsIgnoreCase("merameraawakened");







			boolean hasFlyingFruit = Arrays.stream(DevilFruitsHelper.flyingFruits).anyMatch(p ->
			{				
				return props.getUsedFruit().equalsIgnoreCase(p);
			});	
			
			if(!player.capabilities.isCreativeMode)
			{
				if(!event.entityLiving.worldObj.isRemote)
				{
					if(hasptera) {
						WyNetworkHelper.sendTo(new PacketSpecialFlying(true), (EntityPlayerMP) player);
						player.fallDistance = 0;
						player.addPotionEffect(new PotionEffect(Potion.resistance.id, 20 * 10, 1));
					}
					if((MainConfig.enableSpecialFlying && hasFlyingFruit && !DevilFruitsHelper.isNearbyKairoseki(player))||hasRyuFruit || hasToriFruit || hasRide || hasAbareHimatsuri || hasNu || hasptera || isFlyList() || hasMera)
					{
						WyNetworkHelper.sendTo(new PacketSpecialFlying(true), (EntityPlayerMP) player);
						player.fallDistance = 0;
					}
					else
						WyNetworkHelper.sendTo(new PacketSpecialFlying(false), (EntityPlayerMP) player);
				}
			
				if(player.capabilities.isFlying && player.worldObj.isRemote)
				{
					double extraOffset = 0;
					
					ResourceLocation particleToUse = null;
					if(props.getUsedFruit().equalsIgnoreCase("mokumoku") )
						particleToUse = ID.PARTICLE_ICON_MOKU;
					else if(props.getUsedFruit().equalsIgnoreCase("gasugasu") )
						particleToUse = ID.PARTICLE_ICON_GASU;
					else if(props.getUsedFruit().equalsIgnoreCase("sunasuna") )
						particleToUse = ID.PARTICLE_ICON_SUNA2;
					else if(props.getUsedFruit().equalsIgnoreCase("toritoriphoenix") )
					{
						particleToUse = ID.PARTICLE_ICON_BLUEFLAME;
						extraOffset = 1;
					}
					
					if(particleToUse != null)
					{
						for (int i = 0; i < 5; i++)
						{							
							double offsetX = 0.5 - player.worldObj.rand.nextDouble();
							double offsetY = player.worldObj.rand.nextDouble();
							double offsetZ = 0.5 - player.worldObj.rand.nextDouble();
							
							MainMod.proxy.spawnCustomParticles(player, 
									new EntityParticleFX(player.worldObj, particleToUse, 
											player.posX + offsetX, 
											player.posY - 2 + offsetY + extraOffset, 
											player.posZ + offsetZ, 
											0, 0, 0)
									.setParticleScale(1.3F).setParticleGravity(-0.05F).setParticleAge(5));
						}
					}
				}
			}
		}
	}

	private boolean isFlyList() {
		return false;
	}
}
