package xyz.pixelatedw.MineMineNoMi3.api.abilities.extra;

public enum EffectType
{
	USER,
	PROJECTILE,
	HIT,
	AOE;
}
