package xyz.pixelatedw.MineMineNoMi3.api.math;

public interface ICircle
{
	public void call(int paramInt1, int paramInt2);
}