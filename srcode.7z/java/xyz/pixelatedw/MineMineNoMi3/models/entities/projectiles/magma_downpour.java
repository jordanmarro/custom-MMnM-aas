package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

// Made with Blockbench 3.8.0
// Exported for Minecraft version 1.12
// Paste this class into your mod and generate all required imports


public class magma_downpour extends ModelBase {
    private final ModelRenderer bone81;
    private final ModelRenderer hand9;
    private final ModelRenderer fingers9;
    private final ModelRenderer bone33;
    private final ModelRenderer finger21_r1;
    private final ModelRenderer bone34;
    private final ModelRenderer finger31_r1;
    private final ModelRenderer bone35;
    private final ModelRenderer finger41_r1;
    private final ModelRenderer bone36;
    private final ModelRenderer finger51_r1;
    private final ModelRenderer thumb9;
    private final ModelRenderer cube_r25;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer hand4;
    private final ModelRenderer fingers4;
    private final ModelRenderer bone13;
    private final ModelRenderer finger16_r1;
    private final ModelRenderer bone14;
    private final ModelRenderer finger26_r1;
    private final ModelRenderer bone15;
    private final ModelRenderer finger36_r1;
    private final ModelRenderer bone16;
    private final ModelRenderer finger46_r1;
    private final ModelRenderer thumb4;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer hand;
    private final ModelRenderer fingers;
    private final ModelRenderer bone;
    private final ModelRenderer finger13_r1;
    private final ModelRenderer bone2;
    private final ModelRenderer finger23_r1;
    private final ModelRenderer bone3;
    private final ModelRenderer finger33_r1;
    private final ModelRenderer bone4;
    private final ModelRenderer finger43_r1;
    private final ModelRenderer thumb;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer hand2;
    private final ModelRenderer fingers2;
    private final ModelRenderer bone5;
    private final ModelRenderer finger14_r1;
    private final ModelRenderer bone6;
    private final ModelRenderer finger24_r1;
    private final ModelRenderer bone7;
    private final ModelRenderer finger34_r1;
    private final ModelRenderer bone8;
    private final ModelRenderer finger44_r1;
    private final ModelRenderer thumb2;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer hand3;
    private final ModelRenderer fingers3;
    private final ModelRenderer bone9;
    private final ModelRenderer finger15_r1;
    private final ModelRenderer bone10;
    private final ModelRenderer finger25_r1;
    private final ModelRenderer bone11;
    private final ModelRenderer finger35_r1;
    private final ModelRenderer bone12;
    private final ModelRenderer finger45_r1;
    private final ModelRenderer thumb3;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer hand5;
    private final ModelRenderer fingers5;
    private final ModelRenderer bone17;
    private final ModelRenderer finger17_r1;
    private final ModelRenderer bone18;
    private final ModelRenderer finger27_r1;
    private final ModelRenderer bone19;
    private final ModelRenderer finger37_r1;
    private final ModelRenderer bone20;
    private final ModelRenderer finger47_r1;
    private final ModelRenderer thumb5;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer hand6;
    private final ModelRenderer fingers6;
    private final ModelRenderer bone21;
    private final ModelRenderer finger18_r1;
    private final ModelRenderer bone22;
    private final ModelRenderer finger28_r1;
    private final ModelRenderer bone23;
    private final ModelRenderer finger38_r1;
    private final ModelRenderer bone24;
    private final ModelRenderer finger48_r1;
    private final ModelRenderer thumb6;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer hand10;
    private final ModelRenderer fingers10;
    private final ModelRenderer bone37;
    private final ModelRenderer finger22_r1;
    private final ModelRenderer bone38;
    private final ModelRenderer finger32_r1;
    private final ModelRenderer bone39;
    private final ModelRenderer finger42_r1;
    private final ModelRenderer bone40;
    private final ModelRenderer finger52_r1;
    private final ModelRenderer thumb10;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer hand11;
    private final ModelRenderer fingers11;
    private final ModelRenderer bone41;
    private final ModelRenderer finger23_r2;
    private final ModelRenderer bone42;
    private final ModelRenderer finger33_r2;
    private final ModelRenderer bone43;
    private final ModelRenderer finger43_r2;
    private final ModelRenderer bone44;
    private final ModelRenderer finger53_r1;
    private final ModelRenderer thumb11;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer hand7;
    private final ModelRenderer fingers7;
    private final ModelRenderer bone25;
    private final ModelRenderer finger19_r1;
    private final ModelRenderer bone26;
    private final ModelRenderer finger29_r1;
    private final ModelRenderer bone27;
    private final ModelRenderer finger39_r1;
    private final ModelRenderer bone28;
    private final ModelRenderer finger49_r1;
    private final ModelRenderer thumb7;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer hand12;
    private final ModelRenderer fingers12;
    private final ModelRenderer bone45;
    private final ModelRenderer finger24_r2;
    private final ModelRenderer bone46;
    private final ModelRenderer finger34_r2;
    private final ModelRenderer bone47;
    private final ModelRenderer finger44_r2;
    private final ModelRenderer bone48;
    private final ModelRenderer finger54_r1;
    private final ModelRenderer thumb12;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer hand8;
    private final ModelRenderer fingers8;
    private final ModelRenderer bone29;
    private final ModelRenderer finger20_r1;
    private final ModelRenderer bone30;
    private final ModelRenderer finger30_r1;
    private final ModelRenderer bone31;
    private final ModelRenderer finger40_r1;
    private final ModelRenderer bone32;
    private final ModelRenderer finger50_r1;
    private final ModelRenderer thumb8;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer hand20;
    private final ModelRenderer fingers20;
    private final ModelRenderer bone77;
    private final ModelRenderer finger16_r2;
    private final ModelRenderer bone78;
    private final ModelRenderer finger26_r3;
    private final ModelRenderer bone79;
    private final ModelRenderer finger36_r3;
    private final ModelRenderer bone80;
    private final ModelRenderer finger46_r3;
    private final ModelRenderer thumb20;
    private final ModelRenderer cube_r58;
    private final ModelRenderer cube_r59;
    private final ModelRenderer cube_r60;
    private final ModelRenderer hand13;
    private final ModelRenderer fingers13;
    private final ModelRenderer bone49;
    private final ModelRenderer finger25_r2;
    private final ModelRenderer bone50;
    private final ModelRenderer finger35_r2;
    private final ModelRenderer bone51;
    private final ModelRenderer finger45_r2;
    private final ModelRenderer bone52;
    private final ModelRenderer finger55_r1;
    private final ModelRenderer thumb13;
    private final ModelRenderer cube_r37;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer hand14;
    private final ModelRenderer fingers14;
    private final ModelRenderer bone53;
    private final ModelRenderer finger22_r2;
    private final ModelRenderer bone54;
    private final ModelRenderer finger32_r2;
    private final ModelRenderer bone55;
    private final ModelRenderer finger42_r2;
    private final ModelRenderer bone56;
    private final ModelRenderer finger52_r2;
    private final ModelRenderer thumb14;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer hand15;
    private final ModelRenderer fingers15;
    private final ModelRenderer bone57;
    private final ModelRenderer finger23_r3;
    private final ModelRenderer bone58;
    private final ModelRenderer finger33_r3;
    private final ModelRenderer bone59;
    private final ModelRenderer finger43_r3;
    private final ModelRenderer bone60;
    private final ModelRenderer finger53_r2;
    private final ModelRenderer thumb15;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer cube_r45;
    private final ModelRenderer hand16;
    private final ModelRenderer fingers16;
    private final ModelRenderer bone61;
    private final ModelRenderer finger24_r3;
    private final ModelRenderer bone62;
    private final ModelRenderer finger34_r3;
    private final ModelRenderer bone63;
    private final ModelRenderer finger44_r3;
    private final ModelRenderer bone64;
    private final ModelRenderer finger54_r2;
    private final ModelRenderer thumb16;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer cube_r48;
    private final ModelRenderer hand17;
    private final ModelRenderer fingers17;
    private final ModelRenderer bone65;
    private final ModelRenderer finger25_r3;
    private final ModelRenderer bone66;
    private final ModelRenderer finger35_r3;
    private final ModelRenderer bone67;
    private final ModelRenderer finger45_r3;
    private final ModelRenderer bone68;
    private final ModelRenderer finger55_r2;
    private final ModelRenderer thumb17;
    private final ModelRenderer cube_r49;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer hand18;
    private final ModelRenderer fingers18;
    private final ModelRenderer bone69;
    private final ModelRenderer finger26_r2;
    private final ModelRenderer bone70;
    private final ModelRenderer finger36_r2;
    private final ModelRenderer bone71;
    private final ModelRenderer finger46_r2;
    private final ModelRenderer bone72;
    private final ModelRenderer finger56_r1;
    private final ModelRenderer thumb18;
    private final ModelRenderer cube_r52;
    private final ModelRenderer cube_r53;
    private final ModelRenderer cube_r54;
    private final ModelRenderer hand19;
    private final ModelRenderer fingers19;
    private final ModelRenderer bone73;
    private final ModelRenderer finger15_r2;
    private final ModelRenderer bone74;
    private final ModelRenderer finger25_r4;
    private final ModelRenderer bone75;
    private final ModelRenderer finger35_r4;
    private final ModelRenderer bone76;
    private final ModelRenderer finger45_r4;
    private final ModelRenderer thumb19;
    private final ModelRenderer cube_r55;
    private final ModelRenderer cube_r56;
    private final ModelRenderer cube_r57;

    public magma_downpour() {
        textureWidth = 128;
        textureHeight = 128;

        bone81 = new ModelRenderer(this);
        bone81.setRotationPoint(-30.0F, -54.0F, 1.0F);
        setRotationAngle(bone81, -1.5272F, 0.0F, 0.0F);


        hand9 = new ModelRenderer(this);
        hand9.setRotationPoint(10.0F, 67.0F, -40.0F);
        bone81.addChild(hand9);
        setRotationAngle(hand9, 0.0F, -1.5708F, 0.0F);
        hand9.cubeList.add(new ModelBox(hand9, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand9.cubeList.add(new ModelBox(hand9, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers9 = new ModelRenderer(this);
        fingers9.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand9.addChild(fingers9);


        bone33 = new ModelRenderer(this);
        bone33.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone33);
        bone33.cubeList.add(new ModelBox(bone33, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone33.cubeList.add(new ModelBox(bone33, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger21_r1 = new ModelRenderer(this);
        finger21_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone33.addChild(finger21_r1);
        setRotationAngle(finger21_r1, 0.0F, 0.0F, -1.1345F);
        finger21_r1.cubeList.add(new ModelBox(finger21_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone34 = new ModelRenderer(this);
        bone34.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone34);
        bone34.cubeList.add(new ModelBox(bone34, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone34.cubeList.add(new ModelBox(bone34, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger31_r1 = new ModelRenderer(this);
        finger31_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone34.addChild(finger31_r1);
        setRotationAngle(finger31_r1, 0.0F, 0.0F, -1.1345F);
        finger31_r1.cubeList.add(new ModelBox(finger31_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone35 = new ModelRenderer(this);
        bone35.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone35);
        bone35.cubeList.add(new ModelBox(bone35, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone35.cubeList.add(new ModelBox(bone35, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger41_r1 = new ModelRenderer(this);
        finger41_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone35.addChild(finger41_r1);
        setRotationAngle(finger41_r1, 0.0F, 0.0F, -1.1345F);
        finger41_r1.cubeList.add(new ModelBox(finger41_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone36 = new ModelRenderer(this);
        bone36.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone36);
        bone36.cubeList.add(new ModelBox(bone36, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone36.cubeList.add(new ModelBox(bone36, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger51_r1 = new ModelRenderer(this);
        finger51_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone36.addChild(finger51_r1);
        setRotationAngle(finger51_r1, 0.0F, 0.0F, -1.1345F);
        finger51_r1.cubeList.add(new ModelBox(finger51_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb9 = new ModelRenderer(this);
        thumb9.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(thumb9);


        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb9.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.48F, 0.0F, -0.5236F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb9.addChild(cube_r26);
        setRotationAngle(cube_r26, -0.4363F, 0.0F, 0.0F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb9.addChild(cube_r27);
        setRotationAngle(cube_r27, -1.5708F, -0.6109F, 0.0F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand4 = new ModelRenderer(this);
        hand4.setRotationPoint(71.0F, 38.0F, 22.0F);
        bone81.addChild(hand4);
        setRotationAngle(hand4, 0.0F, -1.5708F, 0.0F);
        hand4.cubeList.add(new ModelBox(hand4, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand4.cubeList.add(new ModelBox(hand4, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers4 = new ModelRenderer(this);
        fingers4.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand4.addChild(fingers4);


        bone13 = new ModelRenderer(this);
        bone13.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone13);
        bone13.cubeList.add(new ModelBox(bone13, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone13.cubeList.add(new ModelBox(bone13, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger16_r1 = new ModelRenderer(this);
        finger16_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone13.addChild(finger16_r1);
        setRotationAngle(finger16_r1, 0.0F, 0.0F, -1.1345F);
        finger16_r1.cubeList.add(new ModelBox(finger16_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone14 = new ModelRenderer(this);
        bone14.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone14);
        bone14.cubeList.add(new ModelBox(bone14, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone14.cubeList.add(new ModelBox(bone14, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger26_r1 = new ModelRenderer(this);
        finger26_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone14.addChild(finger26_r1);
        setRotationAngle(finger26_r1, 0.0F, 0.0F, -1.1345F);
        finger26_r1.cubeList.add(new ModelBox(finger26_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone15 = new ModelRenderer(this);
        bone15.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone15);
        bone15.cubeList.add(new ModelBox(bone15, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone15.cubeList.add(new ModelBox(bone15, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger36_r1 = new ModelRenderer(this);
        finger36_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone15.addChild(finger36_r1);
        setRotationAngle(finger36_r1, 0.0F, 0.0F, -1.1345F);
        finger36_r1.cubeList.add(new ModelBox(finger36_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone16 = new ModelRenderer(this);
        bone16.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone16);
        bone16.cubeList.add(new ModelBox(bone16, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone16.cubeList.add(new ModelBox(bone16, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger46_r1 = new ModelRenderer(this);
        finger46_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone16.addChild(finger46_r1);
        setRotationAngle(finger46_r1, 0.0F, 0.0F, -1.1345F);
        finger46_r1.cubeList.add(new ModelBox(finger46_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb4 = new ModelRenderer(this);
        thumb4.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(thumb4);


        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb4.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.48F, 0.0F, -0.5236F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb4.addChild(cube_r11);
        setRotationAngle(cube_r11, -0.4363F, 0.0F, 0.0F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb4.addChild(cube_r12);
        setRotationAngle(cube_r12, -1.5708F, -0.6109F, 0.0F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand = new ModelRenderer(this);
        hand.setRotationPoint(29.0F, 93.0F, 6.0F);
        bone81.addChild(hand);
        setRotationAngle(hand, 0.0F, -1.5708F, 0.0F);
        hand.cubeList.add(new ModelBox(hand, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand.cubeList.add(new ModelBox(hand, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand.cubeList.add(new ModelBox(hand, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers = new ModelRenderer(this);
        fingers.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand.addChild(fingers);


        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone);
        bone.cubeList.add(new ModelBox(bone, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger13_r1 = new ModelRenderer(this);
        finger13_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone.addChild(finger13_r1);
        setRotationAngle(finger13_r1, 0.0F, 0.0F, -1.1345F);
        finger13_r1.cubeList.add(new ModelBox(finger13_r1, 40, 28, -7.5774F, -3.0937F, -2.0F, 4, 7, 3, 0.0F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone2);
        bone2.cubeList.add(new ModelBox(bone2, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone2.cubeList.add(new ModelBox(bone2, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger23_r1 = new ModelRenderer(this);
        finger23_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone2.addChild(finger23_r1);
        setRotationAngle(finger23_r1, 0.0F, 0.0F, -1.1345F);
        finger23_r1.cubeList.add(new ModelBox(finger23_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone3);
        bone3.cubeList.add(new ModelBox(bone3, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone3.cubeList.add(new ModelBox(bone3, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger33_r1 = new ModelRenderer(this);
        finger33_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone3.addChild(finger33_r1);
        setRotationAngle(finger33_r1, 0.0F, 0.0F, -1.1345F);
        finger33_r1.cubeList.add(new ModelBox(finger33_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone4);
        bone4.cubeList.add(new ModelBox(bone4, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone4.cubeList.add(new ModelBox(bone4, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger43_r1 = new ModelRenderer(this);
        finger43_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone4.addChild(finger43_r1);
        setRotationAngle(finger43_r1, 0.0F, 0.0F, -1.1345F);
        finger43_r1.cubeList.add(new ModelBox(finger43_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb = new ModelRenderer(this);
        thumb.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(thumb);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.48F, 0.0F, -0.5236F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb.addChild(cube_r2);
        setRotationAngle(cube_r2, -0.4363F, 0.0F, 0.0F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb.addChild(cube_r3);
        setRotationAngle(cube_r3, -1.5708F, -0.6109F, 0.0F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand2 = new ModelRenderer(this);
        hand2.setRotationPoint(29.0F, 16.0F, 38.0F);
        bone81.addChild(hand2);
        setRotationAngle(hand2, 0.0F, -1.5708F, 0.0F);
        hand2.cubeList.add(new ModelBox(hand2, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand2.cubeList.add(new ModelBox(hand2, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers2 = new ModelRenderer(this);
        fingers2.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand2.addChild(fingers2);


        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone5);
        bone5.cubeList.add(new ModelBox(bone5, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger14_r1 = new ModelRenderer(this);
        finger14_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone5.addChild(finger14_r1);
        setRotationAngle(finger14_r1, 0.0F, 0.0F, -1.1345F);
        finger14_r1.cubeList.add(new ModelBox(finger14_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone6);
        bone6.cubeList.add(new ModelBox(bone6, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone6.cubeList.add(new ModelBox(bone6, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger24_r1 = new ModelRenderer(this);
        finger24_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone6.addChild(finger24_r1);
        setRotationAngle(finger24_r1, 0.0F, 0.0F, -1.1345F);
        finger24_r1.cubeList.add(new ModelBox(finger24_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone7);
        bone7.cubeList.add(new ModelBox(bone7, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger34_r1 = new ModelRenderer(this);
        finger34_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone7.addChild(finger34_r1);
        setRotationAngle(finger34_r1, 0.0F, 0.0F, -1.1345F);
        finger34_r1.cubeList.add(new ModelBox(finger34_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone8);
        bone8.cubeList.add(new ModelBox(bone8, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone8.cubeList.add(new ModelBox(bone8, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger44_r1 = new ModelRenderer(this);
        finger44_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone8.addChild(finger44_r1);
        setRotationAngle(finger44_r1, 0.0F, 0.0F, -1.1345F);
        finger44_r1.cubeList.add(new ModelBox(finger44_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb2 = new ModelRenderer(this);
        thumb2.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(thumb2);


        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb2.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.48F, 0.0F, -0.5236F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb2.addChild(cube_r5);
        setRotationAngle(cube_r5, -0.4363F, 0.0F, 0.0F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb2.addChild(cube_r6);
        setRotationAngle(cube_r6, -1.5708F, -0.6109F, 0.0F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand3 = new ModelRenderer(this);
        hand3.setRotationPoint(20.0F, 32.0F, -17.0F);
        bone81.addChild(hand3);
        setRotationAngle(hand3, 0.0F, -1.5708F, 0.0F);
        hand3.cubeList.add(new ModelBox(hand3, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand3.cubeList.add(new ModelBox(hand3, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers3 = new ModelRenderer(this);
        fingers3.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand3.addChild(fingers3);


        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone9);
        bone9.cubeList.add(new ModelBox(bone9, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone9.cubeList.add(new ModelBox(bone9, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger15_r1 = new ModelRenderer(this);
        finger15_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone9.addChild(finger15_r1);
        setRotationAngle(finger15_r1, 0.0F, 0.0F, -1.1345F);
        finger15_r1.cubeList.add(new ModelBox(finger15_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone10);
        bone10.cubeList.add(new ModelBox(bone10, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone10.cubeList.add(new ModelBox(bone10, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger25_r1 = new ModelRenderer(this);
        finger25_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone10.addChild(finger25_r1);
        setRotationAngle(finger25_r1, 0.0F, 0.0F, -1.1345F);
        finger25_r1.cubeList.add(new ModelBox(finger25_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone11 = new ModelRenderer(this);
        bone11.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone11);
        bone11.cubeList.add(new ModelBox(bone11, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone11.cubeList.add(new ModelBox(bone11, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger35_r1 = new ModelRenderer(this);
        finger35_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone11.addChild(finger35_r1);
        setRotationAngle(finger35_r1, 0.0F, 0.0F, -1.1345F);
        finger35_r1.cubeList.add(new ModelBox(finger35_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone12 = new ModelRenderer(this);
        bone12.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone12);
        bone12.cubeList.add(new ModelBox(bone12, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone12.cubeList.add(new ModelBox(bone12, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger45_r1 = new ModelRenderer(this);
        finger45_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone12.addChild(finger45_r1);
        setRotationAngle(finger45_r1, 0.0F, 0.0F, -1.1345F);
        finger45_r1.cubeList.add(new ModelBox(finger45_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb3 = new ModelRenderer(this);
        thumb3.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(thumb3);


        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb3.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.48F, 0.0F, -0.5236F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb3.addChild(cube_r8);
        setRotationAngle(cube_r8, -0.4363F, 0.0F, 0.0F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb3.addChild(cube_r9);
        setRotationAngle(cube_r9, -1.5708F, -0.6109F, 0.0F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand5 = new ModelRenderer(this);
        hand5.setRotationPoint(3.0F, 57.0F, 6.0F);
        bone81.addChild(hand5);
        setRotationAngle(hand5, 0.0F, -1.5708F, 0.0F);
        hand5.cubeList.add(new ModelBox(hand5, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand5.cubeList.add(new ModelBox(hand5, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers5 = new ModelRenderer(this);
        fingers5.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand5.addChild(fingers5);


        bone17 = new ModelRenderer(this);
        bone17.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone17);
        bone17.cubeList.add(new ModelBox(bone17, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone17.cubeList.add(new ModelBox(bone17, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger17_r1 = new ModelRenderer(this);
        finger17_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone17.addChild(finger17_r1);
        setRotationAngle(finger17_r1, 0.0F, 0.0F, -1.1345F);
        finger17_r1.cubeList.add(new ModelBox(finger17_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone18 = new ModelRenderer(this);
        bone18.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone18);
        bone18.cubeList.add(new ModelBox(bone18, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone18.cubeList.add(new ModelBox(bone18, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger27_r1 = new ModelRenderer(this);
        finger27_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone18.addChild(finger27_r1);
        setRotationAngle(finger27_r1, 0.0F, 0.0F, -1.1345F);
        finger27_r1.cubeList.add(new ModelBox(finger27_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone19 = new ModelRenderer(this);
        bone19.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone19);
        bone19.cubeList.add(new ModelBox(bone19, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone19.cubeList.add(new ModelBox(bone19, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger37_r1 = new ModelRenderer(this);
        finger37_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone19.addChild(finger37_r1);
        setRotationAngle(finger37_r1, 0.0F, 0.0F, -1.1345F);
        finger37_r1.cubeList.add(new ModelBox(finger37_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone20 = new ModelRenderer(this);
        bone20.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone20);
        bone20.cubeList.add(new ModelBox(bone20, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone20.cubeList.add(new ModelBox(bone20, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger47_r1 = new ModelRenderer(this);
        finger47_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone20.addChild(finger47_r1);
        setRotationAngle(finger47_r1, 0.0F, 0.0F, -1.1345F);
        finger47_r1.cubeList.add(new ModelBox(finger47_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb5 = new ModelRenderer(this);
        thumb5.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(thumb5);


        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb5.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.48F, 0.0F, -0.5236F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb5.addChild(cube_r14);
        setRotationAngle(cube_r14, -0.4363F, 0.0F, 0.0F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb5.addChild(cube_r15);
        setRotationAngle(cube_r15, -1.5708F, -0.6109F, 0.0F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand6 = new ModelRenderer(this);
        hand6.setRotationPoint(-25.0F, 59.0F, 35.0F);
        bone81.addChild(hand6);
        setRotationAngle(hand6, 0.0F, -1.5708F, 0.0F);
        hand6.cubeList.add(new ModelBox(hand6, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand6.cubeList.add(new ModelBox(hand6, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers6 = new ModelRenderer(this);
        fingers6.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand6.addChild(fingers6);


        bone21 = new ModelRenderer(this);
        bone21.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone21);
        bone21.cubeList.add(new ModelBox(bone21, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone21.cubeList.add(new ModelBox(bone21, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger18_r1 = new ModelRenderer(this);
        finger18_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone21.addChild(finger18_r1);
        setRotationAngle(finger18_r1, 0.0F, 0.0F, -1.1345F);
        finger18_r1.cubeList.add(new ModelBox(finger18_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone22 = new ModelRenderer(this);
        bone22.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone22);
        bone22.cubeList.add(new ModelBox(bone22, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone22.cubeList.add(new ModelBox(bone22, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger28_r1 = new ModelRenderer(this);
        finger28_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone22.addChild(finger28_r1);
        setRotationAngle(finger28_r1, 0.0F, 0.0F, -1.1345F);
        finger28_r1.cubeList.add(new ModelBox(finger28_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone23 = new ModelRenderer(this);
        bone23.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone23);
        bone23.cubeList.add(new ModelBox(bone23, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone23.cubeList.add(new ModelBox(bone23, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger38_r1 = new ModelRenderer(this);
        finger38_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone23.addChild(finger38_r1);
        setRotationAngle(finger38_r1, 0.0F, 0.0F, -1.1345F);
        finger38_r1.cubeList.add(new ModelBox(finger38_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone24 = new ModelRenderer(this);
        bone24.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone24);
        bone24.cubeList.add(new ModelBox(bone24, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone24.cubeList.add(new ModelBox(bone24, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger48_r1 = new ModelRenderer(this);
        finger48_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone24.addChild(finger48_r1);
        setRotationAngle(finger48_r1, 0.0F, 0.0F, -1.1345F);
        finger48_r1.cubeList.add(new ModelBox(finger48_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb6 = new ModelRenderer(this);
        thumb6.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(thumb6);


        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb6.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.48F, 0.0F, -0.5236F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb6.addChild(cube_r17);
        setRotationAngle(cube_r17, -0.4363F, 0.0F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb6.addChild(cube_r18);
        setRotationAngle(cube_r18, -1.5708F, -0.6109F, 0.0F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand10 = new ModelRenderer(this);
        hand10.setRotationPoint(46.0F, 87.0F, -34.0F);
        bone81.addChild(hand10);
        setRotationAngle(hand10, 0.0F, -1.5708F, 0.0F);
        hand10.cubeList.add(new ModelBox(hand10, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand10.cubeList.add(new ModelBox(hand10, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers10 = new ModelRenderer(this);
        fingers10.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand10.addChild(fingers10);


        bone37 = new ModelRenderer(this);
        bone37.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone37);
        bone37.cubeList.add(new ModelBox(bone37, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone37.cubeList.add(new ModelBox(bone37, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger22_r1 = new ModelRenderer(this);
        finger22_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone37.addChild(finger22_r1);
        setRotationAngle(finger22_r1, 0.0F, 0.0F, -1.1345F);
        finger22_r1.cubeList.add(new ModelBox(finger22_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone38 = new ModelRenderer(this);
        bone38.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone38);
        bone38.cubeList.add(new ModelBox(bone38, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone38.cubeList.add(new ModelBox(bone38, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger32_r1 = new ModelRenderer(this);
        finger32_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone38.addChild(finger32_r1);
        setRotationAngle(finger32_r1, 0.0F, 0.0F, -1.1345F);
        finger32_r1.cubeList.add(new ModelBox(finger32_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone39 = new ModelRenderer(this);
        bone39.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone39);
        bone39.cubeList.add(new ModelBox(bone39, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone39.cubeList.add(new ModelBox(bone39, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger42_r1 = new ModelRenderer(this);
        finger42_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone39.addChild(finger42_r1);
        setRotationAngle(finger42_r1, 0.0F, 0.0F, -1.1345F);
        finger42_r1.cubeList.add(new ModelBox(finger42_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone40 = new ModelRenderer(this);
        bone40.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone40);
        bone40.cubeList.add(new ModelBox(bone40, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone40.cubeList.add(new ModelBox(bone40, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger52_r1 = new ModelRenderer(this);
        finger52_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone40.addChild(finger52_r1);
        setRotationAngle(finger52_r1, 0.0F, 0.0F, -1.1345F);
        finger52_r1.cubeList.add(new ModelBox(finger52_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb10 = new ModelRenderer(this);
        thumb10.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(thumb10);


        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb10.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.48F, 0.0F, -0.5236F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb10.addChild(cube_r29);
        setRotationAngle(cube_r29, -0.4363F, 0.0F, 0.0F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb10.addChild(cube_r30);
        setRotationAngle(cube_r30, -1.5708F, -0.6109F, 0.0F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand11 = new ModelRenderer(this);
        hand11.setRotationPoint(49.0F, 87.0F, 29.0F);
        bone81.addChild(hand11);
        setRotationAngle(hand11, 0.0F, -1.5708F, 0.0F);
        hand11.cubeList.add(new ModelBox(hand11, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand11.cubeList.add(new ModelBox(hand11, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers11 = new ModelRenderer(this);
        fingers11.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand11.addChild(fingers11);


        bone41 = new ModelRenderer(this);
        bone41.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone41);
        bone41.cubeList.add(new ModelBox(bone41, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone41.cubeList.add(new ModelBox(bone41, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger23_r2 = new ModelRenderer(this);
        finger23_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone41.addChild(finger23_r2);
        setRotationAngle(finger23_r2, 0.0F, 0.0F, -1.1345F);
        finger23_r2.cubeList.add(new ModelBox(finger23_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone42 = new ModelRenderer(this);
        bone42.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone42);
        bone42.cubeList.add(new ModelBox(bone42, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone42.cubeList.add(new ModelBox(bone42, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger33_r2 = new ModelRenderer(this);
        finger33_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone42.addChild(finger33_r2);
        setRotationAngle(finger33_r2, 0.0F, 0.0F, -1.1345F);
        finger33_r2.cubeList.add(new ModelBox(finger33_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone43 = new ModelRenderer(this);
        bone43.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone43);
        bone43.cubeList.add(new ModelBox(bone43, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone43.cubeList.add(new ModelBox(bone43, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger43_r2 = new ModelRenderer(this);
        finger43_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone43.addChild(finger43_r2);
        setRotationAngle(finger43_r2, 0.0F, 0.0F, -1.1345F);
        finger43_r2.cubeList.add(new ModelBox(finger43_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone44 = new ModelRenderer(this);
        bone44.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone44);
        bone44.cubeList.add(new ModelBox(bone44, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone44.cubeList.add(new ModelBox(bone44, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger53_r1 = new ModelRenderer(this);
        finger53_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone44.addChild(finger53_r1);
        setRotationAngle(finger53_r1, 0.0F, 0.0F, -1.1345F);
        finger53_r1.cubeList.add(new ModelBox(finger53_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb11 = new ModelRenderer(this);
        thumb11.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(thumb11);


        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb11.addChild(cube_r31);
        setRotationAngle(cube_r31, 0.48F, 0.0F, -0.5236F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb11.addChild(cube_r32);
        setRotationAngle(cube_r32, -0.4363F, 0.0F, 0.0F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb11.addChild(cube_r33);
        setRotationAngle(cube_r33, -1.5708F, -0.6109F, 0.0F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand7 = new ModelRenderer(this);
        hand7.setRotationPoint(-23.0F, 44.0F, -11.0F);
        bone81.addChild(hand7);
        setRotationAngle(hand7, 0.0F, -1.5708F, 0.0F);
        hand7.cubeList.add(new ModelBox(hand7, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand7.cubeList.add(new ModelBox(hand7, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers7 = new ModelRenderer(this);
        fingers7.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand7.addChild(fingers7);


        bone25 = new ModelRenderer(this);
        bone25.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone25);
        bone25.cubeList.add(new ModelBox(bone25, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone25.cubeList.add(new ModelBox(bone25, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger19_r1 = new ModelRenderer(this);
        finger19_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone25.addChild(finger19_r1);
        setRotationAngle(finger19_r1, 0.0F, 0.0F, -1.1345F);
        finger19_r1.cubeList.add(new ModelBox(finger19_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone26 = new ModelRenderer(this);
        bone26.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone26);
        bone26.cubeList.add(new ModelBox(bone26, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone26.cubeList.add(new ModelBox(bone26, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger29_r1 = new ModelRenderer(this);
        finger29_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone26.addChild(finger29_r1);
        setRotationAngle(finger29_r1, 0.0F, 0.0F, -1.1345F);
        finger29_r1.cubeList.add(new ModelBox(finger29_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone27 = new ModelRenderer(this);
        bone27.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone27);
        bone27.cubeList.add(new ModelBox(bone27, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone27.cubeList.add(new ModelBox(bone27, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger39_r1 = new ModelRenderer(this);
        finger39_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone27.addChild(finger39_r1);
        setRotationAngle(finger39_r1, 0.0F, 0.0F, -1.1345F);
        finger39_r1.cubeList.add(new ModelBox(finger39_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone28 = new ModelRenderer(this);
        bone28.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone28);
        bone28.cubeList.add(new ModelBox(bone28, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone28.cubeList.add(new ModelBox(bone28, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger49_r1 = new ModelRenderer(this);
        finger49_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone28.addChild(finger49_r1);
        setRotationAngle(finger49_r1, 0.0F, 0.0F, -1.1345F);
        finger49_r1.cubeList.add(new ModelBox(finger49_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb7 = new ModelRenderer(this);
        thumb7.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(thumb7);


        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb7.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.48F, 0.0F, -0.5236F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb7.addChild(cube_r20);
        setRotationAngle(cube_r20, -0.4363F, 0.0F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb7.addChild(cube_r21);
        setRotationAngle(cube_r21, -1.5708F, -0.6109F, 0.0F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand12 = new ModelRenderer(this);
        hand12.setRotationPoint(13.0F, 70.0F, 65.0F);
        bone81.addChild(hand12);
        setRotationAngle(hand12, 0.0F, -1.5708F, 0.0F);
        hand12.cubeList.add(new ModelBox(hand12, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand12.cubeList.add(new ModelBox(hand12, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers12 = new ModelRenderer(this);
        fingers12.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand12.addChild(fingers12);


        bone45 = new ModelRenderer(this);
        bone45.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone45);
        bone45.cubeList.add(new ModelBox(bone45, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone45.cubeList.add(new ModelBox(bone45, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger24_r2 = new ModelRenderer(this);
        finger24_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone45.addChild(finger24_r2);
        setRotationAngle(finger24_r2, 0.0F, 0.0F, -1.1345F);
        finger24_r2.cubeList.add(new ModelBox(finger24_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone46 = new ModelRenderer(this);
        bone46.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone46);
        bone46.cubeList.add(new ModelBox(bone46, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone46.cubeList.add(new ModelBox(bone46, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger34_r2 = new ModelRenderer(this);
        finger34_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone46.addChild(finger34_r2);
        setRotationAngle(finger34_r2, 0.0F, 0.0F, -1.1345F);
        finger34_r2.cubeList.add(new ModelBox(finger34_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone47 = new ModelRenderer(this);
        bone47.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone47);
        bone47.cubeList.add(new ModelBox(bone47, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone47.cubeList.add(new ModelBox(bone47, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger44_r2 = new ModelRenderer(this);
        finger44_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone47.addChild(finger44_r2);
        setRotationAngle(finger44_r2, 0.0F, 0.0F, -1.1345F);
        finger44_r2.cubeList.add(new ModelBox(finger44_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone48 = new ModelRenderer(this);
        bone48.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone48);
        bone48.cubeList.add(new ModelBox(bone48, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone48.cubeList.add(new ModelBox(bone48, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger54_r1 = new ModelRenderer(this);
        finger54_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone48.addChild(finger54_r1);
        setRotationAngle(finger54_r1, 0.0F, 0.0F, -1.1345F);
        finger54_r1.cubeList.add(new ModelBox(finger54_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb12 = new ModelRenderer(this);
        thumb12.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(thumb12);


        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb12.addChild(cube_r34);
        setRotationAngle(cube_r34, 0.48F, 0.0F, -0.5236F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb12.addChild(cube_r35);
        setRotationAngle(cube_r35, -0.4363F, 0.0F, 0.0F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb12.addChild(cube_r36);
        setRotationAngle(cube_r36, -1.5708F, -0.6109F, 0.0F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand8 = new ModelRenderer(this);
        hand8.setRotationPoint(67.0F, 70.0F, -24.0F);
        bone81.addChild(hand8);
        setRotationAngle(hand8, 0.0F, -1.5708F, 0.0F);
        hand8.cubeList.add(new ModelBox(hand8, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand8.cubeList.add(new ModelBox(hand8, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers8 = new ModelRenderer(this);
        fingers8.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand8.addChild(fingers8);


        bone29 = new ModelRenderer(this);
        bone29.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone29);
        bone29.cubeList.add(new ModelBox(bone29, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone29.cubeList.add(new ModelBox(bone29, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger20_r1 = new ModelRenderer(this);
        finger20_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone29.addChild(finger20_r1);
        setRotationAngle(finger20_r1, 0.0F, 0.0F, -1.1345F);
        finger20_r1.cubeList.add(new ModelBox(finger20_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone30 = new ModelRenderer(this);
        bone30.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone30);
        bone30.cubeList.add(new ModelBox(bone30, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone30.cubeList.add(new ModelBox(bone30, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger30_r1 = new ModelRenderer(this);
        finger30_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone30.addChild(finger30_r1);
        setRotationAngle(finger30_r1, 0.0F, 0.0F, -1.1345F);
        finger30_r1.cubeList.add(new ModelBox(finger30_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone31 = new ModelRenderer(this);
        bone31.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone31);
        bone31.cubeList.add(new ModelBox(bone31, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone31.cubeList.add(new ModelBox(bone31, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger40_r1 = new ModelRenderer(this);
        finger40_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone31.addChild(finger40_r1);
        setRotationAngle(finger40_r1, 0.0F, 0.0F, -1.1345F);
        finger40_r1.cubeList.add(new ModelBox(finger40_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone32 = new ModelRenderer(this);
        bone32.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone32);
        bone32.cubeList.add(new ModelBox(bone32, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone32.cubeList.add(new ModelBox(bone32, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger50_r1 = new ModelRenderer(this);
        finger50_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone32.addChild(finger50_r1);
        setRotationAngle(finger50_r1, 0.0F, 0.0F, -1.1345F);
        finger50_r1.cubeList.add(new ModelBox(finger50_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb8 = new ModelRenderer(this);
        thumb8.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(thumb8);


        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb8.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.48F, 0.0F, -0.5236F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb8.addChild(cube_r23);
        setRotationAngle(cube_r23, -0.4363F, 0.0F, 0.0F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb8.addChild(cube_r24);
        setRotationAngle(cube_r24, -1.5708F, -0.6109F, 0.0F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand20 = new ModelRenderer(this);
        hand20.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone81.addChild(hand20);
        setRotationAngle(hand20, 0.0F, -1.5708F, 0.0F);
        hand20.cubeList.add(new ModelBox(hand20, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand20.cubeList.add(new ModelBox(hand20, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers20 = new ModelRenderer(this);
        fingers20.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand20.addChild(fingers20);


        bone77 = new ModelRenderer(this);
        bone77.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone77);
        bone77.cubeList.add(new ModelBox(bone77, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone77.cubeList.add(new ModelBox(bone77, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger16_r2 = new ModelRenderer(this);
        finger16_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone77.addChild(finger16_r2);
        setRotationAngle(finger16_r2, 0.0F, 0.0F, -1.1345F);
        finger16_r2.cubeList.add(new ModelBox(finger16_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone78 = new ModelRenderer(this);
        bone78.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone78);
        bone78.cubeList.add(new ModelBox(bone78, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone78.cubeList.add(new ModelBox(bone78, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger26_r3 = new ModelRenderer(this);
        finger26_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone78.addChild(finger26_r3);
        setRotationAngle(finger26_r3, 0.0F, 0.0F, -1.1345F);
        finger26_r3.cubeList.add(new ModelBox(finger26_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone79 = new ModelRenderer(this);
        bone79.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone79);
        bone79.cubeList.add(new ModelBox(bone79, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone79.cubeList.add(new ModelBox(bone79, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger36_r3 = new ModelRenderer(this);
        finger36_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone79.addChild(finger36_r3);
        setRotationAngle(finger36_r3, 0.0F, 0.0F, -1.1345F);
        finger36_r3.cubeList.add(new ModelBox(finger36_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone80 = new ModelRenderer(this);
        bone80.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone80);
        bone80.cubeList.add(new ModelBox(bone80, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone80.cubeList.add(new ModelBox(bone80, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger46_r3 = new ModelRenderer(this);
        finger46_r3.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone80.addChild(finger46_r3);
        setRotationAngle(finger46_r3, 0.0F, 0.0F, -1.1345F);
        finger46_r3.cubeList.add(new ModelBox(finger46_r3, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb20 = new ModelRenderer(this);
        thumb20.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(thumb20);


        cube_r58 = new ModelRenderer(this);
        cube_r58.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb20.addChild(cube_r58);
        setRotationAngle(cube_r58, 0.48F, 0.0F, -0.5236F);
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r59 = new ModelRenderer(this);
        cube_r59.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb20.addChild(cube_r59);
        setRotationAngle(cube_r59, -0.4363F, 0.0F, 0.0F);
        cube_r59.cubeList.add(new ModelBox(cube_r59, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r60 = new ModelRenderer(this);
        cube_r60.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb20.addChild(cube_r60);
        setRotationAngle(cube_r60, -1.5708F, -0.6109F, 0.0F);
        cube_r60.cubeList.add(new ModelBox(cube_r60, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand13 = new ModelRenderer(this);
        hand13.setRotationPoint(58.0F, 76.0F, 59.0F);
        bone81.addChild(hand13);
        setRotationAngle(hand13, 0.0F, -1.5708F, 0.0F);
        hand13.cubeList.add(new ModelBox(hand13, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand13.cubeList.add(new ModelBox(hand13, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers13 = new ModelRenderer(this);
        fingers13.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand13.addChild(fingers13);


        bone49 = new ModelRenderer(this);
        bone49.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone49);
        bone49.cubeList.add(new ModelBox(bone49, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone49.cubeList.add(new ModelBox(bone49, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger25_r2 = new ModelRenderer(this);
        finger25_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone49.addChild(finger25_r2);
        setRotationAngle(finger25_r2, 0.0F, 0.0F, -1.1345F);
        finger25_r2.cubeList.add(new ModelBox(finger25_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone50 = new ModelRenderer(this);
        bone50.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone50);
        bone50.cubeList.add(new ModelBox(bone50, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone50.cubeList.add(new ModelBox(bone50, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger35_r2 = new ModelRenderer(this);
        finger35_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone50.addChild(finger35_r2);
        setRotationAngle(finger35_r2, 0.0F, 0.0F, -1.1345F);
        finger35_r2.cubeList.add(new ModelBox(finger35_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone51 = new ModelRenderer(this);
        bone51.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone51);
        bone51.cubeList.add(new ModelBox(bone51, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone51.cubeList.add(new ModelBox(bone51, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger45_r2 = new ModelRenderer(this);
        finger45_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone51.addChild(finger45_r2);
        setRotationAngle(finger45_r2, 0.0F, 0.0F, -1.1345F);
        finger45_r2.cubeList.add(new ModelBox(finger45_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone52 = new ModelRenderer(this);
        bone52.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone52);
        bone52.cubeList.add(new ModelBox(bone52, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone52.cubeList.add(new ModelBox(bone52, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger55_r1 = new ModelRenderer(this);
        finger55_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone52.addChild(finger55_r1);
        setRotationAngle(finger55_r1, 0.0F, 0.0F, -1.1345F);
        finger55_r1.cubeList.add(new ModelBox(finger55_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb13 = new ModelRenderer(this);
        thumb13.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(thumb13);


        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb13.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.48F, 0.0F, -0.5236F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb13.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.4363F, 0.0F, 0.0F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb13.addChild(cube_r39);
        setRotationAngle(cube_r39, -1.5708F, -0.6109F, 0.0F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand14 = new ModelRenderer(this);
        hand14.setRotationPoint(26.0F, 87.0F, -52.0F);
        bone81.addChild(hand14);
        setRotationAngle(hand14, 0.0F, -1.5708F, 0.0F);
        hand14.cubeList.add(new ModelBox(hand14, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand14.cubeList.add(new ModelBox(hand14, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers14 = new ModelRenderer(this);
        fingers14.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand14.addChild(fingers14);


        bone53 = new ModelRenderer(this);
        bone53.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone53);
        bone53.cubeList.add(new ModelBox(bone53, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone53.cubeList.add(new ModelBox(bone53, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger22_r2 = new ModelRenderer(this);
        finger22_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone53.addChild(finger22_r2);
        setRotationAngle(finger22_r2, 0.0F, 0.0F, -1.1345F);
        finger22_r2.cubeList.add(new ModelBox(finger22_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone54 = new ModelRenderer(this);
        bone54.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone54);
        bone54.cubeList.add(new ModelBox(bone54, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone54.cubeList.add(new ModelBox(bone54, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger32_r2 = new ModelRenderer(this);
        finger32_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone54.addChild(finger32_r2);
        setRotationAngle(finger32_r2, 0.0F, 0.0F, -1.1345F);
        finger32_r2.cubeList.add(new ModelBox(finger32_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone55 = new ModelRenderer(this);
        bone55.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone55);
        bone55.cubeList.add(new ModelBox(bone55, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone55.cubeList.add(new ModelBox(bone55, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger42_r2 = new ModelRenderer(this);
        finger42_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone55.addChild(finger42_r2);
        setRotationAngle(finger42_r2, 0.0F, 0.0F, -1.1345F);
        finger42_r2.cubeList.add(new ModelBox(finger42_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone56 = new ModelRenderer(this);
        bone56.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone56);
        bone56.cubeList.add(new ModelBox(bone56, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone56.cubeList.add(new ModelBox(bone56, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger52_r2 = new ModelRenderer(this);
        finger52_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone56.addChild(finger52_r2);
        setRotationAngle(finger52_r2, 0.0F, 0.0F, -1.1345F);
        finger52_r2.cubeList.add(new ModelBox(finger52_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb14 = new ModelRenderer(this);
        thumb14.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(thumb14);


        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb14.addChild(cube_r40);
        setRotationAngle(cube_r40, 0.48F, 0.0F, -0.5236F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb14.addChild(cube_r41);
        setRotationAngle(cube_r41, -0.4363F, 0.0F, 0.0F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb14.addChild(cube_r42);
        setRotationAngle(cube_r42, -1.5708F, -0.6109F, 0.0F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand15 = new ModelRenderer(this);
        hand15.setRotationPoint(-10.0F, 87.0F, -26.0F);
        bone81.addChild(hand15);
        setRotationAngle(hand15, 0.0F, -1.5708F, 0.0F);
        hand15.cubeList.add(new ModelBox(hand15, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand15.cubeList.add(new ModelBox(hand15, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers15 = new ModelRenderer(this);
        fingers15.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand15.addChild(fingers15);


        bone57 = new ModelRenderer(this);
        bone57.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone57);
        bone57.cubeList.add(new ModelBox(bone57, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone57.cubeList.add(new ModelBox(bone57, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger23_r3 = new ModelRenderer(this);
        finger23_r3.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone57.addChild(finger23_r3);
        setRotationAngle(finger23_r3, 0.0F, 0.0F, -1.1345F);
        finger23_r3.cubeList.add(new ModelBox(finger23_r3, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone58 = new ModelRenderer(this);
        bone58.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone58);
        bone58.cubeList.add(new ModelBox(bone58, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone58.cubeList.add(new ModelBox(bone58, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger33_r3 = new ModelRenderer(this);
        finger33_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone58.addChild(finger33_r3);
        setRotationAngle(finger33_r3, 0.0F, 0.0F, -1.1345F);
        finger33_r3.cubeList.add(new ModelBox(finger33_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone59 = new ModelRenderer(this);
        bone59.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone59);
        bone59.cubeList.add(new ModelBox(bone59, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone59.cubeList.add(new ModelBox(bone59, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger43_r3 = new ModelRenderer(this);
        finger43_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone59.addChild(finger43_r3);
        setRotationAngle(finger43_r3, 0.0F, 0.0F, -1.1345F);
        finger43_r3.cubeList.add(new ModelBox(finger43_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone60 = new ModelRenderer(this);
        bone60.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone60);
        bone60.cubeList.add(new ModelBox(bone60, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone60.cubeList.add(new ModelBox(bone60, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger53_r2 = new ModelRenderer(this);
        finger53_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone60.addChild(finger53_r2);
        setRotationAngle(finger53_r2, 0.0F, 0.0F, -1.1345F);
        finger53_r2.cubeList.add(new ModelBox(finger53_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb15 = new ModelRenderer(this);
        thumb15.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(thumb15);


        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb15.addChild(cube_r43);
        setRotationAngle(cube_r43, 0.48F, 0.0F, -0.5236F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb15.addChild(cube_r44);
        setRotationAngle(cube_r44, -0.4363F, 0.0F, 0.0F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb15.addChild(cube_r45);
        setRotationAngle(cube_r45, -1.5708F, -0.6109F, 0.0F);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand16 = new ModelRenderer(this);
        hand16.setRotationPoint(56.0F, 110.0F, -15.0F);
        bone81.addChild(hand16);
        setRotationAngle(hand16, 0.0F, -1.5708F, 0.0F);
        hand16.cubeList.add(new ModelBox(hand16, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand16.cubeList.add(new ModelBox(hand16, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers16 = new ModelRenderer(this);
        fingers16.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand16.addChild(fingers16);


        bone61 = new ModelRenderer(this);
        bone61.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone61);
        bone61.cubeList.add(new ModelBox(bone61, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone61.cubeList.add(new ModelBox(bone61, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger24_r3 = new ModelRenderer(this);
        finger24_r3.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone61.addChild(finger24_r3);
        setRotationAngle(finger24_r3, 0.0F, 0.0F, -1.1345F);
        finger24_r3.cubeList.add(new ModelBox(finger24_r3, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone62 = new ModelRenderer(this);
        bone62.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone62);
        bone62.cubeList.add(new ModelBox(bone62, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone62.cubeList.add(new ModelBox(bone62, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger34_r3 = new ModelRenderer(this);
        finger34_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone62.addChild(finger34_r3);
        setRotationAngle(finger34_r3, 0.0F, 0.0F, -1.1345F);
        finger34_r3.cubeList.add(new ModelBox(finger34_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone63 = new ModelRenderer(this);
        bone63.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone63);
        bone63.cubeList.add(new ModelBox(bone63, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone63.cubeList.add(new ModelBox(bone63, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger44_r3 = new ModelRenderer(this);
        finger44_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone63.addChild(finger44_r3);
        setRotationAngle(finger44_r3, 0.0F, 0.0F, -1.1345F);
        finger44_r3.cubeList.add(new ModelBox(finger44_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone64 = new ModelRenderer(this);
        bone64.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone64);
        bone64.cubeList.add(new ModelBox(bone64, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone64.cubeList.add(new ModelBox(bone64, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger54_r2 = new ModelRenderer(this);
        finger54_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone64.addChild(finger54_r2);
        setRotationAngle(finger54_r2, 0.0F, 0.0F, -1.1345F);
        finger54_r2.cubeList.add(new ModelBox(finger54_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb16 = new ModelRenderer(this);
        thumb16.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(thumb16);


        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb16.addChild(cube_r46);
        setRotationAngle(cube_r46, 0.48F, 0.0F, -0.5236F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb16.addChild(cube_r47);
        setRotationAngle(cube_r47, -0.4363F, 0.0F, 0.0F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb16.addChild(cube_r48);
        setRotationAngle(cube_r48, -1.5708F, -0.6109F, 0.0F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand17 = new ModelRenderer(this);
        hand17.setRotationPoint(-16.0F, 104.0F, 6.0F);
        bone81.addChild(hand17);
        setRotationAngle(hand17, 0.0F, -1.5708F, 0.0F);
        hand17.cubeList.add(new ModelBox(hand17, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand17.cubeList.add(new ModelBox(hand17, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers17 = new ModelRenderer(this);
        fingers17.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand17.addChild(fingers17);


        bone65 = new ModelRenderer(this);
        bone65.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone65);
        bone65.cubeList.add(new ModelBox(bone65, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone65.cubeList.add(new ModelBox(bone65, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger25_r3 = new ModelRenderer(this);
        finger25_r3.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone65.addChild(finger25_r3);
        setRotationAngle(finger25_r3, 0.0F, 0.0F, -1.1345F);
        finger25_r3.cubeList.add(new ModelBox(finger25_r3, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone66 = new ModelRenderer(this);
        bone66.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone66);
        bone66.cubeList.add(new ModelBox(bone66, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone66.cubeList.add(new ModelBox(bone66, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger35_r3 = new ModelRenderer(this);
        finger35_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone66.addChild(finger35_r3);
        setRotationAngle(finger35_r3, 0.0F, 0.0F, -1.1345F);
        finger35_r3.cubeList.add(new ModelBox(finger35_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone67 = new ModelRenderer(this);
        bone67.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone67);
        bone67.cubeList.add(new ModelBox(bone67, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone67.cubeList.add(new ModelBox(bone67, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger45_r3 = new ModelRenderer(this);
        finger45_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone67.addChild(finger45_r3);
        setRotationAngle(finger45_r3, 0.0F, 0.0F, -1.1345F);
        finger45_r3.cubeList.add(new ModelBox(finger45_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone68 = new ModelRenderer(this);
        bone68.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone68);
        bone68.cubeList.add(new ModelBox(bone68, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone68.cubeList.add(new ModelBox(bone68, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger55_r2 = new ModelRenderer(this);
        finger55_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone68.addChild(finger55_r2);
        setRotationAngle(finger55_r2, 0.0F, 0.0F, -1.1345F);
        finger55_r2.cubeList.add(new ModelBox(finger55_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb17 = new ModelRenderer(this);
        thumb17.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(thumb17);


        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb17.addChild(cube_r49);
        setRotationAngle(cube_r49, 0.48F, 0.0F, -0.5236F);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb17.addChild(cube_r50);
        setRotationAngle(cube_r50, -0.4363F, 0.0F, 0.0F);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb17.addChild(cube_r51);
        setRotationAngle(cube_r51, -1.5708F, -0.6109F, 0.0F);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand18 = new ModelRenderer(this);
        hand18.setRotationPoint(-16.0F, 104.0F, 6.0F);
        bone81.addChild(hand18);
        setRotationAngle(hand18, 0.0F, -1.5708F, 0.0F);
        hand18.cubeList.add(new ModelBox(hand18, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand18.cubeList.add(new ModelBox(hand18, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers18 = new ModelRenderer(this);
        fingers18.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand18.addChild(fingers18);


        bone69 = new ModelRenderer(this);
        bone69.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone69);
        bone69.cubeList.add(new ModelBox(bone69, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone69.cubeList.add(new ModelBox(bone69, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger26_r2 = new ModelRenderer(this);
        finger26_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone69.addChild(finger26_r2);
        setRotationAngle(finger26_r2, 0.0F, 0.0F, -1.1345F);
        finger26_r2.cubeList.add(new ModelBox(finger26_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone70 = new ModelRenderer(this);
        bone70.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone70);
        bone70.cubeList.add(new ModelBox(bone70, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone70.cubeList.add(new ModelBox(bone70, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger36_r2 = new ModelRenderer(this);
        finger36_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone70.addChild(finger36_r2);
        setRotationAngle(finger36_r2, 0.0F, 0.0F, -1.1345F);
        finger36_r2.cubeList.add(new ModelBox(finger36_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone71 = new ModelRenderer(this);
        bone71.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone71);
        bone71.cubeList.add(new ModelBox(bone71, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone71.cubeList.add(new ModelBox(bone71, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger46_r2 = new ModelRenderer(this);
        finger46_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone71.addChild(finger46_r2);
        setRotationAngle(finger46_r2, 0.0F, 0.0F, -1.1345F);
        finger46_r2.cubeList.add(new ModelBox(finger46_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone72 = new ModelRenderer(this);
        bone72.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone72);
        bone72.cubeList.add(new ModelBox(bone72, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone72.cubeList.add(new ModelBox(bone72, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger56_r1 = new ModelRenderer(this);
        finger56_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone72.addChild(finger56_r1);
        setRotationAngle(finger56_r1, 0.0F, 0.0F, -1.1345F);
        finger56_r1.cubeList.add(new ModelBox(finger56_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb18 = new ModelRenderer(this);
        thumb18.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(thumb18);


        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb18.addChild(cube_r52);
        setRotationAngle(cube_r52, 0.48F, 0.0F, -0.5236F);
        cube_r52.cubeList.add(new ModelBox(cube_r52, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb18.addChild(cube_r53);
        setRotationAngle(cube_r53, -0.4363F, 0.0F, 0.0F);
        cube_r53.cubeList.add(new ModelBox(cube_r53, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb18.addChild(cube_r54);
        setRotationAngle(cube_r54, -1.5708F, -0.6109F, 0.0F);
        cube_r54.cubeList.add(new ModelBox(cube_r54, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand19 = new ModelRenderer(this);
        hand19.setRotationPoint(56.0F, -8.0F, 15.0F);
        bone81.addChild(hand19);
        setRotationAngle(hand19, 0.0F, -1.5708F, 0.0F);
        hand19.cubeList.add(new ModelBox(hand19, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand19.cubeList.add(new ModelBox(hand19, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers19 = new ModelRenderer(this);
        fingers19.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand19.addChild(fingers19);


        bone73 = new ModelRenderer(this);
        bone73.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone73);
        bone73.cubeList.add(new ModelBox(bone73, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone73.cubeList.add(new ModelBox(bone73, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger15_r2 = new ModelRenderer(this);
        finger15_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone73.addChild(finger15_r2);
        setRotationAngle(finger15_r2, 0.0F, 0.0F, -1.1345F);
        finger15_r2.cubeList.add(new ModelBox(finger15_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone74 = new ModelRenderer(this);
        bone74.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone74);
        bone74.cubeList.add(new ModelBox(bone74, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone74.cubeList.add(new ModelBox(bone74, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger25_r4 = new ModelRenderer(this);
        finger25_r4.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone74.addChild(finger25_r4);
        setRotationAngle(finger25_r4, 0.0F, 0.0F, -1.1345F);
        finger25_r4.cubeList.add(new ModelBox(finger25_r4, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone75 = new ModelRenderer(this);
        bone75.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone75);
        bone75.cubeList.add(new ModelBox(bone75, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone75.cubeList.add(new ModelBox(bone75, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger35_r4 = new ModelRenderer(this);
        finger35_r4.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone75.addChild(finger35_r4);
        setRotationAngle(finger35_r4, 0.0F, 0.0F, -1.1345F);
        finger35_r4.cubeList.add(new ModelBox(finger35_r4, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone76 = new ModelRenderer(this);
        bone76.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone76);
        bone76.cubeList.add(new ModelBox(bone76, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone76.cubeList.add(new ModelBox(bone76, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger45_r4 = new ModelRenderer(this);
        finger45_r4.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone76.addChild(finger45_r4);
        setRotationAngle(finger45_r4, 0.0F, 0.0F, -1.1345F);
        finger45_r4.cubeList.add(new ModelBox(finger45_r4, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb19 = new ModelRenderer(this);
        thumb19.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(thumb19);


        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb19.addChild(cube_r55);
        setRotationAngle(cube_r55, 0.48F, 0.0F, -0.5236F);
        cube_r55.cubeList.add(new ModelBox(cube_r55, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb19.addChild(cube_r56);
        setRotationAngle(cube_r56, -0.4363F, 0.0F, 0.0F);
        cube_r56.cubeList.add(new ModelBox(cube_r56, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb19.addChild(cube_r57);
        setRotationAngle(cube_r57, -1.5708F, -0.6109F, 0.0F);
        cube_r57.cubeList.add(new ModelBox(cube_r57, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone81.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    
}/*
public class magma_downpour extends ModelBase {
    private final ModelRenderer hand;
    private final ModelRenderer fingers;
    private final ModelRenderer bone;
    private final ModelRenderer finger13_r1;
    private final ModelRenderer bone2;
    private final ModelRenderer finger23_r1;
    private final ModelRenderer bone3;
    private final ModelRenderer finger33_r1;
    private final ModelRenderer bone4;
    private final ModelRenderer finger43_r1;
    private final ModelRenderer thumb;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer hand2;
    private final ModelRenderer fingers2;
    private final ModelRenderer bone5;
    private final ModelRenderer finger14_r1;
    private final ModelRenderer bone6;
    private final ModelRenderer finger24_r1;
    private final ModelRenderer bone7;
    private final ModelRenderer finger34_r1;
    private final ModelRenderer bone8;
    private final ModelRenderer finger44_r1;
    private final ModelRenderer thumb2;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer hand3;
    private final ModelRenderer fingers3;
    private final ModelRenderer bone9;
    private final ModelRenderer finger15_r1;
    private final ModelRenderer bone10;
    private final ModelRenderer finger25_r1;
    private final ModelRenderer bone11;
    private final ModelRenderer finger35_r1;
    private final ModelRenderer bone12;
    private final ModelRenderer finger45_r1;
    private final ModelRenderer thumb3;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer hand4;
    private final ModelRenderer fingers4;
    private final ModelRenderer bone13;
    private final ModelRenderer finger16_r1;
    private final ModelRenderer bone14;
    private final ModelRenderer finger26_r1;
    private final ModelRenderer bone15;
    private final ModelRenderer finger36_r1;
    private final ModelRenderer bone16;
    private final ModelRenderer finger46_r1;
    private final ModelRenderer thumb4;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer hand5;
    private final ModelRenderer fingers5;
    private final ModelRenderer bone17;
    private final ModelRenderer finger17_r1;
    private final ModelRenderer bone18;
    private final ModelRenderer finger27_r1;
    private final ModelRenderer bone19;
    private final ModelRenderer finger37_r1;
    private final ModelRenderer bone20;
    private final ModelRenderer finger47_r1;
    private final ModelRenderer thumb5;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer hand6;
    private final ModelRenderer fingers6;
    private final ModelRenderer bone21;
    private final ModelRenderer finger18_r1;
    private final ModelRenderer bone22;
    private final ModelRenderer finger28_r1;
    private final ModelRenderer bone23;
    private final ModelRenderer finger38_r1;
    private final ModelRenderer bone24;
    private final ModelRenderer finger48_r1;
    private final ModelRenderer thumb6;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer hand7;
    private final ModelRenderer fingers7;
    private final ModelRenderer bone25;
    private final ModelRenderer finger19_r1;
    private final ModelRenderer bone26;
    private final ModelRenderer finger29_r1;
    private final ModelRenderer bone27;
    private final ModelRenderer finger39_r1;
    private final ModelRenderer bone28;
    private final ModelRenderer finger49_r1;
    private final ModelRenderer thumb7;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer hand8;
    private final ModelRenderer fingers8;
    private final ModelRenderer bone29;
    private final ModelRenderer finger20_r1;
    private final ModelRenderer bone30;
    private final ModelRenderer finger30_r1;
    private final ModelRenderer bone31;
    private final ModelRenderer finger40_r1;
    private final ModelRenderer bone32;
    private final ModelRenderer finger50_r1;
    private final ModelRenderer thumb8;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer hand9;
    private final ModelRenderer fingers9;
    private final ModelRenderer bone33;
    private final ModelRenderer finger21_r1;
    private final ModelRenderer bone34;
    private final ModelRenderer finger31_r1;
    private final ModelRenderer bone35;
    private final ModelRenderer finger41_r1;
    private final ModelRenderer bone36;
    private final ModelRenderer finger51_r1;
    private final ModelRenderer thumb9;
    private final ModelRenderer cube_r25;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer hand10;
    private final ModelRenderer fingers10;
    private final ModelRenderer bone37;
    private final ModelRenderer finger22_r1;
    private final ModelRenderer bone38;
    private final ModelRenderer finger32_r1;
    private final ModelRenderer bone39;
    private final ModelRenderer finger42_r1;
    private final ModelRenderer bone40;
    private final ModelRenderer finger52_r1;
    private final ModelRenderer thumb10;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer hand11;
    private final ModelRenderer fingers11;
    private final ModelRenderer bone41;
    private final ModelRenderer finger23_r2;
    private final ModelRenderer bone42;
    private final ModelRenderer finger33_r2;
    private final ModelRenderer bone43;
    private final ModelRenderer finger43_r2;
    private final ModelRenderer bone44;
    private final ModelRenderer finger53_r1;
    private final ModelRenderer thumb11;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer hand12;
    private final ModelRenderer fingers12;
    private final ModelRenderer bone45;
    private final ModelRenderer finger24_r2;
    private final ModelRenderer bone46;
    private final ModelRenderer finger34_r2;
    private final ModelRenderer bone47;
    private final ModelRenderer finger44_r2;
    private final ModelRenderer bone48;
    private final ModelRenderer finger54_r1;
    private final ModelRenderer thumb12;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer hand13;
    private final ModelRenderer fingers13;
    private final ModelRenderer bone49;
    private final ModelRenderer finger25_r2;
    private final ModelRenderer bone50;
    private final ModelRenderer finger35_r2;
    private final ModelRenderer bone51;
    private final ModelRenderer finger45_r2;
    private final ModelRenderer bone52;
    private final ModelRenderer finger55_r1;
    private final ModelRenderer thumb13;
    private final ModelRenderer cube_r37;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer hand14;
    private final ModelRenderer fingers14;
    private final ModelRenderer bone53;
    private final ModelRenderer finger22_r2;
    private final ModelRenderer bone54;
    private final ModelRenderer finger32_r2;
    private final ModelRenderer bone55;
    private final ModelRenderer finger42_r2;
    private final ModelRenderer bone56;
    private final ModelRenderer finger52_r2;
    private final ModelRenderer thumb14;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer hand15;
    private final ModelRenderer fingers15;
    private final ModelRenderer bone57;
    private final ModelRenderer finger23_r3;
    private final ModelRenderer bone58;
    private final ModelRenderer finger33_r3;
    private final ModelRenderer bone59;
    private final ModelRenderer finger43_r3;
    private final ModelRenderer bone60;
    private final ModelRenderer finger53_r2;
    private final ModelRenderer thumb15;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer cube_r45;
    private final ModelRenderer hand16;
    private final ModelRenderer fingers16;
    private final ModelRenderer bone61;
    private final ModelRenderer finger24_r3;
    private final ModelRenderer bone62;
    private final ModelRenderer finger34_r3;
    private final ModelRenderer bone63;
    private final ModelRenderer finger44_r3;
    private final ModelRenderer bone64;
    private final ModelRenderer finger54_r2;
    private final ModelRenderer thumb16;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer cube_r48;
    private final ModelRenderer hand17;
    private final ModelRenderer fingers17;
    private final ModelRenderer bone65;
    private final ModelRenderer finger25_r3;
    private final ModelRenderer bone66;
    private final ModelRenderer finger35_r3;
    private final ModelRenderer bone67;
    private final ModelRenderer finger45_r3;
    private final ModelRenderer bone68;
    private final ModelRenderer finger55_r2;
    private final ModelRenderer thumb17;
    private final ModelRenderer cube_r49;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer hand18;
    private final ModelRenderer fingers18;
    private final ModelRenderer bone69;
    private final ModelRenderer finger26_r2;
    private final ModelRenderer bone70;
    private final ModelRenderer finger36_r2;
    private final ModelRenderer bone71;
    private final ModelRenderer finger46_r2;
    private final ModelRenderer bone72;
    private final ModelRenderer finger56_r1;
    private final ModelRenderer thumb18;
    private final ModelRenderer cube_r52;
    private final ModelRenderer cube_r53;
    private final ModelRenderer cube_r54;
    private final ModelRenderer hand19;
    private final ModelRenderer fingers19;
    private final ModelRenderer bone73;
    private final ModelRenderer finger15_r2;
    private final ModelRenderer bone74;
    private final ModelRenderer finger25_r4;
    private final ModelRenderer bone75;
    private final ModelRenderer finger35_r4;
    private final ModelRenderer bone76;
    private final ModelRenderer finger45_r4;
    private final ModelRenderer thumb19;
    private final ModelRenderer cube_r55;
    private final ModelRenderer cube_r56;
    private final ModelRenderer cube_r57;
    private final ModelRenderer hand20;
    private final ModelRenderer fingers20;
    private final ModelRenderer bone77;
    private final ModelRenderer finger16_r2;
    private final ModelRenderer bone78;
    private final ModelRenderer finger26_r3;
    private final ModelRenderer bone79;
    private final ModelRenderer finger36_r3;
    private final ModelRenderer bone80;
    private final ModelRenderer finger46_r3;
    private final ModelRenderer thumb20;
    private final ModelRenderer cube_r58;
    private final ModelRenderer cube_r59;
    private final ModelRenderer cube_r60;

    public magma_downpour() {
        textureWidth = 128;
        textureHeight = 128;

        hand = new ModelRenderer(this);
        hand.setRotationPoint(-1.0F, 2.0F, 7.0F);
        setRotationAngle(hand, 0.0F, -1.5708F, 0.0F);
        hand.cubeList.add(new ModelBox(hand, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand.cubeList.add(new ModelBox(hand, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand.cubeList.add(new ModelBox(hand, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers = new ModelRenderer(this);
        fingers.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand.addChild(fingers);


        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone);
        bone.cubeList.add(new ModelBox(bone, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger13_r1 = new ModelRenderer(this);
        finger13_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone.addChild(finger13_r1);
        setRotationAngle(finger13_r1, 0.0F, 0.0F, -1.1345F);
        finger13_r1.cubeList.add(new ModelBox(finger13_r1, 40, 28, -7.5774F, -3.0937F, -2.0F, 4, 7, 3, 0.0F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone2);
        bone2.cubeList.add(new ModelBox(bone2, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone2.cubeList.add(new ModelBox(bone2, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger23_r1 = new ModelRenderer(this);
        finger23_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone2.addChild(finger23_r1);
        setRotationAngle(finger23_r1, 0.0F, 0.0F, -1.1345F);
        finger23_r1.cubeList.add(new ModelBox(finger23_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone3);
        bone3.cubeList.add(new ModelBox(bone3, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone3.cubeList.add(new ModelBox(bone3, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger33_r1 = new ModelRenderer(this);
        finger33_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone3.addChild(finger33_r1);
        setRotationAngle(finger33_r1, 0.0F, 0.0F, -1.1345F);
        finger33_r1.cubeList.add(new ModelBox(finger33_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(bone4);
        bone4.cubeList.add(new ModelBox(bone4, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone4.cubeList.add(new ModelBox(bone4, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger43_r1 = new ModelRenderer(this);
        finger43_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone4.addChild(finger43_r1);
        setRotationAngle(finger43_r1, 0.0F, 0.0F, -1.1345F);
        finger43_r1.cubeList.add(new ModelBox(finger43_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb = new ModelRenderer(this);
        thumb.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers.addChild(thumb);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.48F, 0.0F, -0.5236F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb.addChild(cube_r2);
        setRotationAngle(cube_r2, -0.4363F, 0.0F, 0.0F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb.addChild(cube_r3);
        setRotationAngle(cube_r3, -1.5708F, -0.6109F, 0.0F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand2 = new ModelRenderer(this);
        hand2.setRotationPoint(-1.0F, -75.0F, 39.0F);
        setRotationAngle(hand2, 0.0F, -1.5708F, 0.0F);
        hand2.cubeList.add(new ModelBox(hand2, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand2.cubeList.add(new ModelBox(hand2, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers2 = new ModelRenderer(this);
        fingers2.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand2.addChild(fingers2);


        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone5);
        bone5.cubeList.add(new ModelBox(bone5, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger14_r1 = new ModelRenderer(this);
        finger14_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone5.addChild(finger14_r1);
        setRotationAngle(finger14_r1, 0.0F, 0.0F, -1.1345F);
        finger14_r1.cubeList.add(new ModelBox(finger14_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone6);
        bone6.cubeList.add(new ModelBox(bone6, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone6.cubeList.add(new ModelBox(bone6, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger24_r1 = new ModelRenderer(this);
        finger24_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone6.addChild(finger24_r1);
        setRotationAngle(finger24_r1, 0.0F, 0.0F, -1.1345F);
        finger24_r1.cubeList.add(new ModelBox(finger24_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone7);
        bone7.cubeList.add(new ModelBox(bone7, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger34_r1 = new ModelRenderer(this);
        finger34_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone7.addChild(finger34_r1);
        setRotationAngle(finger34_r1, 0.0F, 0.0F, -1.1345F);
        finger34_r1.cubeList.add(new ModelBox(finger34_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(bone8);
        bone8.cubeList.add(new ModelBox(bone8, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone8.cubeList.add(new ModelBox(bone8, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger44_r1 = new ModelRenderer(this);
        finger44_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone8.addChild(finger44_r1);
        setRotationAngle(finger44_r1, 0.0F, 0.0F, -1.1345F);
        finger44_r1.cubeList.add(new ModelBox(finger44_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb2 = new ModelRenderer(this);
        thumb2.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers2.addChild(thumb2);


        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb2.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.48F, 0.0F, -0.5236F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb2.addChild(cube_r5);
        setRotationAngle(cube_r5, -0.4363F, 0.0F, 0.0F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb2.addChild(cube_r6);
        setRotationAngle(cube_r6, -1.5708F, -0.6109F, 0.0F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand3 = new ModelRenderer(this);
        hand3.setRotationPoint(-10.0F, -59.0F, -16.0F);
        setRotationAngle(hand3, 0.0F, -1.5708F, 0.0F);
        hand3.cubeList.add(new ModelBox(hand3, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand3.cubeList.add(new ModelBox(hand3, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers3 = new ModelRenderer(this);
        fingers3.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand3.addChild(fingers3);


        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone9);
        bone9.cubeList.add(new ModelBox(bone9, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone9.cubeList.add(new ModelBox(bone9, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger15_r1 = new ModelRenderer(this);
        finger15_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone9.addChild(finger15_r1);
        setRotationAngle(finger15_r1, 0.0F, 0.0F, -1.1345F);
        finger15_r1.cubeList.add(new ModelBox(finger15_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone10);
        bone10.cubeList.add(new ModelBox(bone10, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone10.cubeList.add(new ModelBox(bone10, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger25_r1 = new ModelRenderer(this);
        finger25_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone10.addChild(finger25_r1);
        setRotationAngle(finger25_r1, 0.0F, 0.0F, -1.1345F);
        finger25_r1.cubeList.add(new ModelBox(finger25_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone11 = new ModelRenderer(this);
        bone11.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone11);
        bone11.cubeList.add(new ModelBox(bone11, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone11.cubeList.add(new ModelBox(bone11, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger35_r1 = new ModelRenderer(this);
        finger35_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone11.addChild(finger35_r1);
        setRotationAngle(finger35_r1, 0.0F, 0.0F, -1.1345F);
        finger35_r1.cubeList.add(new ModelBox(finger35_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone12 = new ModelRenderer(this);
        bone12.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(bone12);
        bone12.cubeList.add(new ModelBox(bone12, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone12.cubeList.add(new ModelBox(bone12, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger45_r1 = new ModelRenderer(this);
        finger45_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone12.addChild(finger45_r1);
        setRotationAngle(finger45_r1, 0.0F, 0.0F, -1.1345F);
        finger45_r1.cubeList.add(new ModelBox(finger45_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb3 = new ModelRenderer(this);
        thumb3.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers3.addChild(thumb3);


        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb3.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.48F, 0.0F, -0.5236F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb3.addChild(cube_r8);
        setRotationAngle(cube_r8, -0.4363F, 0.0F, 0.0F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb3.addChild(cube_r9);
        setRotationAngle(cube_r9, -1.5708F, -0.6109F, 0.0F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand4 = new ModelRenderer(this);
        hand4.setRotationPoint(41.0F, -53.0F, 23.0F);
        setRotationAngle(hand4, 0.0F, -1.5708F, 0.0F);
        hand4.cubeList.add(new ModelBox(hand4, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand4.cubeList.add(new ModelBox(hand4, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers4 = new ModelRenderer(this);
        fingers4.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand4.addChild(fingers4);


        bone13 = new ModelRenderer(this);
        bone13.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone13);
        bone13.cubeList.add(new ModelBox(bone13, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone13.cubeList.add(new ModelBox(bone13, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger16_r1 = new ModelRenderer(this);
        finger16_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone13.addChild(finger16_r1);
        setRotationAngle(finger16_r1, 0.0F, 0.0F, -1.1345F);
        finger16_r1.cubeList.add(new ModelBox(finger16_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone14 = new ModelRenderer(this);
        bone14.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone14);
        bone14.cubeList.add(new ModelBox(bone14, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone14.cubeList.add(new ModelBox(bone14, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger26_r1 = new ModelRenderer(this);
        finger26_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone14.addChild(finger26_r1);
        setRotationAngle(finger26_r1, 0.0F, 0.0F, -1.1345F);
        finger26_r1.cubeList.add(new ModelBox(finger26_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone15 = new ModelRenderer(this);
        bone15.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone15);
        bone15.cubeList.add(new ModelBox(bone15, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone15.cubeList.add(new ModelBox(bone15, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger36_r1 = new ModelRenderer(this);
        finger36_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone15.addChild(finger36_r1);
        setRotationAngle(finger36_r1, 0.0F, 0.0F, -1.1345F);
        finger36_r1.cubeList.add(new ModelBox(finger36_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone16 = new ModelRenderer(this);
        bone16.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(bone16);
        bone16.cubeList.add(new ModelBox(bone16, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone16.cubeList.add(new ModelBox(bone16, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger46_r1 = new ModelRenderer(this);
        finger46_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone16.addChild(finger46_r1);
        setRotationAngle(finger46_r1, 0.0F, 0.0F, -1.1345F);
        finger46_r1.cubeList.add(new ModelBox(finger46_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb4 = new ModelRenderer(this);
        thumb4.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers4.addChild(thumb4);


        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb4.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.48F, 0.0F, -0.5236F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb4.addChild(cube_r11);
        setRotationAngle(cube_r11, -0.4363F, 0.0F, 0.0F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb4.addChild(cube_r12);
        setRotationAngle(cube_r12, -1.5708F, -0.6109F, 0.0F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand5 = new ModelRenderer(this);
        hand5.setRotationPoint(-27.0F, -34.0F, 7.0F);
        setRotationAngle(hand5, 0.0F, -1.5708F, 0.0F);
        hand5.cubeList.add(new ModelBox(hand5, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand5.cubeList.add(new ModelBox(hand5, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers5 = new ModelRenderer(this);
        fingers5.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand5.addChild(fingers5);


        bone17 = new ModelRenderer(this);
        bone17.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone17);
        bone17.cubeList.add(new ModelBox(bone17, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone17.cubeList.add(new ModelBox(bone17, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger17_r1 = new ModelRenderer(this);
        finger17_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone17.addChild(finger17_r1);
        setRotationAngle(finger17_r1, 0.0F, 0.0F, -1.1345F);
        finger17_r1.cubeList.add(new ModelBox(finger17_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone18 = new ModelRenderer(this);
        bone18.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone18);
        bone18.cubeList.add(new ModelBox(bone18, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone18.cubeList.add(new ModelBox(bone18, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger27_r1 = new ModelRenderer(this);
        finger27_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone18.addChild(finger27_r1);
        setRotationAngle(finger27_r1, 0.0F, 0.0F, -1.1345F);
        finger27_r1.cubeList.add(new ModelBox(finger27_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone19 = new ModelRenderer(this);
        bone19.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone19);
        bone19.cubeList.add(new ModelBox(bone19, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone19.cubeList.add(new ModelBox(bone19, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger37_r1 = new ModelRenderer(this);
        finger37_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone19.addChild(finger37_r1);
        setRotationAngle(finger37_r1, 0.0F, 0.0F, -1.1345F);
        finger37_r1.cubeList.add(new ModelBox(finger37_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone20 = new ModelRenderer(this);
        bone20.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(bone20);
        bone20.cubeList.add(new ModelBox(bone20, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone20.cubeList.add(new ModelBox(bone20, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger47_r1 = new ModelRenderer(this);
        finger47_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone20.addChild(finger47_r1);
        setRotationAngle(finger47_r1, 0.0F, 0.0F, -1.1345F);
        finger47_r1.cubeList.add(new ModelBox(finger47_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb5 = new ModelRenderer(this);
        thumb5.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers5.addChild(thumb5);


        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb5.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.48F, 0.0F, -0.5236F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb5.addChild(cube_r14);
        setRotationAngle(cube_r14, -0.4363F, 0.0F, 0.0F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb5.addChild(cube_r15);
        setRotationAngle(cube_r15, -1.5708F, -0.6109F, 0.0F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand6 = new ModelRenderer(this);
        hand6.setRotationPoint(-55.0F, -32.0F, 36.0F);
        setRotationAngle(hand6, 0.0F, -1.5708F, 0.0F);
        hand6.cubeList.add(new ModelBox(hand6, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand6.cubeList.add(new ModelBox(hand6, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers6 = new ModelRenderer(this);
        fingers6.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand6.addChild(fingers6);


        bone21 = new ModelRenderer(this);
        bone21.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone21);
        bone21.cubeList.add(new ModelBox(bone21, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone21.cubeList.add(new ModelBox(bone21, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger18_r1 = new ModelRenderer(this);
        finger18_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone21.addChild(finger18_r1);
        setRotationAngle(finger18_r1, 0.0F, 0.0F, -1.1345F);
        finger18_r1.cubeList.add(new ModelBox(finger18_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone22 = new ModelRenderer(this);
        bone22.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone22);
        bone22.cubeList.add(new ModelBox(bone22, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone22.cubeList.add(new ModelBox(bone22, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger28_r1 = new ModelRenderer(this);
        finger28_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone22.addChild(finger28_r1);
        setRotationAngle(finger28_r1, 0.0F, 0.0F, -1.1345F);
        finger28_r1.cubeList.add(new ModelBox(finger28_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone23 = new ModelRenderer(this);
        bone23.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone23);
        bone23.cubeList.add(new ModelBox(bone23, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone23.cubeList.add(new ModelBox(bone23, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger38_r1 = new ModelRenderer(this);
        finger38_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone23.addChild(finger38_r1);
        setRotationAngle(finger38_r1, 0.0F, 0.0F, -1.1345F);
        finger38_r1.cubeList.add(new ModelBox(finger38_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone24 = new ModelRenderer(this);
        bone24.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(bone24);
        bone24.cubeList.add(new ModelBox(bone24, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone24.cubeList.add(new ModelBox(bone24, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger48_r1 = new ModelRenderer(this);
        finger48_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone24.addChild(finger48_r1);
        setRotationAngle(finger48_r1, 0.0F, 0.0F, -1.1345F);
        finger48_r1.cubeList.add(new ModelBox(finger48_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb6 = new ModelRenderer(this);
        thumb6.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers6.addChild(thumb6);


        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb6.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.48F, 0.0F, -0.5236F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb6.addChild(cube_r17);
        setRotationAngle(cube_r17, -0.4363F, 0.0F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb6.addChild(cube_r18);
        setRotationAngle(cube_r18, -1.5708F, -0.6109F, 0.0F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand7 = new ModelRenderer(this);
        hand7.setRotationPoint(-53.0F, -47.0F, -10.0F);
        setRotationAngle(hand7, 0.0F, -1.5708F, 0.0F);
        hand7.cubeList.add(new ModelBox(hand7, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand7.cubeList.add(new ModelBox(hand7, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers7 = new ModelRenderer(this);
        fingers7.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand7.addChild(fingers7);


        bone25 = new ModelRenderer(this);
        bone25.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone25);
        bone25.cubeList.add(new ModelBox(bone25, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone25.cubeList.add(new ModelBox(bone25, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger19_r1 = new ModelRenderer(this);
        finger19_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone25.addChild(finger19_r1);
        setRotationAngle(finger19_r1, 0.0F, 0.0F, -1.1345F);
        finger19_r1.cubeList.add(new ModelBox(finger19_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone26 = new ModelRenderer(this);
        bone26.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone26);
        bone26.cubeList.add(new ModelBox(bone26, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone26.cubeList.add(new ModelBox(bone26, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger29_r1 = new ModelRenderer(this);
        finger29_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone26.addChild(finger29_r1);
        setRotationAngle(finger29_r1, 0.0F, 0.0F, -1.1345F);
        finger29_r1.cubeList.add(new ModelBox(finger29_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone27 = new ModelRenderer(this);
        bone27.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone27);
        bone27.cubeList.add(new ModelBox(bone27, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone27.cubeList.add(new ModelBox(bone27, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger39_r1 = new ModelRenderer(this);
        finger39_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone27.addChild(finger39_r1);
        setRotationAngle(finger39_r1, 0.0F, 0.0F, -1.1345F);
        finger39_r1.cubeList.add(new ModelBox(finger39_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone28 = new ModelRenderer(this);
        bone28.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(bone28);
        bone28.cubeList.add(new ModelBox(bone28, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone28.cubeList.add(new ModelBox(bone28, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger49_r1 = new ModelRenderer(this);
        finger49_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone28.addChild(finger49_r1);
        setRotationAngle(finger49_r1, 0.0F, 0.0F, -1.1345F);
        finger49_r1.cubeList.add(new ModelBox(finger49_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb7 = new ModelRenderer(this);
        thumb7.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers7.addChild(thumb7);


        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb7.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.48F, 0.0F, -0.5236F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb7.addChild(cube_r20);
        setRotationAngle(cube_r20, -0.4363F, 0.0F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb7.addChild(cube_r21);
        setRotationAngle(cube_r21, -1.5708F, -0.6109F, 0.0F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand8 = new ModelRenderer(this);
        hand8.setRotationPoint(37.0F, -21.0F, -23.0F);
        setRotationAngle(hand8, 0.0F, -1.5708F, 0.0F);
        hand8.cubeList.add(new ModelBox(hand8, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand8.cubeList.add(new ModelBox(hand8, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers8 = new ModelRenderer(this);
        fingers8.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand8.addChild(fingers8);


        bone29 = new ModelRenderer(this);
        bone29.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone29);
        bone29.cubeList.add(new ModelBox(bone29, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone29.cubeList.add(new ModelBox(bone29, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger20_r1 = new ModelRenderer(this);
        finger20_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone29.addChild(finger20_r1);
        setRotationAngle(finger20_r1, 0.0F, 0.0F, -1.1345F);
        finger20_r1.cubeList.add(new ModelBox(finger20_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone30 = new ModelRenderer(this);
        bone30.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone30);
        bone30.cubeList.add(new ModelBox(bone30, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone30.cubeList.add(new ModelBox(bone30, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger30_r1 = new ModelRenderer(this);
        finger30_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone30.addChild(finger30_r1);
        setRotationAngle(finger30_r1, 0.0F, 0.0F, -1.1345F);
        finger30_r1.cubeList.add(new ModelBox(finger30_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone31 = new ModelRenderer(this);
        bone31.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone31);
        bone31.cubeList.add(new ModelBox(bone31, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone31.cubeList.add(new ModelBox(bone31, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger40_r1 = new ModelRenderer(this);
        finger40_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone31.addChild(finger40_r1);
        setRotationAngle(finger40_r1, 0.0F, 0.0F, -1.1345F);
        finger40_r1.cubeList.add(new ModelBox(finger40_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone32 = new ModelRenderer(this);
        bone32.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(bone32);
        bone32.cubeList.add(new ModelBox(bone32, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone32.cubeList.add(new ModelBox(bone32, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger50_r1 = new ModelRenderer(this);
        finger50_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone32.addChild(finger50_r1);
        setRotationAngle(finger50_r1, 0.0F, 0.0F, -1.1345F);
        finger50_r1.cubeList.add(new ModelBox(finger50_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb8 = new ModelRenderer(this);
        thumb8.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers8.addChild(thumb8);


        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb8.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.48F, 0.0F, -0.5236F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb8.addChild(cube_r23);
        setRotationAngle(cube_r23, -0.4363F, 0.0F, 0.0F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb8.addChild(cube_r24);
        setRotationAngle(cube_r24, -1.5708F, -0.6109F, 0.0F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand9 = new ModelRenderer(this);
        hand9.setRotationPoint(-20.0F, -24.0F, -39.0F);
        setRotationAngle(hand9, 0.0F, -1.5708F, 0.0F);
        hand9.cubeList.add(new ModelBox(hand9, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand9.cubeList.add(new ModelBox(hand9, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers9 = new ModelRenderer(this);
        fingers9.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand9.addChild(fingers9);


        bone33 = new ModelRenderer(this);
        bone33.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone33);
        bone33.cubeList.add(new ModelBox(bone33, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone33.cubeList.add(new ModelBox(bone33, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger21_r1 = new ModelRenderer(this);
        finger21_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone33.addChild(finger21_r1);
        setRotationAngle(finger21_r1, 0.0F, 0.0F, -1.1345F);
        finger21_r1.cubeList.add(new ModelBox(finger21_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone34 = new ModelRenderer(this);
        bone34.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone34);
        bone34.cubeList.add(new ModelBox(bone34, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone34.cubeList.add(new ModelBox(bone34, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger31_r1 = new ModelRenderer(this);
        finger31_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone34.addChild(finger31_r1);
        setRotationAngle(finger31_r1, 0.0F, 0.0F, -1.1345F);
        finger31_r1.cubeList.add(new ModelBox(finger31_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone35 = new ModelRenderer(this);
        bone35.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone35);
        bone35.cubeList.add(new ModelBox(bone35, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone35.cubeList.add(new ModelBox(bone35, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger41_r1 = new ModelRenderer(this);
        finger41_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone35.addChild(finger41_r1);
        setRotationAngle(finger41_r1, 0.0F, 0.0F, -1.1345F);
        finger41_r1.cubeList.add(new ModelBox(finger41_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone36 = new ModelRenderer(this);
        bone36.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(bone36);
        bone36.cubeList.add(new ModelBox(bone36, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone36.cubeList.add(new ModelBox(bone36, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger51_r1 = new ModelRenderer(this);
        finger51_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone36.addChild(finger51_r1);
        setRotationAngle(finger51_r1, 0.0F, 0.0F, -1.1345F);
        finger51_r1.cubeList.add(new ModelBox(finger51_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb9 = new ModelRenderer(this);
        thumb9.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers9.addChild(thumb9);


        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb9.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.48F, 0.0F, -0.5236F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb9.addChild(cube_r26);
        setRotationAngle(cube_r26, -0.4363F, 0.0F, 0.0F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb9.addChild(cube_r27);
        setRotationAngle(cube_r27, -1.5708F, -0.6109F, 0.0F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand10 = new ModelRenderer(this);
        hand10.setRotationPoint(16.0F, -4.0F, -33.0F);
        setRotationAngle(hand10, 0.0F, -1.5708F, 0.0F);
        hand10.cubeList.add(new ModelBox(hand10, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand10.cubeList.add(new ModelBox(hand10, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers10 = new ModelRenderer(this);
        fingers10.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand10.addChild(fingers10);


        bone37 = new ModelRenderer(this);
        bone37.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone37);
        bone37.cubeList.add(new ModelBox(bone37, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone37.cubeList.add(new ModelBox(bone37, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger22_r1 = new ModelRenderer(this);
        finger22_r1.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone37.addChild(finger22_r1);
        setRotationAngle(finger22_r1, 0.0F, 0.0F, -1.1345F);
        finger22_r1.cubeList.add(new ModelBox(finger22_r1, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone38 = new ModelRenderer(this);
        bone38.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone38);
        bone38.cubeList.add(new ModelBox(bone38, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone38.cubeList.add(new ModelBox(bone38, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger32_r1 = new ModelRenderer(this);
        finger32_r1.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone38.addChild(finger32_r1);
        setRotationAngle(finger32_r1, 0.0F, 0.0F, -1.1345F);
        finger32_r1.cubeList.add(new ModelBox(finger32_r1, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone39 = new ModelRenderer(this);
        bone39.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone39);
        bone39.cubeList.add(new ModelBox(bone39, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone39.cubeList.add(new ModelBox(bone39, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger42_r1 = new ModelRenderer(this);
        finger42_r1.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone39.addChild(finger42_r1);
        setRotationAngle(finger42_r1, 0.0F, 0.0F, -1.1345F);
        finger42_r1.cubeList.add(new ModelBox(finger42_r1, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone40 = new ModelRenderer(this);
        bone40.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(bone40);
        bone40.cubeList.add(new ModelBox(bone40, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone40.cubeList.add(new ModelBox(bone40, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger52_r1 = new ModelRenderer(this);
        finger52_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone40.addChild(finger52_r1);
        setRotationAngle(finger52_r1, 0.0F, 0.0F, -1.1345F);
        finger52_r1.cubeList.add(new ModelBox(finger52_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb10 = new ModelRenderer(this);
        thumb10.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers10.addChild(thumb10);


        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb10.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.48F, 0.0F, -0.5236F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb10.addChild(cube_r29);
        setRotationAngle(cube_r29, -0.4363F, 0.0F, 0.0F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb10.addChild(cube_r30);
        setRotationAngle(cube_r30, -1.5708F, -0.6109F, 0.0F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand11 = new ModelRenderer(this);
        hand11.setRotationPoint(19.0F, -4.0F, 30.0F);
        setRotationAngle(hand11, 0.0F, -1.5708F, 0.0F);
        hand11.cubeList.add(new ModelBox(hand11, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand11.cubeList.add(new ModelBox(hand11, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers11 = new ModelRenderer(this);
        fingers11.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand11.addChild(fingers11);


        bone41 = new ModelRenderer(this);
        bone41.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone41);
        bone41.cubeList.add(new ModelBox(bone41, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone41.cubeList.add(new ModelBox(bone41, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger23_r2 = new ModelRenderer(this);
        finger23_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone41.addChild(finger23_r2);
        setRotationAngle(finger23_r2, 0.0F, 0.0F, -1.1345F);
        finger23_r2.cubeList.add(new ModelBox(finger23_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone42 = new ModelRenderer(this);
        bone42.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone42);
        bone42.cubeList.add(new ModelBox(bone42, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone42.cubeList.add(new ModelBox(bone42, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger33_r2 = new ModelRenderer(this);
        finger33_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone42.addChild(finger33_r2);
        setRotationAngle(finger33_r2, 0.0F, 0.0F, -1.1345F);
        finger33_r2.cubeList.add(new ModelBox(finger33_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone43 = new ModelRenderer(this);
        bone43.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone43);
        bone43.cubeList.add(new ModelBox(bone43, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone43.cubeList.add(new ModelBox(bone43, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger43_r2 = new ModelRenderer(this);
        finger43_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone43.addChild(finger43_r2);
        setRotationAngle(finger43_r2, 0.0F, 0.0F, -1.1345F);
        finger43_r2.cubeList.add(new ModelBox(finger43_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone44 = new ModelRenderer(this);
        bone44.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(bone44);
        bone44.cubeList.add(new ModelBox(bone44, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone44.cubeList.add(new ModelBox(bone44, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger53_r1 = new ModelRenderer(this);
        finger53_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone44.addChild(finger53_r1);
        setRotationAngle(finger53_r1, 0.0F, 0.0F, -1.1345F);
        finger53_r1.cubeList.add(new ModelBox(finger53_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb11 = new ModelRenderer(this);
        thumb11.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers11.addChild(thumb11);


        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb11.addChild(cube_r31);
        setRotationAngle(cube_r31, 0.48F, 0.0F, -0.5236F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb11.addChild(cube_r32);
        setRotationAngle(cube_r32, -0.4363F, 0.0F, 0.0F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb11.addChild(cube_r33);
        setRotationAngle(cube_r33, -1.5708F, -0.6109F, 0.0F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand12 = new ModelRenderer(this);
        hand12.setRotationPoint(-17.0F, -21.0F, 66.0F);
        setRotationAngle(hand12, 0.0F, -1.5708F, 0.0F);
        hand12.cubeList.add(new ModelBox(hand12, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand12.cubeList.add(new ModelBox(hand12, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers12 = new ModelRenderer(this);
        fingers12.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand12.addChild(fingers12);


        bone45 = new ModelRenderer(this);
        bone45.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone45);
        bone45.cubeList.add(new ModelBox(bone45, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone45.cubeList.add(new ModelBox(bone45, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger24_r2 = new ModelRenderer(this);
        finger24_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone45.addChild(finger24_r2);
        setRotationAngle(finger24_r2, 0.0F, 0.0F, -1.1345F);
        finger24_r2.cubeList.add(new ModelBox(finger24_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone46 = new ModelRenderer(this);
        bone46.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone46);
        bone46.cubeList.add(new ModelBox(bone46, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone46.cubeList.add(new ModelBox(bone46, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger34_r2 = new ModelRenderer(this);
        finger34_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone46.addChild(finger34_r2);
        setRotationAngle(finger34_r2, 0.0F, 0.0F, -1.1345F);
        finger34_r2.cubeList.add(new ModelBox(finger34_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone47 = new ModelRenderer(this);
        bone47.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone47);
        bone47.cubeList.add(new ModelBox(bone47, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone47.cubeList.add(new ModelBox(bone47, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger44_r2 = new ModelRenderer(this);
        finger44_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone47.addChild(finger44_r2);
        setRotationAngle(finger44_r2, 0.0F, 0.0F, -1.1345F);
        finger44_r2.cubeList.add(new ModelBox(finger44_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone48 = new ModelRenderer(this);
        bone48.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(bone48);
        bone48.cubeList.add(new ModelBox(bone48, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone48.cubeList.add(new ModelBox(bone48, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger54_r1 = new ModelRenderer(this);
        finger54_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone48.addChild(finger54_r1);
        setRotationAngle(finger54_r1, 0.0F, 0.0F, -1.1345F);
        finger54_r1.cubeList.add(new ModelBox(finger54_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb12 = new ModelRenderer(this);
        thumb12.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers12.addChild(thumb12);


        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb12.addChild(cube_r34);
        setRotationAngle(cube_r34, 0.48F, 0.0F, -0.5236F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb12.addChild(cube_r35);
        setRotationAngle(cube_r35, -0.4363F, 0.0F, 0.0F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb12.addChild(cube_r36);
        setRotationAngle(cube_r36, -1.5708F, -0.6109F, 0.0F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand13 = new ModelRenderer(this);
        hand13.setRotationPoint(28.0F, -15.0F, 60.0F);
        setRotationAngle(hand13, 0.0F, -1.5708F, 0.0F);
        hand13.cubeList.add(new ModelBox(hand13, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand13.cubeList.add(new ModelBox(hand13, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers13 = new ModelRenderer(this);
        fingers13.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand13.addChild(fingers13);


        bone49 = new ModelRenderer(this);
        bone49.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone49);
        bone49.cubeList.add(new ModelBox(bone49, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone49.cubeList.add(new ModelBox(bone49, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger25_r2 = new ModelRenderer(this);
        finger25_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone49.addChild(finger25_r2);
        setRotationAngle(finger25_r2, 0.0F, 0.0F, -1.1345F);
        finger25_r2.cubeList.add(new ModelBox(finger25_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone50 = new ModelRenderer(this);
        bone50.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone50);
        bone50.cubeList.add(new ModelBox(bone50, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone50.cubeList.add(new ModelBox(bone50, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger35_r2 = new ModelRenderer(this);
        finger35_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone50.addChild(finger35_r2);
        setRotationAngle(finger35_r2, 0.0F, 0.0F, -1.1345F);
        finger35_r2.cubeList.add(new ModelBox(finger35_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone51 = new ModelRenderer(this);
        bone51.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone51);
        bone51.cubeList.add(new ModelBox(bone51, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone51.cubeList.add(new ModelBox(bone51, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger45_r2 = new ModelRenderer(this);
        finger45_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone51.addChild(finger45_r2);
        setRotationAngle(finger45_r2, 0.0F, 0.0F, -1.1345F);
        finger45_r2.cubeList.add(new ModelBox(finger45_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone52 = new ModelRenderer(this);
        bone52.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(bone52);
        bone52.cubeList.add(new ModelBox(bone52, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone52.cubeList.add(new ModelBox(bone52, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger55_r1 = new ModelRenderer(this);
        finger55_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone52.addChild(finger55_r1);
        setRotationAngle(finger55_r1, 0.0F, 0.0F, -1.1345F);
        finger55_r1.cubeList.add(new ModelBox(finger55_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb13 = new ModelRenderer(this);
        thumb13.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers13.addChild(thumb13);


        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb13.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.48F, 0.0F, -0.5236F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb13.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.4363F, 0.0F, 0.0F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb13.addChild(cube_r39);
        setRotationAngle(cube_r39, -1.5708F, -0.6109F, 0.0F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand14 = new ModelRenderer(this);
        hand14.setRotationPoint(-4.0F, -4.0F, -51.0F);
        setRotationAngle(hand14, 0.0F, -1.5708F, 0.0F);
        hand14.cubeList.add(new ModelBox(hand14, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand14.cubeList.add(new ModelBox(hand14, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers14 = new ModelRenderer(this);
        fingers14.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand14.addChild(fingers14);


        bone53 = new ModelRenderer(this);
        bone53.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone53);
        bone53.cubeList.add(new ModelBox(bone53, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone53.cubeList.add(new ModelBox(bone53, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger22_r2 = new ModelRenderer(this);
        finger22_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone53.addChild(finger22_r2);
        setRotationAngle(finger22_r2, 0.0F, 0.0F, -1.1345F);
        finger22_r2.cubeList.add(new ModelBox(finger22_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone54 = new ModelRenderer(this);
        bone54.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone54);
        bone54.cubeList.add(new ModelBox(bone54, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone54.cubeList.add(new ModelBox(bone54, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger32_r2 = new ModelRenderer(this);
        finger32_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone54.addChild(finger32_r2);
        setRotationAngle(finger32_r2, 0.0F, 0.0F, -1.1345F);
        finger32_r2.cubeList.add(new ModelBox(finger32_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone55 = new ModelRenderer(this);
        bone55.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone55);
        bone55.cubeList.add(new ModelBox(bone55, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone55.cubeList.add(new ModelBox(bone55, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger42_r2 = new ModelRenderer(this);
        finger42_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone55.addChild(finger42_r2);
        setRotationAngle(finger42_r2, 0.0F, 0.0F, -1.1345F);
        finger42_r2.cubeList.add(new ModelBox(finger42_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone56 = new ModelRenderer(this);
        bone56.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(bone56);
        bone56.cubeList.add(new ModelBox(bone56, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone56.cubeList.add(new ModelBox(bone56, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger52_r2 = new ModelRenderer(this);
        finger52_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone56.addChild(finger52_r2);
        setRotationAngle(finger52_r2, 0.0F, 0.0F, -1.1345F);
        finger52_r2.cubeList.add(new ModelBox(finger52_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb14 = new ModelRenderer(this);
        thumb14.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers14.addChild(thumb14);


        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb14.addChild(cube_r40);
        setRotationAngle(cube_r40, 0.48F, 0.0F, -0.5236F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb14.addChild(cube_r41);
        setRotationAngle(cube_r41, -0.4363F, 0.0F, 0.0F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb14.addChild(cube_r42);
        setRotationAngle(cube_r42, -1.5708F, -0.6109F, 0.0F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand15 = new ModelRenderer(this);
        hand15.setRotationPoint(-40.0F, -4.0F, -25.0F);
        setRotationAngle(hand15, 0.0F, -1.5708F, 0.0F);
        hand15.cubeList.add(new ModelBox(hand15, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand15.cubeList.add(new ModelBox(hand15, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers15 = new ModelRenderer(this);
        fingers15.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand15.addChild(fingers15);


        bone57 = new ModelRenderer(this);
        bone57.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone57);
        bone57.cubeList.add(new ModelBox(bone57, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone57.cubeList.add(new ModelBox(bone57, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger23_r3 = new ModelRenderer(this);
        finger23_r3.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone57.addChild(finger23_r3);
        setRotationAngle(finger23_r3, 0.0F, 0.0F, -1.1345F);
        finger23_r3.cubeList.add(new ModelBox(finger23_r3, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone58 = new ModelRenderer(this);
        bone58.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone58);
        bone58.cubeList.add(new ModelBox(bone58, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone58.cubeList.add(new ModelBox(bone58, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger33_r3 = new ModelRenderer(this);
        finger33_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone58.addChild(finger33_r3);
        setRotationAngle(finger33_r3, 0.0F, 0.0F, -1.1345F);
        finger33_r3.cubeList.add(new ModelBox(finger33_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone59 = new ModelRenderer(this);
        bone59.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone59);
        bone59.cubeList.add(new ModelBox(bone59, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone59.cubeList.add(new ModelBox(bone59, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger43_r3 = new ModelRenderer(this);
        finger43_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone59.addChild(finger43_r3);
        setRotationAngle(finger43_r3, 0.0F, 0.0F, -1.1345F);
        finger43_r3.cubeList.add(new ModelBox(finger43_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone60 = new ModelRenderer(this);
        bone60.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(bone60);
        bone60.cubeList.add(new ModelBox(bone60, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone60.cubeList.add(new ModelBox(bone60, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger53_r2 = new ModelRenderer(this);
        finger53_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone60.addChild(finger53_r2);
        setRotationAngle(finger53_r2, 0.0F, 0.0F, -1.1345F);
        finger53_r2.cubeList.add(new ModelBox(finger53_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb15 = new ModelRenderer(this);
        thumb15.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers15.addChild(thumb15);


        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb15.addChild(cube_r43);
        setRotationAngle(cube_r43, 0.48F, 0.0F, -0.5236F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb15.addChild(cube_r44);
        setRotationAngle(cube_r44, -0.4363F, 0.0F, 0.0F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb15.addChild(cube_r45);
        setRotationAngle(cube_r45, -1.5708F, -0.6109F, 0.0F);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand16 = new ModelRenderer(this);
        hand16.setRotationPoint(26.0F, 19.0F, -14.0F);
        setRotationAngle(hand16, 0.0F, -1.5708F, 0.0F);
        hand16.cubeList.add(new ModelBox(hand16, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand16.cubeList.add(new ModelBox(hand16, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers16 = new ModelRenderer(this);
        fingers16.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand16.addChild(fingers16);


        bone61 = new ModelRenderer(this);
        bone61.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone61);
        bone61.cubeList.add(new ModelBox(bone61, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone61.cubeList.add(new ModelBox(bone61, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger24_r3 = new ModelRenderer(this);
        finger24_r3.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone61.addChild(finger24_r3);
        setRotationAngle(finger24_r3, 0.0F, 0.0F, -1.1345F);
        finger24_r3.cubeList.add(new ModelBox(finger24_r3, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone62 = new ModelRenderer(this);
        bone62.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone62);
        bone62.cubeList.add(new ModelBox(bone62, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone62.cubeList.add(new ModelBox(bone62, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger34_r3 = new ModelRenderer(this);
        finger34_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone62.addChild(finger34_r3);
        setRotationAngle(finger34_r3, 0.0F, 0.0F, -1.1345F);
        finger34_r3.cubeList.add(new ModelBox(finger34_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone63 = new ModelRenderer(this);
        bone63.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone63);
        bone63.cubeList.add(new ModelBox(bone63, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone63.cubeList.add(new ModelBox(bone63, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger44_r3 = new ModelRenderer(this);
        finger44_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone63.addChild(finger44_r3);
        setRotationAngle(finger44_r3, 0.0F, 0.0F, -1.1345F);
        finger44_r3.cubeList.add(new ModelBox(finger44_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone64 = new ModelRenderer(this);
        bone64.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(bone64);
        bone64.cubeList.add(new ModelBox(bone64, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone64.cubeList.add(new ModelBox(bone64, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger54_r2 = new ModelRenderer(this);
        finger54_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone64.addChild(finger54_r2);
        setRotationAngle(finger54_r2, 0.0F, 0.0F, -1.1345F);
        finger54_r2.cubeList.add(new ModelBox(finger54_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb16 = new ModelRenderer(this);
        thumb16.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers16.addChild(thumb16);


        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb16.addChild(cube_r46);
        setRotationAngle(cube_r46, 0.48F, 0.0F, -0.5236F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb16.addChild(cube_r47);
        setRotationAngle(cube_r47, -0.4363F, 0.0F, 0.0F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb16.addChild(cube_r48);
        setRotationAngle(cube_r48, -1.5708F, -0.6109F, 0.0F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand17 = new ModelRenderer(this);
        hand17.setRotationPoint(-46.0F, 13.0F, 7.0F);
        setRotationAngle(hand17, 0.0F, -1.5708F, 0.0F);
        hand17.cubeList.add(new ModelBox(hand17, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand17.cubeList.add(new ModelBox(hand17, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers17 = new ModelRenderer(this);
        fingers17.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand17.addChild(fingers17);


        bone65 = new ModelRenderer(this);
        bone65.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone65);
        bone65.cubeList.add(new ModelBox(bone65, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone65.cubeList.add(new ModelBox(bone65, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger25_r3 = new ModelRenderer(this);
        finger25_r3.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone65.addChild(finger25_r3);
        setRotationAngle(finger25_r3, 0.0F, 0.0F, -1.1345F);
        finger25_r3.cubeList.add(new ModelBox(finger25_r3, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone66 = new ModelRenderer(this);
        bone66.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone66);
        bone66.cubeList.add(new ModelBox(bone66, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone66.cubeList.add(new ModelBox(bone66, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger35_r3 = new ModelRenderer(this);
        finger35_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone66.addChild(finger35_r3);
        setRotationAngle(finger35_r3, 0.0F, 0.0F, -1.1345F);
        finger35_r3.cubeList.add(new ModelBox(finger35_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone67 = new ModelRenderer(this);
        bone67.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone67);
        bone67.cubeList.add(new ModelBox(bone67, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone67.cubeList.add(new ModelBox(bone67, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger45_r3 = new ModelRenderer(this);
        finger45_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone67.addChild(finger45_r3);
        setRotationAngle(finger45_r3, 0.0F, 0.0F, -1.1345F);
        finger45_r3.cubeList.add(new ModelBox(finger45_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone68 = new ModelRenderer(this);
        bone68.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(bone68);
        bone68.cubeList.add(new ModelBox(bone68, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone68.cubeList.add(new ModelBox(bone68, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger55_r2 = new ModelRenderer(this);
        finger55_r2.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone68.addChild(finger55_r2);
        setRotationAngle(finger55_r2, 0.0F, 0.0F, -1.1345F);
        finger55_r2.cubeList.add(new ModelBox(finger55_r2, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb17 = new ModelRenderer(this);
        thumb17.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers17.addChild(thumb17);


        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb17.addChild(cube_r49);
        setRotationAngle(cube_r49, 0.48F, 0.0F, -0.5236F);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb17.addChild(cube_r50);
        setRotationAngle(cube_r50, -0.4363F, 0.0F, 0.0F);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb17.addChild(cube_r51);
        setRotationAngle(cube_r51, -1.5708F, -0.6109F, 0.0F);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand18 = new ModelRenderer(this);
        hand18.setRotationPoint(-46.0F, 13.0F, 7.0F);
        setRotationAngle(hand18, 0.0F, -1.5708F, 0.0F);
        hand18.cubeList.add(new ModelBox(hand18, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand18.cubeList.add(new ModelBox(hand18, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers18 = new ModelRenderer(this);
        fingers18.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand18.addChild(fingers18);


        bone69 = new ModelRenderer(this);
        bone69.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone69);
        bone69.cubeList.add(new ModelBox(bone69, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone69.cubeList.add(new ModelBox(bone69, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger26_r2 = new ModelRenderer(this);
        finger26_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone69.addChild(finger26_r2);
        setRotationAngle(finger26_r2, 0.0F, 0.0F, -1.1345F);
        finger26_r2.cubeList.add(new ModelBox(finger26_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone70 = new ModelRenderer(this);
        bone70.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone70);
        bone70.cubeList.add(new ModelBox(bone70, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone70.cubeList.add(new ModelBox(bone70, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger36_r2 = new ModelRenderer(this);
        finger36_r2.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone70.addChild(finger36_r2);
        setRotationAngle(finger36_r2, 0.0F, 0.0F, -1.1345F);
        finger36_r2.cubeList.add(new ModelBox(finger36_r2, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone71 = new ModelRenderer(this);
        bone71.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone71);
        bone71.cubeList.add(new ModelBox(bone71, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone71.cubeList.add(new ModelBox(bone71, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger46_r2 = new ModelRenderer(this);
        finger46_r2.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone71.addChild(finger46_r2);
        setRotationAngle(finger46_r2, 0.0F, 0.0F, -1.1345F);
        finger46_r2.cubeList.add(new ModelBox(finger46_r2, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone72 = new ModelRenderer(this);
        bone72.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(bone72);
        bone72.cubeList.add(new ModelBox(bone72, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone72.cubeList.add(new ModelBox(bone72, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger56_r1 = new ModelRenderer(this);
        finger56_r1.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone72.addChild(finger56_r1);
        setRotationAngle(finger56_r1, 0.0F, 0.0F, -1.1345F);
        finger56_r1.cubeList.add(new ModelBox(finger56_r1, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb18 = new ModelRenderer(this);
        thumb18.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers18.addChild(thumb18);


        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb18.addChild(cube_r52);
        setRotationAngle(cube_r52, 0.48F, 0.0F, -0.5236F);
        cube_r52.cubeList.add(new ModelBox(cube_r52, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb18.addChild(cube_r53);
        setRotationAngle(cube_r53, -0.4363F, 0.0F, 0.0F);
        cube_r53.cubeList.add(new ModelBox(cube_r53, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb18.addChild(cube_r54);
        setRotationAngle(cube_r54, -1.5708F, -0.6109F, 0.0F);
        cube_r54.cubeList.add(new ModelBox(cube_r54, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand19 = new ModelRenderer(this);
        hand19.setRotationPoint(26.0F, -99.0F, 16.0F);
        setRotationAngle(hand19, 0.0F, -1.5708F, 0.0F);
        hand19.cubeList.add(new ModelBox(hand19, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand19.cubeList.add(new ModelBox(hand19, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers19 = new ModelRenderer(this);
        fingers19.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand19.addChild(fingers19);


        bone73 = new ModelRenderer(this);
        bone73.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone73);
        bone73.cubeList.add(new ModelBox(bone73, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone73.cubeList.add(new ModelBox(bone73, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger15_r2 = new ModelRenderer(this);
        finger15_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone73.addChild(finger15_r2);
        setRotationAngle(finger15_r2, 0.0F, 0.0F, -1.1345F);
        finger15_r2.cubeList.add(new ModelBox(finger15_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone74 = new ModelRenderer(this);
        bone74.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone74);
        bone74.cubeList.add(new ModelBox(bone74, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone74.cubeList.add(new ModelBox(bone74, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger25_r4 = new ModelRenderer(this);
        finger25_r4.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone74.addChild(finger25_r4);
        setRotationAngle(finger25_r4, 0.0F, 0.0F, -1.1345F);
        finger25_r4.cubeList.add(new ModelBox(finger25_r4, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone75 = new ModelRenderer(this);
        bone75.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone75);
        bone75.cubeList.add(new ModelBox(bone75, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone75.cubeList.add(new ModelBox(bone75, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger35_r4 = new ModelRenderer(this);
        finger35_r4.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone75.addChild(finger35_r4);
        setRotationAngle(finger35_r4, 0.0F, 0.0F, -1.1345F);
        finger35_r4.cubeList.add(new ModelBox(finger35_r4, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone76 = new ModelRenderer(this);
        bone76.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(bone76);
        bone76.cubeList.add(new ModelBox(bone76, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone76.cubeList.add(new ModelBox(bone76, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger45_r4 = new ModelRenderer(this);
        finger45_r4.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone76.addChild(finger45_r4);
        setRotationAngle(finger45_r4, 0.0F, 0.0F, -1.1345F);
        finger45_r4.cubeList.add(new ModelBox(finger45_r4, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb19 = new ModelRenderer(this);
        thumb19.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers19.addChild(thumb19);


        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb19.addChild(cube_r55);
        setRotationAngle(cube_r55, 0.48F, 0.0F, -0.5236F);
        cube_r55.cubeList.add(new ModelBox(cube_r55, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb19.addChild(cube_r56);
        setRotationAngle(cube_r56, -0.4363F, 0.0F, 0.0F);
        cube_r56.cubeList.add(new ModelBox(cube_r56, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb19.addChild(cube_r57);
        setRotationAngle(cube_r57, -1.5708F, -0.6109F, 0.0F);
        cube_r57.cubeList.add(new ModelBox(cube_r57, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));

        hand20 = new ModelRenderer(this);
        hand20.setRotationPoint(-30.0F, -91.0F, 1.0F);
        setRotationAngle(hand20, 0.0F, -1.5708F, 0.0F);
        hand20.cubeList.add(new ModelBox(hand20, 0, 0, -8.0F, -19.0F, -14.0F, 4, 18, 15, 0.0F));
        hand20.cubeList.add(new ModelBox(hand20, 23, 23, -4.0F, -19.0F, -14.0F, 1, 8, 15, 0.0F));

        fingers20 = new ModelRenderer(this);
        fingers20.setRotationPoint(1.0F, 28.0F, -7.0F);
        hand20.addChild(fingers20);


        bone77 = new ModelRenderer(this);
        bone77.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone77);
        bone77.cubeList.add(new ModelBox(bone77, 51, 51, 0.0F, -35.0F, 5.0F, 4, 6, 3, 0.0F));
        bone77.cubeList.add(new ModelBox(bone77, 38, 14, -8.0F, -29.0F, 5.0F, 12, 4, 3, 0.0F));

        finger16_r2 = new ModelRenderer(this);
        finger16_r2.setRotationPoint(2.0F, -40.0F, 7.0F);
        bone77.addChild(finger16_r2);
        setRotationAngle(finger16_r2, 0.0F, 0.0F, -1.1345F);
        finger16_r2.cubeList.add(new ModelBox(finger16_r2, 40, 28, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone78 = new ModelRenderer(this);
        bone78.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone78);
        bone78.cubeList.add(new ModelBox(bone78, 23, 7, -9.0F, -29.0F, 1.0F, 12, 4, 3, 0.0F));
        bone78.cubeList.add(new ModelBox(bone78, 0, 53, -1.0F, -35.0F, 1.0F, 4, 6, 3, 0.0F));

        finger26_r3 = new ModelRenderer(this);
        finger26_r3.setRotationPoint(2.0F, -40.0F, 3.0F);
        bone78.addChild(finger26_r3);
        setRotationAngle(finger26_r3, 0.0F, 0.0F, -1.1345F);
        finger26_r3.cubeList.add(new ModelBox(finger26_r3, 9, 43, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone79 = new ModelRenderer(this);
        bone79.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone79);
        bone79.cubeList.add(new ModelBox(bone79, 23, 0, -8.0F, -29.0F, -3.0F, 12, 4, 3, 0.0F));
        bone79.cubeList.add(new ModelBox(bone79, 53, 0, 0.0F, -35.0F, -3.0F, 4, 6, 3, 0.0F));

        finger36_r3 = new ModelRenderer(this);
        finger36_r3.setRotationPoint(3.0F, -40.0F, -1.0F);
        bone79.addChild(finger36_r3);
        setRotationAngle(finger36_r3, 0.0F, 0.0F, -1.1345F);
        finger36_r3.cubeList.add(new ModelBox(finger36_r3, 23, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        bone80 = new ModelRenderer(this);
        bone80.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(bone80);
        bone80.cubeList.add(new ModelBox(bone80, 14, 53, 1.0F, -35.0F, -7.0F, 3, 6, 3, 0.0F));
        bone80.cubeList.add(new ModelBox(bone80, 40, 21, -7.0F, -29.0F, -7.0F, 11, 4, 3, 0.0F));

        finger46_r3 = new ModelRenderer(this);
        finger46_r3.setRotationPoint(3.0F, -40.0F, -5.0F);
        bone80.addChild(finger46_r3);
        setRotationAngle(finger46_r3, 0.0F, 0.0F, -1.1345F);
        finger46_r3.cubeList.add(new ModelBox(finger46_r3, 37, 46, -8.0F, -4.0F, -2.0F, 4, 7, 3, 0.0F));

        thumb20 = new ModelRenderer(this);
        thumb20.setRotationPoint(0.0F, 0.0F, 0.0F);
        fingers20.addChild(thumb20);


        cube_r58 = new ModelRenderer(this);
        cube_r58.setRotationPoint(-4.0F, -41.0F, 7.0F);
        thumb20.addChild(cube_r58);
        setRotationAngle(cube_r58, 0.48F, 0.0F, -0.5236F);
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 0, -3.0F, -2.0F, 0.0F, 4, 13, 2, 0.0F));

        cube_r59 = new ModelRenderer(this);
        cube_r59.setRotationPoint(0.0F, -34.0F, 12.0F);
        thumb20.addChild(cube_r59);
        setRotationAngle(cube_r59, -0.4363F, 0.0F, 0.0F);
        cube_r59.cubeList.add(new ModelBox(cube_r59, 0, 33, -3.0F, 0.0F, 0.0F, 4, 11, 2, 0.0F));

        cube_r60 = new ModelRenderer(this);
        cube_r60.setRotationPoint(0.0F, -25.0F, 9.0F);
        thumb20.addChild(cube_r60);
        setRotationAngle(cube_r60, -1.5708F, -0.6109F, 0.0F);
        cube_r60.cubeList.add(new ModelBox(cube_r60, 54, 28, -3.0F, 0.0F, 0.0F, 4, 7, 2, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        hand.render(f5);
        hand2.render(f5);
        hand3.render(f5);
        hand4.render(f5);
        hand5.render(f5);
        hand6.render(f5);
        hand7.render(f5);
        hand8.render(f5);
        hand9.render(f5);
        hand10.render(f5);
        hand11.render(f5);
        hand12.render(f5);
        hand13.render(f5);
        hand14.render(f5);
        hand15.render(f5);
        hand16.render(f5);
        hand17.render(f5);
        hand18.render(f5);
        hand19.render(f5);
        hand20.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }*/
}

