package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;// Made with Blockbench 3.7.5
// Exported for Minecraft version 1.12
// Paste this class into your mod and generate all required imports


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;


public class ichidai extends ModelBase {
	private final ModelRenderer bone;
	private final ModelRenderer cube_r1;
	private final ModelRenderer cube_r2;

	public ichidai() {
		textureWidth = 64;
		textureHeight = 64;

		bone = new ModelRenderer(this);
		bone.setRotationPoint(9.0F, 20.0F, -6.0F);
		bone.cubeList.add(new ModelBox(bone, 0, 0, -24.0F, -2.0F, -3.0F, 31, 2, 3, 0.0F));

		cube_r1 = new ModelRenderer(this);
		cube_r1.setRotationPoint(7.0F, 0.0F, 0.0F);
		bone.addChild(cube_r1);
		setRotationAngle(cube_r1, 0.0F, -0.5672F, 0.0F);
		cube_r1.cubeList.add(new ModelBox(cube_r1, 5, 7, -2.0F, -2.0F, -2.0F, 12, 2, 3, 0.0F));

		cube_r2 = new ModelRenderer(this);
		cube_r2.setRotationPoint(-24.0F, 0.0F, 0.0F);
		bone.addChild(cube_r2);
		setRotationAngle(cube_r2, 0.0F, 0.5672F, 0.0F);
		cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 0, -11.0F, -2.0F, -2.0F, 13, 2, 3, 0.0F));
	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		bone.render(f5);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}
}