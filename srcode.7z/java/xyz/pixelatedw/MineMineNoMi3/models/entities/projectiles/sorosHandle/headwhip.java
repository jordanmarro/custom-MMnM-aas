package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;// Made with Blockbench 3.7.5
// Exported for Minecraft version 1.12
// Paste this class into your mod and generate all required imports


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class headwhip extends ModelBase {
private final ModelRenderer bone7;
private final ModelRenderer cube_r1;
private final ModelRenderer bone8;
private final ModelRenderer cube_r2;
private final ModelRenderer bone9;
private final ModelRenderer cube_r3;
private final ModelRenderer bone10;
private final ModelRenderer cube_r4;
private final ModelRenderer cube_r5;
private final ModelRenderer cube_r6;
private final ModelRenderer cube_r7;
private final ModelRenderer cube_r8;
private final ModelRenderer cube_r9;
private final ModelRenderer cube_r10;

public headwhip() {
        textureWidth = 224;
        textureHeight = 224;

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(2.0F, 3.0F, 20.0F);
        setRotationAngle(bone7, 0.3927F, -0.7418F, -0.1309F);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(9.0F, 5.0F, -5.0F);
        bone7.addChild(cube_r1);
        setRotationAngle(cube_r1, -0.3491F, 1.0036F, 0.0F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 47, 161, -10.0F, -16.0F, -18.0F, 0, 8, 16, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 37, 107, -14.0F, -8.0F, -20.0F, 9, 10, 18, 0.0F));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(-9.0F, -4.0F, -5.0F);
        bone7.addChild(bone8);
        setRotationAngle(bone8, 0.0F, 0.3927F, 0.0F);


        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(0.1684F, -0.0612F, -3.0674F);
        bone8.addChild(cube_r2);
        setRotationAngle(cube_r2, -0.0873F, 0.3927F, 0.3491F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 163, 72, -2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 167, 141, -6.8716F, -4.1979F, -9.4368F, 9, 10, 13, 0.0F));

        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(-4.0F, -4.0F, -10.0F);
        bone8.addChild(bone9);
        setRotationAngle(bone9, 0.0436F, 0.0F, 0.0F);


        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(-0.594F, 0.9996F, -4.2158F);
        bone9.addChild(cube_r3);
        setRotationAngle(cube_r3, -0.0873F, 0.6109F, 0.3491F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 75, 91, -2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 0, 119, -6.8716F, -4.1979F, -13.4368F, 9, 10, 17, 0.0F));

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(-8.0F, -5.0F, -11.0F);
        bone9.addChild(bone10);
        setRotationAngle(bone10, -0.48F, 0.0F, -0.2618F);


        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone10.addChild(cube_r4);
        setRotationAngle(cube_r4, -0.0873F, 0.1309F, 0.1309F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 53, 32, 0.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 54, 0, -7.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 32, -7.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 44, 8, 0.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 33, -4.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 14, 48, -3.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 32, -4.4153F, -0.1666F, -23.0497F, 5, 0, 10, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 92, 107, -9.4153F, -12.1666F, -14.0497F, 14, 15, 12, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(3.406F, -6.0004F, -8.2158F);
        bone10.addChild(cube_r5);
        setRotationAngle(cube_r5, -0.0873F, 0.1309F, 0.6981F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(-7.594F, -6.0004F, -8.2158F);
        bone10.addChild(cube_r6);
        setRotationAngle(cube_r6, -0.0873F, 0.1309F, -0.6981F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone10.addChild(cube_r7);
        setRotationAngle(cube_r7, -0.0436F, 0.1309F, 0.1309F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 212, -0.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 212, -5.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 164, 126, -9.027F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 128, 0, -10.027F, -1.208F, -14.7396F, 16, 1, 13, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone10.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.3054F, 0.1309F, 0.1309F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 4, 0, 0.973F, -3.208F, -14.2842F, 1, 2, 0, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 4, 0, -6.027F, -3.208F, -14.2842F, 1, 2, 0, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 16, 1.973F, -3.208F, -14.2842F, 0, 2, 0, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 173, 19, -9.027F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 186, 115, -11.027F, -1.208F, -14.7396F, 18, 9, 0, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 138, 42, -10.027F, -1.208F, -15.7396F, 16, 1, 14, 0.0F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone10.addChild(cube_r9);
        setRotationAngle(cube_r9, -0.1745F, 0.1309F, 0.1309F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 175, 57, 4.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 188, 56, -22.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0.0F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(7.1447F, 6.0519F, -9.4387F);
        bone10.addChild(cube_r10);
        setRotationAngle(cube_r10, -0.0873F, 0.6109F, 0.1309F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 36, 0, -4.4153F, -0.1666F, -23.0497F, 5, 0, 8, 0.0F));
        }

@Override
public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone7.render(f5);
        }

public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
        }
        }
        