package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class rope extends ModelBase {
    private final ModelRenderer bone9;
    private final ModelRenderer bone;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer bone6;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer bone7;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer bone8;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;

    public rope() {
        textureWidth = 64;
        textureHeight = 64;

        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(0, 24, 23);
        setRotationAngle(bone9, 0, 1.5708F, 0);


        bone = new ModelRenderer(this);
        bone.setRotationPoint(0, -2, 0);
        bone9.addChild(bone);
        bone.setTextureOffset(6, 8).addBox(12, -4, -3, 4, 1, 1, 0);
        bone.setTextureOffset(0, 0).addBox(-8, -4, -3, 16, 4, 2, 0);
        bone.setTextureOffset(10, 12).addBox(12, -1, -3, 3, 1, 1, 0);
        bone.setTextureOffset(6, 6).addBox(12, -3, -3, 5, 1, 1, 0);
        bone.setTextureOffset(10, 10).addBox(12, -2, -3, 4, 1, 1, 0);

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(11, 0, -2);
        bone.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.9599F, -1.5708F, 0);
        cube_r1.setTextureOffset(0, 14).addBox(-1, -4, 4, 1, 4, 1, 0);

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(8, 0, -2);
        bone.addChild(cube_r2);
        setRotationAngle(cube_r2, 1.5708F, -1.5708F, 0);
        cube_r2.setTextureOffset(0, 6).addBox(-1, -4, 0, 1, 4, 4, 0);

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(64, 0, 0);
        bone.addChild(bone5);
        bone5.setTextureOffset(6, 8).addBox(12, -4, -3, 4, 1, 1, 0);
        bone5.setTextureOffset(0, 0).addBox(-8, -4, -3, 16, 4, 2, 0);
        bone5.setTextureOffset(10, 12).addBox(12, -1, -3, 3, 1, 1, 0);
        bone5.setTextureOffset(6, 6).addBox(12, -3, -3, 5, 1, 1, 0);
        bone5.setTextureOffset(10, 10).addBox(12, -2, -3, 4, 1, 1, 0);

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(11, 0, -2);
        bone5.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.9599F, -1.5708F, 0);
        cube_r9.setTextureOffset(0, 14).addBox(-1, -4, 4, 1, 4, 1, 0);

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(8, 0, -2);
        bone5.addChild(cube_r10);
        setRotationAngle(cube_r10, 1.5708F, -1.5708F, 0);
        cube_r10.setTextureOffset(0, 6).addBox(-1, -4, 0, 1, 4, 4, 0);

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(48, -4, -3);
        bone.addChild(bone6);
        setRotationAngle(bone6, 3.1416F, 0, 0);
        bone6.setTextureOffset(6, 8).addBox(44, -4, -3, 4, 1, 1, 0);
        bone6.setTextureOffset(0, 0).addBox(24, -4, -3, 16, 4, 2, 0);
        bone6.setTextureOffset(10, 12).addBox(44, -1, -3, 3, 1, 1, 0);
        bone6.setTextureOffset(6, 6).addBox(44, -3, -3, 5, 1, 1, 0);
        bone6.setTextureOffset(10, 10).addBox(44, -2, -3, 4, 1, 1, 0);

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(11, 0, -2);
        bone6.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.9599F, -1.5708F, 0);
        cube_r11.setTextureOffset(0, 14).addBox(-1, -30.2129F, -14.3544F, 1, 4, 1, 0);

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(8, 0, -2);
        bone6.addChild(cube_r12);
        setRotationAngle(cube_r12, 1.5708F, -1.5708F, 0);
        cube_r12.setTextureOffset(0, 6).addBox(-1, -36, 0, 1, 4, 4, 0);

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(96, 0, 0);
        bone.addChild(bone7);
        bone7.setTextureOffset(6, 8).addBox(12, -4, -3, 4, 1, 1, 0);
        bone7.setTextureOffset(0, 0).addBox(-8, -4, -3, 16, 4, 2, 0);
        bone7.setTextureOffset(10, 12).addBox(12, -1, -3, 3, 1, 1, 0);
        bone7.setTextureOffset(6, 6).addBox(12, -3, -3, 5, 1, 1, 0);
        bone7.setTextureOffset(10, 10).addBox(12, -2, -3, 4, 1, 1, 0);

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(11, 0, -2);
        bone7.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.9599F, -1.5708F, 0);
        cube_r13.setTextureOffset(0, 14).addBox(-1, -4, 4, 1, 4, 1, 0);

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(8, 0, -2);
        bone7.addChild(cube_r14);
        setRotationAngle(cube_r14, 1.5708F, -1.5708F, 0);
        cube_r14.setTextureOffset(0, 6).addBox(-1, -4, 0, 1, 4, 4, 0);

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(80, -4, -3);
        bone.addChild(bone8);
        setRotationAngle(bone8, 3.1416F, 0, 0);
        bone8.setTextureOffset(6, 8).addBox(44, -4, -3, 4, 1, 1, 0);
        bone8.setTextureOffset(0, 0).addBox(24, -4, -3, 16, 4, 2, 0);
        bone8.setTextureOffset(10, 12).addBox(44, -1, -3, 3, 1, 1, 0);
        bone8.setTextureOffset(6, 6).addBox(44, -3, -3, 5, 1, 1, 0);
        bone8.setTextureOffset(10, 10).addBox(44, -2, -3, 4, 1, 1, 0);

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(11, 0, -2);
        bone8.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.9599F, -1.5708F, 0);
        cube_r15.setTextureOffset(0, 14).addBox(-1, -30.2129F, -14.3544F, 1, 4, 1, 0);

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(8, 0, -2);
        bone8.addChild(cube_r16);
        setRotationAngle(cube_r16, 1.5708F, -1.5708F, 0);
        cube_r16.setTextureOffset(0, 6).addBox(-1, -36, 0, 1, 4, 4, 0);

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(16, -6, -3);
        bone9.addChild(bone2);
        setRotationAngle(bone2, 3.1416F, 0, 0);
        bone2.setTextureOffset(6, 8).addBox(12, -4, -3, 4, 1, 1, 0);
        bone2.setTextureOffset(0, 0).addBox(-8, -4, -3, 16, 4, 2, 0);
        bone2.setTextureOffset(10, 12).addBox(12, -1, -3, 3, 1, 1, 0);
        bone2.setTextureOffset(6, 6).addBox(12, -3, -3, 5, 1, 1, 0);
        bone2.setTextureOffset(10, 10).addBox(12, -2, -3, 4, 1, 1, 0);

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(11, 0, -2);
        bone2.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.9599F, -1.5708F, 0);
        cube_r3.setTextureOffset(0, 14).addBox(-1, -4, 4, 1, 4, 1, 0);

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(8, 0, -2);
        bone2.addChild(cube_r4);
        setRotationAngle(cube_r4, 1.5708F, -1.5708F, 0);
        cube_r4.setTextureOffset(0, 6).addBox(-1, -4, 0, 1, 4, 4, 0);

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(32, -2, 0);
        bone9.addChild(bone3);
        bone3.setTextureOffset(6, 8).addBox(12, -4, -3, 4, 1, 1, 0);
        bone3.setTextureOffset(0, 0).addBox(-8, -4, -3, 16, 4, 2, 0);
        bone3.setTextureOffset(10, 12).addBox(12, -1, -3, 3, 1, 1, 0);
        bone3.setTextureOffset(6, 6).addBox(12, -3, -3, 5, 1, 1, 0);
        bone3.setTextureOffset(10, 10).addBox(12, -2, -3, 4, 1, 1, 0);

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(11, 0, -2);
        bone3.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.9599F, -1.5708F, 0);
        cube_r5.setTextureOffset(0, 14).addBox(-1, -4, 4, 1, 4, 1, 0);

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(8, 0, -2);
        bone3.addChild(cube_r6);
        setRotationAngle(cube_r6, 1.5708F, -1.5708F, 0);
        cube_r6.setTextureOffset(0, 6).addBox(-1, -4, 0, 1, 4, 4, 0);

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(16, -6, -3);
        bone9.addChild(bone4);
        setRotationAngle(bone4, 3.1416F, 0, 0);
        bone4.setTextureOffset(6, 8).addBox(44, -4, -3, 4, 1, 1, 0);
        bone4.setTextureOffset(0, 0).addBox(24, -4, -3, 16, 4, 2, 0);
        bone4.setTextureOffset(10, 12).addBox(44, -1, -3, 3, 1, 1, 0);
        bone4.setTextureOffset(6, 6).addBox(44, -3, -3, 5, 1, 1, 0);
        bone4.setTextureOffset(10, 10).addBox(44, -2, -3, 4, 1, 1, 0);

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(11, 0, -2);
        bone4.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.9599F, -1.5708F, 0);
        cube_r7.setTextureOffset(0, 14).addBox(-1, -30.2129F, -14.3544F, 1, 4, 1, 0);

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(8, 0, -2);
        bone4.addChild(cube_r8);
        setRotationAngle(cube_r8, 1.5708F, -1.5708F, 0);
        cube_r8.setTextureOffset(0, 6).addBox(-1, -36, 0, 1, 4, 4, 0);
    
        bone.offsetY -= 1;
        bone2.offsetY -= 1;
        bone3.offsetY -= 1;
        bone4.offsetY -= 1;
        bone5.offsetY -= 1;
        bone6.offsetY -= 1;
        bone7.offsetY -= 1;
        bone8.offsetY -= 1;
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
        bone2.render(f5);
        bone3.render(f5);
        bone4.render(f5);
        bone5.render(f5);
        bone6.render(f5);
        bone7.render(f5);
        bone8.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

}
