package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;

// Made with Blockbench 3.7.4
// Exported for Minecraft version 1.12
// Paste this class into your mod and generate all required imports


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class inugami extends ModelBase {
    private final ModelRenderer bone;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer cube_r25;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer cube_r37;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r42;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer cube_r45;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer cube_r48;

    public inugami() {
        textureWidth = 256;
        textureHeight = 256;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 13.0F, -3.0F);
        bone.cubeList.add(new ModelBox(bone, 1, 49, -3.0F, -5.0F, 2.0F, 6, 1, 11, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 10, 202, -3.0F, 6.0F, 2.0F, 6, 1, 11, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 0, 126, -4.0F, -4.0F, 1.0F, 8, 10, 13, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 0, 54, -4.0F, -1.0F, 11.0F, 8, 9, 22, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 10, 202, -3.0F, -3.0F, 0.0F, 6, 3, 1, 0.0F));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-1.0F, 6.0F, -10.0F);
        bone.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.2182F, 0.0F, -0.829F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(0.0F, 6.0F, -10.0F);
        bone.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.2182F, 0.0F, -0.829F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(1.0F, 6.0F, -10.0F);
        bone.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.2182F, 0.0F, -0.829F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(2.0F, 6.0F, -10.0F);
        bone.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.2182F, 0.0F, -0.829F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(3.0F, 6.0F, -10.0F);
        bone.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.2182F, 0.0F, -0.829F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(4.0F, 6.0F, -10.0F);
        bone.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.2182F, 0.0F, -0.829F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(4.0F, 6.0F, -10.0F);
        bone.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.2182F, 0.0F, 0.0F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 31, 66, -1.0F, -2.0F, 0.0F, 1, 2, 1, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 31, 66, -8.0F, -2.0F, 0.0F, 1, 2, 1, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(-2.0F, -1.0F, -10.0F);
        bone.addChild(cube_r8);
        setRotationAngle(cube_r8, -0.2182F, 0.4363F, 0.6109F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 36, 47, -1.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(-1.0F, -1.0F, -10.0F);
        bone.addChild(cube_r9);
        setRotationAngle(cube_r9, -0.2182F, 0.4363F, 0.6109F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 36, 47, -1.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(0.0F, -1.0F, -10.0F);
        bone.addChild(cube_r10);
        setRotationAngle(cube_r10, -0.2182F, 0.4363F, 0.6109F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 36, 47, -1.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(1.0F, -1.0F, -10.0F);
        bone.addChild(cube_r11);
        setRotationAngle(cube_r11, -0.2182F, 0.4363F, 0.6109F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 36, 47, -1.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(2.0F, -1.0F, -10.0F);
        bone.addChild(cube_r12);
        setRotationAngle(cube_r12, -0.2182F, 0.4363F, 0.6109F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 36, 47, -1.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(3.0F, -1.0F, -10.0F);
        bone.addChild(cube_r13);
        setRotationAngle(cube_r13, -0.2182F, 0.4363F, 0.6109F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 36, 47, -1.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(4.0F, -1.0F, -10.0F);
        bone.addChild(cube_r14);
        setRotationAngle(cube_r14, -0.3491F, 0.0F, 0.0F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 36, 47, -1.0F, -1.0F, 0.0F, 1, 3, 1, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 36, 47, -8.0F, -1.0F, 0.0F, 1, 3, 1, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(0.0F, 4.0F, 1.0F);
        bone.addChild(cube_r15);
        setRotationAngle(cube_r15, -0.3054F, 0.0F, 0.0F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 10, 202, 4.0F, -2.0F, -12.0F, 0, 1, 12, 0.0F));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 10, 202, -4.0F, -2.0F, -12.0F, 0, 1, 12, 0.0F));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 15, 222, -4.0F, -2.0F, -12.0F, 8, 1, 0, 0.0F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(0.0F, 6.0F, 1.0F);
        bone.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.1309F, 0.0F, 0.0F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 10, 202, -4.0F, -1.0F, -11.0F, 8, 1, 12, 0.0F));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(0.0F, -3.0F, -11.0F);
        bone.addChild(cube_r17);
        setRotationAngle(cube_r17, -0.3054F, 0.0F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 10, 202, -2.0F, -2.0F, 0.0F, 4, 2, 2, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(0.0F, -2.0F, -10.0F);
        bone.addChild(cube_r18);
        setRotationAngle(cube_r18, -0.3054F, 0.0F, 0.0F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 10, 202, -3.0F, -2.0F, -1.0F, 6, 2, 3, 0.0F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(0.0F, 2.0F, 1.0F);
        bone.addChild(cube_r19);
        setRotationAngle(cube_r19, -0.3054F, 0.0F, 0.0F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 10, 202, -4.0F, -2.0F, -12.0F, 8, 2, 13, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(0.0F, 5.0F, 1.0F);
        bone.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.1309F, 0.0F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 70, 167, -4.0F, -2.0F, -11.0F, 8, 2, 0, 0.0F));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 67, 156, -4.0F, -2.0F, -11.0F, 0, 2, 11, 0.0F));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 66, 156, 4.0F, -2.0F, -11.0F, 0, 2, 11, 0.0F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(2.0F, 6.0F, -3.0F);
        bone.addChild(bone2);


        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(cube_r21);
        setRotationAngle(cube_r21, -0.0436F, -0.9599F, 1.4399F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(0.0F, 0.0F, -1.0F);
        bone2.addChild(cube_r22);
        setRotationAngle(cube_r22, -0.0436F, -0.9599F, 1.4399F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(0.0F, 0.0F, -2.0F);
        bone2.addChild(cube_r23);
        setRotationAngle(cube_r23, -0.0436F, -1.0036F, 1.4399F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(0.0F, 0.0F, -3.0F);
        bone2.addChild(cube_r24);
        setRotationAngle(cube_r24, -0.0436F, -0.7854F, 1.4399F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone2.addChild(cube_r25);
        setRotationAngle(cube_r25, -0.0436F, -0.7854F, 1.4399F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(0.0F, 0.0F, -5.0F);
        bone2.addChild(cube_r26);
        setRotationAngle(cube_r26, -0.0436F, -0.7854F, 1.4399F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(0.0F, 0.0F, -6.0F);
        bone2.addChild(cube_r27);
        setRotationAngle(cube_r27, -0.0436F, -0.7854F, 1.4399F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(-2.0F, 4.0F, -3.0F);
        bone.addChild(bone5);
        setRotationAngle(bone5, -0.0436F, 0.0873F, -3.0543F);


        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone5.addChild(cube_r28);
        setRotationAngle(cube_r28, -0.0436F, -0.9599F, 1.4399F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(0.0F, 0.0F, -1.0F);
        bone5.addChild(cube_r29);
        setRotationAngle(cube_r29, -0.0436F, -0.9599F, 1.4399F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(0.0F, 0.0F, -2.0F);
        bone5.addChild(cube_r30);
        setRotationAngle(cube_r30, -0.0436F, -1.0036F, 1.4399F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(0.0F, 0.0F, -3.0F);
        bone5.addChild(cube_r31);
        setRotationAngle(cube_r31, -0.0436F, -0.7854F, 1.4399F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone5.addChild(cube_r32);
        setRotationAngle(cube_r32, -0.0436F, -0.7854F, 1.4399F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(0.0F, 0.0F, -5.0F);
        bone5.addChild(cube_r33);
        setRotationAngle(cube_r33, -0.0436F, -0.7854F, 1.4399F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(0.0F, 0.0F, -6.0F);
        bone5.addChild(cube_r34);
        setRotationAngle(cube_r34, -0.0436F, -0.7854F, 1.4399F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(-2.0F, 1.0F, -3.0F);
        bone.addChild(bone4);
        setRotationAngle(bone4, 0.3054F, 0.0F, -3.0107F);


        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone4.addChild(cube_r35);
        setRotationAngle(cube_r35, -0.0436F, -0.9599F, 1.4399F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(0.0F, 0.0F, -1.0F);
        bone4.addChild(cube_r36);
        setRotationAngle(cube_r36, -0.0436F, -0.9599F, 1.4399F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(0.0F, 0.0F, -2.0F);
        bone4.addChild(cube_r37);
        setRotationAngle(cube_r37, -0.0436F, -1.0036F, 1.4399F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(0.0F, 0.0F, -3.0F);
        bone4.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.0436F, -0.7854F, 1.4399F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone4.addChild(cube_r39);
        setRotationAngle(cube_r39, -0.0436F, -0.7854F, 1.4399F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(0.0F, 0.0F, -5.0F);
        bone4.addChild(cube_r40);
        setRotationAngle(cube_r40, -0.0436F, -0.7854F, 1.4399F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(0.0F, 0.0F, -6.0F);
        bone4.addChild(cube_r41);
        setRotationAngle(cube_r41, -0.0436F, -0.7854F, 1.4399F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(4.0F, 1.0F, -3.0F);
        bone.addChild(bone3);
        setRotationAngle(bone3, 0.3054F, 0.0F, -3.0107F);


        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone3.addChild(cube_r42);
        setRotationAngle(cube_r42, -0.0436F, -0.9599F, 1.4399F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(0.0F, 0.0F, -1.0F);
        bone3.addChild(cube_r43);
        setRotationAngle(cube_r43, -0.0436F, -0.9599F, 1.4399F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(0.0F, 0.0F, -2.0F);
        bone3.addChild(cube_r44);
        setRotationAngle(cube_r44, -0.0436F, -1.0036F, 1.4399F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(0.0F, 0.0F, -3.0F);
        bone3.addChild(cube_r45);
        setRotationAngle(cube_r45, -0.0436F, -0.7854F, 1.4399F);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone3.addChild(cube_r46);
        setRotationAngle(cube_r46, -0.0436F, -0.7854F, 1.4399F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0.0F, 0.0F, -5.0F);
        bone3.addChild(cube_r47);
        setRotationAngle(cube_r47, -0.0436F, -0.7854F, 1.4399F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(0.0F, 0.0F, -6.0F);
        bone3.addChild(cube_r48);
        setRotationAngle(cube_r48, -0.0436F, -0.7854F, 1.4399F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 31, 66, -1.0F, -2.0F, 0.0F, 1, 1, 1, 0.0F));

        bone.offsetY -= 1.0f;

    }



    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}