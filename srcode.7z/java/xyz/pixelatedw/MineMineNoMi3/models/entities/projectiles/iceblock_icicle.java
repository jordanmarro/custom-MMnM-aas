package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class iceblock_icicle extends ModelBase {
    private final ModelRenderer bone;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;

    public iceblock_icicle() {
        textureWidth = 512;
        textureHeight = 512;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 24.0F, 0.0F);
        bone.cubeList.add(new ModelBox(bone, 230, 112, -24.0F, -55.0F, -14.0F, 46, 44, 2, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 0, 0, -25.0F, -57.0F, -62.0F, 48, 47, 48, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 230, 158, -23.0F, -54.0F, -65.0F, 44, 42, 1, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 120, 120, -22.0F, -53.0F, -77.0F, 42, 40, 13, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 0, 95, -21.0F, -51.0F, -97.0F, 40, 34, 20, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 0, 149, -19.0F, -49.0F, -117.0F, 36, 30, 20, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 238, 0, -11.0F, -45.0F, -138.0F, 21, 21, 21, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 157, 60, -9.0F, -42.0F, -173.0F, 17, 17, 35, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 144, 0, -7.0F, -40.0F, -208.0F, 12, 13, 35, 0.0F));
        bone.cubeList.add(new ModelBox(bone, 112, 173, -24.0F, -55.0F, -64.0F, 46, 44, 2, 0.0F));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-25.0F, -16.0F, -37.0F);
        bone.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0F, -1.5708F, 0.0F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 96, 219, -24.0F, -39.0F, 0.0F, 46, 44, 2, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(16.0F, -58.0F, -37.0F);
        bone.addChild(cube_r2);
        setRotationAngle(cube_r2, -1.5708F, -1.5708F, 0.0F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 199, -24.0F, -39.0F, -1.0F, 46, 44, 2, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(16.0F, -9.0F, -37.0F);
        bone.addChild(cube_r3);
        setRotationAngle(cube_r3, -1.5708F, -1.5708F, 0.0F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 208, 208, -24.0F, -39.0F, -1.0F, 46, 44, 2, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(24.0F, -16.0F, -37.0F);
        bone.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.0F, -1.5708F, 0.0F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 226, 48, -24.0F, -39.0F, -1.0F, 46, 44, 2, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

}
