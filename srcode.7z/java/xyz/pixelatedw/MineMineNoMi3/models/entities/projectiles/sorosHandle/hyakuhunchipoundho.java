package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;// Made with Blockbench 3.7.5
// Exported for Minecraft version 1.12
// Paste this class into your mod and generate all required imports


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class hyakuhunchipoundho extends ModelBase {
	private final ModelRenderer bone;
	private final ModelRenderer cube_r1;
	private final ModelRenderer cube_r2;
	private final ModelRenderer bone2;
	private final ModelRenderer cube_r3;
	private final ModelRenderer cube_r4;
	private final ModelRenderer bone3;
	private final ModelRenderer cube_r5;
	private final ModelRenderer cube_r6;

	public hyakuhunchipoundho() {
		textureWidth = 8;
		textureHeight = 8;

		bone = new ModelRenderer(this);
		bone.setRotationPoint(-9.0F, 8.0F, -14.0F);
		setRotationAngle(bone, -1.7017F, -0.0873F, -0.7418F);
		bone.cubeList.add(new ModelBox(bone, 0, 0, -1.0F, -12.0F, 3.0F, 1, 26, 2, 0.0F));

		cube_r1 = new ModelRenderer(this);
		cube_r1.setRotationPoint(0.0F, 0.0F, 0.0F);
		bone.addChild(cube_r1);
		setRotationAngle(cube_r1, -2.3562F, 0.0F, 0.0F);
		

		cube_r2 = new ModelRenderer(this);
		cube_r2.setRotationPoint(0.0F, -5.0F, 1.0F);
		bone.addChild(cube_r2);
		setRotationAngle(cube_r2, -0.48F, 0.0F, 0.0F);
		cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 0, -1.0F, -14.0F, -1.0F, 1, 7, 2, 0.0F));

		bone2 = new ModelRenderer(this);
		bone2.setRotationPoint(13.0F, 11.0F, -18.0F);
		setRotationAngle(bone2, -1.5708F, -0.0873F, 1.2653F);
		bone2.cubeList.add(new ModelBox(bone2, 0, 0, -1.0F, -12.0F, 3.0F, 1, 26, 2, 0.0F));

		cube_r3 = new ModelRenderer(this);
		cube_r3.setRotationPoint(0.0F, 0.0F, 0.0F);
		bone2.addChild(cube_r3);
		setRotationAngle(cube_r3, -2.3562F, 0.0F, 0.0F);
		

		cube_r4 = new ModelRenderer(this);
		cube_r4.setRotationPoint(0.0F, -5.0F, 1.0F);
		bone2.addChild(cube_r4);
		setRotationAngle(cube_r4, -0.48F, 0.0F, 0.0F);
		cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 0, -1.0F, -14.0F, -1.0F, 1, 7, 2, 0.0F));

		bone3 = new ModelRenderer(this);
		bone3.setRotationPoint(9.0F, 20.0F, -18.0F);
		setRotationAngle(bone3, -1.5708F, -0.0873F, 1.2653F);
		bone3.cubeList.add(new ModelBox(bone3, 0, 0, -1.0F, -12.0F, 3.0F, 1, 26, 2, 0.0F));

		cube_r5 = new ModelRenderer(this);
		cube_r5.setRotationPoint(0.0F, 0.0F, 0.0F);
		bone3.addChild(cube_r5);
		setRotationAngle(cube_r5, -2.3562F, 0.0F, 0.0F);
		

		cube_r6 = new ModelRenderer(this);
		cube_r6.setRotationPoint(0.0F, -5.0F, 1.0F);
		bone3.addChild(cube_r6);
		setRotationAngle(cube_r6, -0.48F, 0.0F, 0.0F);
		cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 0, -1.0F, -14.0F, -1.0F, 1, 7, 2, 0.0F));
	}

	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		bone.render(f5);
		bone2.render(f5);
		bone3.render(f5);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}
}