package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class amanoiwato extends ModelBase {
    private final ModelRenderer main;
    private final ModelRenderer cube_r1;
    private final ModelRenderer face;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;

    public amanoiwato() {
        textureWidth = 256;
        textureHeight = 256;

        main = new ModelRenderer(this);
        main.setRotationPoint(-2.0F, 6.0F, -6.0F);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(1.0F, -5.2216F, -5.7569F);
        main.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0436F, 0.0F, 0.0F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 87, 158, -7.0F, -5.7741F, -0.9172F, 16, 16, 51, 0.0F));

        face = new ModelRenderer(this);
        face.setRotationPoint(-2.0F, 6.0F, -6.0F);
        setRotationAngle(face, -0.1309F, 0.0F, 0.0F);


        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(7.0F, -10.0F, -9.0F);
        face.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.1745F, 0.0F, 0.5236F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 57, 0, 0.0F, -2.7224F, -0.537F, 4, 4, 4, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(2.0F, -3.0F, -9.0F);
        face.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.1745F, 0.0F, 0.0F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 0, 0, -4.0F, -2.7224F, -0.537F, 4, 4, 5, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 0, 9, 0.0F, -2.7224F, -0.537F, 4, 4, 5, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(7.0F, 0.0F, -13.0F);
        face.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.1745F, 0.0F, 0.0F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 78, 42, -4.0F, -1.7224F, 3.0F, 1, 1, 2, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 10, 87, -7.0F, -1.7224F, 3.0F, 1, 1, 2, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(6.0F, 0.0F, -12.0F);
        face.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.1745F, 0.0F, 0.0F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 73, 87, -5.0F, -2.7224F, 1.463F, 2, 2, 3, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(-7.0F, 7.0F, -9.0F);
        face.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.1745F, 0.0F, 0.0F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 163, 2.0F, -6.7224F, 1.463F, 1, 4, 3, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 4, 15.0F, -7.7224F, 2.463F, 2, 1, 0, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 73, 3, 3.0F, -6.7224F, 2.463F, 1, 4, 0, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 73, 11, 14.0F, -6.7224F, 2.463F, 1, 4, 0, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 8, 163, 15.0F, -6.7224F, 1.463F, 1, 4, 3, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 60, 38, 3.0F, -2.7224F, 1.463F, 12, 1, 3, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(1.1983F, 6.445F, -9.0F);
        face.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.1745F, 0.0F, -0.2182F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 72, 98, -6.0F, -11.7224F, 1.463F, 3, 1, 3, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 13, 9, -6.0F, -10.7224F, 2.463F, 3, 1, 0, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(2.8017F, 6.445F, -9.0F);
        face.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.1745F, 0.0F, 0.2182F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 102, 42, 3.0F, -11.7224F, 1.463F, 3, 1, 3, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 29, 3.0F, -10.7224F, 2.463F, 3, 1, 0, 0.0F));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(-2.1098F, 8.6322F, -9.0F);
        face.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.1745F, 0.0F, 0.3054F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 13, 13, -6.0F, -10.7224F, 2.463F, 3, 1, 0, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 96, 63, -6.0F, -11.7224F, 1.463F, 3, 1, 3, 0.0F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(6.1098F, 8.6322F, -9.0F);
        face.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.1745F, 0.0F, -0.3054F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 8, 18, 3.0F, -10.7224F, 2.463F, 3, 1, 0, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 118, 81, 3.0F, -11.7224F, 1.463F, 3, 1, 3, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(-2.0F, 8.0F, -9.0F);
        face.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.1745F, 0.0F, 0.0F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 113, 145, -6.0F, -11.7224F, 1.463F, 1, 4, 3, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 160, 103, 13.0F, -11.7224F, 1.463F, 1, 4, 3, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 100, 38, -6.0F, -7.7224F, 1.463F, 3, 1, 3, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 128, 96, 11.0F, -7.7224F, 1.463F, 3, 1, 3, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(-2.0F, 6.7793F, -7.0938F);
        face.addChild(cube_r12);
        setRotationAngle(cube_r12, 0.48F, 0.0F, 0.0F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 57, 0, -5.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));
        cube_r12.cubeList.add(new ModelBox(cube_r12, 80, 87, 12.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(-2.0F, 0.1234F, -12.4667F);
        face.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.0436F, 0.0F, 0.0F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 56, 18, -5.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));
        cube_r13.cubeList.add(new ModelBox(cube_r13, 34, 67, 12.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(-2.0F, 2.1215F, -12.3795F);
        face.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.0436F, 0.0F, 0.0F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 56, 21, -5.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 0, 87, 12.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(-2.0F, 4.1787F, -10.5819F);
        face.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.2618F, 0.0F, 0.0F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 56, 24, -5.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 52, 87, 12.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(-2.0F, 4.3572F, -5.6745F);
        face.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.8727F, 0.0F, 0.0F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 56, 27, -5.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));
        cube_r16.cubeList.add(new ModelBox(cube_r16, 0, 95, 12.0F, -7.7224F, 1.463F, 1, 2, 1, 0.0F));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(6.0F, 6.0F, -9.0F);
        face.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.1745F, 0.0F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 28, -9.0F, -2.7224F, 2.463F, 10, 1, 0, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(-2.0F, 4.1481F, -11.6248F);
        face.addChild(cube_r18);
        setRotationAngle(cube_r18, -0.2182F, 0.0F, 0.0F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 0, 0, 0.0F, -2.7224F, 1.463F, 1, 3, 1, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 0, 9, 7.0F, -2.7224F, 1.463F, 1, 3, 1, 0.0F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(-2.0F, 2.7496F, -11.6611F);
        face.addChild(cube_r19);
        setRotationAngle(cube_r19, -0.4363F, 0.0F, 0.0F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 0, 70, 0.0F, -2.7224F, 1.463F, 1, 1, 1, 0.0F));
        cube_r19.cubeList.add(new ModelBox(cube_r19, 21, 70, 7.0F, -2.7224F, 1.463F, 1, 1, 1, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(-2.0F, 1.6607F, -11.3129F);
        face.addChild(cube_r20);
        setRotationAngle(cube_r20, -0.5236F, 0.0F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 57, 8, 0.0F, -3.7224F, 1.463F, 1, 2, 1, 0.0F));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 0, 67, 7.0F, -3.7224F, 1.463F, 1, 2, 1, 0.0F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(-2.0F, 2.0F, -11.0F);
        face.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.1745F, 0.0F, 0.0F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 20, 85, 0.0F, -2.7224F, 2.463F, 4, 2, 0, 0.0F));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 28, 85, 4.0F, -2.7224F, 2.463F, 4, 2, 0, 0.0F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(6.0F, 1.0F, -11.0F);
        face.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.1745F, 0.0F, 0.0F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 0, 78, -8.0F, -2.7224F, 1.463F, 8, 2, 3, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(6.0F, -7.0F, -9.0F);
        face.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.1745F, 0.0F, 0.0F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 87, -4.0F, -2.7224F, -0.537F, 3, 4, 4, 0.0F));
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 95, -7.0F, -2.7224F, -0.537F, 3, 4, 4, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(-3.0F, -10.0F, -9.0F);
        face.addChild(cube_r24);
        setRotationAngle(cube_r24, 0.1745F, 0.0F, -0.5236F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 57, 8, -4.0F, -2.7224F, -0.537F, 4, 4, 4, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        main.render(f5);
        face.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}