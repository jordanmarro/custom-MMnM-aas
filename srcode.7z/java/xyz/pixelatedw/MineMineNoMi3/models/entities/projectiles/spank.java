package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class spank  extends ModelBase {
    private final ModelRenderer bone2;
    private final ModelRenderer palm_r1;
    private final ModelRenderer palm_r2;
    private final ModelRenderer hand_r1;
    private final ModelRenderer hand_r2;
    private final ModelRenderer hand_r3;
    private final ModelRenderer hand_r4;
    private final ModelRenderer hand_r5;
    private final ModelRenderer hand_r6;
    private final ModelRenderer hand_r7;
    private final ModelRenderer hand_r8;
    private final ModelRenderer hand_r9;
    private final ModelRenderer hand_r10;
    private final ModelRenderer hand_r11;
    private final ModelRenderer hand_r12;
    private final ModelRenderer thumb_r1;
    private final ModelRenderer thumbjoint_r1;
    private final ModelRenderer mainarm_r1;
    private final ModelRenderer fingers;
    private final ModelRenderer middlefinger;
    private final ModelRenderer indexfinger;
    private final ModelRenderer pinky;
    private final ModelRenderer pointerfinger;
    private final ModelRenderer bone;

    public spank() {
        textureWidth = 256;
        textureHeight = 256;

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(0, 24, 9);
        setRotationAngle(bone2, 0, 1.6144F, 0);


        palm_r1 = new ModelRenderer(this);
        palm_r1.setRotationPoint(62, -1, 17);
        bone2.addChild(palm_r1);
        setRotationAngle(palm_r1, 0, -0.0436F, 0);
        palm_r1.cubeList.add(new ModelBox(palm_r1, 0, 0, -10, -18, -9, 5, 7, 2, 0));

        palm_r2 = new ModelRenderer(this);
        palm_r2.setRotationPoint(62, -1, 0);
        bone2.addChild(palm_r2);
        setRotationAngle(palm_r2, 0, -0.0436F, 0);
        palm_r2.cubeList.add(new ModelBox(palm_r2, 27, 28, -9, -11, -9, 4, 11, 8, 0));
        palm_r2.cubeList.add(new ModelBox(palm_r2, 0, 89, -10, -18, -9, 5, 7, 2, 0));
        palm_r2.cubeList.add(new ModelBox(palm_r2, 0, 69, -9, -11, 1, 4, 11, 9, 0));
        palm_r2.cubeList.add(new ModelBox(palm_r2, 46, 46, -9, -22, -9, 4, 4, 19, 0));
        palm_r2.cubeList.add(new ModelBox(palm_r2, 0, 28, -10, -22, -9, 4, 22, 19, 0));

        hand_r1 = new ModelRenderer(this);
        hand_r1.setRotationPoint(62, -26, 0);
        bone2.addChild(hand_r1);
        setRotationAngle(hand_r1, -0.0322F, -0.0295F, 0.8295F);
        hand_r1.cubeList.add(new ModelBox(hand_r1, 78, 78, -10, -6, 6, 5, 6, 4, 0));

        hand_r2 = new ModelRenderer(this);
        hand_r2.setRotationPoint(63, -25, 0);
        bone2.addChild(hand_r2);
        setRotationAngle(hand_r2, -0.0131F, -0.0416F, 0.3057F);
        hand_r2.cubeList.add(new ModelBox(hand_r2, 60, 80, -10, -6, 6, 5, 6, 4, 0));

        hand_r3 = new ModelRenderer(this);
        hand_r3.setRotationPoint(62, -20, 0);
        bone2.addChild(hand_r3);
        setRotationAngle(hand_r3, -0.0094F, -0.0426F, 0.2184F);
        hand_r3.cubeList.add(new ModelBox(hand_r3, 75, 39, -10, -7, 6, 5, 7, 4, 0));

        hand_r4 = new ModelRenderer(this);
        hand_r4.setRotationPoint(63, -27, -15);
        bone2.addChild(hand_r4);
        setRotationAngle(hand_r4, -0.025F, -0.0357F, 0.6113F);
        hand_r4.cubeList.add(new ModelBox(hand_r4, 82, 69, -10, -4, 6, 5, 5, 4, 0));

        hand_r5 = new ModelRenderer(this);
        hand_r5.setRotationPoint(63, -26, -15);
        bone2.addChild(hand_r5);
        setRotationAngle(hand_r5, -0.0113F, -0.0421F, 0.262F);
        hand_r5.cubeList.add(new ModelBox(hand_r5, 74, 88, -10, -4, 6, 5, 4, 4, 0));

        hand_r6 = new ModelRenderer(this);
        hand_r6.setRotationPoint(62, -21, -15);
        bone2.addChild(hand_r6);
        setRotationAngle(hand_r6, -0.0094F, -0.0426F, 0.2184F);
        hand_r6.cubeList.add(new ModelBox(hand_r6, 64, 69, -10, -6, 6, 5, 7, 4, 0));

        hand_r7 = new ModelRenderer(this);
        hand_r7.setRotationPoint(64, -30, -10);
        bone2.addChild(hand_r7);
        setRotationAngle(hand_r7, -0.0266F, -0.0346F, 0.655F);
        hand_r7.cubeList.add(new ModelBox(hand_r7, 42, 85, -10, -5, 6, 5, 5, 4, 0));

        hand_r8 = new ModelRenderer(this);
        hand_r8.setRotationPoint(63, -27, -10);
        bone2.addChild(hand_r8);
        setRotationAngle(hand_r8, -0.0184F, -0.0395F, 0.4367F);
        hand_r8.cubeList.add(new ModelBox(hand_r8, 75, 50, -10, -6, 6, 5, 6, 4, 0));

        hand_r9 = new ModelRenderer(this);
        hand_r9.setRotationPoint(62, -21, -10);
        bone2.addChild(hand_r9);
        setRotationAngle(hand_r9, -0.0094F, -0.0426F, 0.2184F);
        hand_r9.cubeList.add(new ModelBox(hand_r9, 53, 28, -10, -8, 6, 5, 9, 4, 0));

        hand_r10 = new ModelRenderer(this);
        hand_r10.setRotationPoint(65, -32, -5);
        bone2.addChild(hand_r10);
        setRotationAngle(hand_r10, -0.0266F, -0.0346F, 0.655F);
        hand_r10.cubeList.add(new ModelBox(hand_r10, 71, 28, -10, -7, 6, 5, 7, 4, 0));

        hand_r11 = new ModelRenderer(this);
        hand_r11.setRotationPoint(63, -27, -5);
        bone2.addChild(hand_r11);
        setRotationAngle(hand_r11, -0.0184F, -0.0395F, 0.4367F);
        hand_r11.cubeList.add(new ModelBox(hand_r11, 46, 69, -10, -8, 6, 5, 8, 4, 0));

        hand_r12 = new ModelRenderer(this);
        hand_r12.setRotationPoint(62, -21, -5);
        bone2.addChild(hand_r12);
        setRotationAngle(hand_r12, -0.0094F, -0.0426F, 0.2184F);
        hand_r12.cubeList.add(new ModelBox(hand_r12, 46, 47, -10, -9, 6, 5, 10, 4, 0));

        thumb_r1 = new ModelRenderer(this);
        thumb_r1.setRotationPoint(60, -12, 13);
        bone2.addChild(thumb_r1);
        setRotationAngle(thumb_r1, 0.0436F, -0.0436F, 0);
        thumb_r1.cubeList.add(new ModelBox(thumb_r1, 0, 28, -8, -14, 1, 4, 13, 5, 0));

        thumbjoint_r1 = new ModelRenderer(this);
        thumbjoint_r1.setRotationPoint(60, -6, 6);
        bone2.addChild(thumbjoint_r1);
        setRotationAngle(thumbjoint_r1, -0.7418F, -0.0436F, 0);
        thumbjoint_r1.cubeList.add(new ModelBox(thumbjoint_r1, 28, 69, -8, -14, 0, 4, 15, 5, 0));

        mainarm_r1 = new ModelRenderer(this);
        mainarm_r1.setRotationPoint(10, -1, -8);
        bone2.addChild(mainarm_r1);
        setRotationAngle(mainarm_r1, 0, -0.0436F, 0);
        mainarm_r1.cubeList.add(new ModelBox(mainarm_r1, 0, 0, -31, -12, 0, 73, 12, 16, 0));

        fingers = new ModelRenderer(this);
        fingers.setRotationPoint(62, -23, 0);
        bone2.addChild(fingers);


        middlefinger = new ModelRenderer(this);
        middlefinger.setRotationPoint(0, 2, -5);
        fingers.addChild(middlefinger);


        indexfinger = new ModelRenderer(this);
        indexfinger.setRotationPoint(0, 2, -10);
        fingers.addChild(indexfinger);


        pinky = new ModelRenderer(this);
        pinky.setRotationPoint(0, 2, -15);
        fingers.addChild(pinky);


        pointerfinger = new ModelRenderer(this);
        pointerfinger.setRotationPoint(0, 0, 0);
        fingers.addChild(pointerfinger);


        bone = new ModelRenderer(this);
        bone.setRotationPoint(62, -1, 0);
        bone2.addChild(bone);
   
        bone2.offsetY -= 1;


        }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone2.render(f5);
    }

        public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
            modelRenderer.rotateAngleX = x;
            modelRenderer.rotateAngleY = y;
            modelRenderer.rotateAngleZ = z;
        }
    }

