package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class clutch extends ModelBase {
    private final ModelRenderer arm1;
    private final ModelRenderer arm2;
    private final ModelRenderer arm2_r1;
    private final ModelRenderer arm1_r1;
    private final ModelRenderer bb_main;
    private final ModelRenderer arm2_r2;
    private final ModelRenderer arm1_r2;

    public clutch() {
        textureWidth = 64;
        textureHeight = 64;

        arm1 = new ModelRenderer(this);
        arm1.setRotationPoint(-6.0F, -2.0F, 4.0F);


        arm2 = new ModelRenderer(this);
        arm2.setRotationPoint(0.0F, 6.0F, -7.0F);
        setRotationAngle(arm2, 3.1416F, 0.0F, 0.0F);


        arm2_r1 = new ModelRenderer(this);
        arm2_r1.setRotationPoint(0.0F, 0.0F, 0.0F);
        arm2.addChild(arm2_r1);
        setRotationAngle(arm2_r1, -1.6581F, 1.6144F, 0.0F);
        arm2_r1.cubeList.add(new ModelBox(arm2_r1, 35, 2, -4.0F, -3.0F, 0.0F, 4, 8, 4, 0.0F));

        arm1_r1 = new ModelRenderer(this);
        arm1_r1.setRotationPoint(-4.0F, -2.0F, -1.0F);
        arm2.addChild(arm1_r1);
        setRotationAngle(arm1_r1, -2.0071F, 0.0F, 0.0F);
        arm1_r1.cubeList.add(new ModelBox(arm1_r1, 35, 2, -4.0F, -5.0F, 0.0F, 4, 10, 4, 0.0F));

        bb_main = new ModelRenderer(this);
        bb_main.setRotationPoint(0.0F, 24.0F, 0.0F);


        arm2_r2 = new ModelRenderer(this);
        arm2_r2.setRotationPoint(-2.0F, -25.0F, 5.0F);
        bb_main.addChild(arm2_r2);
        setRotationAngle(arm2_r2, -1.6581F, 1.6144F, 0.0F);
        arm2_r2.cubeList.add(new ModelBox(arm2_r2, 31, 1, -4.0F, -3.0F, 0.0F, 4, 8, 4, 0.0F));

        arm1_r2 = new ModelRenderer(this);
        arm1_r2.setRotationPoint(-6.0F, -27.0F, 4.0F);
        bb_main.addChild(arm1_r2);
        setRotationAngle(arm1_r2, -2.0071F, 0.0F, 0.0F);
        arm1_r2.cubeList.add(new ModelBox(arm1_r2, 31, 1, -4.0F, -5.0F, 0.0F, 4, 10, 4, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        arm1.render(f5);
        arm2.render(f5);
        bb_main.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
