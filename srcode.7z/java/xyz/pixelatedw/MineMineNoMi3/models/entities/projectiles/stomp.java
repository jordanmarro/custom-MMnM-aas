package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class stomp extends ModelBase {
    private final ModelRenderer bone;
    private final ModelRenderer bone1;
    private final ModelRenderer base28_r1;
    private final ModelRenderer base27_r1;
    private final ModelRenderer base25_r1;
    private final ModelRenderer base25_r2;
    private final ModelRenderer bone2;
    private final ModelRenderer base29_r1;
    private final ModelRenderer base28_r2;
    private final ModelRenderer base26_r1;
    private final ModelRenderer base26_r2;

    public stomp() {
        textureWidth = 512;
        textureHeight = 512;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(-23, 64, -18);
        setRotationAngle(bone, 1.5708F, -3.098F, 0);


        bone1 = new ModelRenderer(this);
        bone1.setRotationPoint(0, 0, 80);
        bone.addChild(bone1);
        bone1.setTextureOffset(104, 0).addBox(-73, 14, -4, 32, 32, 32, 0);
        bone1.setTextureOffset(0, 137).addBox(-72, -18, -3, 30, 32, 30, 0);
        bone1.setTextureOffset(120, 137).addBox(-71, -50, -2, 28, 32, 28, 0);
        bone1.setTextureOffset(94, 197).addBox(-70, -77, -1, 26, 27, 26, 0);

        base28_r1 = new ModelRenderer(this);
        base28_r1.setRotationPoint(0, 0, 0);
        bone1.addChild(base28_r1);
        setRotationAngle(base28_r1, 0, 0, -3.1416F);
        base28_r1.setTextureOffset(78, 98).addBox(-55, -46, -1, 60, 13, 26, 0);

        base27_r1 = new ModelRenderer(this);
        base27_r1.setRotationPoint(-6, 0, 0);
        bone1.addChild(base27_r1);
        setRotationAngle(base27_r1, 0, 0, 2.8798F);
        base27_r1.setTextureOffset(206, 38).addBox(-18, -44, -1, 26, 19, 26, 0);

        base25_r1 = new ModelRenderer(this);
        base25_r1.setRotationPoint(-50, -54, 0);
        bone1.addChild(base25_r1);
        setRotationAngle(base25_r1, 0, 0, 2.6616F);
        base25_r1.setTextureOffset(0, 0).addBox(-26, -98, -1, 26, 98, 26, 0);

        base25_r2 = new ModelRenderer(this);
        base25_r2.setRotationPoint(-72, -62, 0);
        bone1.addChild(base25_r2);
        setRotationAngle(base25_r2, 0, 0, 2.0508F);
        base25_r2.setTextureOffset(198, 198).addBox(-22, -38, -1, 22, 28, 26, 0);
        base25_r2.setTextureOffset(0, 224).addBox(-25, -38, -1, 25, 21, 26, 0);

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(0, 0, 0);
        bone.addChild(bone2);
        bone2.setTextureOffset(104, 0).addBox(-73, 14, -4, 32, 32, 32, 0);
        bone2.setTextureOffset(0, 137).addBox(-72, -18, -3, 30, 32, 30, 0);
        bone2.setTextureOffset(120, 137).addBox(-71, -50, -2, 28, 32, 28, 0);
        bone2.setTextureOffset(94, 197).addBox(-70, -77, -1, 26, 27, 26, 0);

        base29_r1 = new ModelRenderer(this);
        base29_r1.setRotationPoint(0, 0, 0);
        bone2.addChild(base29_r1);
        setRotationAngle(base29_r1, 0, 0, -3.1416F);
        base29_r1.setTextureOffset(78, 98).addBox(-55, -46, -1, 60, 13, 26, 0);

        base28_r2 = new ModelRenderer(this);
        base28_r2.setRotationPoint(-6, 0, 0);
        bone2.addChild(base28_r2);
        setRotationAngle(base28_r2, 0, 0, 2.8798F);
        base28_r2.setTextureOffset(206, 38).addBox(-18, -44, -1, 26, 19, 26, 0);

        base26_r1 = new ModelRenderer(this);
        base26_r1.setRotationPoint(-50, -54, 0);
        bone2.addChild(base26_r1);
        setRotationAngle(base26_r1, 0, 0, 2.6616F);
        base26_r1.setTextureOffset(0, 0).addBox(-26, -98, -1, 26, 98, 26, 0);

        base26_r2 = new ModelRenderer(this);
        base26_r2.setRotationPoint(-72, -62, 0);
        bone2.addChild(base26_r2);
        setRotationAngle(base26_r2, 0, 0, 2.0508F);
        base26_r2.setTextureOffset(198, 198).addBox(-22, -38, -1, 22, 28, 26, 0);
        base26_r2.setTextureOffset(0, 224).addBox(-25, -38, -1, 25, 21, 26, 0);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}