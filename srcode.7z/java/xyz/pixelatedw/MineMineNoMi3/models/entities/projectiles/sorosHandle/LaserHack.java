package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;


import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.soros.RyuRyuNoMiAbilities;
import xyz.pixelatedw.MineMineNoMi3.soros.RyuRyuNoMiProjectiles;

import java.awt.*;

//ok so that it's a hack trick to make the laser
public class LaserHack {

    EntityPlayer pl = Minecraft.getMinecraft().thePlayer;
    Minecraft mc = Minecraft.getMinecraft();
    double x,y,z;

    public boolean doThatTouchBlockOrEntities() {
        for(Object e : mc.theWorld.loadedEntityList) {
            Entity ent = (Entity) e;
            if(ent != null)  {
                if(ent.posX == x && ent.posY == y && ent.posZ == z) {
                    return false;
                }
            }
        }
       if(mc.theWorld.getBlock(((int) x), ((int) y), ((int) z)) != Blocks.air)  {
            return false;
       }
       return true;
    }


    @SubscribeEvent
    public void rwl(final RenderWorldLastEvent event) {
        if (pl != null) {
            if (isSendingSomeLaser()) {
                for (int i = 0; i < mc.theWorld.loadedEntityList.size(); i++) {
                    if ((mc.theWorld.loadedEntityList.get(i) instanceof Entity) && !mc.theWorld.loadedEntityList.
                            get(i).equals(pl)) {
                        Entity p = (Entity) mc.theWorld.loadedEntityList.get(i);

                        if (p.isInvisible()) {
                            return;
                        }

                        final double renderPosX = RenderManager.renderPosX;
                        final double renderPosY = RenderManager.renderPosY;
                        final double renderPosZ = RenderManager.renderPosZ;

                        final double xPos = p.lastTickPosX - renderPosX;
                        final double yPos = p.lastTickPosY - renderPosY;
                        final double zPos = p.lastTickPosZ - renderPosZ;

                        mc.gameSettings.viewBobbing = false;

                        GL11.glEnable(2848);
                        GL11.glDisable(3553);
                        GL11.glEnable(2884);
                        GL11.glDisable(2929);
                        GL11.glPushMatrix();
                        GL11.glDisable(2896);

                            Color a = Color.red;
                        MovingObjectPosition mop = WyHelper.rayTraceBlocks(pl);
                        double is = mop.blockX;
                        double j = mop.blockY;
                        double k = mop.blockZ;
                        x = is;
                        y = j;
                        z = k;

                        drawline(p, is, j, k, a.getRed() / 255.0f, a.getGreen() / 255.0F, a.getBlue() / 255.0f);

                        GL11.glEnable(2896);
                        GL11.glPopMatrix();
                        GL11.glDisable(2848);
                        GL11.glEnable(2929);
                        GL11.glEnable(3553);
                        GL11.glDisable(2848);

                    }
                }
            }

        }
    }

    private boolean isSendingSomeLaser() {
        return RyuRyuNoMiAbilities.BoroBreathClass.renderLaser;
    }

    private void drawline(Entity p, double xPos, double yPos, double zPos, float r, float g, float b) {
        GL11.glLineWidth(0.2f);
        GL11.glColor4f(r, g, b, 1.0f);
        GL11.glBegin(GL11.GL_LINES);
        final Vec3 eyes = pl.getLookVec();
        GL11.glVertex3d(eyes.xCoord, pl.getEyeHeight() + eyes.yCoord - 0.1f, eyes.zCoord);
        for(int i = (int) pl.posX; i < xPos; i++) {
            if(doThatTouchBlockOrEntities()) {
                AbilityExplosion exp = WyHelper.newExplosion(p, xPos, yPos, zPos, 10);
                exp.setFireAfterExplosion(true);
                exp.doExplosion();
            } else {
                GL11.glVertex3d(p.boundingBox.minX - p.posX + i, p.boundingBox.minY - p.posY + yPos + 0.95f,
                        p.boundingBox.minZ - p.posZ + zPos);
                GL11.glEnd();
            }
        }
    }
}

