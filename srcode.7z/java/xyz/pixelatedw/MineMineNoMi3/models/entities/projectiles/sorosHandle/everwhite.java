package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class everwhite extends ModelBase {
    private final ModelRenderer bone3;
    private final ModelRenderer string12;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer string13;
    private final ModelRenderer cube_r45;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer cube_r48;
    private final ModelRenderer string14;
    private final ModelRenderer cube_r49;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer cube_r52;
    private final ModelRenderer string15;
    private final ModelRenderer cube_r53;
    private final ModelRenderer cube_r54;
    private final ModelRenderer cube_r55;
    private final ModelRenderer cube_r56;
    private final ModelRenderer string16;
    private final ModelRenderer cube_r57;
    private final ModelRenderer cube_r58;
    private final ModelRenderer cube_r59;
    private final ModelRenderer cube_r60;
    private final ModelRenderer bone2;
    private final ModelRenderer string2;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer string3;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer string4;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer string5;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer string6;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer bone4;
    private final ModelRenderer string7;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer cube_r25;
    private final ModelRenderer string8;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer string9;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer string10;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer cube_r37;
    private final ModelRenderer string11;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r61;
    private final ModelRenderer bone5;
    private final ModelRenderer string17;
    private final ModelRenderer cube_r62;
    private final ModelRenderer cube_r63;
    private final ModelRenderer cube_r64;
    private final ModelRenderer cube_r65;
    private final ModelRenderer string18;
    private final ModelRenderer cube_r66;
    private final ModelRenderer cube_r67;
    private final ModelRenderer cube_r68;
    private final ModelRenderer cube_r69;
    private final ModelRenderer string19;
    private final ModelRenderer cube_r70;
    private final ModelRenderer cube_r71;
    private final ModelRenderer cube_r72;
    private final ModelRenderer cube_r73;
    private final ModelRenderer string20;
    private final ModelRenderer cube_r74;
    private final ModelRenderer cube_r75;
    private final ModelRenderer cube_r76;
    private final ModelRenderer cube_r77;
    private final ModelRenderer string21;
    private final ModelRenderer cube_r78;
    private final ModelRenderer cube_r79;
    private final ModelRenderer cube_r80;
    private final ModelRenderer cube_r81;
    private final ModelRenderer bone6;
    private final ModelRenderer string22;
    private final ModelRenderer cube_r82;
    private final ModelRenderer cube_r83;
    private final ModelRenderer cube_r84;
    private final ModelRenderer cube_r85;
    private final ModelRenderer string23;
    private final ModelRenderer cube_r86;
    private final ModelRenderer cube_r87;
    private final ModelRenderer cube_r88;
    private final ModelRenderer cube_r89;
    private final ModelRenderer string24;
    private final ModelRenderer cube_r90;
    private final ModelRenderer cube_r91;
    private final ModelRenderer cube_r92;
    private final ModelRenderer cube_r93;
    private final ModelRenderer string25;
    private final ModelRenderer cube_r94;
    private final ModelRenderer cube_r95;
    private final ModelRenderer cube_r96;
    private final ModelRenderer cube_r97;
    private final ModelRenderer string26;
    private final ModelRenderer cube_r98;
    private final ModelRenderer cube_r99;
    private final ModelRenderer cube_r100;
    private final ModelRenderer cube_r101;
    private final ModelRenderer bone7;
    private final ModelRenderer string27;
    private final ModelRenderer cube_r102;
    private final ModelRenderer cube_r103;
    private final ModelRenderer cube_r104;
    private final ModelRenderer cube_r105;
    private final ModelRenderer string28;
    private final ModelRenderer cube_r106;
    private final ModelRenderer cube_r107;
    private final ModelRenderer cube_r108;
    private final ModelRenderer cube_r109;
    private final ModelRenderer string29;
    private final ModelRenderer cube_r110;
    private final ModelRenderer cube_r111;
    private final ModelRenderer cube_r112;
    private final ModelRenderer cube_r113;
    private final ModelRenderer string30;
    private final ModelRenderer cube_r114;
    private final ModelRenderer cube_r115;
    private final ModelRenderer cube_r116;
    private final ModelRenderer cube_r117;
    private final ModelRenderer string31;
    private final ModelRenderer cube_r118;
    private final ModelRenderer cube_r119;
    private final ModelRenderer cube_r120;
    private final ModelRenderer cube_r121;
    private final ModelRenderer bone8;
    private final ModelRenderer string32;
    private final ModelRenderer cube_r122;
    private final ModelRenderer cube_r123;
    private final ModelRenderer cube_r124;
    private final ModelRenderer cube_r125;
    private final ModelRenderer string33;
    private final ModelRenderer cube_r126;
    private final ModelRenderer cube_r127;
    private final ModelRenderer cube_r128;
    private final ModelRenderer cube_r129;
    private final ModelRenderer string34;
    private final ModelRenderer cube_r130;
    private final ModelRenderer cube_r131;
    private final ModelRenderer cube_r132;
    private final ModelRenderer cube_r133;
    private final ModelRenderer string35;
    private final ModelRenderer cube_r134;
    private final ModelRenderer cube_r135;
    private final ModelRenderer cube_r136;
    private final ModelRenderer cube_r137;
    private final ModelRenderer string36;
    private final ModelRenderer cube_r138;
    private final ModelRenderer cube_r139;
    private final ModelRenderer cube_r140;
    private final ModelRenderer cube_r141;
    private final ModelRenderer bone9;
    private final ModelRenderer string37;
    private final ModelRenderer cube_r142;
    private final ModelRenderer cube_r143;
    private final ModelRenderer cube_r144;
    private final ModelRenderer cube_r145;
    private final ModelRenderer string38;
    private final ModelRenderer cube_r146;
    private final ModelRenderer cube_r147;
    private final ModelRenderer cube_r148;
    private final ModelRenderer cube_r149;
    private final ModelRenderer string39;
    private final ModelRenderer cube_r150;
    private final ModelRenderer cube_r151;
    private final ModelRenderer cube_r152;
    private final ModelRenderer cube_r153;
    private final ModelRenderer string40;
    private final ModelRenderer cube_r154;
    private final ModelRenderer cube_r155;
    private final ModelRenderer cube_r156;
    private final ModelRenderer cube_r157;
    private final ModelRenderer string41;
    private final ModelRenderer cube_r158;
    private final ModelRenderer cube_r159;
    private final ModelRenderer cube_r160;
    private final ModelRenderer cube_r161;
    private final ModelRenderer bone10;
    private final ModelRenderer string42;
    private final ModelRenderer cube_r162;
    private final ModelRenderer cube_r163;
    private final ModelRenderer cube_r164;
    private final ModelRenderer cube_r165;
    private final ModelRenderer string43;
    private final ModelRenderer cube_r166;
    private final ModelRenderer cube_r167;
    private final ModelRenderer cube_r168;
    private final ModelRenderer cube_r169;
    private final ModelRenderer string44;
    private final ModelRenderer cube_r170;
    private final ModelRenderer cube_r171;
    private final ModelRenderer cube_r172;
    private final ModelRenderer cube_r173;
    private final ModelRenderer string45;
    private final ModelRenderer cube_r174;
    private final ModelRenderer cube_r175;
    private final ModelRenderer cube_r176;
    private final ModelRenderer cube_r177;
    private final ModelRenderer string46;
    private final ModelRenderer cube_r178;
    private final ModelRenderer cube_r179;
    private final ModelRenderer cube_r180;
    private final ModelRenderer cube_r181;
    private final ModelRenderer bone11;
    private final ModelRenderer string47;
    private final ModelRenderer cube_r182;
    private final ModelRenderer cube_r183;
    private final ModelRenderer cube_r184;
    private final ModelRenderer cube_r185;
    private final ModelRenderer string48;
    private final ModelRenderer cube_r186;
    private final ModelRenderer cube_r187;
    private final ModelRenderer cube_r188;
    private final ModelRenderer cube_r189;
    private final ModelRenderer string49;
    private final ModelRenderer cube_r190;
    private final ModelRenderer cube_r191;
    private final ModelRenderer cube_r192;
    private final ModelRenderer cube_r193;
    private final ModelRenderer string50;
    private final ModelRenderer cube_r194;
    private final ModelRenderer cube_r195;
    private final ModelRenderer cube_r196;
    private final ModelRenderer cube_r197;
    private final ModelRenderer string51;
    private final ModelRenderer cube_r198;
    private final ModelRenderer cube_r199;
    private final ModelRenderer cube_r200;
    private final ModelRenderer cube_r201;

    public everwhite() {
        textureWidth = 256;
        textureHeight = 256;

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(7, 32, -10);
        setRotationAngle(bone3, -0.0436F, -0.1745F, -1.3962F);


        string12 = new ModelRenderer(this);
        string12.setRotationPoint(11, -10, 1);
        bone3.addChild(string12);
        setRotationAngle(string12, -0.2182F, 0.3491F, 2.4871F);


        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(8, 3, -24);
        string12.addChild(cube_r41);
        setRotationAngle(cube_r41, 0.0873F, -0.3491F, 0.2618F);
        cube_r41.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(4, 1, -11);
        string12.addChild(cube_r42);
        setRotationAngle(cube_r42, 0.0436F, -0.3054F, 0.2618F);
        cube_r42.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(0, 0, 0);
        string12.addChild(cube_r43);
        setRotationAngle(cube_r43, 0, -0.3054F, 0.48F);
        cube_r43.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(7, 3, -26);
        string12.addChild(cube_r44);
        setRotationAngle(cube_r44, 0.0873F, -0.6109F, 0.2618F);
        cube_r44.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string13 = new ModelRenderer(this);
        string13.setRotationPoint(11, -8, -2);
        bone3.addChild(string13);
        setRotationAngle(string13, -0.2182F, 0.3491F, 2.4871F);


        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(8, 3, -24);
        string13.addChild(cube_r45);
        setRotationAngle(cube_r45, 0.0873F, -0.3491F, 0.2618F);
        cube_r45.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(4, 1, -11);
        string13.addChild(cube_r46);
        setRotationAngle(cube_r46, 0.0436F, -0.3054F, 0.2618F);
        cube_r46.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0, 0, 0);
        string13.addChild(cube_r47);
        setRotationAngle(cube_r47, 0, -0.3054F, 0.48F);
        cube_r47.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(7, 3, -26);
        string13.addChild(cube_r48);
        setRotationAngle(cube_r48, 0.0873F, -0.6109F, 0.2618F);
        cube_r48.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string14 = new ModelRenderer(this);
        string14.setRotationPoint(15, -11, -10);
        bone3.addChild(string14);
        setRotationAngle(string14, -0.2182F, 0.3491F, 2.4871F);


        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(8, 3, -24);
        string14.addChild(cube_r49);
        setRotationAngle(cube_r49, 0.0873F, -0.3491F, 0.2618F);
        cube_r49.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(4, 1, -11);
        string14.addChild(cube_r50);
        setRotationAngle(cube_r50, 0.0436F, -0.3054F, 0.2618F);
        cube_r50.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(0, 0, 0);
        string14.addChild(cube_r51);
        setRotationAngle(cube_r51, 0, -0.3054F, 0.48F);
        cube_r51.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(7, 3, -26);
        string14.addChild(cube_r52);
        setRotationAngle(cube_r52, 0.0873F, -0.6109F, 0.2618F);
        cube_r52.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string15 = new ModelRenderer(this);
        string15.setRotationPoint(11.5908F, -5.7362F, -6);
        bone3.addChild(string15);
        setRotationAngle(string15, -0.2182F, 0.3491F, 2.4871F);


        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(8, 3, -24);
        string15.addChild(cube_r53);
        setRotationAngle(cube_r53, 0.0873F, -0.3491F, 0.2618F);
        cube_r53.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(4, 1, -11);
        string15.addChild(cube_r54);
        setRotationAngle(cube_r54, 0.0436F, -0.3054F, 0.2618F);
        cube_r54.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(0, 0, 0);
        string15.addChild(cube_r55);
        setRotationAngle(cube_r55, 0, -0.3054F, 0.48F);
        cube_r55.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(7, 3, -26);
        string15.addChild(cube_r56);
        setRotationAngle(cube_r56, 0.0873F, -0.6109F, 0.2618F);
        cube_r56.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string16 = new ModelRenderer(this);
        string16.setRotationPoint(8, -7, 5);
        bone3.addChild(string16);
        setRotationAngle(string16, -0.2182F, 0.3491F, 2.4871F);


        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(8, 3, -24);
        string16.addChild(cube_r57);
        setRotationAngle(cube_r57, 0.0873F, -0.3491F, 0.2618F);
        cube_r57.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r58 = new ModelRenderer(this);
        cube_r58.setRotationPoint(4, 1, -11);
        string16.addChild(cube_r58);
        setRotationAngle(cube_r58, 0.0436F, -0.3054F, 0.2618F);
        cube_r58.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r59 = new ModelRenderer(this);
        cube_r59.setRotationPoint(0, 0, 0);
        string16.addChild(cube_r59);
        setRotationAngle(cube_r59, 0, -0.3054F, 0.48F);
        cube_r59.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r60 = new ModelRenderer(this);
        cube_r60.setRotationPoint(7, 3, -26);
        string16.addChild(cube_r60);
        setRotationAngle(cube_r60, 0.0873F, -0.6109F, 0.2618F);
        cube_r60.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(2, 32, -10);
        setRotationAngle(bone2, -0.0436F, -0.1745F, -1.3962F);


        string2 = new ModelRenderer(this);
        string2.setRotationPoint(11, -10, 1);
        bone2.addChild(string2);
        setRotationAngle(string2, -0.2182F, 0.3491F, 2.4871F);


        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(8, 3, -24);
        string2.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.0873F, -0.3491F, 0.2618F);
        cube_r2.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(4, 1, -11);
        string2.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.0436F, -0.3054F, 0.2618F);
        cube_r3.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(0, 0, 0);
        string2.addChild(cube_r4);
        setRotationAngle(cube_r4, 0, -0.3054F, 0.48F);
        cube_r4.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(7, 3, -26);
        string2.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.0873F, -0.6109F, 0.2618F);
        cube_r5.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string3 = new ModelRenderer(this);
        string3.setRotationPoint(11, -8, -2);
        bone2.addChild(string3);
        setRotationAngle(string3, -0.2182F, 0.3491F, 2.4871F);


        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(8, 3, -24);
        string3.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.0873F, -0.3491F, 0.2618F);
        cube_r6.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(4, 1, -11);
        string3.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.0436F, -0.3054F, 0.2618F);
        cube_r7.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(0, 0, 0);
        string3.addChild(cube_r8);
        setRotationAngle(cube_r8, 0, -0.3054F, 0.48F);
        cube_r8.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(7, 3, -26);
        string3.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.0873F, -0.6109F, 0.2618F);
        cube_r9.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string4 = new ModelRenderer(this);
        string4.setRotationPoint(15, -11, -10);
        bone2.addChild(string4);
        setRotationAngle(string4, -0.2182F, 0.3491F, 2.4871F);


        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(8, 3, -24);
        string4.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.0873F, -0.3491F, 0.2618F);
        cube_r10.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(4, 1, -11);
        string4.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.0436F, -0.3054F, 0.2618F);
        cube_r11.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(0, 0, 0);
        string4.addChild(cube_r12);
        setRotationAngle(cube_r12, 0, -0.3054F, 0.48F);
        cube_r12.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(7, 3, -26);
        string4.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.0873F, -0.6109F, 0.2618F);
        cube_r13.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string5 = new ModelRenderer(this);
        string5.setRotationPoint(11.5908F, -5.7362F, -6);
        bone2.addChild(string5);
        setRotationAngle(string5, -0.2182F, 0.3491F, 2.4871F);


        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(8, 3, -24);
        string5.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.0873F, -0.3491F, 0.2618F);
        cube_r14.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(4, 1, -11);
        string5.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.0436F, -0.3054F, 0.2618F);
        cube_r15.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(0, 0, 0);
        string5.addChild(cube_r16);
        setRotationAngle(cube_r16, 0, -0.3054F, 0.48F);
        cube_r16.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(7, 3, -26);
        string5.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.0873F, -0.6109F, 0.2618F);
        cube_r17.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string6 = new ModelRenderer(this);
        string6.setRotationPoint(8, -7, 5);
        bone2.addChild(string6);
        setRotationAngle(string6, -0.2182F, 0.3491F, 2.4871F);


        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(8, 3, -24);
        string6.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.0873F, -0.3491F, 0.2618F);
        cube_r18.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(4, 1, -11);
        string6.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.0436F, -0.3054F, 0.2618F);
        cube_r19.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(0, 0, 0);
        string6.addChild(cube_r20);
        setRotationAngle(cube_r20, 0, -0.3054F, 0.48F);
        cube_r20.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(7, 3, -26);
        string6.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.0873F, -0.6109F, 0.2618F);
        cube_r21.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(12, 32, -10);
        setRotationAngle(bone4, -0.0436F, -0.1745F, -1.3962F);


        string7 = new ModelRenderer(this);
        string7.setRotationPoint(11, -10, 1);
        bone4.addChild(string7);
        setRotationAngle(string7, -0.2182F, 0.3491F, 2.4871F);


        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(8, 3, -24);
        string7.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.0873F, -0.3491F, 0.2618F);
        cube_r22.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(4, 1, -11);
        string7.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.0436F, -0.3054F, 0.2618F);
        cube_r23.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(0, 0, 0);
        string7.addChild(cube_r24);
        setRotationAngle(cube_r24, 0, -0.3054F, 0.48F);
        cube_r24.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(7, 3, -26);
        string7.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.0873F, -0.6109F, 0.2618F);
        cube_r25.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string8 = new ModelRenderer(this);
        string8.setRotationPoint(11, -8, -2);
        bone4.addChild(string8);
        setRotationAngle(string8, -0.2182F, 0.3491F, 2.4871F);


        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(8, 3, -24);
        string8.addChild(cube_r26);
        setRotationAngle(cube_r26, 0.0873F, -0.3491F, 0.2618F);
        cube_r26.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(4, 1, -11);
        string8.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.0436F, -0.3054F, 0.2618F);
        cube_r27.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(0, 0, 0);
        string8.addChild(cube_r28);
        setRotationAngle(cube_r28, 0, -0.3054F, 0.48F);
        cube_r28.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(7, 3, -26);
        string8.addChild(cube_r29);
        setRotationAngle(cube_r29, 0.0873F, -0.6109F, 0.2618F);
        cube_r29.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string9 = new ModelRenderer(this);
        string9.setRotationPoint(15, -11, -10);
        bone4.addChild(string9);
        setRotationAngle(string9, -0.2182F, 0.3491F, 2.4871F);


        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(8, 3, -24);
        string9.addChild(cube_r30);
        setRotationAngle(cube_r30, 0.0873F, -0.3491F, 0.2618F);
        cube_r30.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(4, 1, -11);
        string9.addChild(cube_r31);
        setRotationAngle(cube_r31, 0.0436F, -0.3054F, 0.2618F);
        cube_r31.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(0, 0, 0);
        string9.addChild(cube_r32);
        setRotationAngle(cube_r32, 0, -0.3054F, 0.48F);
        cube_r32.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(7, 3, -26);
        string9.addChild(cube_r33);
        setRotationAngle(cube_r33, 0.0873F, -0.6109F, 0.2618F);
        cube_r33.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string10 = new ModelRenderer(this);
        string10.setRotationPoint(11.5908F, -5.7362F, -6);
        bone4.addChild(string10);
        setRotationAngle(string10, -0.2182F, 0.3491F, 2.4871F);


        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(8, 3, -24);
        string10.addChild(cube_r34);
        setRotationAngle(cube_r34, 0.0873F, -0.3491F, 0.2618F);
        cube_r34.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(4, 1, -11);
        string10.addChild(cube_r35);
        setRotationAngle(cube_r35, 0.0436F, -0.3054F, 0.2618F);
        cube_r35.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(0, 0, 0);
        string10.addChild(cube_r36);
        setRotationAngle(cube_r36, 0, -0.3054F, 0.48F);
        cube_r36.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(7, 3, -26);
        string10.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.0873F, -0.6109F, 0.2618F);
        cube_r37.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string11 = new ModelRenderer(this);
        string11.setRotationPoint(8, -7, 5);
        bone4.addChild(string11);
        setRotationAngle(string11, -0.2182F, 0.3491F, 2.4871F);


        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(8, 3, -24);
        string11.addChild(cube_r38);
        setRotationAngle(cube_r38, 0.0873F, -0.3491F, 0.2618F);
        cube_r38.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(4, 1, -11);
        string11.addChild(cube_r39);
        setRotationAngle(cube_r39, 0.0436F, -0.3054F, 0.2618F);
        cube_r39.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(0, 0, 0);
        string11.addChild(cube_r40);
        setRotationAngle(cube_r40, 0, -0.3054F, 0.48F);
        cube_r40.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r61 = new ModelRenderer(this);
        cube_r61.setRotationPoint(7, 3, -26);
        string11.addChild(cube_r61);
        setRotationAngle(cube_r61, 0.0873F, -0.6109F, 0.2618F);
        cube_r61.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(-3, 32, -10);
        setRotationAngle(bone5, -0.0436F, -0.1745F, -1.3962F);


        string17 = new ModelRenderer(this);
        string17.setRotationPoint(11, -10, 1);
        bone5.addChild(string17);
        setRotationAngle(string17, -0.2182F, 0.3491F, 2.4871F);


        cube_r62 = new ModelRenderer(this);
        cube_r62.setRotationPoint(8, 3, -24);
        string17.addChild(cube_r62);
        setRotationAngle(cube_r62, 0.0873F, -0.3491F, 0.2618F);
        cube_r62.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r63 = new ModelRenderer(this);
        cube_r63.setRotationPoint(4, 1, -11);
        string17.addChild(cube_r63);
        setRotationAngle(cube_r63, 0.0436F, -0.3054F, 0.2618F);
        cube_r63.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r64 = new ModelRenderer(this);
        cube_r64.setRotationPoint(0, 0, 0);
        string17.addChild(cube_r64);
        setRotationAngle(cube_r64, 0, -0.3054F, 0.48F);
        cube_r64.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r65 = new ModelRenderer(this);
        cube_r65.setRotationPoint(7, 3, -26);
        string17.addChild(cube_r65);
        setRotationAngle(cube_r65, 0.0873F, -0.6109F, 0.2618F);
        cube_r65.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string18 = new ModelRenderer(this);
        string18.setRotationPoint(11, -8, -2);
        bone5.addChild(string18);
        setRotationAngle(string18, -0.2182F, 0.3491F, 2.4871F);


        cube_r66 = new ModelRenderer(this);
        cube_r66.setRotationPoint(8, 3, -24);
        string18.addChild(cube_r66);
        setRotationAngle(cube_r66, 0.0873F, -0.3491F, 0.2618F);
        cube_r66.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r67 = new ModelRenderer(this);
        cube_r67.setRotationPoint(4, 1, -11);
        string18.addChild(cube_r67);
        setRotationAngle(cube_r67, 0.0436F, -0.3054F, 0.2618F);
        cube_r67.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r68 = new ModelRenderer(this);
        cube_r68.setRotationPoint(0, 0, 0);
        string18.addChild(cube_r68);
        setRotationAngle(cube_r68, 0, -0.3054F, 0.48F);
        cube_r68.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r69 = new ModelRenderer(this);
        cube_r69.setRotationPoint(7, 3, -26);
        string18.addChild(cube_r69);
        setRotationAngle(cube_r69, 0.0873F, -0.6109F, 0.2618F);
        cube_r69.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string19 = new ModelRenderer(this);
        string19.setRotationPoint(15, -11, -10);
        bone5.addChild(string19);
        setRotationAngle(string19, -0.2182F, 0.3491F, 2.4871F);


        cube_r70 = new ModelRenderer(this);
        cube_r70.setRotationPoint(8, 3, -24);
        string19.addChild(cube_r70);
        setRotationAngle(cube_r70, 0.0873F, -0.3491F, 0.2618F);
        cube_r70.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r71 = new ModelRenderer(this);
        cube_r71.setRotationPoint(4, 1, -11);
        string19.addChild(cube_r71);
        setRotationAngle(cube_r71, 0.0436F, -0.3054F, 0.2618F);
        cube_r71.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r72 = new ModelRenderer(this);
        cube_r72.setRotationPoint(0, 0, 0);
        string19.addChild(cube_r72);
        setRotationAngle(cube_r72, 0, -0.3054F, 0.48F);
        cube_r72.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r73 = new ModelRenderer(this);
        cube_r73.setRotationPoint(7, 3, -26);
        string19.addChild(cube_r73);
        setRotationAngle(cube_r73, 0.0873F, -0.6109F, 0.2618F);
        cube_r73.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string20 = new ModelRenderer(this);
        string20.setRotationPoint(11.5908F, -5.7362F, -6);
        bone5.addChild(string20);
        setRotationAngle(string20, -0.2182F, 0.3491F, 2.4871F);


        cube_r74 = new ModelRenderer(this);
        cube_r74.setRotationPoint(8, 3, -24);
        string20.addChild(cube_r74);
        setRotationAngle(cube_r74, 0.0873F, -0.3491F, 0.2618F);
        cube_r74.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r75 = new ModelRenderer(this);
        cube_r75.setRotationPoint(4, 1, -11);
        string20.addChild(cube_r75);
        setRotationAngle(cube_r75, 0.0436F, -0.3054F, 0.2618F);
        cube_r75.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r76 = new ModelRenderer(this);
        cube_r76.setRotationPoint(0, 0, 0);
        string20.addChild(cube_r76);
        setRotationAngle(cube_r76, 0, -0.3054F, 0.48F);
        cube_r76.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r77 = new ModelRenderer(this);
        cube_r77.setRotationPoint(7, 3, -26);
        string20.addChild(cube_r77);
        setRotationAngle(cube_r77, 0.0873F, -0.6109F, 0.2618F);
        cube_r77.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string21 = new ModelRenderer(this);
        string21.setRotationPoint(8, -7, 5);
        bone5.addChild(string21);
        setRotationAngle(string21, -0.2182F, 0.3491F, 2.4871F);


        cube_r78 = new ModelRenderer(this);
        cube_r78.setRotationPoint(8, 3, -24);
        string21.addChild(cube_r78);
        setRotationAngle(cube_r78, 0.0873F, -0.3491F, 0.2618F);
        cube_r78.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r79 = new ModelRenderer(this);
        cube_r79.setRotationPoint(4, 1, -11);
        string21.addChild(cube_r79);
        setRotationAngle(cube_r79, 0.0436F, -0.3054F, 0.2618F);
        cube_r79.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r80 = new ModelRenderer(this);
        cube_r80.setRotationPoint(0, 0, 0);
        string21.addChild(cube_r80);
        setRotationAngle(cube_r80, 0, -0.3054F, 0.48F);
        cube_r80.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r81 = new ModelRenderer(this);
        cube_r81.setRotationPoint(7, 3, -26);
        string21.addChild(cube_r81);
        setRotationAngle(cube_r81, 0.0873F, -0.6109F, 0.2618F);
        cube_r81.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(15, 32, -10);
        setRotationAngle(bone6, -0.0436F, -0.1745F, -1.3962F);


        string22 = new ModelRenderer(this);
        string22.setRotationPoint(11, -10, 1);
        bone6.addChild(string22);
        setRotationAngle(string22, -0.2182F, 0.3491F, 2.4871F);


        cube_r82 = new ModelRenderer(this);
        cube_r82.setRotationPoint(8, 3, -24);
        string22.addChild(cube_r82);
        setRotationAngle(cube_r82, 0.0873F, -0.3491F, 0.2618F);
        cube_r82.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r83 = new ModelRenderer(this);
        cube_r83.setRotationPoint(4, 1, -11);
        string22.addChild(cube_r83);
        setRotationAngle(cube_r83, 0.0436F, -0.3054F, 0.2618F);
        cube_r83.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r84 = new ModelRenderer(this);
        cube_r84.setRotationPoint(0, 0, 0);
        string22.addChild(cube_r84);
        setRotationAngle(cube_r84, 0, -0.3054F, 0.48F);
        cube_r84.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r85 = new ModelRenderer(this);
        cube_r85.setRotationPoint(7, 3, -26);
        string22.addChild(cube_r85);
        setRotationAngle(cube_r85, 0.0873F, -0.6109F, 0.2618F);
        cube_r85.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string23 = new ModelRenderer(this);
        string23.setRotationPoint(11, -8, -2);
        bone6.addChild(string23);
        setRotationAngle(string23, -0.2182F, 0.3491F, 2.4871F);


        cube_r86 = new ModelRenderer(this);
        cube_r86.setRotationPoint(8, 3, -24);
        string23.addChild(cube_r86);
        setRotationAngle(cube_r86, 0.0873F, -0.3491F, 0.2618F);
        cube_r86.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r87 = new ModelRenderer(this);
        cube_r87.setRotationPoint(4, 1, -11);
        string23.addChild(cube_r87);
        setRotationAngle(cube_r87, 0.0436F, -0.3054F, 0.2618F);
        cube_r87.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r88 = new ModelRenderer(this);
        cube_r88.setRotationPoint(0, 0, 0);
        string23.addChild(cube_r88);
        setRotationAngle(cube_r88, 0, -0.3054F, 0.48F);
        cube_r88.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r89 = new ModelRenderer(this);
        cube_r89.setRotationPoint(7, 3, -26);
        string23.addChild(cube_r89);
        setRotationAngle(cube_r89, 0.0873F, -0.6109F, 0.2618F);
        cube_r89.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string24 = new ModelRenderer(this);
        string24.setRotationPoint(15, -11, -10);
        bone6.addChild(string24);
        setRotationAngle(string24, -0.2182F, 0.3491F, 2.4871F);


        cube_r90 = new ModelRenderer(this);
        cube_r90.setRotationPoint(8, 3, -24);
        string24.addChild(cube_r90);
        setRotationAngle(cube_r90, 0.0873F, -0.3491F, 0.2618F);
        cube_r90.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r91 = new ModelRenderer(this);
        cube_r91.setRotationPoint(4, 1, -11);
        string24.addChild(cube_r91);
        setRotationAngle(cube_r91, 0.0436F, -0.3054F, 0.2618F);
        cube_r91.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r92 = new ModelRenderer(this);
        cube_r92.setRotationPoint(0, 0, 0);
        string24.addChild(cube_r92);
        setRotationAngle(cube_r92, 0, -0.3054F, 0.48F);
        cube_r92.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r93 = new ModelRenderer(this);
        cube_r93.setRotationPoint(7, 3, -26);
        string24.addChild(cube_r93);
        setRotationAngle(cube_r93, 0.0873F, -0.6109F, 0.2618F);
        cube_r93.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string25 = new ModelRenderer(this);
        string25.setRotationPoint(11.5908F, -5.7362F, -6);
        bone6.addChild(string25);
        setRotationAngle(string25, -0.2182F, 0.3491F, 2.4871F);


        cube_r94 = new ModelRenderer(this);
        cube_r94.setRotationPoint(8, 3, -24);
        string25.addChild(cube_r94);
        setRotationAngle(cube_r94, 0.0873F, -0.3491F, 0.2618F);
        cube_r94.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r95 = new ModelRenderer(this);
        cube_r95.setRotationPoint(4, 1, -11);
        string25.addChild(cube_r95);
        setRotationAngle(cube_r95, 0.0436F, -0.3054F, 0.2618F);
        cube_r95.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r96 = new ModelRenderer(this);
        cube_r96.setRotationPoint(0, 0, 0);
        string25.addChild(cube_r96);
        setRotationAngle(cube_r96, 0, -0.3054F, 0.48F);
        cube_r96.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r97 = new ModelRenderer(this);
        cube_r97.setRotationPoint(7, 3, -26);
        string25.addChild(cube_r97);
        setRotationAngle(cube_r97, 0.0873F, -0.6109F, 0.2618F);
        cube_r97.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string26 = new ModelRenderer(this);
        string26.setRotationPoint(8, -7, 5);
        bone6.addChild(string26);
        setRotationAngle(string26, -0.2182F, 0.3491F, 2.4871F);


        cube_r98 = new ModelRenderer(this);
        cube_r98.setRotationPoint(8, 3, -24);
        string26.addChild(cube_r98);
        setRotationAngle(cube_r98, 0.0873F, -0.3491F, 0.2618F);
        cube_r98.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r99 = new ModelRenderer(this);
        cube_r99.setRotationPoint(4, 1, -11);
        string26.addChild(cube_r99);
        setRotationAngle(cube_r99, 0.0436F, -0.3054F, 0.2618F);
        cube_r99.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r100 = new ModelRenderer(this);
        cube_r100.setRotationPoint(0, 0, 0);
        string26.addChild(cube_r100);
        setRotationAngle(cube_r100, 0, -0.3054F, 0.48F);
        cube_r100.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r101 = new ModelRenderer(this);
        cube_r101.setRotationPoint(7, 3, -26);
        string26.addChild(cube_r101);
        setRotationAngle(cube_r101, 0.0873F, -0.6109F, 0.2618F);
        cube_r101.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(-8, 32, -10);
        setRotationAngle(bone7, -0.0436F, -0.1745F, -1.3962F);


        string27 = new ModelRenderer(this);
        string27.setRotationPoint(11, -10, 1);
        bone7.addChild(string27);
        setRotationAngle(string27, -0.2182F, 0.3491F, 2.4871F);


        cube_r102 = new ModelRenderer(this);
        cube_r102.setRotationPoint(8, 3, -24);
        string27.addChild(cube_r102);
        setRotationAngle(cube_r102, 0.0873F, -0.3491F, 0.2618F);
        cube_r102.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r103 = new ModelRenderer(this);
        cube_r103.setRotationPoint(4, 1, -11);
        string27.addChild(cube_r103);
        setRotationAngle(cube_r103, 0.0436F, -0.3054F, 0.2618F);
        cube_r103.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r104 = new ModelRenderer(this);
        cube_r104.setRotationPoint(0, 0, 0);
        string27.addChild(cube_r104);
        setRotationAngle(cube_r104, 0, -0.3054F, 0.48F);
        cube_r104.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r105 = new ModelRenderer(this);
        cube_r105.setRotationPoint(7, 3, -26);
        string27.addChild(cube_r105);
        setRotationAngle(cube_r105, 0.0873F, -0.6109F, 0.2618F);
        cube_r105.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string28 = new ModelRenderer(this);
        string28.setRotationPoint(11, -8, -2);
        bone7.addChild(string28);
        setRotationAngle(string28, -0.2182F, 0.3491F, 2.4871F);


        cube_r106 = new ModelRenderer(this);
        cube_r106.setRotationPoint(8, 3, -24);
        string28.addChild(cube_r106);
        setRotationAngle(cube_r106, 0.0873F, -0.3491F, 0.2618F);
        cube_r106.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r107 = new ModelRenderer(this);
        cube_r107.setRotationPoint(4, 1, -11);
        string28.addChild(cube_r107);
        setRotationAngle(cube_r107, 0.0436F, -0.3054F, 0.2618F);
        cube_r107.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r108 = new ModelRenderer(this);
        cube_r108.setRotationPoint(0, 0, 0);
        string28.addChild(cube_r108);
        setRotationAngle(cube_r108, 0, -0.3054F, 0.48F);
        cube_r108.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r109 = new ModelRenderer(this);
        cube_r109.setRotationPoint(7, 3, -26);
        string28.addChild(cube_r109);
        setRotationAngle(cube_r109, 0.0873F, -0.6109F, 0.2618F);
        cube_r109.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string29 = new ModelRenderer(this);
        string29.setRotationPoint(15, -11, -10);
        bone7.addChild(string29);
        setRotationAngle(string29, -0.2182F, 0.3491F, 2.4871F);


        cube_r110 = new ModelRenderer(this);
        cube_r110.setRotationPoint(8, 3, -24);
        string29.addChild(cube_r110);
        setRotationAngle(cube_r110, 0.0873F, -0.3491F, 0.2618F);
        cube_r110.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r111 = new ModelRenderer(this);
        cube_r111.setRotationPoint(4, 1, -11);
        string29.addChild(cube_r111);
        setRotationAngle(cube_r111, 0.0436F, -0.3054F, 0.2618F);
        cube_r111.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r112 = new ModelRenderer(this);
        cube_r112.setRotationPoint(0, 0, 0);
        string29.addChild(cube_r112);
        setRotationAngle(cube_r112, 0, -0.3054F, 0.48F);
        cube_r112.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r113 = new ModelRenderer(this);
        cube_r113.setRotationPoint(7, 3, -26);
        string29.addChild(cube_r113);
        setRotationAngle(cube_r113, 0.0873F, -0.6109F, 0.2618F);
        cube_r113.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string30 = new ModelRenderer(this);
        string30.setRotationPoint(11.5908F, -5.7362F, -6);
        bone7.addChild(string30);
        setRotationAngle(string30, -0.2182F, 0.3491F, 2.4871F);


        cube_r114 = new ModelRenderer(this);
        cube_r114.setRotationPoint(8, 3, -24);
        string30.addChild(cube_r114);
        setRotationAngle(cube_r114, 0.0873F, -0.3491F, 0.2618F);
        cube_r114.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r115 = new ModelRenderer(this);
        cube_r115.setRotationPoint(4, 1, -11);
        string30.addChild(cube_r115);
        setRotationAngle(cube_r115, 0.0436F, -0.3054F, 0.2618F);
        cube_r115.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r116 = new ModelRenderer(this);
        cube_r116.setRotationPoint(0, 0, 0);
        string30.addChild(cube_r116);
        setRotationAngle(cube_r116, 0, -0.3054F, 0.48F);
        cube_r116.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r117 = new ModelRenderer(this);
        cube_r117.setRotationPoint(7, 3, -26);
        string30.addChild(cube_r117);
        setRotationAngle(cube_r117, 0.0873F, -0.6109F, 0.2618F);
        cube_r117.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string31 = new ModelRenderer(this);
        string31.setRotationPoint(8, -7, 5);
        bone7.addChild(string31);
        setRotationAngle(string31, -0.2182F, 0.3491F, 2.4871F);


        cube_r118 = new ModelRenderer(this);
        cube_r118.setRotationPoint(8, 3, -24);
        string31.addChild(cube_r118);
        setRotationAngle(cube_r118, 0.0873F, -0.3491F, 0.2618F);
        cube_r118.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r119 = new ModelRenderer(this);
        cube_r119.setRotationPoint(4, 1, -11);
        string31.addChild(cube_r119);
        setRotationAngle(cube_r119, 0.0436F, -0.3054F, 0.2618F);
        cube_r119.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r120 = new ModelRenderer(this);
        cube_r120.setRotationPoint(0, 0, 0);
        string31.addChild(cube_r120);
        setRotationAngle(cube_r120, 0, -0.3054F, 0.48F);
        cube_r120.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r121 = new ModelRenderer(this);
        cube_r121.setRotationPoint(7, 3, -26);
        string31.addChild(cube_r121);
        setRotationAngle(cube_r121, 0.0873F, -0.6109F, 0.2618F);
        cube_r121.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(-8, 32, -10);
        setRotationAngle(bone8, -0.0436F, -0.0436F, -1.3962F);


        string32 = new ModelRenderer(this);
        string32.setRotationPoint(11, -10, 1);
        bone8.addChild(string32);
        setRotationAngle(string32, -0.2182F, 0.3491F, 2.4871F);


        cube_r122 = new ModelRenderer(this);
        cube_r122.setRotationPoint(8, 3, -24);
        string32.addChild(cube_r122);
        setRotationAngle(cube_r122, 0.0873F, -0.3491F, 0.2618F);
        cube_r122.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r123 = new ModelRenderer(this);
        cube_r123.setRotationPoint(4, 1, -11);
        string32.addChild(cube_r123);
        setRotationAngle(cube_r123, 0.0436F, -0.3054F, 0.2618F);
        cube_r123.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r124 = new ModelRenderer(this);
        cube_r124.setRotationPoint(0, 0, 0);
        string32.addChild(cube_r124);
        setRotationAngle(cube_r124, 0, -0.3054F, 0.48F);
        cube_r124.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r125 = new ModelRenderer(this);
        cube_r125.setRotationPoint(7, 3, -26);
        string32.addChild(cube_r125);
        setRotationAngle(cube_r125, 0.0873F, -0.6109F, 0.2618F);
        cube_r125.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string33 = new ModelRenderer(this);
        string33.setRotationPoint(11, -8, -2);
        bone8.addChild(string33);
        setRotationAngle(string33, -0.2182F, 0.3491F, 2.4871F);


        cube_r126 = new ModelRenderer(this);
        cube_r126.setRotationPoint(8, 3, -24);
        string33.addChild(cube_r126);
        setRotationAngle(cube_r126, 0.0873F, -0.3491F, 0.2618F);
        cube_r126.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r127 = new ModelRenderer(this);
        cube_r127.setRotationPoint(4, 1, -11);
        string33.addChild(cube_r127);
        setRotationAngle(cube_r127, 0.0436F, -0.3054F, 0.2618F);
        cube_r127.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r128 = new ModelRenderer(this);
        cube_r128.setRotationPoint(0, 0, 0);
        string33.addChild(cube_r128);
        setRotationAngle(cube_r128, 0, -0.3054F, 0.48F);
        cube_r128.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r129 = new ModelRenderer(this);
        cube_r129.setRotationPoint(7, 3, -26);
        string33.addChild(cube_r129);
        setRotationAngle(cube_r129, 0.0873F, -0.6109F, 0.2618F);
        cube_r129.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string34 = new ModelRenderer(this);
        string34.setRotationPoint(15, -11, -10);
        bone8.addChild(string34);
        setRotationAngle(string34, -0.2182F, 0.3491F, 2.4871F);


        cube_r130 = new ModelRenderer(this);
        cube_r130.setRotationPoint(8, 3, -24);
        string34.addChild(cube_r130);
        setRotationAngle(cube_r130, 0.0873F, -0.3491F, 0.2618F);
        cube_r130.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r131 = new ModelRenderer(this);
        cube_r131.setRotationPoint(4, 1, -11);
        string34.addChild(cube_r131);
        setRotationAngle(cube_r131, 0.0436F, -0.3054F, 0.2618F);
        cube_r131.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r132 = new ModelRenderer(this);
        cube_r132.setRotationPoint(0, 0, 0);
        string34.addChild(cube_r132);
        setRotationAngle(cube_r132, 0, -0.3054F, 0.48F);
        cube_r132.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r133 = new ModelRenderer(this);
        cube_r133.setRotationPoint(7, 3, -26);
        string34.addChild(cube_r133);
        setRotationAngle(cube_r133, 0.0873F, -0.6109F, 0.2618F);
        cube_r133.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string35 = new ModelRenderer(this);
        string35.setRotationPoint(11.5908F, -5.7362F, -6);
        bone8.addChild(string35);
        setRotationAngle(string35, -0.2182F, 0.3491F, 2.4871F);


        cube_r134 = new ModelRenderer(this);
        cube_r134.setRotationPoint(8, 3, -24);
        string35.addChild(cube_r134);
        setRotationAngle(cube_r134, 0.0873F, -0.3491F, 0.2618F);
        cube_r134.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r135 = new ModelRenderer(this);
        cube_r135.setRotationPoint(4, 1, -11);
        string35.addChild(cube_r135);
        setRotationAngle(cube_r135, 0.0436F, -0.3054F, 0.2618F);
        cube_r135.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r136 = new ModelRenderer(this);
        cube_r136.setRotationPoint(0, 0, 0);
        string35.addChild(cube_r136);
        setRotationAngle(cube_r136, 0, -0.3054F, 0.48F);
        cube_r136.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r137 = new ModelRenderer(this);
        cube_r137.setRotationPoint(7, 3, -26);
        string35.addChild(cube_r137);
        setRotationAngle(cube_r137, 0.0873F, -0.6109F, 0.2618F);
        cube_r137.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string36 = new ModelRenderer(this);
        string36.setRotationPoint(8, -7, 5);
        bone8.addChild(string36);
        setRotationAngle(string36, -0.2182F, 0.3491F, 2.4871F);


        cube_r138 = new ModelRenderer(this);
        cube_r138.setRotationPoint(8, 3, -24);
        string36.addChild(cube_r138);
        setRotationAngle(cube_r138, 0.0873F, -0.3491F, 0.2618F);
        cube_r138.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r139 = new ModelRenderer(this);
        cube_r139.setRotationPoint(4, 1, -11);
        string36.addChild(cube_r139);
        setRotationAngle(cube_r139, 0.0436F, -0.3054F, 0.2618F);
        cube_r139.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r140 = new ModelRenderer(this);
        cube_r140.setRotationPoint(0, 0, 0);
        string36.addChild(cube_r140);
        setRotationAngle(cube_r140, 0, -0.3054F, 0.48F);
        cube_r140.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r141 = new ModelRenderer(this);
        cube_r141.setRotationPoint(7, 3, -26);
        string36.addChild(cube_r141);
        setRotationAngle(cube_r141, 0.0873F, -0.6109F, 0.2618F);
        cube_r141.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(10, 32, -10);
        setRotationAngle(bone9, -0.0436F, -0.0436F, -1.3962F);


        string37 = new ModelRenderer(this);
        string37.setRotationPoint(11, -10, 1);
        bone9.addChild(string37);
        setRotationAngle(string37, -0.2182F, 0.3491F, 2.4871F);


        cube_r142 = new ModelRenderer(this);
        cube_r142.setRotationPoint(8, 3, -24);
        string37.addChild(cube_r142);
        setRotationAngle(cube_r142, 0.0873F, -0.3491F, 0.2618F);
        cube_r142.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r143 = new ModelRenderer(this);
        cube_r143.setRotationPoint(4, 1, -11);
        string37.addChild(cube_r143);
        setRotationAngle(cube_r143, 0.0436F, -0.3054F, 0.2618F);
        cube_r143.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r144 = new ModelRenderer(this);
        cube_r144.setRotationPoint(0, 0, 0);
        string37.addChild(cube_r144);
        setRotationAngle(cube_r144, 0, -0.3054F, 0.48F);
        cube_r144.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r145 = new ModelRenderer(this);
        cube_r145.setRotationPoint(7, 3, -26);
        string37.addChild(cube_r145);
        setRotationAngle(cube_r145, 0.0873F, -0.6109F, 0.2618F);
        cube_r145.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string38 = new ModelRenderer(this);
        string38.setRotationPoint(11, -8, -2);
        bone9.addChild(string38);
        setRotationAngle(string38, -0.2182F, 0.3491F, 2.4871F);


        cube_r146 = new ModelRenderer(this);
        cube_r146.setRotationPoint(8, 3, -24);
        string38.addChild(cube_r146);
        setRotationAngle(cube_r146, 0.0873F, -0.3491F, 0.2618F);
        cube_r146.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r147 = new ModelRenderer(this);
        cube_r147.setRotationPoint(4, 1, -11);
        string38.addChild(cube_r147);
        setRotationAngle(cube_r147, 0.0436F, -0.3054F, 0.2618F);
        cube_r147.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r148 = new ModelRenderer(this);
        cube_r148.setRotationPoint(0, 0, 0);
        string38.addChild(cube_r148);
        setRotationAngle(cube_r148, 0, -0.3054F, 0.48F);
        cube_r148.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r149 = new ModelRenderer(this);
        cube_r149.setRotationPoint(7, 3, -26);
        string38.addChild(cube_r149);
        setRotationAngle(cube_r149, 0.0873F, -0.6109F, 0.2618F);
        cube_r149.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string39 = new ModelRenderer(this);
        string39.setRotationPoint(15, -11, -10);
        bone9.addChild(string39);
        setRotationAngle(string39, -0.2182F, 0.3491F, 2.4871F);


        cube_r150 = new ModelRenderer(this);
        cube_r150.setRotationPoint(8, 3, -24);
        string39.addChild(cube_r150);
        setRotationAngle(cube_r150, 0.0873F, -0.3491F, 0.2618F);
        cube_r150.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r151 = new ModelRenderer(this);
        cube_r151.setRotationPoint(4, 1, -11);
        string39.addChild(cube_r151);
        setRotationAngle(cube_r151, 0.0436F, -0.3054F, 0.2618F);
        cube_r151.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r152 = new ModelRenderer(this);
        cube_r152.setRotationPoint(0, 0, 0);
        string39.addChild(cube_r152);
        setRotationAngle(cube_r152, 0, -0.3054F, 0.48F);
        cube_r152.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r153 = new ModelRenderer(this);
        cube_r153.setRotationPoint(7, 3, -26);
        string39.addChild(cube_r153);
        setRotationAngle(cube_r153, 0.0873F, -0.6109F, 0.2618F);
        cube_r153.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string40 = new ModelRenderer(this);
        string40.setRotationPoint(11.5908F, -5.7362F, -6);
        bone9.addChild(string40);
        setRotationAngle(string40, -0.2182F, 0.3491F, 2.4871F);


        cube_r154 = new ModelRenderer(this);
        cube_r154.setRotationPoint(8, 3, -24);
        string40.addChild(cube_r154);
        setRotationAngle(cube_r154, 0.0873F, -0.3491F, 0.2618F);
        cube_r154.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r155 = new ModelRenderer(this);
        cube_r155.setRotationPoint(4, 1, -11);
        string40.addChild(cube_r155);
        setRotationAngle(cube_r155, 0.0436F, -0.3054F, 0.2618F);
        cube_r155.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r156 = new ModelRenderer(this);
        cube_r156.setRotationPoint(0, 0, 0);
        string40.addChild(cube_r156);
        setRotationAngle(cube_r156, 0, -0.3054F, 0.48F);
        cube_r156.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r157 = new ModelRenderer(this);
        cube_r157.setRotationPoint(7, 3, -26);
        string40.addChild(cube_r157);
        setRotationAngle(cube_r157, 0.0873F, -0.6109F, 0.2618F);
        cube_r157.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string41 = new ModelRenderer(this);
        string41.setRotationPoint(8, -7, 5);
        bone9.addChild(string41);
        setRotationAngle(string41, -0.2182F, 0.3491F, 2.4871F);


        cube_r158 = new ModelRenderer(this);
        cube_r158.setRotationPoint(8, 3, -24);
        string41.addChild(cube_r158);
        setRotationAngle(cube_r158, 0.0873F, -0.3491F, 0.2618F);
        cube_r158.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r159 = new ModelRenderer(this);
        cube_r159.setRotationPoint(4, 1, -11);
        string41.addChild(cube_r159);
        setRotationAngle(cube_r159, 0.0436F, -0.3054F, 0.2618F);
        cube_r159.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r160 = new ModelRenderer(this);
        cube_r160.setRotationPoint(0, 0, 0);
        string41.addChild(cube_r160);
        setRotationAngle(cube_r160, 0, -0.3054F, 0.48F);
        cube_r160.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r161 = new ModelRenderer(this);
        cube_r161.setRotationPoint(7, 3, -26);
        string41.addChild(cube_r161);
        setRotationAngle(cube_r161, 0.0873F, -0.6109F, 0.2618F);
        cube_r161.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(1, 32, -10);
        setRotationAngle(bone10, -0.0436F, -0.0436F, -1.3962F);


        string42 = new ModelRenderer(this);
        string42.setRotationPoint(11, -10, 1);
        bone10.addChild(string42);
        setRotationAngle(string42, -0.2182F, 0.3491F, 2.4871F);


        cube_r162 = new ModelRenderer(this);
        cube_r162.setRotationPoint(8, 3, -24);
        string42.addChild(cube_r162);
        setRotationAngle(cube_r162, 0.0873F, -0.3491F, 0.2618F);
        cube_r162.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r163 = new ModelRenderer(this);
        cube_r163.setRotationPoint(4, 1, -11);
        string42.addChild(cube_r163);
        setRotationAngle(cube_r163, 0.0436F, -0.3054F, 0.2618F);
        cube_r163.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r164 = new ModelRenderer(this);
        cube_r164.setRotationPoint(0, 0, 0);
        string42.addChild(cube_r164);
        setRotationAngle(cube_r164, 0, -0.3054F, 0.48F);
        cube_r164.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r165 = new ModelRenderer(this);
        cube_r165.setRotationPoint(7, 3, -26);
        string42.addChild(cube_r165);
        setRotationAngle(cube_r165, 0.0873F, -0.6109F, 0.2618F);
        cube_r165.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string43 = new ModelRenderer(this);
        string43.setRotationPoint(11, -8, -2);
        bone10.addChild(string43);
        setRotationAngle(string43, -0.2182F, 0.3491F, 2.4871F);


        cube_r166 = new ModelRenderer(this);
        cube_r166.setRotationPoint(8, 3, -24);
        string43.addChild(cube_r166);
        setRotationAngle(cube_r166, 0.0873F, -0.3491F, 0.2618F);
        cube_r166.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r167 = new ModelRenderer(this);
        cube_r167.setRotationPoint(4, 1, -11);
        string43.addChild(cube_r167);
        setRotationAngle(cube_r167, 0.0436F, -0.3054F, 0.2618F);
        cube_r167.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r168 = new ModelRenderer(this);
        cube_r168.setRotationPoint(0, 0, 0);
        string43.addChild(cube_r168);
        setRotationAngle(cube_r168, 0, -0.3054F, 0.48F);
        cube_r168.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r169 = new ModelRenderer(this);
        cube_r169.setRotationPoint(7, 3, -26);
        string43.addChild(cube_r169);
        setRotationAngle(cube_r169, 0.0873F, -0.6109F, 0.2618F);
        cube_r169.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string44 = new ModelRenderer(this);
        string44.setRotationPoint(15, -11, -10);
        bone10.addChild(string44);
        setRotationAngle(string44, -0.2182F, 0.3491F, 2.4871F);


        cube_r170 = new ModelRenderer(this);
        cube_r170.setRotationPoint(8, 3, -24);
        string44.addChild(cube_r170);
        setRotationAngle(cube_r170, 0.0873F, -0.3491F, 0.2618F);
        cube_r170.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r171 = new ModelRenderer(this);
        cube_r171.setRotationPoint(4, 1, -11);
        string44.addChild(cube_r171);
        setRotationAngle(cube_r171, 0.0436F, -0.3054F, 0.2618F);
        cube_r171.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r172 = new ModelRenderer(this);
        cube_r172.setRotationPoint(0, 0, 0);
        string44.addChild(cube_r172);
        setRotationAngle(cube_r172, 0, -0.3054F, 0.48F);
        cube_r172.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r173 = new ModelRenderer(this);
        cube_r173.setRotationPoint(7, 3, -26);
        string44.addChild(cube_r173);
        setRotationAngle(cube_r173, 0.0873F, -0.6109F, 0.2618F);
        cube_r173.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string45 = new ModelRenderer(this);
        string45.setRotationPoint(11.5908F, -5.7362F, -6);
        bone10.addChild(string45);
        setRotationAngle(string45, -0.2182F, 0.3491F, 2.4871F);


        cube_r174 = new ModelRenderer(this);
        cube_r174.setRotationPoint(8, 3, -24);
        string45.addChild(cube_r174);
        setRotationAngle(cube_r174, 0.0873F, -0.3491F, 0.2618F);
        cube_r174.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r175 = new ModelRenderer(this);
        cube_r175.setRotationPoint(4, 1, -11);
        string45.addChild(cube_r175);
        setRotationAngle(cube_r175, 0.0436F, -0.3054F, 0.2618F);
        cube_r175.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r176 = new ModelRenderer(this);
        cube_r176.setRotationPoint(0, 0, 0);
        string45.addChild(cube_r176);
        setRotationAngle(cube_r176, 0, -0.3054F, 0.48F);
        cube_r176.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r177 = new ModelRenderer(this);
        cube_r177.setRotationPoint(7, 3, -26);
        string45.addChild(cube_r177);
        setRotationAngle(cube_r177, 0.0873F, -0.6109F, 0.2618F);
        cube_r177.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string46 = new ModelRenderer(this);
        string46.setRotationPoint(8, -7, 5);
        bone10.addChild(string46);
        setRotationAngle(string46, -0.2182F, 0.3491F, 2.4871F);


        cube_r178 = new ModelRenderer(this);
        cube_r178.setRotationPoint(8, 3, -24);
        string46.addChild(cube_r178);
        setRotationAngle(cube_r178, 0.0873F, -0.3491F, 0.2618F);
        cube_r178.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r179 = new ModelRenderer(this);
        cube_r179.setRotationPoint(4, 1, -11);
        string46.addChild(cube_r179);
        setRotationAngle(cube_r179, 0.0436F, -0.3054F, 0.2618F);
        cube_r179.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r180 = new ModelRenderer(this);
        cube_r180.setRotationPoint(0, 0, 0);
        string46.addChild(cube_r180);
        setRotationAngle(cube_r180, 0, -0.3054F, 0.48F);
        cube_r180.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r181 = new ModelRenderer(this);
        cube_r181.setRotationPoint(7, 3, -26);
        string46.addChild(cube_r181);
        setRotationAngle(cube_r181, 0.0873F, -0.6109F, 0.2618F);
        cube_r181.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        bone11 = new ModelRenderer(this);
        bone11.setRotationPoint(1, 32, -21);
        setRotationAngle(bone11, -0.0436F, -0.0436F, -1.3962F);


        string47 = new ModelRenderer(this);
        string47.setRotationPoint(11, -10, 1);
        bone11.addChild(string47);
        setRotationAngle(string47, -0.2182F, 0.3491F, 2.4871F);


        cube_r182 = new ModelRenderer(this);
        cube_r182.setRotationPoint(8, 3, -24);
        string47.addChild(cube_r182);
        setRotationAngle(cube_r182, 0.0873F, -0.3491F, 0.2618F);
        cube_r182.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r183 = new ModelRenderer(this);
        cube_r183.setRotationPoint(4, 1, -11);
        string47.addChild(cube_r183);
        setRotationAngle(cube_r183, 0.0436F, -0.3054F, 0.2618F);
        cube_r183.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r184 = new ModelRenderer(this);
        cube_r184.setRotationPoint(0, 0, 0);
        string47.addChild(cube_r184);
        setRotationAngle(cube_r184, 0, -0.3054F, 0.48F);
        cube_r184.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r185 = new ModelRenderer(this);
        cube_r185.setRotationPoint(7, 3, -26);
        string47.addChild(cube_r185);
        setRotationAngle(cube_r185, 0.0873F, -0.6109F, 0.2618F);
        cube_r185.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string48 = new ModelRenderer(this);
        string48.setRotationPoint(11, -8, -2);
        bone11.addChild(string48);
        setRotationAngle(string48, -0.2182F, 0.3491F, 2.4871F);


        cube_r186 = new ModelRenderer(this);
        cube_r186.setRotationPoint(8, 3, -24);
        string48.addChild(cube_r186);
        setRotationAngle(cube_r186, 0.0873F, -0.3491F, 0.2618F);
        cube_r186.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r187 = new ModelRenderer(this);
        cube_r187.setRotationPoint(4, 1, -11);
        string48.addChild(cube_r187);
        setRotationAngle(cube_r187, 0.0436F, -0.3054F, 0.2618F);
        cube_r187.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r188 = new ModelRenderer(this);
        cube_r188.setRotationPoint(0, 0, 0);
        string48.addChild(cube_r188);
        setRotationAngle(cube_r188, 0, -0.3054F, 0.48F);
        cube_r188.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r189 = new ModelRenderer(this);
        cube_r189.setRotationPoint(7, 3, -26);
        string48.addChild(cube_r189);
        setRotationAngle(cube_r189, 0.0873F, -0.6109F, 0.2618F);
        cube_r189.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string49 = new ModelRenderer(this);
        string49.setRotationPoint(15, -11, -10);
        bone11.addChild(string49);
        setRotationAngle(string49, -0.2182F, 0.3491F, 2.4871F);


        cube_r190 = new ModelRenderer(this);
        cube_r190.setRotationPoint(8, 3, -24);
        string49.addChild(cube_r190);
        setRotationAngle(cube_r190, 0.0873F, -0.3491F, 0.2618F);
        cube_r190.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r191 = new ModelRenderer(this);
        cube_r191.setRotationPoint(4, 1, -11);
        string49.addChild(cube_r191);
        setRotationAngle(cube_r191, 0.0436F, -0.3054F, 0.2618F);
        cube_r191.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r192 = new ModelRenderer(this);
        cube_r192.setRotationPoint(0, 0, 0);
        string49.addChild(cube_r192);
        setRotationAngle(cube_r192, 0, -0.3054F, 0.48F);
        cube_r192.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r193 = new ModelRenderer(this);
        cube_r193.setRotationPoint(7, 3, -26);
        string49.addChild(cube_r193);
        setRotationAngle(cube_r193, 0.0873F, -0.6109F, 0.2618F);
        cube_r193.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string50 = new ModelRenderer(this);
        string50.setRotationPoint(11.5908F, -5.7362F, -6);
        bone11.addChild(string50);
        setRotationAngle(string50, -0.2182F, 0.3491F, 2.4871F);


        cube_r194 = new ModelRenderer(this);
        cube_r194.setRotationPoint(8, 3, -24);
        string50.addChild(cube_r194);
        setRotationAngle(cube_r194, 0.0873F, -0.3491F, 0.2618F);
        cube_r194.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r195 = new ModelRenderer(this);
        cube_r195.setRotationPoint(4, 1, -11);
        string50.addChild(cube_r195);
        setRotationAngle(cube_r195, 0.0436F, -0.3054F, 0.2618F);
        cube_r195.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r196 = new ModelRenderer(this);
        cube_r196.setRotationPoint(0, 0, 0);
        string50.addChild(cube_r196);
        setRotationAngle(cube_r196, 0, -0.3054F, 0.48F);
        cube_r196.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r197 = new ModelRenderer(this);
        cube_r197.setRotationPoint(7, 3, -26);
        string50.addChild(cube_r197);
        setRotationAngle(cube_r197, 0.0873F, -0.6109F, 0.2618F);
        cube_r197.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);

        string51 = new ModelRenderer(this);
        string51.setRotationPoint(8, -7, 5);
        bone11.addChild(string51);
        setRotationAngle(string51, -0.2182F, 0.3491F, 2.4871F);


        cube_r198 = new ModelRenderer(this);
        cube_r198.setRotationPoint(8, 3, -24);
        string51.addChild(cube_r198);
        setRotationAngle(cube_r198, 0.0873F, -0.3491F, 0.2618F);
        cube_r198.setTextureOffset(0, 0).addBox(-1, 0, -10, 1, 1, 13, 0);

        cube_r199 = new ModelRenderer(this);
        cube_r199.setRotationPoint(4, 1, -11);
        string51.addChild(cube_r199);
        setRotationAngle(cube_r199, 0.0436F, -0.3054F, 0.2618F);
        cube_r199.setTextureOffset(0, 0).addBox(-1, 0, -12, 1, 1, 22, 0);

        cube_r200 = new ModelRenderer(this);
        cube_r200.setRotationPoint(0, 0, 0);
        string51.addChild(cube_r200);
        setRotationAngle(cube_r200, 0, -0.3054F, 0.48F);
        cube_r200.setTextureOffset(0, 0).addBox(-1, -1, -3, 2, 2, 13, 0);

        cube_r201 = new ModelRenderer(this);
        cube_r201.setRotationPoint(7, 3, -26);
        string51.addChild(cube_r201);
        setRotationAngle(cube_r201, 0.0873F, -0.6109F, 0.2618F);
        cube_r201.setTextureOffset(0, 0).addBox(-1, 0, -11, 0, 1, 3, 0);


        bone3.offsetY -= 1.0f;
        bone2.offsetY -= 1.0f;
        bone4.offsetY -= 1.0f;
        bone5.offsetY -= 1.0f;
        bone6.offsetY -= 1.0f;
        bone7.offsetY -= 1.0f;
        bone8.offsetY -= 1.0f;
        bone9.offsetY -= 1.0f;
        bone10.offsetY -= 1.0f;
        bone11.offsetY -= 1.0f;
    }

 

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone3.render(f5);
        bone2.render(f5);
        bone4.render(f5);
        bone5.render(f5);
        bone6.render(f5);
        bone7.render(f5);
        bone8.render(f5);
        bone9.render(f5);
        bone10.render(f5);
        bone11.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
