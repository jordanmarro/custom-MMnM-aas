package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class Kamaitachi extends ModelBase {
    private final ModelRenderer bone;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;

    public Kamaitachi() {
        textureWidth = 4096;
        textureHeight = 4096;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(-4, 10, -10);
        setRotationAngle(bone, 0, 0, -0.2182F);
        bone.setTextureOffset(0, 0).addBox(-1, -11, 4, 1, 16, 1, 0);

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(0, 0, 0);
        bone.addChild(cube_r1);
        setRotationAngle(cube_r1, -2.3562F, 0, 0);
        cube_r1.setTextureOffset(0, 0).addBox(-1, -13, 0, 1, 7, 1, 0);

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(0, -5, 1);
        bone.addChild(cube_r2);
        setRotationAngle(cube_r2, -0.48F, 0, 0);
        cube_r2.setTextureOffset(0, 0).addBox(-1, -13, 0, 1, 7, 1, 0);
        bone.offsetY -= 1.0f;
    }



    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}

