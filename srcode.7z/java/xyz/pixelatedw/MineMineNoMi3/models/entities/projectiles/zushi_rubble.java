package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class zushi_rubble extends ModelBase {
    private final ModelRenderer bone4;
    private final ModelRenderer dirt1;
    private final ModelRenderer cube_r1;
    private final ModelRenderer dirt2;
    private final ModelRenderer cube_r2;
    private final ModelRenderer dirt3;
    private final ModelRenderer cube_r3;
    private final ModelRenderer dirt4;
    private final ModelRenderer cube_r4;
    private final ModelRenderer dirt5;
    private final ModelRenderer cube_r5;
    private final ModelRenderer bone;
    private final ModelRenderer cube_r6;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r7;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r8;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r9;
    private final ModelRenderer thebench;
    private final ModelRenderer cube_r10;
    private final ModelRenderer thefridge;
    private final ModelRenderer cube_r11;
    private final ModelRenderer thestove;
    private final ModelRenderer cube_r12;
    private final ModelRenderer bone7;
    private final ModelRenderer cube_r13;
    private final ModelRenderer lamp;
    private final ModelRenderer cube_r14;
    private final ModelRenderer lamp2;
    private final ModelRenderer cube_r15;
    private final ModelRenderer lamp3;
    private final ModelRenderer cube_r16;
    private final ModelRenderer block5;
    private final ModelRenderer cube_r17;
    private final ModelRenderer block7;
    private final ModelRenderer cube_r18;
    private final ModelRenderer bb_main;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;

    public zushi_rubble() {
        textureWidth = 256;
        textureHeight = 256;

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(-5.0F, 11.0F, -16.0F);
        setRotationAngle(bone4, -1.3526F, 0.0F, 0.0F);


        dirt1 = new ModelRenderer(this);
        dirt1.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone4.addChild(dirt1);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(-1.0F, -9.0F, -4.0F);
        dirt1.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0F, -0.3491F, -0.5236F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        dirt2 = new ModelRenderer(this);
        dirt2.setRotationPoint(-19.0F, 0.0F, 0.0F);
        bone4.addChild(dirt2);
        setRotationAngle(dirt2, 0.1745F, -0.4363F, -0.3491F);


        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(-32.0F, -1.0F, -31.0F);
        dirt2.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.0F, -0.3491F, -0.5236F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r2.cubeList.add(new ModelBox(cube_r2, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        dirt3 = new ModelRenderer(this);
        dirt3.setRotationPoint(22.0F, 2.0F, -48.0F);
        bone4.addChild(dirt3);


        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(7.0F, -2.0F, -4.0F);
        dirt3.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.0F, 1.3963F, 0.48F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        dirt4 = new ModelRenderer(this);
        dirt4.setRotationPoint(-2.0F, -5.0F, -51.0F);
        bone4.addChild(dirt4);
        setRotationAngle(dirt4, -1.2654F, -2.0071F, -1.4399F);


        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(7.0F, -2.0F, -4.0F);
        dirt4.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.0F, 1.3963F, 0.48F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        dirt5 = new ModelRenderer(this);
        dirt5.setRotationPoint(22.0F, 3.0F, -22.0F);
        bone4.addChild(dirt5);
        setRotationAngle(dirt5, -1.2654F, 0.5672F, -2.2689F);


        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(7.0F, -2.0F, -4.0F);
        dirt5.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.0F, 1.3963F, 0.48F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r5.cubeList.add(new ModelBox(cube_r5, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, -1.0F, -3.0F);
        bone4.addChild(bone);


        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.0F, 0.0F, -0.5236F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 96, 112, -6.0F, -1.0F, -15.0F, 7, 1, 16, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 48, 101, -6.0F, -2.0F, -16.0F, 13, 3, 1, 0.0F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 116, 129, 1.0F, -1.0F, -15.0F, 6, 1, 6, 0.0F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(5.0F, -20.0F, -9.0F);
        bone4.addChild(bone2);


        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone2.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.5236F, 0.0F, -0.5236F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 27, 31, -10.0F, -1.0F, -8.0F, 1, 1, 3, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 9, 37, -12.0F, -1.0F, -5.0F, 3, 1, 2, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 25, -13.0F, -1.0F, -3.0F, 4, 1, 3, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 30, 121, -9.0F, -1.0F, -11.0F, 1, 1, 11, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 12, 51, -4.0F, -1.0F, -13.0F, 2, 1, 1, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 12, 48, -2.0F, -1.0F, -14.0F, 2, 1, 2, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 48, 87, -8.0F, -1.0F, -12.0F, 8, 1, 13, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(7.0F, -6.0F, -27.0F);
        bone4.addChild(bone3);


        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone3.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.0436F, -0.0873F, 0.829F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 14, 34, -13.0F, -1.0F, -2.0F, 5, 1, 1, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 52, 37, -16.0F, -1.0F, -1.0F, 8, 1, 2, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 34, -14.0F, -1.0F, -7.0F, 6, 1, 1, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 16, 28, -16.0F, -1.0F, -6.0F, 8, 1, 2, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 17, 0.0F, -2.0F, -13.0F, 1, 3, 14, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 112, 87, -8.0F, -1.0F, -13.0F, 8, 1, 14, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 29, -14.0F, -1.0F, -11.0F, 6, 1, 1, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 52, 54, -16.0F, -1.0F, -13.0F, 8, 1, 2, 0.0F));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(-26.0F, -6.0F, -7.0F);
        bone4.addChild(bone5);


        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone5.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.5236F, 0.0F, -1.0908F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 106, 15, 3.0F, -1.0F, -13.0F, 4, 1, 6, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 96, 83, 3.0F, -1.0F, -7.0F, 7, 1, 2, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 68, 29, 3.0F, -1.0F, -5.0F, 8, 1, 6, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 70, 101, -12.0F, -1.0F, -29.0F, 4, 1, 6, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 68, 11, -14.0F, -1.0F, -23.0F, 6, 1, 9, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 106, 0, -7.0F, -2.0F, -22.0F, 9, 1, 22, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 66, 87, -8.0F, -1.0F, -23.0F, 11, 1, 24, 0.0F));

        thebench = new ModelRenderer(this);
        thebench.setRotationPoint(-1.0F, -21.0F, -44.0F);
        bone4.addChild(thebench);


        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(0.0F, 0.0F, 0.0F);
        thebench.addChild(cube_r10);
        setRotationAngle(cube_r10, 2.0944F, -0.8727F, 1.6581F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 30, 8, -1.0F, -8.0F, 18.0F, 1, 7, 1, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 30, 0, -11.0F, -8.0F, -13.0F, 1, 7, 1, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 10, 17, -1.0F, -8.0F, -13.0F, 1, 7, 1, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 40, 54, -12.0F, -1.0F, -13.0F, 12, 1, 32, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 12, 40, -11.0F, -8.0F, 18.0F, 1, 7, 1, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 72, 5, -1.0F, 0.0F, -13.0F, 1, 11, 32, 0.0F));

        thefridge = new ModelRenderer(this);
        thefridge.setRotationPoint(-58.0F, -44.0F, -78.0F);
        bone4.addChild(thefridge);
        setRotationAngle(thefridge, -0.0436F, -0.3491F, 0.3927F);


        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(31.0F, 18.0F, 24.0F);
        thefridge.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.7418F, 0.0F, 0.3054F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 0, -1.0F, -4.0F, -3.0F, 14, 16, 1, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 68, 0, -1.0F, -15.0F, -3.0F, 14, 10, 1, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 37, -2.0F, -16.0F, -2.0F, 16, 29, 20, 0.0F));

        thestove = new ModelRenderer(this);
        thestove.setRotationPoint(34.0F, -34.0F, -38.0F);
        bone4.addChild(thestove);


        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(0.0F, 0.0F, 0.0F);
        thestove.addChild(cube_r12);
        setRotationAngle(cube_r12, 0.0F, 0.0F, 0.6545F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 96, 73, 2.0F, -6.0F, 14.0F, 15, 6, 4, 0.0F));
        cube_r12.cubeList.add(new ModelBox(cube_r12, 0, 87, 2.0F, 0.0F, 0.0F, 15, 16, 18, 0.0F));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(-29.0F, -1.0F, -63.0F);
        bone4.addChild(bone7);
        setRotationAngle(bone7, 0.0F, -0.8727F, -0.6981F);


        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(0.0F, 0.0F, -4.0F);
        bone7.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.0F, 0.0F, -0.5236F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 50, 112, -6.0F, -1.0F, -15.0F, 7, 1, 16, 0.0F));
        cube_r13.cubeList.add(new ModelBox(cube_r13, 98, 0, -6.0F, -2.0F, -16.0F, 13, 3, 1, 0.0F));
        cube_r13.cubeList.add(new ModelBox(cube_r13, 128, 77, 1.0F, -1.0F, -15.0F, 6, 1, 6, 0.0F));

        lamp = new ModelRenderer(this);
        lamp.setRotationPoint(26.0F, -31.0F, -42.0F);
        bone4.addChild(lamp);
        setRotationAngle(lamp, -0.0436F, -0.3927F, 1.4835F);


        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(12.0F, 0.0F, -33.0F);
        lamp.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.5672F, 0.0F, -1.0036F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 68, 21, -1.6259F, -7.1196F, -6.0183F, 7, 1, 7, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 16, 17, -0.6259F, -12.1196F, -5.0183F, 5, 6, 5, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 0, 37, 0.3741F, -6.1196F, -4.0183F, 3, 17, 3, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 106, 23, -1.6259F, 10.8804F, -6.0183F, 7, 1, 7, 0.0F));

        lamp2 = new ModelRenderer(this);
        lamp2.setRotationPoint(-19.0F, 22.0F, -12.0F);
        bone4.addChild(lamp2);
        setRotationAngle(lamp2, -0.3054F, 0.2182F, -0.6981F);


        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(12.0F, 0.0F, -33.0F);
        lamp2.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.5672F, 0.0F, -1.0036F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 68, 21, -1.6259F, -7.1196F, -6.0183F, 7, 1, 7, 0.0F));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 16, 17, -0.6259F, -12.1196F, -5.0183F, 5, 6, 5, 0.0F));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 0, 37, 0.3741F, -6.1196F, -4.0183F, 3, 17, 3, 0.0F));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 106, 23, -1.6259F, 10.8804F, -6.0183F, 7, 1, 7, 0.0F));

        lamp3 = new ModelRenderer(this);
        lamp3.setRotationPoint(8.0F, 31.0F, -25.0F);
        bone4.addChild(lamp3);
        setRotationAngle(lamp3, 0.0F, -1.4399F, -0.9599F);


        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(12.0F, 0.0F, -33.0F);
        lamp3.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.5672F, 0.0F, -1.0036F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 68, 21, -1.6259F, -7.1196F, -6.0183F, 7, 1, 7, 0.0F));
        cube_r16.cubeList.add(new ModelBox(cube_r16, 16, 17, -0.6259F, -12.1196F, -5.0183F, 5, 6, 5, 0.0F));
        cube_r16.cubeList.add(new ModelBox(cube_r16, 0, 37, 0.3741F, -6.1196F, -4.0183F, 3, 17, 3, 0.0F));
        cube_r16.cubeList.add(new ModelBox(cube_r16, 106, 23, -1.6259F, 10.8804F, -6.0183F, 7, 1, 7, 0.0F));

        block5 = new ModelRenderer(this);
        block5.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone4.addChild(block5);


        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(-1.0F, -9.0F, -4.0F);
        block5.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.0F, -0.3491F, -0.5236F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        block7 = new ModelRenderer(this);
        block7.setRotationPoint(-19.0F, 0.0F, 0.0F);
        block5.addChild(block7);
        setRotationAngle(block7, 0.1745F, -0.4363F, -0.3491F);


        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(-32.0F, -1.0F, -31.0F);
        block7.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.0F, -0.3491F, -0.5236F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 112, 136, -7.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 32, 136, -5.0F, -7.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 122, 136, 0.0F, -5.0F, 1.0F, 1, 4, 4, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 16, 136, -5.0F, 0.0F, 1.0F, 4, 1, 4, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 138, 37, -5.0F, -5.0F, -1.0F, 4, 4, 1, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 132, 136, -5.0F, -5.0F, 6.0F, 4, 4, 1, 0.0F));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 48, 129, -6.0F, -6.0F, 0.0F, 6, 6, 6, 0.0F));

        bb_main = new ModelRenderer(this);
        bb_main.setRotationPoint(5.0F, 13.0F, 16.0F);
        bone4.addChild(bb_main);


        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(-5.0F, -9.0F, -74.0F);
        bb_main.addChild(cube_r19);
        setRotationAngle(cube_r19, 2.0944F, -0.8727F, 1.6581F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 0, 0, -16.0F, -1.0F, -17.0F, 16, 1, 36, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(21.0F, -19.0F, -46.0F);
        bb_main.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.5236F, 0.0F, 0.9163F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 96, 48, -8.0F, -1.0F, -23.0F, 11, 1, 24, 0.0F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(-11.0F, -19.0F, -39.0F);
        bb_main.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.5236F, 0.0F, -0.6545F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 0, 121, -8.0F, -1.0F, -13.0F, 8, 1, 14, 0.0F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(11.0F, -19.0F, -11.0F);
        bb_main.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.5236F, 0.0F, 0.9163F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 126, 102, -8.0F, -1.0F, -13.0F, 8, 1, 14, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone4.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

}
