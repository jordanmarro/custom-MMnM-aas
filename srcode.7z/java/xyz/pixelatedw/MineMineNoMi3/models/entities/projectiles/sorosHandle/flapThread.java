package xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class flapThread extends ModelBase {
    private final ModelRenderer bone;
    private final ModelRenderer string2;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer string3;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer string4;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer string5;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer string6;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer bone2;
    private final ModelRenderer string7;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer string8;
    private final ModelRenderer cube_r25;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer cube_r28;
    private final ModelRenderer string9;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer string10;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer string11;
    private final ModelRenderer cube_r37;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer bone3;
    private final ModelRenderer string12;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer string13;
    private final ModelRenderer cube_r45;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer cube_r48;
    private final ModelRenderer string14;
    private final ModelRenderer cube_r49;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer cube_r52;
    private final ModelRenderer string15;
    private final ModelRenderer cube_r53;
    private final ModelRenderer cube_r54;
    private final ModelRenderer cube_r55;
    private final ModelRenderer cube_r56;
    private final ModelRenderer string16;
    private final ModelRenderer cube_r57;
    private final ModelRenderer cube_r58;
    private final ModelRenderer cube_r59;
    private final ModelRenderer cube_r60;
    private final ModelRenderer bone4;
    private final ModelRenderer string17;
    private final ModelRenderer cube_r61;
    private final ModelRenderer cube_r62;
    private final ModelRenderer cube_r63;
    private final ModelRenderer cube_r64;
    private final ModelRenderer string18;
    private final ModelRenderer cube_r65;
    private final ModelRenderer cube_r66;
    private final ModelRenderer cube_r67;
    private final ModelRenderer cube_r68;
    private final ModelRenderer string19;
    private final ModelRenderer cube_r69;
    private final ModelRenderer cube_r70;
    private final ModelRenderer cube_r71;
    private final ModelRenderer cube_r72;
    private final ModelRenderer string20;
    private final ModelRenderer cube_r73;
    private final ModelRenderer cube_r74;
    private final ModelRenderer cube_r75;
    private final ModelRenderer cube_r76;
    private final ModelRenderer string21;
    private final ModelRenderer cube_r77;
    private final ModelRenderer cube_r78;
    private final ModelRenderer cube_r79;
    private final ModelRenderer cube_r80;

    public flapThread() {
        textureWidth = 256;
        textureHeight = 256;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(-4.0F, 25.0F, 0.0F);
        setRotationAngle(bone, 0.0F, 0.0873F, 0.0F);


        string2 = new ModelRenderer(this);
        string2.setRotationPoint(11.0F, -10.0F, 1.0F);
        bone.addChild(string2);
        setRotationAngle(string2, -0.2182F, 0.3491F, 2.4871F);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(8.0F, 3.0F, -24.0F);
        string2.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0873F, -0.3491F, 0.2618F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(4.0F, 1.0F, -11.0F);
        string2.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.0436F, -0.3054F, 0.2618F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(0.0F, 0.0F, 0.0F);
        string2.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.0F, -0.3054F, 0.48F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(7.0F, 3.0F, -26.0F);
        string2.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.0873F, -0.6109F, 0.2618F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string3 = new ModelRenderer(this);
        string3.setRotationPoint(11.0F, -8.0F, -2.0F);
        bone.addChild(string3);
        setRotationAngle(string3, -0.2182F, 0.3491F, 2.4871F);


        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(8.0F, 3.0F, -24.0F);
        string3.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.0873F, -0.3491F, 0.2618F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(4.0F, 1.0F, -11.0F);
        string3.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.0436F, -0.3054F, 0.2618F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(0.0F, 0.0F, 0.0F);
        string3.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.0F, -0.3054F, 0.48F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(7.0F, 3.0F, -26.0F);
        string3.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.0873F, -0.6109F, 0.2618F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string4 = new ModelRenderer(this);
        string4.setRotationPoint(15.0F, -11.0F, -10.0F);
        bone.addChild(string4);
        setRotationAngle(string4, -0.2182F, 0.3491F, 2.4871F);


        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(8.0F, 3.0F, -24.0F);
        string4.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.0873F, -0.3491F, 0.2618F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(4.0F, 1.0F, -11.0F);
        string4.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.0436F, -0.3054F, 0.2618F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(0.0F, 0.0F, 0.0F);
        string4.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.0F, -0.3054F, 0.48F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(7.0F, 3.0F, -26.0F);
        string4.addChild(cube_r12);
        setRotationAngle(cube_r12, 0.0873F, -0.6109F, 0.2618F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string5 = new ModelRenderer(this);
        string5.setRotationPoint(13.0F, -4.0F, -6.0F);
        bone.addChild(string5);
        setRotationAngle(string5, -0.2182F, 0.3491F, 2.4871F);


        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(8.0F, 3.0F, -24.0F);
        string5.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.0873F, -0.3491F, 0.2618F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(4.0F, 1.0F, -11.0F);
        string5.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.0436F, -0.3054F, 0.2618F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(0.0F, 0.0F, 0.0F);
        string5.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.0F, -0.3054F, 0.48F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(7.0F, 3.0F, -26.0F);
        string5.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.0873F, -0.6109F, 0.2618F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string6 = new ModelRenderer(this);
        string6.setRotationPoint(8.0F, -7.0F, 5.0F);
        bone.addChild(string6);
        setRotationAngle(string6, -0.2182F, 0.3491F, 2.4871F);


        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(8.0F, 3.0F, -24.0F);
        string6.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.0873F, -0.3491F, 0.2618F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(4.0F, 1.0F, -11.0F);
        string6.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.0436F, -0.3054F, 0.2618F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(0.0F, 0.0F, 0.0F);
        string6.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.0F, -0.3054F, 0.48F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(7.0F, 3.0F, -26.0F);
        string6.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.0873F, -0.6109F, 0.2618F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(5.0F, 12.0F, 0.0F);
        setRotationAngle(bone2, -0.0436F, 0.1309F, -2.9234F);


        string7 = new ModelRenderer(this);
        string7.setRotationPoint(11.0F, -10.0F, 1.0F);
        bone2.addChild(string7);
        setRotationAngle(string7, -0.2182F, 0.3491F, 2.4871F);


        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(8.0F, 3.0F, -24.0F);
        string7.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.0873F, -0.3491F, 0.2618F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(4.0F, 1.0F, -11.0F);
        string7.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.0436F, -0.3054F, 0.2618F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(0.0F, 0.0F, 0.0F);
        string7.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.0F, -0.3054F, 0.48F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(7.0F, 3.0F, -26.0F);
        string7.addChild(cube_r24);
        setRotationAngle(cube_r24, 0.0873F, -0.6109F, 0.2618F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string8 = new ModelRenderer(this);
        string8.setRotationPoint(11.0F, -8.0F, -2.0F);
        bone2.addChild(string8);
        setRotationAngle(string8, -0.2182F, 0.3491F, 2.4871F);


        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(8.0F, 3.0F, -24.0F);
        string8.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.0873F, -0.3491F, 0.2618F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(4.0F, 1.0F, -11.0F);
        string8.addChild(cube_r26);
        setRotationAngle(cube_r26, 0.0436F, -0.3054F, 0.2618F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(0.0F, 0.0F, 0.0F);
        string8.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.0F, -0.3054F, 0.48F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(7.0F, 3.0F, -26.0F);
        string8.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.0873F, -0.6109F, 0.2618F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string9 = new ModelRenderer(this);
        string9.setRotationPoint(15.0F, -11.0F, -10.0F);
        bone2.addChild(string9);
        setRotationAngle(string9, -0.2182F, 0.3491F, 2.4871F);


        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(8.0F, 3.0F, -24.0F);
        string9.addChild(cube_r29);
        setRotationAngle(cube_r29, 0.0873F, -0.3491F, 0.2618F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(4.0F, 1.0F, -11.0F);
        string9.addChild(cube_r30);
        setRotationAngle(cube_r30, 0.0436F, -0.3054F, 0.2618F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(0.0F, 0.0F, 0.0F);
        string9.addChild(cube_r31);
        setRotationAngle(cube_r31, 0.0F, -0.3054F, 0.48F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(7.0F, 3.0F, -26.0F);
        string9.addChild(cube_r32);
        setRotationAngle(cube_r32, 0.0873F, -0.6109F, 0.2618F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string10 = new ModelRenderer(this);
        string10.setRotationPoint(11.5908F, -5.7362F, -6.0F);
        bone2.addChild(string10);
        setRotationAngle(string10, -0.2182F, 0.3491F, 2.4871F);


        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(8.0F, 3.0F, -24.0F);
        string10.addChild(cube_r33);
        setRotationAngle(cube_r33, 0.0873F, -0.3491F, 0.2618F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(4.0F, 1.0F, -11.0F);
        string10.addChild(cube_r34);
        setRotationAngle(cube_r34, 0.0436F, -0.3054F, 0.2618F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0.0F, 0.0F, 0.0F);
        string10.addChild(cube_r35);
        setRotationAngle(cube_r35, 0.0F, -0.3054F, 0.48F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(7.0F, 3.0F, -26.0F);
        string10.addChild(cube_r36);
        setRotationAngle(cube_r36, 0.0873F, -0.6109F, 0.2618F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string11 = new ModelRenderer(this);
        string11.setRotationPoint(8.0F, -7.0F, 5.0F);
        bone2.addChild(string11);
        setRotationAngle(string11, -0.2182F, 0.3491F, 2.4871F);


        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(8.0F, 3.0F, -24.0F);
        string11.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.0873F, -0.3491F, 0.2618F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(4.0F, 1.0F, -11.0F);
        string11.addChild(cube_r38);
        setRotationAngle(cube_r38, 0.0436F, -0.3054F, 0.2618F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(0.0F, 0.0F, 0.0F);
        string11.addChild(cube_r39);
        setRotationAngle(cube_r39, 0.0F, -0.3054F, 0.48F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(7.0F, 3.0F, -26.0F);
        string11.addChild(cube_r40);
        setRotationAngle(cube_r40, 0.0873F, -0.6109F, 0.2618F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(7.0F, 8.0F, 0.0F);
        setRotationAngle(bone3, -0.0436F, 0.1309F, -2.9234F);


        string12 = new ModelRenderer(this);
        string12.setRotationPoint(11.0F, -10.0F, 1.0F);
        bone3.addChild(string12);
        setRotationAngle(string12, -0.2182F, 0.3491F, 2.4871F);


        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(8.0F, 3.0F, -24.0F);
        string12.addChild(cube_r41);
        setRotationAngle(cube_r41, 0.0873F, -0.3491F, 0.2618F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(4.0F, 1.0F, -11.0F);
        string12.addChild(cube_r42);
        setRotationAngle(cube_r42, 0.0436F, -0.3054F, 0.2618F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(0.0F, 0.0F, 0.0F);
        string12.addChild(cube_r43);
        setRotationAngle(cube_r43, 0.0F, -0.3054F, 0.48F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(7.0F, 3.0F, -26.0F);
        string12.addChild(cube_r44);
        setRotationAngle(cube_r44, 0.0873F, -0.6109F, 0.2618F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string13 = new ModelRenderer(this);
        string13.setRotationPoint(11.0F, -8.0F, -2.0F);
        bone3.addChild(string13);
        setRotationAngle(string13, -0.2182F, 0.3491F, 2.4871F);


        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(8.0F, 3.0F, -24.0F);
        string13.addChild(cube_r45);
        setRotationAngle(cube_r45, 0.0873F, -0.3491F, 0.2618F);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(4.0F, 1.0F, -11.0F);
        string13.addChild(cube_r46);
        setRotationAngle(cube_r46, 0.0436F, -0.3054F, 0.2618F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0.0F, 0.0F, 0.0F);
        string13.addChild(cube_r47);
        setRotationAngle(cube_r47, 0.0F, -0.3054F, 0.48F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(7.0F, 3.0F, -26.0F);
        string13.addChild(cube_r48);
        setRotationAngle(cube_r48, 0.0873F, -0.6109F, 0.2618F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string14 = new ModelRenderer(this);
        string14.setRotationPoint(15.0F, -11.0F, -10.0F);
        bone3.addChild(string14);
        setRotationAngle(string14, -0.2182F, 0.3491F, 2.4871F);


        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(8.0F, 3.0F, -24.0F);
        string14.addChild(cube_r49);
        setRotationAngle(cube_r49, 0.0873F, -0.3491F, 0.2618F);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(4.0F, 1.0F, -11.0F);
        string14.addChild(cube_r50);
        setRotationAngle(cube_r50, 0.0436F, -0.3054F, 0.2618F);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(0.0F, 0.0F, 0.0F);
        string14.addChild(cube_r51);
        setRotationAngle(cube_r51, 0.0F, -0.3054F, 0.48F);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(7.0F, 3.0F, -26.0F);
        string14.addChild(cube_r52);
        setRotationAngle(cube_r52, 0.0873F, -0.6109F, 0.2618F);
        cube_r52.cubeList.add(new ModelBox(cube_r52, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string15 = new ModelRenderer(this);
        string15.setRotationPoint(11.5908F, -5.7362F, -6.0F);
        bone3.addChild(string15);
        setRotationAngle(string15, -0.2182F, 0.3491F, 2.4871F);


        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(8.0F, 3.0F, -24.0F);
        string15.addChild(cube_r53);
        setRotationAngle(cube_r53, 0.0873F, -0.3491F, 0.2618F);
        cube_r53.cubeList.add(new ModelBox(cube_r53, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(4.0F, 1.0F, -11.0F);
        string15.addChild(cube_r54);
        setRotationAngle(cube_r54, 0.0436F, -0.3054F, 0.2618F);
        cube_r54.cubeList.add(new ModelBox(cube_r54, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(0.0F, 0.0F, 0.0F);
        string15.addChild(cube_r55);
        setRotationAngle(cube_r55, 0.0F, -0.3054F, 0.48F);
        cube_r55.cubeList.add(new ModelBox(cube_r55, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(7.0F, 3.0F, -26.0F);
        string15.addChild(cube_r56);
        setRotationAngle(cube_r56, 0.0873F, -0.6109F, 0.2618F);
        cube_r56.cubeList.add(new ModelBox(cube_r56, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string16 = new ModelRenderer(this);
        string16.setRotationPoint(8.0F, -7.0F, 5.0F);
        bone3.addChild(string16);
        setRotationAngle(string16, -0.2182F, 0.3491F, 2.4871F);


        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(8.0F, 3.0F, -24.0F);
        string16.addChild(cube_r57);
        setRotationAngle(cube_r57, 0.0873F, -0.3491F, 0.2618F);
        cube_r57.cubeList.add(new ModelBox(cube_r57, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r58 = new ModelRenderer(this);
        cube_r58.setRotationPoint(4.0F, 1.0F, -11.0F);
        string16.addChild(cube_r58);
        setRotationAngle(cube_r58, 0.0436F, -0.3054F, 0.2618F);
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r59 = new ModelRenderer(this);
        cube_r59.setRotationPoint(0.0F, 0.0F, 0.0F);
        string16.addChild(cube_r59);
        setRotationAngle(cube_r59, 0.0F, -0.3054F, 0.48F);
        cube_r59.cubeList.add(new ModelBox(cube_r59, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r60 = new ModelRenderer(this);
        cube_r60.setRotationPoint(7.0F, 3.0F, -26.0F);
        string16.addChild(cube_r60);
        setRotationAngle(cube_r60, 0.0873F, -0.6109F, 0.2618F);
        cube_r60.cubeList.add(new ModelBox(cube_r60, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(-3.0F, 21.0F, 0.0F);
        setRotationAngle(bone4, 0.0F, 0.0873F, 0.0F);


        string17 = new ModelRenderer(this);
        string17.setRotationPoint(11.0F, -10.0F, 1.0F);
        bone4.addChild(string17);
        setRotationAngle(string17, -0.2182F, 0.3491F, 2.4871F);


        cube_r61 = new ModelRenderer(this);
        cube_r61.setRotationPoint(8.0F, 3.0F, -24.0F);
        string17.addChild(cube_r61);
        setRotationAngle(cube_r61, 0.0873F, -0.3491F, 0.2618F);
        cube_r61.cubeList.add(new ModelBox(cube_r61, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r62 = new ModelRenderer(this);
        cube_r62.setRotationPoint(4.0F, 1.0F, -11.0F);
        string17.addChild(cube_r62);
        setRotationAngle(cube_r62, 0.0436F, -0.3054F, 0.2618F);
        cube_r62.cubeList.add(new ModelBox(cube_r62, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r63 = new ModelRenderer(this);
        cube_r63.setRotationPoint(0.0F, 0.0F, 0.0F);
        string17.addChild(cube_r63);
        setRotationAngle(cube_r63, 0.0F, -0.3054F, 0.48F);
        cube_r63.cubeList.add(new ModelBox(cube_r63, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r64 = new ModelRenderer(this);
        cube_r64.setRotationPoint(7.0F, 3.0F, -26.0F);
        string17.addChild(cube_r64);
        setRotationAngle(cube_r64, 0.0873F, -0.6109F, 0.2618F);
        cube_r64.cubeList.add(new ModelBox(cube_r64, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string18 = new ModelRenderer(this);
        string18.setRotationPoint(11.0F, -8.0F, -2.0F);
        bone4.addChild(string18);
        setRotationAngle(string18, -0.2182F, 0.3491F, 2.4871F);


        cube_r65 = new ModelRenderer(this);
        cube_r65.setRotationPoint(8.0F, 3.0F, -24.0F);
        string18.addChild(cube_r65);
        setRotationAngle(cube_r65, 0.0873F, -0.3491F, 0.2618F);
        cube_r65.cubeList.add(new ModelBox(cube_r65, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r66 = new ModelRenderer(this);
        cube_r66.setRotationPoint(4.0F, 1.0F, -11.0F);
        string18.addChild(cube_r66);
        setRotationAngle(cube_r66, 0.0436F, -0.3054F, 0.2618F);
        cube_r66.cubeList.add(new ModelBox(cube_r66, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r67 = new ModelRenderer(this);
        cube_r67.setRotationPoint(0.0F, 0.0F, 0.0F);
        string18.addChild(cube_r67);
        setRotationAngle(cube_r67, 0.0F, -0.3054F, 0.48F);
        cube_r67.cubeList.add(new ModelBox(cube_r67, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r68 = new ModelRenderer(this);
        cube_r68.setRotationPoint(7.0F, 3.0F, -26.0F);
        string18.addChild(cube_r68);
        setRotationAngle(cube_r68, 0.0873F, -0.6109F, 0.2618F);
        cube_r68.cubeList.add(new ModelBox(cube_r68, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string19 = new ModelRenderer(this);
        string19.setRotationPoint(15.0F, -11.0F, -10.0F);
        bone4.addChild(string19);
        setRotationAngle(string19, -0.2182F, 0.3491F, 2.4871F);


        cube_r69 = new ModelRenderer(this);
        cube_r69.setRotationPoint(8.0F, 3.0F, -24.0F);
        string19.addChild(cube_r69);
        setRotationAngle(cube_r69, 0.0873F, -0.3491F, 0.2618F);
        cube_r69.cubeList.add(new ModelBox(cube_r69, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r70 = new ModelRenderer(this);
        cube_r70.setRotationPoint(4.0F, 1.0F, -11.0F);
        string19.addChild(cube_r70);
        setRotationAngle(cube_r70, 0.0436F, -0.3054F, 0.2618F);
        cube_r70.cubeList.add(new ModelBox(cube_r70, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r71 = new ModelRenderer(this);
        cube_r71.setRotationPoint(0.0F, 0.0F, 0.0F);
        string19.addChild(cube_r71);
        setRotationAngle(cube_r71, 0.0F, -0.3054F, 0.48F);
        cube_r71.cubeList.add(new ModelBox(cube_r71, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r72 = new ModelRenderer(this);
        cube_r72.setRotationPoint(7.0F, 3.0F, -26.0F);
        string19.addChild(cube_r72);
        setRotationAngle(cube_r72, 0.0873F, -0.6109F, 0.2618F);
        cube_r72.cubeList.add(new ModelBox(cube_r72, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string20 = new ModelRenderer(this);
        string20.setRotationPoint(13.0F, -4.0F, -6.0F);
        bone4.addChild(string20);
        setRotationAngle(string20, -0.2182F, 0.3491F, 2.4871F);


        cube_r73 = new ModelRenderer(this);
        cube_r73.setRotationPoint(8.0F, 3.0F, -24.0F);
        string20.addChild(cube_r73);
        setRotationAngle(cube_r73, 0.0873F, -0.3491F, 0.2618F);
        cube_r73.cubeList.add(new ModelBox(cube_r73, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r74 = new ModelRenderer(this);
        cube_r74.setRotationPoint(4.0F, 1.0F, -11.0F);
        string20.addChild(cube_r74);
        setRotationAngle(cube_r74, 0.0436F, -0.3054F, 0.2618F);
        cube_r74.cubeList.add(new ModelBox(cube_r74, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r75 = new ModelRenderer(this);
        cube_r75.setRotationPoint(0.0F, 0.0F, 0.0F);
        string20.addChild(cube_r75);
        setRotationAngle(cube_r75, 0.0F, -0.3054F, 0.48F);
        cube_r75.cubeList.add(new ModelBox(cube_r75, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r76 = new ModelRenderer(this);
        cube_r76.setRotationPoint(7.0F, 3.0F, -26.0F);
        string20.addChild(cube_r76);
        setRotationAngle(cube_r76, 0.0873F, -0.6109F, 0.2618F);
        cube_r76.cubeList.add(new ModelBox(cube_r76, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        string21 = new ModelRenderer(this);
        string21.setRotationPoint(8.0F, -7.0F, 5.0F);
        bone4.addChild(string21);
        setRotationAngle(string21, -0.2182F, 0.3491F, 2.4871F);


        cube_r77 = new ModelRenderer(this);
        cube_r77.setRotationPoint(8.0F, 3.0F, -24.0F);
        string21.addChild(cube_r77);
        setRotationAngle(cube_r77, 0.0873F, -0.3491F, 0.2618F);
        cube_r77.cubeList.add(new ModelBox(cube_r77, 0, 0, -1.0F, 0.0F, -10.0F, 1, 1, 13, 0.0F));

        cube_r78 = new ModelRenderer(this);
        cube_r78.setRotationPoint(4.0F, 1.0F, -11.0F);
        string21.addChild(cube_r78);
        setRotationAngle(cube_r78, 0.0436F, -0.3054F, 0.2618F);
        cube_r78.cubeList.add(new ModelBox(cube_r78, 0, 0, -1.0F, 0.0F, -12.0F, 1, 1, 22, 0.0F));

        cube_r79 = new ModelRenderer(this);
        cube_r79.setRotationPoint(0.0F, 0.0F, 0.0F);
        string21.addChild(cube_r79);
        setRotationAngle(cube_r79, 0.0F, -0.3054F, 0.48F);
        cube_r79.cubeList.add(new ModelBox(cube_r79, 0, 0, -1.0F, -1.0F, -3.0F, 2, 2, 13, 0.0F));

        cube_r80 = new ModelRenderer(this);
        cube_r80.setRotationPoint(7.0F, 3.0F, -26.0F);
        string21.addChild(cube_r80);
        setRotationAngle(cube_r80, 0.0873F, -0.6109F, 0.2618F);
        cube_r80.cubeList.add(new ModelBox(cube_r80, 0, 0, -1.0F, 0.0F, -11.0F, 0, 1, 3, 0.0F));

        bone.offsetY -= 1.0f;
        bone2.offsetY -= 1.0f;
        bone3.offsetY -= 1.0f;
        bone4.offsetY -= 1.0f;
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        bone.render(f5);
        bone2.render(f5);
        bone3.render(f5);
        bone4.render(f5);


    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}