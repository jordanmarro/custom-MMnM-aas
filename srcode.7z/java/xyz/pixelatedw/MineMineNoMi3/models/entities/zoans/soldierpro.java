package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;

public class soldierpro extends ModelZoanMorph {
    private final ModelRenderer bone;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer arm;
    private final ModelRenderer leftarm;
    private final ModelRenderer cube_r18;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r19;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer rightarm;
    private final ModelRenderer cube_r22;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r23;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r24;
    private final ModelRenderer cube_r25;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;

    public soldierpro() {
        textureWidth = 240;
        textureHeight = 240;

        bone = new ModelRenderer(this);
        bone.setRotationPoint(-8, 24, 0);
        bone.setTextureOffset(106, 186).addBox(14, -16, -2, 5, 16, 4, 0);
        bone.setTextureOffset(106, 186).addBox(-3, -16, -2, 5, 16, 4, 0);
        bone.setTextureOffset(101, 158).addBox(14, -3, -7, 5, 3, 4, 0.6F);
        bone.setTextureOffset(101, 158).addBox(-3, -3, -7, 5, 3, 4, 0.6F);
        bone.setTextureOffset(47, 0).addBox(14, -10, -2, 5, 10, 4, 0.6F);
        bone.setTextureOffset(47, 0).addBox(-3, -10, -2, 5, 10, 4, 0.6F);
        bone.setTextureOffset(148, 184).addBox(14, -32, -2, 5, 16, 4, 0);
        bone.setTextureOffset(148, 184).addBox(-3, -32, -2, 5, 16, 4, 0);
        bone.setTextureOffset(0, 106).addBox(-9, -48, -9, 34, 16, 17, 0);
        bone.setTextureOffset(115, 52).addBox(-9, -33, -9, 34, 8, 17, 0.1F);
        bone.setTextureOffset(85, 138).addBox(-9, -36, -9, 34, 3, 17, 0.3F);
        bone.setTextureOffset(51, 51).addBox(5, -36, -10, 6, 6, 1, 0);
        bone.setTextureOffset(102, 106).addBox(-8, -64, -8, 32, 16, 16, 0);
        bone.setTextureOffset(0, 139).addBox(-7, -65, -5, 30, 1, 13, 0);
        bone.setTextureOffset(0, 69).addBox(-15, -64, -5, 46, 21, 16, 0);
        bone.setTextureOffset(67, 0).addBox(-16, -43, -5, 48, 34, 16, 0);
        bone.setTextureOffset(0, 49).addBox(4, -78, -10, 8, 7, 9, 0);
        bone.setTextureOffset(67, 50).addBox(4, -80, -10, 8, 2, 9, 0.1F);
        bone.setTextureOffset(67, 51).addBox(4, -78.5F, -10, 8, 1, 9, 0.1F);
        bone.setTextureOffset(124, 186).addBox(12, -80, -9, 1, 9, 8, 0.1F);
        bone.setTextureOffset(77, 11).addBox(13, -77, -6, 1, 2, 2, 0.2F);
        bone.setTextureOffset(67, 54).addBox(2, -77, -6, 1, 2, 2, 0.2F);
        bone.setTextureOffset(76, 181).addBox(3, -80, -9, 1, 9, 8, 0.1F);
        bone.setTextureOffset(11, 12).addBox(12, -80, -10, 1, 1, 1, 0.1F);
        bone.setTextureOffset(10, 9).addBox(3, -80, -10, 1, 1, 1, 0.1F);
        bone.setTextureOffset(75, 139).addBox(4, -80, -1, 8, 9, 1, 0.1F);
        bone.setTextureOffset(124, 97).addBox(4, -82, -9, 8, 2, 7, 0);
        bone.setTextureOffset(25, 49).addBox(5, -84, -8, 6, 2, 5, 0);
        bone.setTextureOffset(11, 0).addBox(7.5F, -75, -11, 1, 2, 1, 0);
        bone.setTextureOffset(0, 153).addBox(1, -71, -11, 14, 7, 11, 0);
        bone.setTextureOffset(108, 77).addBox(1, -67, -11, 14, 5, 1, 0.1F);
        bone.setTextureOffset(0, 69).addBox(5, -62, -11, 6, 9, 2, 0.1F);
        bone.setTextureOffset(0, 17).addBox(5.5F, -53, -11, 5, 9, 1, 0.1F);
        bone.setTextureOffset(0, 34).addBox(6, -44, -11, 4, 9, 1, 0.1F);
        bone.setTextureOffset(0, 49).addBox(7, -35, -11, 2, 7, 1, 0.1F);
        bone.setTextureOffset(0, 34).addBox(-2, -66, -10, 20, 4, 11, 0.1F);

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(30, -62, 4);
        bone.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.1309F, -0.0436F, 0.2618F);
        cube_r1.setTextureOffset(0, 0).addBox(-14, -2, -14, 16, 2, 15, 0);

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(-14, -62, 4);
        bone.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.1309F, 0.0436F, -0.2618F);
        cube_r2.setTextureOffset(0, 17).addBox(-2, -2, -14, 16, 2, 15, 0);

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(8, -80.4583F, 0.9501F);
        bone.addChild(cube_r3);
        setRotationAngle(cube_r3, -1.7453F, 0, 0);
        cube_r3.setTextureOffset(132, 158).addBox(-1, -20, 2, 2, 20, 8, 0);

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(10, -85.1329F, -0.1619F);
        bone.addChild(cube_r4);
        setRotationAngle(cube_r4, -1.5272F, 0, 0);
        cube_r4.setTextureOffset(62, 173).addBox(-3, -20, 6, 2, 20, 5, 0);

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(8, -87.3709F, -1.5255F);
        bone.addChild(cube_r5);
        setRotationAngle(cube_r5, -1.3963F, 0, 0);
        cube_r5.setTextureOffset(152, 158).addBox(-1, -20, 2, 2, 17, 9, 0);

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(8, -85.8398F, -4.9935F);
        bone.addChild(cube_r6);
        setRotationAngle(cube_r6, -0.9599F, 0, 0);
        cube_r6.setTextureOffset(0, 171).addBox(-1, -21, 2, 2, 16, 9, 0);

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(8, -84.4261F, -6.1705F);
        bone.addChild(cube_r7);
        setRotationAngle(cube_r7, -0.5236F, 0, 0);
        cube_r7.setTextureOffset(88, 158).addBox(-1, -20, 2, 2, 22, 9, 0);

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(10, -84.2751F, -10.24F);
        bone.addChild(cube_r8);
        setRotationAngle(cube_r8, -0.2618F, 0, 0);
        cube_r8.setTextureOffset(22, 171).addBox(-3, -20, 2, 2, 15, 9, 0);

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(-1, -84.8856F, 3.122F);
        bone.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.1745F, 0, 0);
        cube_r9.setTextureOffset(110, 158).addBox(8, -19, -12, 2, 19, 9, 0);

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(-2.9442F, -78.4737F, -1);
        bone.addChild(cube_r10);
        setRotationAngle(cube_r10, 0, 0, 0.3927F);
        cube_r10.setTextureOffset(0, 9).addBox(-6, 1, -5, 4, 2, 2, 0);

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(18.9442F, -78.4737F, -1);
        bone.addChild(cube_r11);
        setRotationAngle(cube_r11, 0, 0, -0.3927F);
        cube_r11.setTextureOffset(51, 38).addBox(2, 1, -5, 4, 2, 2, 0);

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(0.6844F, -77.5243F, -1);
        bone.addChild(cube_r12);
        setRotationAngle(cube_r12, 0, 0, 0.3054F);
        cube_r12.setTextureOffset(0, 27).addBox(-6, 1, -5, 4, 2, 2, 0);

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(15.3156F, -77.5243F, -1);
        bone.addChild(cube_r13);
        setRotationAngle(cube_r13, 0, 0, -0.3054F);
        cube_r13.setTextureOffset(34, 56).addBox(2, 1, -5, 4, 2, 2, 0);

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(4, -78, -1);
        bone.addChild(cube_r14);
        setRotationAngle(cube_r14, 0, 0, 0.0436F);
        cube_r14.setTextureOffset(51, 34).addBox(-6, 1, -5, 4, 2, 2, 0);

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(12, -78, -1);
        bone.addChild(cube_r15);
        setRotationAngle(cube_r15, 0, 0, -0.0436F);
        cube_r15.setTextureOffset(51, 58).addBox(2, 1, -5, 4, 2, 2, 0);

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(-24.1443F, -83.6987F, -15.8F);
        bone.addChild(cube_r16);
        setRotationAngle(cube_r16, 0, 0, -0.9163F);
        cube_r16.setTextureOffset(203, 221).addBox(-8, 25, 8, 2, 3, 17, 0.2F);

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(8.3831F, -58.7395F, -16.2F);
        bone.addChild(cube_r17);
        setRotationAngle(cube_r17, 0, 0, -0.9163F);
        cube_r17.setTextureOffset(50, 153).addBox(-8, 25, 8, 2, 3, 17, 0.2F);
        cube_r17.setTextureOffset(0, 211).addBox(-8, -7, 8, 2, 1, 1, 0.5F);
        cube_r17.setTextureOffset(87, 61).addBox(-9, -8, 8, 4, 3, 1, 0.3F);
        cube_r17.setTextureOffset(0, 211).addBox(-8, -1, 8, 2, 1, 1, 0.5F);
        cube_r17.setTextureOffset(0, 80).addBox(-9, -2, 8, 4, 3, 1, 0.3F);
        cube_r17.setTextureOffset(166, 184).addBox(-8, -16, 8, 2, 24, 1, 0.2F);
        cube_r17.setTextureOffset(0, 211).addBox(-8, 9, 7, 2, 1, 1, 0.5F);
        cube_r17.setTextureOffset(77, 61).addBox(-9, 8, 7, 4, 3, 1, 0.3F);
        cube_r17.setTextureOffset(0, 211).addBox(-8, 15, 7, 2, 1, 1, 0.5F);
        cube_r17.setTextureOffset(67, 61).addBox(-9, 14, 7, 4, 3, 1, 0.3F);
        cube_r17.setTextureOffset(0, 211).addBox(-8, 21, 7, 2, 1, 1, 0.5F);
        cube_r17.setTextureOffset(67, 11).addBox(-9, 20, 7, 4, 3, 1, 0.3F);
        cube_r17.setTextureOffset(142, 186).addBox(-8, 8, 7, 2, 20, 1, 0.2F);

        arm = new ModelRenderer(this);
        arm.setRotationPoint(-20, -62, -3);
        bone.addChild(arm);


        leftarm = new ModelRenderer(this);
        leftarm.setRotationPoint(0, 0, 0);
        arm.addChild(leftarm);


        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(39.4685F, 0.1131F, 4);
        leftarm.addChild(cube_r18);
        setRotationAngle(cube_r18, 0, 0, -0.4363F);
        cube_r18.setTextureOffset(174, 174).addBox(1, 0, -3, 4, 16, 5, 0);

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(0, 0, 0);
        leftarm.addChild(bone2);


        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(45.8804F, 13.5831F, 4);
        bone2.addChild(cube_r19);
        setRotationAngle(cube_r19, 0, 0, -0.2182F);
        cube_r19.setTextureOffset(170, 138).addBox(1, 0, -3, 4, 9, 5, 0);

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(0, 0, 0);
        bone2.addChild(bone3);


        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(45.3632F, 28.345F, 4.7F);
        bone3.addChild(cube_r20);
        setRotationAngle(cube_r20, 0, 0, -0.2182F);
        cube_r20.setTextureOffset(85, 106).addBox(3, 0, -5, 6, 6, 7, 0);

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(47.179F, 19.4409F, 4);
        bone3.addChild(cube_r21);
        setRotationAngle(cube_r21, 0, 0, -0.2182F);
        cube_r21.setTextureOffset(179, 0).addBox(1, 3, -3, 4, 6, 5, 0.3F);

        rightarm = new ModelRenderer(this);
        rightarm.setRotationPoint(12, 1, 3);
        arm.addChild(rightarm);
        setRotationAngle(rightarm, -0.4363F, 0, 0);


        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(4.5315F, -0.8869F, 1);
        rightarm.addChild(cube_r22);
        setRotationAngle(cube_r22, 0, 0, 0.4363F);
        cube_r22.setTextureOffset(44, 173).addBox(-5, 0, -3, 4, 16, 5, 0);

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(-5.8804F, 11.5831F, 3);
        rightarm.addChild(bone4);
        setRotationAngle(bone4, -0.3491F, -0.1309F, 0);


        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(0, 0, 0);
        bone4.addChild(cube_r23);
        setRotationAngle(cube_r23, 0, 0, 0.2182F);
        cube_r23.setTextureOffset(71, 153).addBox(-0.8784F, 0.1105F, -5, 4, 9, 5, 0);

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(-0.1196F, 8.4169F, -3);
        bone4.addChild(bone5);
        setRotationAngle(bone5, -0.829F, 0, 0);


        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(5.0229F, 7.063F, 1.6837F);
        bone5.addChild(cube_r24);
        setRotationAngle(cube_r24, 0, 0, 0.2182F);
        cube_r24.setTextureOffset(67, 50).addBox(-7.316F, 3.3588F, 8.0163F, 2, 2, 2, 0.4F);
        cube_r24.setTextureOffset(154, 97).addBox(-10.316F, 0.3588F, -5.9837F, 8, 8, 1, 0);
        cube_r24.setTextureOffset(0, 0).addBox(-6.9159F, 2.3588F, -70.9837F, 1, 4, 65, 0);
        cube_r24.setTextureOffset(34, 49).addBox(-7.316F, 3.3588F, -4.9837F, 2, 2, 13, 0);

        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(4.6368F, 7.345F, 1.7F);
        bone5.addChild(cube_r25);
        setRotationAngle(cube_r25, 0, 0, 0.2182F);
        cube_r25.setTextureOffset(101, 50).addBox(-9, 0, -5, 6, 6, 7, 0);

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(2.821F, -1.5591F, 1);
        bone5.addChild(cube_r26);
        setRotationAngle(cube_r26, 0, 0, 0.2182F);
        cube_r26.setTextureOffset(39, 153).addBox(-5, 3, -3, 4, 6, 5, 0.3F);

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(2.8224F, -2.2251F, 1.2219F);
        bone5.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.0436F, -0.1745F, 0.1309F);
        cube_r27.setTextureOffset(0, 0).addBox(-5.1984F, 1.012F, -1.0932F, 4, 6, 3, 0);
    bone.offsetY += 1.5;
    }

    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw,
                                  float headPitch, float scaleFactor, Entity ent)
    {

    }


    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        bone.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}
