package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.ModelZoanMorph;

public class buddha extends ModelZoanMorph {
    private final ModelRenderer Body;
    private final ModelRenderer chest;
    private final ModelRenderer neck;
    private final ModelRenderer RightArm;
    private final ModelRenderer subarm;
    private final ModelRenderer hand;
    private final ModelRenderer thumb;
    private final ModelRenderer fingers;
    private final ModelRenderer LeftArm;
    private final ModelRenderer subarm2;
    private final ModelRenderer hand2;
    private final ModelRenderer thumb2;
    private final ModelRenderer fingers2;
    private final ModelRenderer Head;
    private final ModelRenderer nose;
    private final ModelRenderer afro;
    private final ModelRenderer RightLeg;
    private final ModelRenderer LeftLeg;

    public buddha() {
        textureWidth = 256;
        textureHeight = 256;

        Body = new ModelRenderer(this);
        Body.setRotationPoint(1.0F, 24.0F, 0.0F);
        Body.cubeList.add(new ModelBox(Body, 0, 112, -21.0F, -91.0F, -9.0F, 40, 24, 24, 0.0F));
        Body.cubeList.add(new ModelBox(Body, 140, 80, -8.0F, -96.0F, -3.0F, 14, 5, 5, 0.0F));
        Body.cubeList.add(new ModelBox(Body, 0, 50, -21.0F, -67.0F, -15.0F, 40, 32, 30, 0.0F));
        Body.cubeList.add(new ModelBox(Body, 0, 0, -23.0F, -40.0F, -17.0F, 44, 15, 35, 0.0F));
        Body.offsetY += 1;

        chest = new ModelRenderer(this);
        chest.setRotationPoint(-1.0F, -67.0F, -15.0F);
        Body.addChild(chest);
        setRotationAngle(chest, -0.2443F, 0.0F, 0.0F);
        chest.cubeList.add(new ModelBox(chest, 110, 50, -20.0F, -24.0F, 0.0F, 40, 24, 6, 0.0F));

        neck = new ModelRenderer(this);
        neck.setRotationPoint(-1.0F, -91.0F, 13.0F);
        Body.addChild(neck);
        setRotationAngle(neck, 0.3927F, 0.0F, 0.0F);
        neck.cubeList.add(new ModelBox(neck, 149, 182, -7.0F, -10.3827F, -9.9239F, 14, 10, 5, 0.0F));

        RightArm = new ModelRenderer(this);
        RightArm.setRotationPoint(-21.0F, -91.0F, 2.0F);
        Body.addChild(RightArm);
        setRotationAngle(RightArm, 0.0F, 0.0F, -0.7854F);
        RightArm.cubeList.add(new ModelBox(RightArm, 123, 0, -28.0F, 0.0F, -7.0F, 28, 14, 14, 0.0F));

        subarm = new ModelRenderer(this);
        subarm.setRotationPoint(-28.0F, 0.0F, 0.0F);
        RightArm.addChild(subarm);
        setRotationAngle(subarm, 0.0F, 0.0F, -0.5236F);
        subarm.cubeList.add(new ModelBox(subarm, 122, 94, -27.0F, 0.0F, -9.0F, 27, 17, 18, 0.0F));

        hand = new ModelRenderer(this);
        hand.setRotationPoint(-27.0F, 4.0F, 0.0F);
        subarm.addChild(hand);
        setRotationAngle(hand, 0.0F, 0.0F, -0.3927F);
        hand.cubeList.add(new ModelBox(hand, 0, 160, -14.0F, 0.0F, -10.0F, 14, 8, 19, 0.0F));

        thumb = new ModelRenderer(this);
        thumb.setRotationPoint(-1.0F, 5.0F, -10.0F);
        hand.addChild(thumb);
        setRotationAngle(thumb, 0.0F, 0.8727F, -0.4363F);
        thumb.cubeList.add(new ModelBox(thumb, 0, 50, -4.0F, -2.0F, -8.0F, 4, 4, 9, 0.0F));

        fingers = new ModelRenderer(this);
        fingers.setRotationPoint(-14.0F, 3.0F, -0.5F);
        hand.addChild(fingers);
        setRotationAngle(fingers, 0.0F, 0.0F, -0.7854F);
        fingers.cubeList.add(new ModelBox(fingers, 0, 23, -9.0F, 0.0F, -9.5F, 9, 4, 4, 0.0F));
        fingers.cubeList.add(new ModelBox(fingers, 0, 23, -9.0F, 0.0F, -4.5F, 9, 4, 4, 0.0F));
        fingers.cubeList.add(new ModelBox(fingers, 0, 23, -9.0F, 0.0F, 0.5F, 9, 4, 4, 0.0F));
        fingers.cubeList.add(new ModelBox(fingers, 0, 23, -9.0F, 0.0F, 5.5F, 9, 4, 4, 0.0F));

        LeftArm = new ModelRenderer(this);
        LeftArm.setRotationPoint(19.0F, -91.0F, 2.0F);
        Body.addChild(LeftArm);
        setRotationAngle(LeftArm, 0.0F, 0.0F, 0.7854F);
        LeftArm.cubeList.add(new ModelBox(LeftArm, 123, 0, 0.0F, 0.0F, -7.0F, 28, 14, 14, 0.0F));

        subarm2 = new ModelRenderer(this);
        subarm2.setRotationPoint(28.0F, 0.0F, 0.0F);
        LeftArm.addChild(subarm2);
        setRotationAngle(subarm2, 0.0F, 0.0F, 0.5236F);
        subarm2.cubeList.add(new ModelBox(subarm2, 122, 94, 0.0F, 0.0F, -9.0F, 27, 17, 18, 0.0F));

        hand2 = new ModelRenderer(this);
        hand2.setRotationPoint(27.0F, 4.0F, 0.0F);
        subarm2.addChild(hand2);
        setRotationAngle(hand2, 0.0F, 0.0F, 0.3927F);
        hand2.cubeList.add(new ModelBox(hand2, 0, 160, 0.0F, 0.0F, -10.0F, 14, 8, 19, 0.0F));

        thumb2 = new ModelRenderer(this);
        thumb2.setRotationPoint(1.0F, 5.0F, -10.0F);
        hand2.addChild(thumb2);
        setRotationAngle(thumb2, 0.4363F, -0.8727F, 0.0F);
        thumb2.cubeList.add(new ModelBox(thumb2, 0, 50, 0.0F, -2.0F, -8.0F, 4, 4, 9, 0.0F));

        fingers2 = new ModelRenderer(this);
        fingers2.setRotationPoint(14.0F, 3.0F, -0.5F);
        hand2.addChild(fingers2);
        setRotationAngle(fingers2, 0.0F, 0.0F, 0.7854F);
        fingers2.cubeList.add(new ModelBox(fingers2, 0, 23, 0.0F, 0.0F, -9.5F, 9, 4, 4, 0.0F));
        fingers2.cubeList.add(new ModelBox(fingers2, 0, 23, 0.0F, 0.0F, -4.5F, 9, 4, 4, 0.0F));
        fingers2.cubeList.add(new ModelBox(fingers2, 0, 23, 0.0F, 0.0F, 0.5F, 9, 4, 4, 0.0F));
        fingers2.cubeList.add(new ModelBox(fingers2, 0, 23, 0.0F, 0.0F, 5.5F, 9, 4, 4, 0.0F));

        Head = new ModelRenderer(this);
        Head.setRotationPoint(0.0F, -72.0F, 1.0F);
        setRotationAngle(Head, 0.2618F, 0.0F, 0.0F);
        Head.cubeList.add(new ModelBox(Head, 114, 165, -5.0F, -10.0F, -9.0F, 10, 12, 10, 0.0F));
        Head.cubeList.add(new ModelBox(Head, 98, 64, -0.5F, -8.0F, -9.05F, 1, 1, 0, 0.0F));
        Head.cubeList.add(new ModelBox(Head, 154, 165, -6.0F, -10.0F, -6.5F, 12, 10, 7, 0.0F));
        Head.offsetY += 1;
        nose = new ModelRenderer(this);
        nose.setRotationPoint(0.0F, -5.0F, -9.0F);
        Head.addChild(nose);
        setRotationAngle(nose, -0.3927F, 0.0F, 0.0F);
        nose.cubeList.add(new ModelBox(nose, 47, 71, -1.0F, -1.0F, -0.5F, 2, 4, 2, 0.0F));

        afro = new ModelRenderer(this);
        afro.setRotationPoint(0.0F, -9.0F, 5.0F);
        Head.addChild(afro);
        setRotationAngle(afro, 0.7854F, 0.0F, 0.0F);
        afro.cubeList.add(new ModelBox(afro, 128, 129, -9.0F, -13.0F, -10.0F, 18, 18, 18, 0.0F));

        RightLeg = new ModelRenderer(this);
        RightLeg.setRotationPoint(-12.0F, -11.0F, 3.0F);
        setRotationAngle(RightLeg, 0.0F, 0.3927F, 0.0F);
        RightLeg.cubeList.add(new ModelBox(RightLeg, 66, 160, -6.0F, 0.0F, -6.0F, 12, 18, 12, 0.0F));
        RightLeg.cubeList.add(new ModelBox(RightLeg, 0, 0, -4.0F, 16.0F, -5.9F, 8, 15, 8, 0.0F));
        RightLeg.cubeList.add(new ModelBox(RightLeg, 158, 28, -5.0F, 31.0F, -15.0F, 10, 4, 18, 0.0F));

        LeftLeg = new ModelRenderer(this);
        LeftLeg.setRotationPoint(12.0F, -11.0F, 3.0F);
        setRotationAngle(LeftLeg, 0.0F, -0.3927F, 0.0F);
        LeftLeg.cubeList.add(new ModelBox(LeftLeg, 66, 160, -6.0F, 0.0F, -6.0F, 12, 18, 12, 0.0F));
        LeftLeg.cubeList.add(new ModelBox(LeftLeg, 0, 0, -4.0F, 16.0F, -5.9F, 8, 15, 8, 0.0F));
        LeftLeg.cubeList.add(new ModelBox(LeftLeg, 158, 28, -5.0F, 31.0F, -15.0F, 10, 4, 18, 0.0F));
        LeftLeg.offsetY += 0.9;
        RightLeg.offsetY += 0.9;
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        Body.render(f5);
        Head.render(f5);
        RightLeg.render(f5);
        LeftLeg.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    public boolean isMoving() {
        return Minecraft.getMinecraft().gameSettings.keyBindForward.isPressed() ||
                Minecraft.getMinecraft().gameSettings.keyBindBack.isPressed() ||
                Minecraft.getMinecraft().gameSettings.keyBindLeft.isPressed() ||
                Minecraft.getMinecraft().gameSettings.keyBindRight.isPressed() ||
                Minecraft.getMinecraft().thePlayer.movementInput.moveForward != 0.0f ||
                Minecraft.getMinecraft().thePlayer.movementInput.moveStrafe != 0.0f;

    }
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw,
                                  float headPitch, float scaleFactor, Entity ent)
    {
        EntityLivingBase entity = ((EntityLivingBase) ent);


        this.Head.rotateAngleY = headYaw / (270F / (float) Math.PI);
        this.Head.rotateAngleX = headPitch / (360F / (float) Math.PI);
        if (ent.onGround && isMoving())
        {
            LeftLeg.rotateAngleX = MathHelper.cos(limbSwing * 0.6F) * 0.8F * limbSwingAmount;
            RightLeg.rotateAngleX = MathHelper.cos(limbSwing * 0.6F + (float) Math.PI) * 0.8F * limbSwingAmount;

            LeftArm.rotateAngleX = (float) degToRad(65);
            RightArm.rotateAngleX = (float) degToRad(65);

            LeftArm.rotateAngleZ = (float) degToRad(57);
            RightArm.rotateAngleZ = (float) degToRad(-57);


            RightArm.rotateAngleY = MathHelper.cos(limbSwing * 0.6662F) * 0.4F * limbSwingAmount;
            LeftArm.rotateAngleY = -MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.4F * limbSwingAmount;
        }

        if (entity.isSwingInProgress)
        {
            RightArm.rotateAngleY = MathHelper.sin(entity.swingProgress * 3.0F + (float) Math.PI) * 1.2F;
            RightArm.rotateAngleZ = -MathHelper.cos(entity.swingProgress * 4.0F + (float) Math.PI) * 0.2F;
        }

        if (ent.getDistance(ent.prevPosX, ent.prevPosY, ent.prevPosZ) <= 0.1F && !entity.isSwingInProgress && ent.onGround)
        {
            RightArm.rotateAngleX = 1.134F;
            RightArm.rotateAngleY = -0.261F;
            RightArm.rotateAngleZ = -0.994F;
        }
    }

    protected float degToRad(double degrees)
    {
        return (float) (degrees * (double) Math.PI / 180);
    }

    public ModelRenderer getHandRenderer() {
        return RightArm;
    }
}