package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;


import net.minecraft.client.model.*;
import net.minecraft.entity.*;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.ModelZoanMorph;

public class ModelMammoth extends ModelZoanMorph {
    public ModelRenderer LeftBackThigh;
    public ModelRenderer RightBackThigh;
    public ModelRenderer Waist;
    public ModelRenderer LeftBackCalf;
    public ModelRenderer LeftBackFoot;
    public ModelRenderer RightBackCalf;
    public ModelRenderer RightBackFoot;
    public ModelRenderer Tail;
    public ModelRenderer Chest;
    public ModelRenderer FurBackRightWaist;
    public ModelRenderer FurBackLeftWaist;
    public ModelRenderer Neck;
    public ModelRenderer RightFrontThigh1;
    public ModelRenderer LeftFrontThigh1;
    public ModelRenderer FurFrontLeftChest;
    public ModelRenderer FurFrontRightChest;
    public ModelRenderer FurJointChest;
    public ModelRenderer LowerHead;
    public ModelRenderer FurFrontRightNeck;
    public ModelRenderer FurFrontLeftNeck;
    public ModelRenderer FurJointNeck;
    public ModelRenderer Mouth;
    public ModelRenderer LeftEar;
    public ModelRenderer RightEar;
    public ModelRenderer Trunk1;
    public ModelRenderer UpperHead;
    public ModelRenderer LeftTusk1;
    public ModelRenderer RightTusk1;
    public ModelRenderer Trunk2;
    public ModelRenderer Trunk3;
    public ModelRenderer Trunk4;
    public ModelRenderer Trunk5;
    public ModelRenderer Trunk6;
    public ModelRenderer Trunk7;
    public ModelRenderer LeftTusk2;
    public ModelRenderer LeftTusk3;
    public ModelRenderer LeftTusk4;
    public ModelRenderer LeftTusk5;
    public ModelRenderer RightTusk2;
    public ModelRenderer RightTusk3;
    public ModelRenderer RightTusk4;
    public ModelRenderer RightTusk5;
    public ModelRenderer FurFrontMiddleNeck;
    public ModelRenderer RightFrontThigh2;
    public ModelRenderer RightFrontCalf;
    public ModelRenderer RightFrontFoot;
    public ModelRenderer LeftFrontThigh2;
    public ModelRenderer LeftFrontCalf;
    public ModelRenderer LeftFrontFoot;
    public ModelRenderer FurFrontMiddleChest;
    public ModelRenderer[] lefttuskparts;
    public ModelRenderer[] righttuskparts;
    public ModelRenderer[] trunkParts;


    public ModelMammoth() {
      
        textureWidth = 128;
        textureHeight = 128;
        (this.RightBackFoot = new ModelRenderer(this, 0, 59)).setRotationPoint(0.0f, 8.0f, 2.0f);
        this.RightBackFoot.addBox(-2.0f, 0.0f, -2.0f, 4, 5, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightBackFoot, -0.19198622f, -0.0f, 0.0f);
        (this.RightFrontCalf = new ModelRenderer(this, 0, 34)).setRotationPoint(0.0f, 5.7f, 3.7f);
        this.RightFrontCalf.addBox(-2.0f, 0.0f, -2.8f, 4, 7, 5, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightFrontCalf, -0.33161256f, -0.0f, 0.0f);
        (this.Chest = new ModelRenderer(this, 28, 1)).setRotationPoint(0.0f, -1.0f, -7.0f);
        this.Chest.addBox(-9.0f, -9.5f, -17.0f, 18, 19, 17, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Chest, 0.2268928f, 0.0f, 0.0f);
        (this.Mouth = new ModelRenderer(this, 44, 115)).setRotationPoint(0.0f, 4.0f, -2.25f);
        this.Mouth.addBox(-3.5f, 0.0f, -7.0f, 7, 2, 7, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Mouth, 0.33457962f, -0.0f, 0.0f);
        (this.Trunk6 = new ModelRenderer(this, 102, 2)).setRotationPoint(0.0f, 0.0f, -4.75f);
        this.Trunk6.addBox(-2.0f, -2.0f, -6.0f, 4, 4, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk6, 0.2617994f, 0.0f, 0.0f);
        (this.FurFrontRightChest = new ModelRenderer(this, 86, 73)).setRotationPoint(6.6f, 8.7f, -9.0f);
        this.FurFrontRightChest.addBox(0.0f, 0.0f, -8.0f, 0, 9, 17, 0.0f);
        this.setRotateAngle((ModelRenderer)this.FurFrontRightChest, 0.0f, 0.08726646f, 0.0f);
        (this.LeftTusk2 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 7.0f, 0.0f);
        this.LeftTusk2.addBox(-1.0f, 0.0f, -1.0f, 2, 6, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftTusk2, -0.2617994f, 0.0f, 0.017453292f);
        (this.LeftTusk5 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 4.5f, 0.0f);
        this.LeftTusk5.addBox(-1.0f, 0.0f, -1.0f, 2, 4, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftTusk5, -0.5235988f, 0.08726646f, 0.017453292f);
        (this.RightTusk1 = new ModelRenderer(this, 79, 39)).setRotationPoint(-3.5f, 2.0f, -5.0f);
        this.RightTusk1.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightTusk1, -0.17453292f, 0.0f, 0.17453292f);
        (this.LeftFrontFoot = new ModelRenderer(this, 0, 48)).setRotationPoint(0.0f, 7.0f, -2.8f);
        this.LeftFrontFoot.addBox(-2.0f, 0.0f, 0.0f, 4, 4, 5, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftFrontFoot, 0.12217305f, -0.0f, 0.0f);
        (this.LeftFrontCalf = new ModelRenderer(this, 0, 34)).setRotationPoint(0.0f, 5.7f, 3.7f);
        this.LeftFrontCalf.addBox(-2.0f, 0.0f, -2.8f, 4, 7, 5, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftFrontCalf, -0.33161256f, -0.0f, 0.0f);
        (this.RightEar = new ModelRenderer(this, 114, 39)).setRotationPoint(-4.5f, -4.0f, -2.0f);
        this.RightEar.addBox(-1.0f, 0.0f, 0.0f, 1, 4, 3, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightEar, 0.13508849f, -0.61086524f, 0.0f);
        (this.Trunk4 = new ModelRenderer(this, 100, 53)).setRotationPoint(0.0f, 0.0f, -5.25f);
        this.Trunk4.addBox(-3.0f, -3.0f, -6.0f, 6, 6, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk4, 0.17453292f, 0.0f, 0.0f);
        (this.LeftBackThigh = new ModelRenderer(this, 0, 87)).setRotationPoint(6.0f, 5.3f, 12.0f);
        this.LeftBackThigh.addBox(-3.0f, -2.5f, -2.7f, 6, 10, 8, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftBackThigh, -0.13613568f, -0.0f, 0.0f);
        (this.Neck = new ModelRenderer(this, 92, 106)).setRotationPoint(0.0f, -2.5f, -15.2f);
        this.Neck.addBox(-6.0f, -7.0f, -4.0f, 12, 14, 4, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Neck, 0.045553092f, -0.0f, 0.0f);
        (this.LeftTusk3 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 5.0f, 0.0f);
        this.LeftTusk3.addBox(-1.0f, 0.0f, -1.0f, 2, 5, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftTusk3, -0.43633232f, 0.08726646f, 0.017453292f);
        (this.UpperHead = new ModelRenderer(this, 0, 106)).setRotationPoint(0.0f, -4.0f, -1.0f);
        this.UpperHead.addBox(-4.5f, -4.5f, -6.5f, 9, 5, 12, 0.0f);
        this.setRotateAngle((ModelRenderer)this.UpperHead, -0.08726646f, 0.0f, 0.0f);
        (this.RightBackCalf = new ModelRenderer(this, 0, 71)).setRotationPoint(0.0f, 6.6f, -2.0f);
        this.RightBackCalf.addBox(-2.5f, 0.0f, 0.0f, 5, 9, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightBackCalf, 0.3281219f, -0.0f, 0.0f);
        (this.RightTusk4 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 4.5f, 0.0f);
        this.RightTusk4.addBox(-1.0f, 0.0f, -1.0f, 2, 5, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightTusk4, -0.34906584f, -0.08726646f, -0.017453292f);
        (this.FurFrontLeftNeck = new ModelRenderer(this, 86, 73)).setRotationPoint(-6.0f, 6.3f, 4.0f);
        this.FurFrontLeftNeck.addBox(0.0f, 0.0f, -8.0f, 0, 9, 17, 0.0f);
        (this.FurFrontMiddleChest = new ModelRenderer(this, 91, 78)).setRotationPoint(0.0f, 0.0f, 0.0f);
        this.FurFrontMiddleChest.addBox(0.0f, 0.0f, -6.0f, 0, 9, 12, 0.0f);
        this.setRotateAngle((ModelRenderer)this.FurFrontMiddleChest, 3.1415927f, 1.5707964f, 3.1415927f);
        (this.FurJointChest = new ModelRenderer(this, 0, 0)).setRotationPoint(0.0f, 8.7f, -17.0f);
        this.FurJointChest.addBox(0.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f);
        (this.LeftFrontThigh2 = new ModelRenderer(this, 0, 19)).setRotationPoint(1.0f, 9.0f, 0.5f);
        this.LeftFrontThigh2.addBox(-2.5f, 0.0f, 0.0f, 5, 7, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftFrontThigh2, 0.15707964f, -0.0f, 0.0f);
        (this.Tail = new ModelRenderer(this, 23, 18)).setRotationPoint(-0.5f, -7.0f, 5.0f);
        this.Tail.addBox(0.0f, 0.0f, 0.0f, 1, 9, 1, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Tail, 0.4098033f, 0.0f, 0.0f);
        (this.RightFrontFoot = new ModelRenderer(this, 0, 48)).setRotationPoint(0.0f, 7.0f, -2.8f);
        this.RightFrontFoot.addBox(-2.0f, 0.0f, 0.0f, 4, 4, 5, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightFrontFoot, 0.12217305f, -0.0f, 0.0f);
        (this.FurBackLeftWaist = new ModelRenderer(this, 86, 73)).setRotationPoint(-7.9f, 8.0f, -5.5f);
        this.FurBackLeftWaist.addBox(0.0f, 0.0f, -8.0f, 0, 9, 17, 0.0f);
        this.setRotateAngle((ModelRenderer)this.FurBackLeftWaist, 0.29670596f, 0.0f, 0.0f);
        (this.LeftFrontThigh1 = new ModelRenderer(this, 0, 0)).setRotationPoint(7.0f, -1.1f, -16.0f);
        this.LeftFrontThigh1.addBox(-2.0f, 0.0f, 0.0f, 6, 10, 7, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftFrontThigh1, 0.13962634f, -0.0f, 0.0f);
        (this.RightTusk5 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 4.5f, 0.0f);
        this.RightTusk5.addBox(-1.0f, 0.0f, -1.0f, 2, 4, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightTusk5, -0.5235988f, -0.08726646f, -0.017453292f);
        (this.Trunk3 = new ModelRenderer(this, 100, 14)).setRotationPoint(0.0f, 0.0f, -3.5f);
        this.Trunk3.addBox(-3.5f, -3.5f, -7.0f, 7, 7, 7, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk3, 0.2617994f, 0.0f, 0.0f);
        (this.RightFrontThigh2 = new ModelRenderer(this, 0, 19)).setRotationPoint(-1.0f, 9.0f, 0.5f);
        this.RightFrontThigh2.addBox(-2.5f, 0.0f, 0.0f, 5, 7, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightFrontThigh2, 0.15707964f, -0.0f, 0.0f);
        (this.FurJointNeck = new ModelRenderer(this, 0, 0)).setRotationPoint(0.0f, 6.3f, -3.9f);
        this.FurJointNeck.addBox(0.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f);
        (this.LeftBackCalf = new ModelRenderer(this, 0, 71)).setRotationPoint(0.0f, 6.6f, -2.0f);
        this.LeftBackCalf.addBox(-2.5f, 0.0f, 0.0f, 5, 9, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftBackCalf, 0.3281219f, -0.0f, 0.0f);
        (this.Trunk5 = new ModelRenderer(this, 91, 40)).setRotationPoint(0.0f, 0.0f, -4.75f);
        this.Trunk5.addBox(-2.5f, -2.5f, -6.0f, 5, 5, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk5, 0.17453292f, 0.0f, 0.0f);
        (this.FurBackRightWaist = new ModelRenderer(this, 86, 73)).setRotationPoint(7.9f, 8.0f, -5.5f);
        this.FurBackRightWaist.addBox(0.0f, 0.0f, -8.0f, 0, 9, 17, 0.0f);
        this.setRotateAngle((ModelRenderer)this.FurBackRightWaist, 0.27314404f, 0.0f, 0.0f);
        (this.LeftBackFoot = new ModelRenderer(this, 0, 59)).setRotationPoint(0.0f, 8.0f, 2.0f);
        this.LeftBackFoot.addBox(-2.0f, 0.0f, -2.0f, 4, 5, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftBackFoot, -0.19198622f, -0.0f, 0.0f);
        (this.Trunk2 = new ModelRenderer(this, 43, 94)).setRotationPoint(0.0f, -1.25f, -3.5f);
        this.Trunk2.addBox(-4.0f, -4.5f, -5.0f, 8, 9, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk2, 0.5235988f, 0.0f, 0.0f);
        (this.LeftEar = new ModelRenderer(this, 114, 39)).setRotationPoint(4.5f, -4.0f, -2.0f);
        this.LeftEar.addBox(0.0f, 0.0f, 0.0f, 1, 4, 3, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftEar, 0.13508849f, 0.61086524f, 0.0f);
        (this.RightBackThigh = new ModelRenderer(this, 0, 87)).setRotationPoint(-6.0f, 5.3f, 12.0f);
        this.RightBackThigh.addBox(-3.0f, -2.5f, -2.7f, 6, 10, 8, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightBackThigh, -0.13613568f, -0.0f, 0.0f);
        (this.LowerHead = new ModelRenderer(this, 29, 73)).setRotationPoint(0.0f, -2.5f, -4.0f);
        this.LowerHead.addBox(-5.5f, -6.0f, -8.0f, 11, 12, 8, 0.0f);
        (this.RightFrontThigh1 = new ModelRenderer(this, 0, 0)).setRotationPoint(-7.0f, -1.1f, -16.0f);
        this.RightFrontThigh1.addBox(-4.0f, 0.0f, 0.0f, 6, 10, 7, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightFrontThigh1, 0.13962634f, -0.0f, 0.0f);
        (this.Trunk1 = new ModelRenderer(this, 88, 73)).setRotationPoint(0.0f, 0.0f, -5.0f);
        this.Trunk1.addBox(-4.5f, -6.0f, -5.75f, 9, 11, 6, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk1, 0.5235988f, 0.0f, 0.0f);
        (this.LeftTusk4 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 4.5f, 0.0f);
        this.LeftTusk4.addBox(-1.0f, 0.0f, -1.0f, 2, 5, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftTusk4, -0.34906584f, 0.08726646f, 0.017453292f);
        (this.Waist = new ModelRenderer(this, 22, 38)).setRotationPoint(0.0f, 5.3f, 12.0f);
        this.Waist.addBox(-8.0f, -9.0f, -10.5f, 16, 18, 16, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Waist, -0.31415927f, 0.0f, 0.0f);
        (this.RightTusk3 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 5.0f, 0.0f);
        this.RightTusk3.addBox(-1.0f, 0.0f, -1.0f, 2, 5, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightTusk3, -0.43633232f, -0.08726646f, -0.017453292f);
        (this.FurFrontLeftChest = new ModelRenderer(this, 86, 73)).setRotationPoint(-6.6f, 8.7f, -9.0f);
        this.FurFrontLeftChest.addBox(0.0f, 0.0f, -8.0f, 0, 9, 17, 0.0f);
        this.setRotateAngle((ModelRenderer)this.FurFrontLeftChest, 0.0f, -0.08726646f, 0.0f);
        (this.Trunk7 = new ModelRenderer(this, 107, 30)).setRotationPoint(0.0f, 0.0f, -4.75f);
        this.Trunk7.addBox(-1.5f, -1.5f, -5.0f, 3, 3, 5, 0.0f);
        this.setRotateAngle((ModelRenderer)this.Trunk7, 0.17453292f, 0.0f, 0.0f);
        (this.RightTusk2 = new ModelRenderer(this, 79, 39)).setRotationPoint(0.0f, 7.0f, 0.0f);
        this.RightTusk2.addBox(-1.0f, 0.0f, -1.0f, 2, 6, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.RightTusk2, -0.2617994f, 0.0f, -0.017453292f);
        (this.LeftTusk1 = new ModelRenderer(this, 79, 39)).setRotationPoint(3.5f, 2.0f, -5.0f);
        this.LeftTusk1.addBox(-1.0f, 0.0f, -1.0f, 2, 8, 2, 0.0f);
        this.setRotateAngle((ModelRenderer)this.LeftTusk1, -0.17453292f, 0.0f, -0.17453292f);
        (this.FurFrontMiddleNeck = new ModelRenderer(this, 91, 78)).setRotationPoint(0.0f, 0.0f, 0.0f);
        this.FurFrontMiddleNeck.addBox(0.0f, 0.0f, -6.0f, 0, 9, 12, 0.0f);
        this.setRotateAngle((ModelRenderer)this.FurFrontMiddleNeck, 3.1415927f, 1.5707964f, 3.1415927f);
        (this.FurFrontRightNeck = new ModelRenderer(this, 86, 73)).setRotationPoint(6.0f, 6.3f, 4.0f);
        this.FurFrontRightNeck.addBox(0.0f, 0.0f, -8.0f, 0, 9, 17, 0.0f);
        this.RightBackCalf.addChild((ModelRenderer)this.RightBackFoot);
        this.RightFrontThigh2.addChild((ModelRenderer)this.RightFrontCalf);
        this.Waist.addChild((ModelRenderer)this.Chest);
        this.LowerHead.addChild((ModelRenderer)this.Mouth);
        this.Trunk5.addChild((ModelRenderer)this.Trunk6);
        this.Chest.addChild((ModelRenderer)this.FurFrontRightChest);
        this.LeftTusk1.addChild((ModelRenderer)this.LeftTusk2);
        this.LeftTusk4.addChild((ModelRenderer)this.LeftTusk5);
        this.LowerHead.addChild((ModelRenderer)this.RightTusk1);
        this.LeftFrontCalf.addChild((ModelRenderer)this.LeftFrontFoot);
        this.LeftFrontThigh2.addChild((ModelRenderer)this.LeftFrontCalf);
        this.LowerHead.addChild((ModelRenderer)this.RightEar);
        this.Trunk3.addChild((ModelRenderer)this.Trunk4);
        this.Chest.addChild((ModelRenderer)this.Neck);
        this.LeftTusk2.addChild((ModelRenderer)this.LeftTusk3);
        this.LowerHead.addChild((ModelRenderer)this.UpperHead);
        this.RightBackThigh.addChild((ModelRenderer)this.RightBackCalf);
        this.RightTusk3.addChild((ModelRenderer)this.RightTusk4);
        this.Neck.addChild((ModelRenderer)this.FurFrontLeftNeck);
        this.FurJointChest.addChild((ModelRenderer)this.FurFrontMiddleChest);
        this.Chest.addChild((ModelRenderer)this.FurJointChest);
        this.LeftFrontThigh1.addChild((ModelRenderer)this.LeftFrontThigh2);
        this.Waist.addChild((ModelRenderer)this.Tail);
        this.RightFrontCalf.addChild((ModelRenderer)this.RightFrontFoot);
        this.Waist.addChild((ModelRenderer)this.FurBackLeftWaist);
        this.Chest.addChild((ModelRenderer)this.LeftFrontThigh1);
        this.RightTusk4.addChild((ModelRenderer)this.RightTusk5);
        this.Trunk2.addChild((ModelRenderer)this.Trunk3);
        this.RightFrontThigh1.addChild((ModelRenderer)this.RightFrontThigh2);
        this.Neck.addChild((ModelRenderer)this.FurJointNeck);
        this.LeftBackThigh.addChild((ModelRenderer)this.LeftBackCalf);
        this.Trunk4.addChild((ModelRenderer)this.Trunk5);
        this.Waist.addChild((ModelRenderer)this.FurBackRightWaist);
        this.LeftBackCalf.addChild((ModelRenderer)this.LeftBackFoot);
        this.Trunk1.addChild((ModelRenderer)this.Trunk2);
        this.LowerHead.addChild((ModelRenderer)this.LeftEar);
        this.Neck.addChild((ModelRenderer)this.LowerHead);
        this.Chest.addChild((ModelRenderer)this.RightFrontThigh1);
        this.LowerHead.addChild((ModelRenderer)this.Trunk1);
        this.LeftTusk3.addChild((ModelRenderer)this.LeftTusk4);
        this.RightTusk2.addChild((ModelRenderer)this.RightTusk3);
        this.Chest.addChild((ModelRenderer)this.FurFrontLeftChest);
        this.Trunk6.addChild((ModelRenderer)this.Trunk7);
        this.RightTusk1.addChild((ModelRenderer)this.RightTusk2);
        this.LowerHead.addChild((ModelRenderer)this.LeftTusk1);
        this.FurJointNeck.addChild((ModelRenderer)this.FurFrontMiddleNeck);
        this.Neck.addChild((ModelRenderer)this.FurFrontRightNeck);
        this.trunkParts = new ModelRenderer[] { this.Trunk7, this.Trunk6, this.Trunk5, this.Trunk4, this.Trunk3, this.Trunk2, this.Trunk1 };
        this.lefttuskparts = new ModelRenderer[] { this.LeftTusk5, this.LeftTusk4, this.LeftTusk3, this.LeftTusk2, this.LeftTusk1 };
        this.righttuskparts = new ModelRenderer[] { this.RightTusk5, this.RightTusk4, this.RightTusk3, this.RightTusk2, this.RightTusk1 };

    }

    public void render(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.render(entity, f, f1, f2, f3, f4, f5);
        this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        this.LeftBackThigh.render(f5);
        this.RightBackThigh.render(f5);
        this.Waist.render(f5);
    }

    private void setRotateAngle(final ModelRenderer model, final float x, final float y, final float z) {
        model.rotateAngleX = x;
        model.rotateAngleY = y;
        model.rotateAngleZ = z;
    }

    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch, float scaleFactor, Entity ent)
    {

        this.UpperHead.rotateAngleY = headYaw / (270F / (float) Math.PI);
        this.UpperHead.rotateAngleX = headPitch / (360F / (float) Math.PI);
        this.LowerHead.rotateAngleY = headYaw / (270F / (float) Math.PI);
        this.LowerHead.rotateAngleX = headPitch / (360F / (float) Math.PI);

        this.LeftBackThigh.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 0.3F * limbSwingAmount;
        this.RightBackThigh.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.3F * limbSwingAmount;

        this.LeftFrontThigh1.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 0.4F * limbSwingAmount;
        this.LeftFrontThigh2.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 0.4F * limbSwingAmount;

        this.RightFrontThigh1.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.4F * limbSwingAmount;
        this.RightFrontThigh2.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 0.4F * limbSwingAmount;

    }



    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}
