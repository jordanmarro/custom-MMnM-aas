// Made with Blockbench 3.6.6
// Exported for Minecraft version 1.15
// Paste this class into your mod and generate all required imports

package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.api.WyRenderHelper;


public class mochi_wheel extends ModelZoanMorph {
    private final ModelRenderer mochi_wheel;
    private final ModelRenderer half1;
    private final ModelRenderer quarter1;
    private final ModelRenderer side1;
    private final ModelRenderer side2;
    private final ModelRenderer side3;
    private final ModelRenderer side4;
    private final ModelRenderer quarter2;
    private final ModelRenderer side5;
    private final ModelRenderer side6;
    private final ModelRenderer side7;
    private final ModelRenderer side8;
    private final ModelRenderer half2;
    private final ModelRenderer quarter3;
    private final ModelRenderer side9;
    private final ModelRenderer side10;
    private final ModelRenderer side11;
    private final ModelRenderer side12;
    private final ModelRenderer quarter4;
    private final ModelRenderer side13;
    private final ModelRenderer side14;
    private final ModelRenderer side15;
    private final ModelRenderer side16;

    public mochi_wheel() {
        textureWidth = 256;
        textureHeight = 256;

        mochi_wheel = new ModelRenderer(this);
        mochi_wheel.setRotationPoint(-10.0F, 1.5F, 0.5F);
        mochi_wheel.offsetY += 1.5;

        half1 = new ModelRenderer(this);
        half1.setRotationPoint(0.0F, 22.5F, 3.5F);
        mochi_wheel.addChild(half1);


        quarter1 = new ModelRenderer(this);
        quarter1.setRotationPoint(0.0F, 0.0F, 0.0F);
        half1.addChild(quarter1);


        side1 = new ModelRenderer(this);
        side1.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter1.addChild(side1);
        side1.setTextureOffset(162, 63).addBox(-26.0F, -12.0F, 0.0F, 24, 12, 9, 0.0F);

        side2 = new ModelRenderer(this);
        side2.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter1.addChild(side2);
        setRotationAngle(side2, -0.3927F, 0.0F, 0.0F);
        side2.setTextureOffset(0, 156).addBox(-26.0F, -12.0F, -9.0F, 24, 12, 9, 0.0F);

        side3 = new ModelRenderer(this);
        side3.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter1.addChild(side3);
        setRotationAngle(side3, -0.7854F, 0.0F, 0.0F);
        side3.setTextureOffset(90, 144).addBox(-26.0F, -8.5558F, -17.3149F, 24, 12, 9, 0.0F);

        side4 = new ModelRenderer(this);
        side4.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter1.addChild(side4);
        setRotationAngle(side4, -1.1781F, 0.0F, 0.0F);
        side4.setTextureOffset(0, 135).addBox(-26.0F, -2.1919F, -23.6789F, 24, 12, 9, 0.0F);

        quarter2 = new ModelRenderer(this);
        quarter2.setRotationPoint(0.0F, 0.0F, 0.0F);
        half1.addChild(quarter2);
        setRotationAngle(quarter2, -1.5708F, 0.0F, 0.0F);


        side5 = new ModelRenderer(this);
        side5.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter2.addChild(side5);
        side5.setTextureOffset(90, 123).addBox(-26.0F, 14.123F, -19.123F, 24, 12, 9, 0.0F);

        side6 = new ModelRenderer(this);
        side6.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter2.addChild(side6);
        setRotationAngle(side6, -0.3927F, 0.0F, 0.0F);
        side6.setTextureOffset(0, 114).addBox(-26.0F, 19.4526F, -16.6705F, 24, 12, 9, 0.0F);

        side7 = new ModelRenderer(this);
        side7.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter2.addChild(side7);
        setRotationAngle(side7, -0.7854F, 0.0F, 0.0F);
        side7.setTextureOffset(90, 102).addBox(-26.0F, 23.4379F, -12.3652F, 24, 12, 9, 0.0F);

        side8 = new ModelRenderer(this);
        side8.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter2.addChild(side8);
        setRotationAngle(side8, -1.1781F, 0.0F, 0.0F);
        side8.setTextureOffset(0, 93).addBox(-26.0F, 25.4723F, -6.8624F, 24, 12, 9, 0.0F);

        half2 = new ModelRenderer(this);
        half2.setRotationPoint(0.0F, 22.5F, 3.5F);
        mochi_wheel.addChild(half2);
        setRotationAngle(half2, 3.1416F, 0.0F, 0.0F);


        quarter3 = new ModelRenderer(this);
        quarter3.setRotationPoint(0.0F, 0.0F, 0.0F);
        half2.addChild(quarter3);


        side9 = new ModelRenderer(this);
        side9.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter3.addChild(side9);
        side9.setTextureOffset(90, 42).addBox(-26.0F, 33.2461F, 7.0F, 24, 12, 9, 0.0F);

        side10 = new ModelRenderer(this);
        side10.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter3.addChild(side10);
        setRotationAngle(side10, -0.3927F, 0.0F, 0.0F);
        side10.setTextureOffset(90, 21).addBox(-26.0F, 27.1231F, 14.7821F, 24, 12, 9, 0.0F);

        side11 = new ModelRenderer(this);
        side11.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter3.addChild(side11);
        setRotationAngle(side11, -0.7854F, 0.0F, 0.0F);
        side11.setTextureOffset(90, 0).addBox(-26.0F, 18.4882F, 19.6286F, 24, 12, 9, 0.0F);

        side12 = new ModelRenderer(this);
        side12.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter3.addChild(side12);
        setRotationAngle(side12, -1.1781F, 0.0F, 0.0F);
        side12.setTextureOffset(81, 81).addBox(-26.0F, 8.6559F, 20.8018F, 24, 12, 9, 0.0F);

        quarter4 = new ModelRenderer(this);
        quarter4.setRotationPoint(0.0F, 0.0F, 0.0F);
        half2.addChild(quarter4);
        setRotationAngle(quarter4, -1.5708F, 0.0F, 0.0F);


        side13 = new ModelRenderer(this);
        side13.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter4.addChild(side13);
        side13.setTextureOffset(0, 63).addBox(-26.0F, 7.123F, 26.123F, 24, 12, 9, 0.0F);

        side14 = new ModelRenderer(this);
        side14.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter4.addChild(side14);
        setRotationAngle(side14, -0.3927F, 0.0F, 0.0F);
        side14.setTextureOffset(0, 42).addBox(-26.0F, -4.3295F, 22.4526F, 24, 12, 9, 0.0F);

        side15 = new ModelRenderer(this);
        side15.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter4.addChild(side15);
        setRotationAngle(side15, -0.7854F, 0.0F, 0.0F);
        side15.setTextureOffset(0, 21).addBox(-26.0F, -13.5056F, 14.6789F, 24, 12, 9, 0.0F);

        side16 = new ModelRenderer(this);
        side16.setRotationPoint(24.0F, 0.0F, -8.0F);
        quarter4.addChild(side16);
        setRotationAngle(side16, -1.1781F, 0.0F, 0.0F);
        side16.setTextureOffset(0, 0).addBox(-26.0F, -19.0084F, 3.9853F, 24, 12, 9, 0.0F);
    }

    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch, float scaleFactor, Entity ent)
    {
        mochi_wheel.rotateAngleX = MathHelper.cos(ageInTicks * 0.1F) * 0.3F;
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
    {
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        mochi_wheel.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}