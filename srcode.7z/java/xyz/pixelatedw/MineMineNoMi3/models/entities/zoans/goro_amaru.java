package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class goro_amaru  extends ModelZoanMorph {

    private final ModelRenderer body;
    private final ModelRenderer cube_r1;
    private final ModelRenderer TomoeDrums;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer tomoe1;
    private final ModelRenderer tomoe2;
    private final ModelRenderer cube_r7;
    private final ModelRenderer tomoe3;
    private final ModelRenderer cube_r8;
    private final ModelRenderer tomoe4;
    private final ModelRenderer cube_r9;
    private final ModelRenderer legs2;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer rightarm;
    private final ModelRenderer righthand;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer leftarm;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer lefthand;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer heads;
    private final ModelRenderer cube_r25;
    private final ModelRenderer mainhead_r1;
    private final ModelRenderer legs;
    private final ModelRenderer hair;
    private final ModelRenderer hair_r1;
    private final ModelRenderer hair_r2;
    private final ModelRenderer hair_r3;
    private final ModelRenderer hair_r4;
    private final ModelRenderer hair_r5;
    private final ModelRenderer hair_r6;
    private final ModelRenderer hair_r7;
    private final ModelRenderer hair_r8;
    private final ModelRenderer hair_r9;
    private final ModelRenderer hair_r10;
    private final ModelRenderer hair_r11;
    private final ModelRenderer hair_r12;
    private final ModelRenderer hair_r13;
    private final ModelRenderer hair_r14;
    private final ModelRenderer hair_r15;
    private final ModelRenderer hair_r16;
    private final ModelRenderer hair_r17;
    private final ModelRenderer hair_r18;
    private final ModelRenderer hair_r19;
    private final ModelRenderer hair_r20;
    private final ModelRenderer hair_r21;
    private final ModelRenderer hair_r22;
    private final ModelRenderer hair_r23;
    private final ModelRenderer hair_r24;
    private final ModelRenderer hair_r25;
    private final ModelRenderer hair_r26;
    private final ModelRenderer hair_r27;
    private final ModelRenderer hair_r28;
    private final ModelRenderer hair_r29;
    private final ModelRenderer hair_r30;
    private final ModelRenderer hair_r31;
    private final ModelRenderer hair_r32;
    private final ModelRenderer hair_r33;
    private final ModelRenderer hair_r34;
    private final ModelRenderer hair_r35;
    private final ModelRenderer hair_r36;
    private final ModelRenderer hair_r37;
    private final ModelRenderer hair_r38;
    private final ModelRenderer hair_r39;
    private final ModelRenderer hair_r40;
    private final ModelRenderer bone2;
    private final ModelRenderer earlobe_r1;
    private final ModelRenderer earlobe_r2;
    private final ModelRenderer earlobe_r3;
    private final ModelRenderer earlobe_r4;
    private final ModelRenderer bone;
    private final ModelRenderer earlobe_r5;
    private final ModelRenderer earlobe_r6;
    private final ModelRenderer earlobe_r7;
    private final ModelRenderer earlobe_r8;
    private final ModelRenderer dragonthings;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer bone7;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer bottomjaw;
    private final ModelRenderer teeth5_r1;
    private final ModelRenderer topjaw;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r36;
    private final ModelRenderer cube_r37;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer dragonthings2;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r45;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer bottomjaw2;
    private final ModelRenderer teeth6_r1;
    private final ModelRenderer topjaw2;
    private final ModelRenderer bone6;
    private final ModelRenderer cube_r48;
    private final ModelRenderer cube_r49;
    private final ModelRenderer bone8;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;

    public goro_amaru() {
        textureWidth = 256;
        textureHeight = 256;

        body = new ModelRenderer(this);
        body.setRotationPoint(-15.8F, -13.0F, -5.0F);
        setRotationAngle(body, 0.0F, 2.0944F, 0.0F);


        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(0.0F, 32.0F, 0.0F);
        body.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0F, -0.5236F, 0.0F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 29, 22, -5.0F, -19.0F, -13.0F, 6, 1, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 156, 40, -7.0F, -21.0F, -13.0F, 8, 2, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 130, 196, 1.0F, -21.0F, -13.0F, 1, 3, 20, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 154, 138, -11.0F, -26.0F, -13.0F, 12, 5, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 34, 0, 1.0F, -26.0F, 8.0F, 1, 3, 7, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 61, 186, 1.0F, -26.0F, -13.0F, 1, 5, 21, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 84, 1.0F, -21.0F, 18.0F, 1, 2, 6, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 26, 207, 1.0F, -21.0F, 24.0F, 1, 3, 18, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 154, 125, 1.0F, -26.0F, 15.0F, 1, 5, 27, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 99, 39, 1.0F, -36.0F, -13.0F, 0, 10, 55, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 6, 2, -17.0F, -21.0F, 41.0F, 2, 1, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 37, 173, -22.0F, -21.0F, 41.0F, 5, 3, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 135, 40, -22.0F, -23.0F, 41.0F, 8, 2, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 6, 0, -11.0F, -21.0F, 41.0F, 3, 1, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 154, 144, -8.0F, -21.0F, 41.0F, 9, 3, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 135, 25, -12.0F, -23.0F, 41.0F, 13, 2, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 152, 196, -22.0F, -26.0F, 41.0F, 23, 3, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 208, 181, -22.0F, -36.0F, 41.0F, 23, 10, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 99, 29, 1.0F, -36.0F, -13.0F, 1, 10, 55, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 165, 6, -23.0F, -18.0F, -12.0F, 1, 1, 5, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 40, 134, -23.0F, -19.0F, -13.0F, 5, 2, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 154, 148, -23.0F, -21.0F, -13.0F, 8, 2, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 8, 84, -13.0F, -26.0F, -13.0F, 2, 3, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 18, -23.0F, -26.0F, -13.0F, 10, 5, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 153, 200, -23.0F, -21.0F, -12.0F, 1, 3, 19, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 187, 157, -23.0F, -21.0F, 21.0F, 1, 3, 21, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 159, 169, -23.0F, -26.0F, 14.0F, 1, 3, 4, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 182, 182, -23.0F, -26.0F, 18.0F, 1, 5, 24, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 156, 53, -23.0F, -26.0F, -12.0F, 1, 5, 26, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 98, 105, -23.0F, -36.0F, -12.0F, 1, 10, 54, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 38, -23.0F, -36.0F, -13.0F, 24, 10, 1, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 84, -22.0F, -45.0F, -12.0F, 23, 22, 53, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 159, 0.0F, -72.0F, -9.0F, 1, 14, 23, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 0, 0.0F, -72.0F, 15.0F, 1, 14, 24, 0.0F));
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 0, -21.0F, -77.0F, -11.0F, 21, 33, 51, 0.0F));

        TomoeDrums = new ModelRenderer(this);
        TomoeDrums.setRotationPoint(-52.1423F, 37.0F, 57.6025F);
        body.addChild(TomoeDrums);
        setRotationAngle(TomoeDrums, 0.0F, -2.0944F, 0.0F);


        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(-67.0F, -120.0F, 16.0F);
        TomoeDrums.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.0F, 0.0F, -1.5708F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 30, 0, -1.0F, -4.0F, 0.0F, 1, 21, 1, 0.0F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(-83.0F, -116.0F, 16.0F);
        TomoeDrums.addChild(cube_r3);
        setRotationAngle(cube_r3, -0.4363F, 0.0F, 0.5236F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 30, 0, -1.0F, -4.0F, 0.0F, 1, 21, 1, 0.0F));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(-37.0F, -116.0F, 16.0F);
        TomoeDrums.addChild(cube_r4);
        setRotationAngle(cube_r4, -0.4363F, 0.0F, -0.5236F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 30, 0, -1.0F, -4.0F, 0.0F, 1, 21, 1, 0.0F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(-35.0F, -85.0F, 9.0F);
        TomoeDrums.addChild(cube_r5);
        setRotationAngle(cube_r5, -0.3054F, 0.0F, 0.6981F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 26, 0, -1.0F, -4.0F, 0.0F, 1, 22, 1, 0.0F));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(-87.0F, -85.0F, 9.0F);
        TomoeDrums.addChild(cube_r6);
        setRotationAngle(cube_r6, -0.3054F, 0.0F, -0.6981F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 26, 0, -1.0F, -4.0F, 0.0F, 1, 22, 1, 0.0F));

        tomoe1 = new ModelRenderer(this);
        tomoe1.setRotationPoint(0.0F, 2.0F, 0.0F);
        TomoeDrums.addChild(tomoe1);
        tomoe1.cubeList.add(new ModelBox(tomoe1, 0, 117, -97.0F, -106.0F, 8.0F, 16, 16, 4, 0.0F));
        tomoe1.cubeList.add(new ModelBox(tomoe1, 10, 0, -98.0F, -105.0F, 8.0F, 1, 14, 4, 0.0F));
        tomoe1.cubeList.add(new ModelBox(tomoe1, 84, 197, -96.0F, -107.0F, 8.0F, 14, 1, 4, 0.0F));
        tomoe1.cubeList.add(new ModelBox(tomoe1, 0, 0, -81.0F, -105.0F, 8.0F, 1, 14, 4, 0.0F));
        tomoe1.cubeList.add(new ModelBox(tomoe1, 183, 147, -96.0F, -90.0F, 8.0F, 14, 1, 4, 0.0F));

        tomoe2 = new ModelRenderer(this);
        tomoe2.setRotationPoint(57.0F, 2.0F, 0.0F);
        TomoeDrums.addChild(tomoe2);


        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(-81.0F, -90.0F, 11.0F);
        tomoe2.addChild(cube_r7);
        setRotationAngle(cube_r7, 0.0F, 0.0F, 0.829F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 183, 147, -19.7291F, 5.1609F, -3.0F, 14, 1, 4, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 0, -4.7291F, -9.8391F, -3.0F, 1, 14, 4, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 84, 197, -19.7291F, -11.8391F, -3.0F, 14, 1, 4, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 10, 0, -21.7291F, -9.8391F, -3.0F, 1, 14, 4, 0.0F));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 0, 117, -20.7291F, -10.8391F, -3.0F, 16, 16, 4, 0.0F));

        tomoe3 = new ModelRenderer(this);
        tomoe3.setRotationPoint(42.0F, -22.0F, 7.0F);
        TomoeDrums.addChild(tomoe3);


        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(-81.0F, -90.0F, 11.0F);
        tomoe3.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.0F, 0.0F, 0.5672F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 183, 147, -15.0749F, 3.6048F, -3.0F, 14, 1, 4, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 0, -0.0749F, -11.3952F, -3.0F, 1, 14, 4, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 84, 197, -15.0749F, -13.3952F, -3.0F, 14, 1, 4, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 10, 0, -17.0749F, -11.3952F, -3.0F, 1, 14, 4, 0.0F));
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 117, -16.0749F, -12.3952F, -3.0F, 16, 16, 4, 0.0F));

        tomoe4 = new ModelRenderer(this);
        tomoe4.setRotationPoint(15.0F, -22.0F, 7.0F);
        TomoeDrums.addChild(tomoe4);


        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(-81.0F, -90.0F, 11.0F);
        tomoe4.addChild(cube_r9);
        setRotationAngle(cube_r9, -0.1309F, 0.0F, -0.5236F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 183, 147, -12.0F, -5.1962F, -4.0F, 14, 1, 4, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 0, 0, 3.0F, -20.1962F, -4.0F, 1, 14, 4, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 84, 197, -12.0F, -22.1962F, -4.0F, 14, 1, 4, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 10, 0, -14.0F, -20.1962F, -4.0F, 1, 14, 4, 0.0F));
        cube_r9.cubeList.add(new ModelBox(cube_r9, 0, 117, -13.0F, -21.1962F, -4.0F, 16, 16, 4, 0.0F));

        legs2 = new ModelRenderer(this);
        legs2.setRotationPoint(-23.2F, 10.0F, 17.0F);
        body.addChild(legs2);


        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(0.0F, 0.0F, 0.0F);
        legs2.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.0F, -0.5236F, 0.0F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 210, 147, -3.0F, 16.0F, -2.0F, 8, 10, 10, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 99, 104, -4.0F, -1.0F, -5.0F, 10, 17, 16, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 93, 25, -5.0F, -1.0F, -6.0F, 12, 6, 18, 0.0F));
        cube_r10.cubeList.add(new ModelBox(cube_r10, 208, 192, 5.0F, 24.0F, -2.0F, 9, 2, 10, 0.0F));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(13.0F, 0.0F, -23.0F);
        legs2.addChild(cube_r11);
        setRotationAngle(cube_r11, 0.0F, -0.5236F, 0.0F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 212, 212, 5.0F, 24.0F, -3.0F, 9, 2, 10, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 209, 84, -3.0F, 16.0F, -3.0F, 8, 10, 10, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 84, -4.0F, -1.0F, -6.0F, 10, 17, 16, 0.0F));
        cube_r11.cubeList.add(new ModelBox(cube_r11, 48, 159, -5.0F, -1.0F, -7.0F, 12, 6, 18, 0.0F));

        rightarm = new ModelRenderer(this);
        rightarm.setRotationPoint(-4.2942F, -42.0F, -12.0981F);
        body.addChild(rightarm);
        setRotationAngle(rightarm, 0.0F, -0.5672F, 0.0F);
        rightarm.cubeList.add(new ModelBox(rightarm, 154, 104, 25.0F, 2.0F, -11.0F, 30, 11, 10, 0.0F));
        rightarm.cubeList.add(new ModelBox(rightarm, 93, 0, -4.0F, 1.0F, -12.0F, 30, 13, 12, 0.0F));

        righthand = new ModelRenderer(this);
        righthand.setRotationPoint(-9.0F, 12.0F, 57.0F);
        rightarm.addChild(righthand);
        righthand.cubeList.add(new ModelBox(righthand, 182, 211, 64.0F, -11.0F, -68.0F, 4, 12, 11, 0.0F));
        righthand.cubeList.add(new ModelBox(righthand, 170, 125, 65.0F, -16.0F, -68.0F, 3, 5, 2, 0.0F));
        righthand.cubeList.add(new ModelBox(righthand, 154, 125, 65.0F, -18.0F, -65.0F, 3, 7, 2, 0.0F));
        righthand.cubeList.add(new ModelBox(righthand, 93, 0, 65.0F, -19.0F, -62.0F, 3, 8, 2, 0.0F));
        righthand.cubeList.add(new ModelBox(righthand, 156, 76, 65.0F, -18.0F, -59.0F, 3, 1, 2, 0.0F));
        righthand.cubeList.add(new ModelBox(righthand, 98, 169, 65.0F, -17.0F, -59.0F, 3, 6, 2, 0.0F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(70.0F, -7.0F, -55.0F);
        righthand.addChild(cube_r12);
        setRotationAngle(cube_r12, -0.1745F, 0.0F, 0.0F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 154, 104, -5.0F, -6.0F, 0.0F, 3, 8, 2, 0.0F));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(70.0F, -15.0F, -68.0F);
        righthand.addChild(cube_r13);
        setRotationAngle(cube_r13, 0.0F, 0.0F, 0.3491F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 176, -5.0F, -2.0F, 0.0F, 3, 3, 2, 0.0F));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(70.0F, -17.0F, -65.0F);
        righthand.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.0F, 0.0F, 0.3491F);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 10, 176, -5.0F, -2.0F, 0.0F, 3, 3, 2, 0.0F));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 35, 177, -5.0F, -2.0F, 6.0F, 3, 3, 2, 0.0F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(70.0F, -18.0F, -62.0F);
        righthand.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.0F, 0.0F, 0.3491F);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 150, 179, -5.0F, -2.0F, 0.0F, 3, 3, 2, 0.0F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(70.0F, -1.0F, -58.0F);
        righthand.addChild(cube_r16);
        setRotationAngle(cube_r16, -0.5236F, 0.0F, 0.0F);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 25, 159, -5.0F, -6.0F, 0.0F, 3, 7, 2, 0.0F));

        leftarm = new ModelRenderer(this);
        leftarm.setRotationPoint(-1.5981F, -25.0F, -19.5F);
        body.addChild(leftarm);


        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(3.3038F, -5.0F, -3.5981F);
        leftarm.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.0F, -0.1309F, 0.0F);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 154, 104, -44.146F, -5.0F, 65.5475F, 30, 11, 10, 0.0F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(3.3038F, -5.0F, -3.5981F);
        leftarm.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.0F, 0.3491F, 0.0F);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 93, 0, -72.2628F, -6.0F, 30.9138F, 30, 13, 12, 0.0F));

        lefthand = new ModelRenderer(this);
        lefthand.setRotationPoint(-11.0F, 0.0F, -8.0F);
        leftarm.addChild(lefthand);
        setRotationAngle(lefthand, 0.0F, 0.2182F, 0.0F);


        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(0.0F, 0.0F, 0.0F);
        lefthand.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.0F, 0.6981F, 0.0F);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 34, 10, -59.974F, -5.0F, 49.7911F, 3, 9, 3, 0.0F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(-11.0F, 1.0F, 58.0F);
        lefthand.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.0F, -1.6144F, 0.0F);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 165, 0, 12.4009F, -8.0F, 5.9254F, 4, 3, 3, 0.0F));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 51, 165, 12.4009F, -11.0F, 5.9254F, 4, 3, 3, 0.0F));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 51, 159, 12.4009F, -2.0F, 5.9254F, 4, 3, 3, 0.0F));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 0, 92, 12.4009F, -5.0F, 5.9254F, 4, 3, 3, 0.0F));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(-11.0F, 1.0F, 58.0F);
        lefthand.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.0F, 0.1745F, 0.0F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 93, 25, -10.4546F, -5.0F, 14.3128F, 6, 3, 3, 0.0F));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 93, 37, -10.4546F, -2.0F, 14.3128F, 6, 3, 3, 0.0F));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 135, 34, -10.4546F, -8.0F, 14.3128F, 6, 3, 3, 0.0F));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 156, 34, -10.4546F, -11.0F, 14.3128F, 6, 3, 3, 0.0F));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(-21.0F, 1.0F, 58.0F);
        lefthand.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.0F, 1.2217F, 0.0F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 93, 31, -12.9572F, -5.0F, 11.6526F, 6, 3, 3, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 135, 28, -12.9572F, -2.0F, 11.6526F, 6, 3, 3, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 156, 28, -12.9572F, -8.0F, 11.6526F, 6, 3, 3, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 156, 53, -12.9572F, -11.0F, 11.6526F, 6, 3, 3, 0.0F));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 64, 212, -9.9572F, -11.0F, 0.6526F, 3, 12, 11, 0.0F));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(-21.0F, 1.0F, 58.0F);
        lefthand.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.0F, 1.1345F, 0.0F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 25, 173, -9.8843F, 1.0F, 4.0237F, 3, 3, 3, 0.0F));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(-21.0F, 1.0F, 58.0F);
        lefthand.addChild(cube_r24);
        setRotationAngle(cube_r24, 0.0F, 0.6981F, 0.0F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 154, 125, -6.5317F, 1.0F, 9.2172F, 3, 3, 10, 0.0F));

        heads = new ModelRenderer(this);
        heads.setRotationPoint(5.7801F, -20.0F, 32.5372F);
        lefthand.addChild(heads);
        setRotationAngle(heads, 0.0F, -0.6981F, 0.0F);


        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(0.0F, 0.0F, 0.0F);
        heads.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.0F, 0.0F, -0.4363F);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 43, 0, 1.8001F, -8.1837F, 11.1204F, 2, 3, 2, 0.0F));

        mainhead_r1 = new ModelRenderer(this);
        mainhead_r1.setRotationPoint(0.0F, 0.0F, 5.0F);
        heads.addChild(mainhead_r1);
        setRotationAngle(mainhead_r1, 0.0F, -0.0436F, 0.0F);
        mainhead_r1.cubeList.add(new ModelBox(mainhead_r1, 94, 169, -14.0F, -14.0F, 0.0F, 14, 14, 14, 0.0F));

        legs = new ModelRenderer(this);
        legs.setRotationPoint(-13.2F, 73.0F, 11.0F);
        heads.addChild(legs);


        hair = new ModelRenderer(this);
        hair.setRotationPoint(0.0F, 0.0F, 0.0F);
        heads.addChild(hair);


        hair_r1 = new ModelRenderer(this);
        hair_r1.setRotationPoint(-2.0F, -13.0F, -5.0F);
        hair.addChild(hair_r1);
        setRotationAngle(hair_r1, -0.0436F, -0.0436F, -0.6545F);
        hair_r1.cubeList.add(new ModelBox(hair_r1, 147, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r2 = new ModelRenderer(this);
        hair_r2.setRotationPoint(0.0F, -13.0F, -5.0F);
        hair.addChild(hair_r2);
        setRotationAngle(hair_r2, 0.0436F, -0.0436F, -0.6545F);
        hair_r2.cubeList.add(new ModelBox(hair_r2, 18, 0, 0.0F, -21.0F, 13.0F, 0, 3, 1, 0.0F));
        hair_r2.cubeList.add(new ModelBox(hair_r2, 34, 9, 0.0F, -18.0F, 12.0F, 0, 3, 1, 0.0F));
        hair_r2.cubeList.add(new ModelBox(hair_r2, 78, 181, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r3 = new ModelRenderer(this);
        hair_r3.setRotationPoint(-11.0F, -13.0F, -5.0F);
        hair.addChild(hair_r3);
        setRotationAngle(hair_r3, 0.0436F, -0.0436F, -0.6545F);
        hair_r3.cubeList.add(new ModelBox(hair_r3, 40, 82, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r4 = new ModelRenderer(this);
        hair_r4.setRotationPoint(-9.0F, -13.0F, -5.0F);
        hair.addChild(hair_r4);
        setRotationAngle(hair_r4, 0.0436F, -0.0436F, -0.6545F);
        hair_r4.cubeList.add(new ModelBox(hair_r4, 103, 103, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r5 = new ModelRenderer(this);
        hair_r5.setRotationPoint(-4.0F, -13.0F, -5.0F);
        hair.addChild(hair_r5);
        setRotationAngle(hair_r5, 0.0436F, -0.0436F, -0.6545F);
        hair_r5.cubeList.add(new ModelBox(hair_r5, 139, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r6 = new ModelRenderer(this);
        hair_r6.setRotationPoint(-14.0F, -15.0F, 1.0F);
        hair.addChild(hair_r6);
        setRotationAngle(hair_r6, 0.0F, -0.0436F, -0.6545F);
        hair_r6.cubeList.add(new ModelBox(hair_r6, 44, 82, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r7 = new ModelRenderer(this);
        hair_r7.setRotationPoint(-12.0F, -15.0F, 1.0F);
        hair.addChild(hair_r7);
        setRotationAngle(hair_r7, 0.0F, -0.0436F, -0.6545F);
        hair_r7.cubeList.add(new ModelBox(hair_r7, 107, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r8 = new ModelRenderer(this);
        hair_r8.setRotationPoint(-7.0F, -15.0F, 1.0F);
        hair.addChild(hair_r8);
        setRotationAngle(hair_r8, 0.0F, -0.0436F, -0.6545F);
        hair_r8.cubeList.add(new ModelBox(hair_r8, 143, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r9 = new ModelRenderer(this);
        hair_r9.setRotationPoint(-3.0F, -15.0F, 1.0F);
        hair.addChild(hair_r9);
        setRotationAngle(hair_r9, 0.0F, -0.0436F, -0.6545F);
        hair_r9.cubeList.add(new ModelBox(hair_r9, 66, 181, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r10 = new ModelRenderer(this);
        hair_r10.setRotationPoint(-1.0F, -15.0F, 1.0F);
        hair.addChild(hair_r10);
        setRotationAngle(hair_r10, -0.1309F, -0.0436F, -0.6545F);
        hair_r10.cubeList.add(new ModelBox(hair_r10, 48, 14, 0.0F, -20.0F, 12.0F, 0, 5, 1, 0.0F));
        hair_r10.cubeList.add(new ModelBox(hair_r10, 74, 181, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r11 = new ModelRenderer(this);
        hair_r11.setRotationPoint(-12.0F, -15.0F, 1.0F);
        hair.addChild(hair_r11);
        setRotationAngle(hair_r11, -0.1309F, -0.0436F, -0.6545F);
        hair_r11.cubeList.add(new ModelBox(hair_r11, 36, 82, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r12 = new ModelRenderer(this);
        hair_r12.setRotationPoint(-10.0F, -15.0F, 1.0F);
        hair.addChild(hair_r12);
        setRotationAngle(hair_r12, -0.1309F, -0.0436F, -0.6545F);
        hair_r12.cubeList.add(new ModelBox(hair_r12, 48, 19, 0.0F, -19.0F, 13.0F, 0, 4, 1, 0.0F));
        hair_r12.cubeList.add(new ModelBox(hair_r12, 99, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r13 = new ModelRenderer(this);
        hair_r13.setRotationPoint(-5.0F, -15.0F, 1.0F);
        hair.addChild(hair_r13);
        setRotationAngle(hair_r13, -0.1309F, -0.0436F, -0.6545F);
        hair_r13.cubeList.add(new ModelBox(hair_r13, 135, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r14 = new ModelRenderer(this);
        hair_r14.setRotationPoint(-13.0F, -14.0F, -2.0F);
        hair.addChild(hair_r14);
        setRotationAngle(hair_r14, 0.0873F, -0.0436F, -0.6109F);
        hair_r14.cubeList.add(new ModelBox(hair_r14, 148, 64, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r15 = new ModelRenderer(this);
        hair_r15.setRotationPoint(-11.0F, -14.0F, -2.0F);
        hair.addChild(hair_r15);
        setRotationAngle(hair_r15, 0.0873F, -0.0436F, -0.6109F);
        hair_r15.cubeList.add(new ModelBox(hair_r15, 46, 17, 0.0F, -22.0F, 13.0F, 0, 5, 1, 0.0F));
        hair_r15.cubeList.add(new ModelBox(hair_r15, 4, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r16 = new ModelRenderer(this);
        hair_r16.setRotationPoint(-6.0F, -14.0F, -2.0F);
        hair.addChild(hair_r16);
        setRotationAngle(hair_r16, 0.0873F, -0.0436F, -0.6109F);
        hair_r16.cubeList.add(new ModelBox(hair_r16, 90, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r17 = new ModelRenderer(this);
        hair_r17.setRotationPoint(-2.0F, -14.0F, -2.0F);
        hair.addChild(hair_r17);
        setRotationAngle(hair_r17, 0.0873F, -0.0436F, -0.6109F);
        hair_r17.cubeList.add(new ModelBox(hair_r17, 172, 57, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r18 = new ModelRenderer(this);
        hair_r18.setRotationPoint(-11.0F, -14.0F, -2.0F);
        hair.addChild(hair_r18);
        setRotationAngle(hair_r18, 0.0F, -0.0436F, -0.6545F);
        hair_r18.cubeList.add(new ModelBox(hair_r18, 156, 57, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r19 = new ModelRenderer(this);
        hair_r19.setRotationPoint(-9.0F, -14.0F, -2.0F);
        hair.addChild(hair_r19);
        setRotationAngle(hair_r19, 0.0F, -0.0436F, -0.6545F);
        hair_r19.cubeList.add(new ModelBox(hair_r19, 8, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r20 = new ModelRenderer(this);
        hair_r20.setRotationPoint(-4.0F, -14.0F, -2.0F);
        hair.addChild(hair_r20);
        setRotationAngle(hair_r20, 0.0F, -0.0436F, -0.6545F);
        hair_r20.cubeList.add(new ModelBox(hair_r20, 94, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r21 = new ModelRenderer(this);
        hair_r21.setRotationPoint(-11.0F, -11.0F, -7.0F);
        hair.addChild(hair_r21);
        setRotationAngle(hair_r21, 0.2182F, -0.0436F, -0.6545F);
        hair_r21.cubeList.add(new ModelBox(hair_r21, 0, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r22 = new ModelRenderer(this);
        hair_r22.setRotationPoint(-9.0F, -11.0F, -7.0F);
        hair.addChild(hair_r22);
        setRotationAngle(hair_r22, 0.2182F, -0.0436F, -0.6545F);
        hair_r22.cubeList.add(new ModelBox(hair_r22, 12, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r23 = new ModelRenderer(this);
        hair_r23.setRotationPoint(6.0F, -11.0F, 8.0F);
        hair.addChild(hair_r23);
        setRotationAngle(hair_r23, 0.2182F, -0.6981F, -0.6545F);
        hair_r23.cubeList.add(new ModelBox(hair_r23, 44, 115, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r24 = new ModelRenderer(this);
        hair_r24.setRotationPoint(1.0F, -11.0F, 8.0F);
        hair.addChild(hair_r24);
        setRotationAngle(hair_r24, 0.2182F, -0.6981F, -0.6545F);
        hair_r24.cubeList.add(new ModelBox(hair_r24, 48, 115, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r25 = new ModelRenderer(this);
        hair_r25.setRotationPoint(-10.0F, -4.0F, 3.0F);
        hair.addChild(hair_r25);
        setRotationAngle(hair_r25, 0.2182F, 0.6981F, -0.6545F);
        hair_r25.cubeList.add(new ModelBox(hair_r25, 144, 47, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r26 = new ModelRenderer(this);
        hair_r26.setRotationPoint(-6.0F, -4.0F, 3.0F);
        hair.addChild(hair_r26);
        setRotationAngle(hair_r26, 0.2182F, 0.6981F, -0.6545F);
        hair_r26.cubeList.add(new ModelBox(hair_r26, 144, 64, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r27 = new ModelRenderer(this);
        hair_r27.setRotationPoint(-6.0F, -4.0F, -3.0F);
        hair.addChild(hair_r27);
        setRotationAngle(hair_r27, 0.2182F, 0.6981F, -0.6545F);
        hair_r27.cubeList.add(new ModelBox(hair_r27, 148, 47, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r28 = new ModelRenderer(this);
        hair_r28.setRotationPoint(-8.0F, -10.0F, -7.0F);
        hair.addChild(hair_r28);
        setRotationAngle(hair_r28, 0.2182F, 0.2182F, -0.6545F);
        hair_r28.cubeList.add(new ModelBox(hair_r28, 160, 57, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r29 = new ModelRenderer(this);
        hair_r29.setRotationPoint(0.0F, -11.0F, -7.0F);
        hair.addChild(hair_r29);
        setRotationAngle(hair_r29, 0.2182F, -0.0436F, -0.6545F);
        hair_r29.cubeList.add(new ModelBox(hair_r29, 168, 57, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r30 = new ModelRenderer(this);
        hair_r30.setRotationPoint(2.0F, -11.0F, -7.0F);
        hair.addChild(hair_r30);
        setRotationAngle(hair_r30, 0.2618F, -0.0436F, -0.6545F);
        hair_r30.cubeList.add(new ModelBox(hair_r30, 84, 181, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r31 = new ModelRenderer(this);
        hair_r31.setRotationPoint(-5.0F, -17.0F, 6.0F);
        hair.addChild(hair_r31);
        setRotationAngle(hair_r31, -0.3927F, -0.0436F, -0.7854F);
        hair_r31.cubeList.add(new ModelBox(hair_r31, 14, 88, 0.0F, -21.0F, 13.0F, 0, 4, 1, 0.0F));
        hair_r31.cubeList.add(new ModelBox(hair_r31, 176, 51, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r32 = new ModelRenderer(this);
        hair_r32.setRotationPoint(-14.0F, -17.0F, 6.0F);
        hair.addChild(hair_r32);
        setRotationAngle(hair_r32, -0.2618F, -0.0436F, -0.6981F);
        hair_r32.cubeList.add(new ModelBox(hair_r32, 40, 115, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));
        hair_r32.cubeList.add(new ModelBox(hair_r32, 48, 9, 0.0F, -22.0F, 12.0F, 0, 5, 1, 0.0F));

        hair_r33 = new ModelRenderer(this);
        hair_r33.setRotationPoint(-12.0F, -17.0F, 6.0F);
        hair.addChild(hair_r33);
        setRotationAngle(hair_r33, -0.2618F, -0.0436F, -0.6981F);
        hair_r33.cubeList.add(new ModelBox(hair_r33, 16, 157, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r34 = new ModelRenderer(this);
        hair_r34.setRotationPoint(-7.0F, -17.0F, 6.0F);
        hair.addChild(hair_r34);
        setRotationAngle(hair_r34, -0.2618F, -0.0436F, -0.6981F);
        hair_r34.cubeList.add(new ModelBox(hair_r34, 164, 57, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r35 = new ModelRenderer(this);
        hair_r35.setRotationPoint(-3.0F, -17.0F, 6.0F);
        hair.addChild(hair_r35);
        setRotationAngle(hair_r35, -0.2618F, -0.0436F, -0.6981F);
        hair_r35.cubeList.add(new ModelBox(hair_r35, 120, 195, 0.0F, -17.0F, 12.0F, 0, 17, 2, 0.0F));

        hair_r36 = new ModelRenderer(this);
        hair_r36.setRotationPoint(-13.0F, -14.0F, 5.0F);
        hair.addChild(hair_r36);
        setRotationAngle(hair_r36, 0.0F, -0.0436F, -0.6981F);
        hair_r36.cubeList.add(new ModelBox(hair_r36, 20, 0, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r37 = new ModelRenderer(this);
        hair_r37.setRotationPoint(-11.0F, -14.0F, 5.0F);
        hair.addChild(hair_r37);
        setRotationAngle(hair_r37, 0.0F, -0.0436F, -0.6981F);
        hair_r37.cubeList.add(new ModelBox(hair_r37, 48, 82, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r38 = new ModelRenderer(this);
        hair_r38.setRotationPoint(-6.0F, -14.0F, 5.0F);
        hair.addChild(hair_r38);
        setRotationAngle(hair_r38, 0.0F, -0.0436F, -0.6981F);
        hair_r38.cubeList.add(new ModelBox(hair_r38, 111, 102, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r39 = new ModelRenderer(this);
        hair_r39.setRotationPoint(-2.0F, -14.0F, 5.0F);
        hair.addChild(hair_r39);
        setRotationAngle(hair_r39, 0.0F, -0.0436F, -0.6981F);
        hair_r39.cubeList.add(new ModelBox(hair_r39, 70, 181, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        hair_r40 = new ModelRenderer(this);
        hair_r40.setRotationPoint(0.0F, -14.0F, 5.0F);
        hair.addChild(hair_r40);
        setRotationAngle(hair_r40, 0.0F, -0.0436F, -0.6981F);
        hair_r40.cubeList.add(new ModelBox(hair_r40, 183, 123, 0.0F, -15.0F, 12.0F, 0, 15, 2, 0.0F));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(-8.4226F, -5.1483F, 10.69F);
        heads.addChild(bone2);
        setRotationAngle(bone2, 0.0F, 3.1416F, 0.0F);


        earlobe_r1 = new ModelRenderer(this);
        earlobe_r1.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone2.addChild(earlobe_r1);
        setRotationAngle(earlobe_r1, 0.1745F, -0.0436F, -0.2618F);
        earlobe_r1.cubeList.add(new ModelBox(earlobe_r1, 88, 183, -13.2481F, -4.7899F, 1.4188F, 2, 12, 1, 0.0F));

        earlobe_r2 = new ModelRenderer(this);
        earlobe_r2.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone2.addChild(earlobe_r2);
        setRotationAngle(earlobe_r2, -0.829F, -0.0436F, 0.4363F);
        earlobe_r2.cubeList.add(new ModelBox(earlobe_r2, 187, 125, -13.0407F, -6.964F, 3.9765F, 2, 9, 1, 0.0F));

        earlobe_r3 = new ModelRenderer(this);
        earlobe_r3.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone2.addChild(earlobe_r3);
        setRotationAngle(earlobe_r3, 0.1745F, -0.4363F, 1.4399F);
        earlobe_r3.cubeList.add(new ModelBox(earlobe_r3, 136, 169, -5.4222F, 6.1592F, 8.5934F, 2, 6, 1, 0.0F));

        earlobe_r4 = new ModelRenderer(this);
        earlobe_r4.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone2.addChild(earlobe_r4);
        setRotationAngle(earlobe_r4, 0.3054F, -0.0436F, 0.0F);
        earlobe_r4.cubeList.add(new ModelBox(earlobe_r4, 190, 53, -5.2181F, -13.5021F, 8.236F, 2, 9, 1, 0.0F));

        bone = new ModelRenderer(this);
        bone.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone2.addChild(bone);


        earlobe_r5 = new ModelRenderer(this);
        earlobe_r5.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone.addChild(earlobe_r5);
        setRotationAngle(earlobe_r5, -0.3491F, -0.0436F, -0.2618F);
        earlobe_r5.cubeList.add(new ModelBox(earlobe_r5, 179, 0, -13.9101F, -1.2361F, -7.2447F, 2, 12, 1, 0.0F));

        earlobe_r6 = new ModelRenderer(this);
        earlobe_r6.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone.addChild(earlobe_r6);
        setRotationAngle(earlobe_r6, -0.3054F, -0.0436F, 0.0F);
        earlobe_r6.cubeList.add(new ModelBox(earlobe_r6, 185, 0, -6.265F, -13.8931F, -13.4286F, 2, 9, 1, 0.0F));

        earlobe_r7 = new ModelRenderer(this);
        earlobe_r7.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone.addChild(earlobe_r7);
        setRotationAngle(earlobe_r7, 0.2182F, -0.0436F, 0.4363F);
        earlobe_r7.cubeList.add(new ModelBox(earlobe_r7, 184, 53, -13.0549F, -4.7536F, -7.7372F, 2, 9, 1, 0.0F));

        earlobe_r8 = new ModelRenderer(this);
        earlobe_r8.setRotationPoint(0.0F, 11.0F, 1.0F);
        bone.addChild(earlobe_r8);
        setRotationAngle(earlobe_r8, 0.5236F, 0.0873F, 1.4399F);
        earlobe_r8.cubeList.add(new ModelBox(earlobe_r8, 34, 0, -9.0658F, -2.7263F, -13.1149F, 2, 6, 1, 0.0F));

        dragonthings = new ModelRenderer(this);
        dragonthings.setRotationPoint(41.0F, 11.0F, -32.0F);


        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(38.0F, -24.0F, 82.0F);
        dragonthings.addChild(cube_r26);
        setRotationAngle(cube_r26, -0.1309F, -1.8762F, 0.2618F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 183, 125, -1.0F, -2.0F, 58.0F, 10, 7, 15, 0.0F));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(37.0F, -16.0F, 29.0F);
        dragonthings.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.0F, -1.0036F, 0.2618F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 177, 0, -1.0F, -2.0F, 57.0F, 10, 7, 16, 0.0F));

        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(23.0F, 9.0F, 9.0F);
        dragonthings.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.3491F, -0.6981F, 0.3491F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 183, 125, -1.0F, -2.0F, 58.0F, 10, 7, 15, 0.0F));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(4.0F, 1.0F, 0.0F);
        dragonthings.addChild(cube_r29);
        setRotationAngle(cube_r29, 0.3491F, -0.3054F, 0.3491F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 194, 23, -1.0F, -2.0F, 44.0F, 10, 7, 14, 0.0F));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(-2.0F, -45.0F, 10.0F);
        dragonthings.addChild(cube_r30);
        setRotationAngle(cube_r30, -0.6109F, 0.2618F, 0.3491F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 194, 23, -1.0F, -2.0F, 30.0F, 10, 7, 14, 0.0F));

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(7.0F, -34.0F, 10.0F);
        dragonthings.addChild(cube_r31);
        setRotationAngle(cube_r31, -0.3491F, -0.2182F, 0.48F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 184, 53, -1.0F, -1.0F, 12.0F, 9, 8, 15, 0.0F));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(2.0F, -37.0F, 12.0F);
        dragonthings.addChild(cube_r32);
        setRotationAngle(cube_r32, -0.3491F, 0.2618F, 0.48F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 196, -1.0F, -1.0F, 0.0F, 9, 8, 13, 0.0F));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 196, -1.0F, -1.0F, 0.0F, 9, 8, 13, 0.0F));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(-4.0F, -39.0F, 4.0F);
        dragonthings.addChild(bone7);
        setRotationAngle(bone7, 0.0F, 0.6109F, 0.3491F);
        bone7.cubeList.add(new ModelBox(bone7, 92, 206, 0.0F, -2.0F, 0.0F, 7, 10, 13, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 136, 169, 0.0F, 3.0F, -9.0F, 7, 1, 9, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 2, 0, 0.0F, 4.0F, -9.0F, 1, 2, 0, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 0.0F, 4.0F, -9.0F, 0, 1, 1, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 0.0F, 4.0F, -7.0F, 0, 1, 2, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 0.0F, 4.0F, -4.0F, 0, 1, 2, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 1.0F, 4.0F, -9.0F, 1, 1, 0, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 3.0F, 4.0F, -9.0F, 1, 1, 0, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 5.0F, 4.0F, -9.0F, 1, 1, 0, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 2, 0, 6.0F, 4.0F, -9.0F, 1, 2, 0, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 7.0F, 4.0F, -7.0F, 0, 1, 2, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 7.0F, 4.0F, -4.0F, 0, 1, 2, 0.0F));
        bone7.cubeList.add(new ModelBox(bone7, 0, 0, 7.0F, 4.0F, -9.0F, 0, 1, 1, 0.0F));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone7.addChild(cube_r33);
        setRotationAngle(cube_r33, -0.48F, 0.0F, 0.0F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 43, 10, 3.0F, -10.0F, 0.0F, 1, 3, 0, 0.0F));
        cube_r33.cubeList.add(new ModelBox(cube_r33, 0, 84, 2.0F, -7.0F, 0.0F, 3, 6, 0, 0.0F));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(-4.0F, 3.0F, 0.0F);
        bone7.addChild(cube_r34);
        setRotationAngle(cube_r34, -0.3491F, 0.0F, -0.3491F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 14, 84, 5.0F, -11.0F, 0.0F, 1, 5, 0, 0.0F));
        cube_r34.cubeList.add(new ModelBox(cube_r34, 14, 84, 6.0F, -7.0F, 0.0F, 1, 5, 0, 0.0F));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(-1.0F, -1.0F, 0.0F);
        bone7.addChild(cube_r35);
        setRotationAngle(cube_r35, -0.3491F, 0.0F, 0.3491F);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 14, 84, 7.0F, -11.0F, 0.0F, 1, 5, 0, 0.0F));
        cube_r35.cubeList.add(new ModelBox(cube_r35, 14, 84, 6.0F, -7.0F, 0.0F, 1, 5, 0, 0.0F));

        bottomjaw = new ModelRenderer(this);
        bottomjaw.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone7.addChild(bottomjaw);


        teeth5_r1 = new ModelRenderer(this);
        teeth5_r1.setRotationPoint(3.0F, 0.0F, 0.0F);
        bottomjaw.addChild(teeth5_r1);
        setRotationAngle(teeth5_r1, 0.6109F, 0.0F, 0.0F);
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 12, 3, 0.0F, 5.0F, -12.0F, 1, 1, 0, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 12, 3, 2.0F, 5.0F, -12.0F, 1, 1, 0, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 20, 0, 3.0F, 4.0F, -12.0F, 1, 2, 0, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 0, 1, 4.0F, 5.0F, -7.0F, 0, 1, 2, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 0, 1, 4.0F, 5.0F, -10.0F, 0, 1, 2, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 11, 1, 4.0F, 5.0F, -12.0F, 0, 1, 1, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 12, 3, -2.0F, 5.0F, -12.0F, 1, 1, 0, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 0, 1, -3.0F, 5.0F, -7.0F, 0, 1, 2, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 0, 1, -3.0F, 5.0F, -10.0F, 0, 1, 2, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 11, 1, -3.0F, 5.0F, -12.0F, 0, 1, 1, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 20, 0, -3.0F, 4.0F, -12.0F, 1, 2, 0, 0.0F));
        teeth5_r1.cubeList.add(new ModelBox(teeth5_r1, 25, 159, -3.0F, 6.0F, -12.0F, 7, 2, 12, 0.0F));

        topjaw = new ModelRenderer(this);
        topjaw.setRotationPoint(-41.0F, 49.0F, 32.0F);
        bone7.addChild(topjaw);


        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(48.0F, 49.0F, -29.0F);
        bone7.addChild(bone3);
        setRotationAngle(bone3, 0.0F, 3.1416F, 0.0F);


        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(55.0F, -42.0F, -30.0F);
        bone3.addChild(cube_r36);
        setRotationAngle(cube_r36, -0.1309F, 0.0F, 2.618F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 22, 17, 5.0F, -1.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r36.cubeList.add(new ModelBox(cube_r36, 16, 0, 4.0F, -4.0F, 0.0F, 1, 4, 0, 0.0F));

        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(45.0F, -51.0F, -30.0F);
        bone3.addChild(cube_r37);
        setRotationAngle(cube_r37, -0.3054F, 0.0F, 0.6109F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 22, 17, 6.0F, -8.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r37.cubeList.add(new ModelBox(cube_r37, 46, 10, 5.0F, -3.0F, 0.0F, 1, 8, 0, 0.0F));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(-41.0F, -45.0F, -29.0F);
        bone7.addChild(bone4);
        setRotationAngle(bone4, 0.0F, 3.1416F, -3.1416F);


        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(55.0F, -47.0F, -30.0F);
        bone4.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.1309F, 0.0F, 2.618F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 22, 17, 5.0F, -1.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 16, 0, 4.0F, -4.0F, 0.0F, 1, 4, 0, 0.0F));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(45.0F, -56.0F, -30.0F);
        bone4.addChild(cube_r39);
        setRotationAngle(cube_r39, -0.3054F, 0.0F, 0.6109F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 22, 17, 6.0F, -8.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r39.cubeList.add(new ModelBox(cube_r39, 46, 10, 5.0F, -3.0F, 0.0F, 1, 8, 0, 0.0F));

        dragonthings2 = new ModelRenderer(this);
        dragonthings2.setRotationPoint(-19.0F, -53.0F, -32.0F);
        setRotationAngle(dragonthings2, 0.0F, 0.0F, -2.3998F);
        dragonthings2.cubeList.add(new ModelBox(dragonthings2, 150, 169, -1.0F, -38.0F, 33.0F, 9, 8, 19, 0.0F));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(-25.0F, -29.0F, 66.0F);
        dragonthings2.addChild(cube_r40);
        setRotationAngle(cube_r40, -0.2618F, -1.4399F, 0.0F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 32, 183, -1.0F, -1.0F, -3.0F, 9, 8, 16, 0.0F));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(-11.0F, -32.0F, 61.0F);
        dragonthings2.addChild(cube_r41);
        setRotationAngle(cube_r41, -0.2618F, -1.2217F, 0.0F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 156, 25, -1.0F, -1.0F, -7.0F, 9, 8, 20, 0.0F));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(-1.0F, -36.0F, 51.0F);
        dragonthings2.addChild(cube_r42);
        setRotationAngle(cube_r42, -0.2618F, -0.6545F, 0.0F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 32, 183, -1.0F, -1.0F, -3.0F, 9, 8, 16, 0.0F));

        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(0.0F, -32.0F, 22.0F);
        dragonthings2.addChild(cube_r43);
        setRotationAngle(cube_r43, 0.4363F, 0.0F, 0.0F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 32, 183, -1.0F, -1.0F, -3.0F, 9, 8, 16, 0.0F));
        cube_r43.cubeList.add(new ModelBox(cube_r43, 32, 183, -1.0F, -1.0F, -3.0F, 9, 8, 16, 0.0F));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(0.0F, -36.0F, 12.0F);
        dragonthings2.addChild(cube_r44);
        setRotationAngle(cube_r44, -0.3491F, 0.0F, 0.0F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 0, 196, -1.0F, -1.0F, 0.0F, 9, 8, 13, 0.0F));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(1.7677F, -29.7436F, -2.0F);
        dragonthings2.addChild(bone5);
        setRotationAngle(bone5, 0.1745F, -0.5236F, 2.4871F);
        bone5.cubeList.add(new ModelBox(bone5, 92, 206, 0.0F, -2.0F, 0.0F, 7, 10, 13, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 136, 169, 0.0F, 3.0F, -9.0F, 7, 1, 9, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 2, 0, 0.0F, 4.0F, -9.0F, 1, 2, 0, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 0.0F, 4.0F, -9.0F, 0, 1, 1, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 0.0F, 4.0F, -7.0F, 0, 1, 2, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 0.0F, 4.0F, -4.0F, 0, 1, 2, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 1.0F, 4.0F, -9.0F, 1, 1, 0, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 3.0F, 4.0F, -9.0F, 1, 1, 0, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 5.0F, 4.0F, -9.0F, 1, 1, 0, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 2, 0, 6.0F, 4.0F, -9.0F, 1, 2, 0, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 7.0F, 4.0F, -7.0F, 0, 1, 2, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 7.0F, 4.0F, -4.0F, 0, 1, 2, 0.0F));
        bone5.cubeList.add(new ModelBox(bone5, 0, 0, 7.0F, 4.0F, -9.0F, 0, 1, 1, 0.0F));

        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone5.addChild(cube_r45);
        setRotationAngle(cube_r45, -0.48F, 0.0F, 0.0F);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 43, 10, 3.0F, -10.0F, 0.0F, 1, 3, 0, 0.0F));
        cube_r45.cubeList.add(new ModelBox(cube_r45, 0, 84, 2.0F, -7.0F, 0.0F, 3, 6, 0, 0.0F));

        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(-4.0F, 3.0F, 0.0F);
        bone5.addChild(cube_r46);
        setRotationAngle(cube_r46, -0.3491F, 0.0F, -0.3491F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 14, 84, 5.0F, -11.0F, 0.0F, 1, 5, 0, 0.0F));
        cube_r46.cubeList.add(new ModelBox(cube_r46, 14, 84, 6.0F, -7.0F, 0.0F, 1, 5, 0, 0.0F));

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(-1.0F, -1.0F, 0.0F);
        bone5.addChild(cube_r47);
        setRotationAngle(cube_r47, -0.3491F, 0.0F, 0.3491F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 14, 84, 7.0F, -11.0F, 0.0F, 1, 5, 0, 0.0F));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 14, 84, 6.0F, -7.0F, 0.0F, 1, 5, 0, 0.0F));

        bottomjaw2 = new ModelRenderer(this);
        bottomjaw2.setRotationPoint(0.0F, 0.0F, 0.0F);
        bone5.addChild(bottomjaw2);


        teeth6_r1 = new ModelRenderer(this);
        teeth6_r1.setRotationPoint(3.0F, 0.0F, 0.0F);
        bottomjaw2.addChild(teeth6_r1);
        setRotationAngle(teeth6_r1, 0.6109F, 0.0F, 0.0F);
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 12, 3, 0.0F, 5.0F, -12.0F, 1, 1, 0, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 12, 3, 2.0F, 5.0F, -12.0F, 1, 1, 0, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 20, 0, 3.0F, 4.0F, -12.0F, 1, 2, 0, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 0, 1, 4.0F, 5.0F, -7.0F, 0, 1, 2, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 0, 1, 4.0F, 5.0F, -10.0F, 0, 1, 2, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 11, 1, 4.0F, 5.0F, -12.0F, 0, 1, 1, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 12, 3, -2.0F, 5.0F, -12.0F, 1, 1, 0, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 0, 1, -3.0F, 5.0F, -7.0F, 0, 1, 2, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 0, 1, -3.0F, 5.0F, -10.0F, 0, 1, 2, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 11, 1, -3.0F, 5.0F, -12.0F, 0, 1, 1, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 20, 0, -3.0F, 4.0F, -12.0F, 1, 2, 0, 0.0F));
        teeth6_r1.cubeList.add(new ModelBox(teeth6_r1, 25, 159, -3.0F, 6.0F, -12.0F, 7, 2, 12, 0.0F));

        topjaw2 = new ModelRenderer(this);
        topjaw2.setRotationPoint(-41.0F, 49.0F, 32.0F);
        bone5.addChild(topjaw2);


        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(48.0F, 49.0F, -29.0F);
        bone5.addChild(bone6);
        setRotationAngle(bone6, 0.0F, 3.1416F, 0.0F);


        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(55.0F, -42.0F, -30.0F);
        bone6.addChild(cube_r48);
        setRotationAngle(cube_r48, -0.1309F, 0.0F, 2.618F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 22, 17, 5.0F, -1.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 16, 0, 4.0F, -4.0F, 0.0F, 1, 4, 0, 0.0F));

        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(45.0F, -51.0F, -30.0F);
        bone6.addChild(cube_r49);
        setRotationAngle(cube_r49, -0.3054F, 0.0F, 0.6109F);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 22, 17, 6.0F, -8.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r49.cubeList.add(new ModelBox(cube_r49, 46, 10, 5.0F, -3.0F, 0.0F, 1, 8, 0, 0.0F));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(-41.0F, -45.0F, -29.0F);
        bone5.addChild(bone8);
        setRotationAngle(bone8, 0.0F, 3.1416F, -3.1416F);


        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(55.0F, -47.0F, -30.0F);
        bone8.addChild(cube_r50);
        setRotationAngle(cube_r50, -0.1309F, 0.0F, 2.618F);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 22, 17, 5.0F, -1.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r50.cubeList.add(new ModelBox(cube_r50, 16, 0, 4.0F, -4.0F, 0.0F, 1, 4, 0, 0.0F));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(45.0F, -56.0F, -30.0F);
        bone8.addChild(cube_r51);
        setRotationAngle(cube_r51, -0.3054F, 0.0F, 0.6109F);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 22, 17, 6.0F, -8.0F, 0.0F, 1, 6, 0, 0.0F));
        cube_r51.cubeList.add(new ModelBox(cube_r51, 46, 10, 5.0F, -3.0F, 0.0F, 1, 8, 0, 0.0F));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        body.render(f5);
        dragonthings.render(f5);
        dragonthings2.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}
