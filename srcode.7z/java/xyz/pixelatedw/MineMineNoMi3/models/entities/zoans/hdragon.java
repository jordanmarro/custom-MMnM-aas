package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;// Made with Blockbench 3.7.5
// Exported for Minecraft version 1.12
// Paste this class into your mod and generate all required imports


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class hdragon extends ModelZoanMorph {
    private final ModelRenderer group;
    private final ModelRenderer body;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer cube_r21;
    private final ModelRenderer bone2;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer head;
    private final ModelRenderer head2;
    private final ModelRenderer bone;
    private final ModelRenderer cube_r25;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r26;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r27;
    private final ModelRenderer bone6;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer bone7;
    private final ModelRenderer cube_r35;
    private final ModelRenderer bone8;
    private final ModelRenderer cube_r36;
    private final ModelRenderer bone9;
    private final ModelRenderer cube_r37;
    private final ModelRenderer bone10;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer bone11;
    private final ModelRenderer cube_r45;
    private final ModelRenderer bone12;
    private final ModelRenderer cube_r46;
    private final ModelRenderer bone13;
    private final ModelRenderer cube_r47;
    private final ModelRenderer bone14;
    private final ModelRenderer cube_r48;
    private final ModelRenderer cube_r49;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer cube_r52;
    private final ModelRenderer cube_r53;
    private final ModelRenderer cube_r54;
    private final ModelRenderer bone15;
    private final ModelRenderer cube_r55;
    private final ModelRenderer bone16;
    private final ModelRenderer cube_r56;
    private final ModelRenderer bone17;
    private final ModelRenderer cube_r57;
    private final ModelRenderer bone18;
    private final ModelRenderer cube_r58;
    private final ModelRenderer cube_r59;
    private final ModelRenderer cube_r60;
    private final ModelRenderer cube_r61;
    private final ModelRenderer cube_r62;
    private final ModelRenderer cube_r63;
    private final ModelRenderer cube_r64;
    private final ModelRenderer bone19;
    private final ModelRenderer cube_r65;
    private final ModelRenderer bone20;
    private final ModelRenderer cube_r66;
    private final ModelRenderer bone21;
    private final ModelRenderer cube_r67;
    private final ModelRenderer bone22;
    private final ModelRenderer cube_r68;
    private final ModelRenderer cube_r69;
    private final ModelRenderer cube_r70;
    private final ModelRenderer cube_r71;
    private final ModelRenderer cube_r72;
    private final ModelRenderer cube_r73;
    private final ModelRenderer cube_r74;
    private final ModelRenderer bone23;
    private final ModelRenderer cube_r75;
    private final ModelRenderer bone24;
    private final ModelRenderer cube_r76;
    private final ModelRenderer bone25;
    private final ModelRenderer cube_r77;
    private final ModelRenderer bone26;
    private final ModelRenderer cube_r78;
    private final ModelRenderer cube_r79;
    private final ModelRenderer cube_r80;
    private final ModelRenderer cube_r81;
    private final ModelRenderer cube_r82;
    private final ModelRenderer cube_r83;
    private final ModelRenderer cube_r84;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r85;
    private final ModelRenderer cube_r86;
    private final ModelRenderer cube_r87;
    private final ModelRenderer cube_r88;
    private final ModelRenderer cube_r89;
    private final ModelRenderer cube_r90;
    private final ModelRenderer cube_r91;
    private final ModelRenderer leg;
    private final ModelRenderer bone31;
    private final ModelRenderer cube_r92;
    private final ModelRenderer bone27;
    private final ModelRenderer cube_r93;
    private final ModelRenderer bone28;
    private final ModelRenderer cube_r94;
    private final ModelRenderer bone29;
    private final ModelRenderer cube_r95;
    private final ModelRenderer bone30;
    private final ModelRenderer cube_r96;
    private final ModelRenderer cube_r97;
    private final ModelRenderer cube_r98;
    private final ModelRenderer cube_r99;
    private final ModelRenderer cube_r100;
    private final ModelRenderer cube_r101;
    private final ModelRenderer bone32;
    private final ModelRenderer cube_r102;
    private final ModelRenderer bone33;
    private final ModelRenderer cube_r103;
    private final ModelRenderer bone34;
    private final ModelRenderer cube_r104;
    private final ModelRenderer bone35;
    private final ModelRenderer cube_r105;
    private final ModelRenderer bone36;
    private final ModelRenderer cube_r106;
    private final ModelRenderer cube_r107;
    private final ModelRenderer cube_r108;
    private final ModelRenderer cube_r109;
    private final ModelRenderer cube_r110;
    private final ModelRenderer cube_r111;
    private final ModelRenderer bone37;
    private final ModelRenderer cube_r112;
    private final ModelRenderer bone38;
    private final ModelRenderer cube_r113;
    private final ModelRenderer bone39;
    private final ModelRenderer cube_r114;
    private final ModelRenderer bone40;
    private final ModelRenderer cube_r115;
    private final ModelRenderer bone41;
    private final ModelRenderer cube_r116;
    private final ModelRenderer cube_r117;
    private final ModelRenderer cube_r118;
    private final ModelRenderer cube_r119;
    private final ModelRenderer cube_r120;
    private final ModelRenderer cube_r121;
    private final ModelRenderer bone42;
    private final ModelRenderer cube_r122;
    private final ModelRenderer bone43;
    private final ModelRenderer cube_r123;
    private final ModelRenderer bone44;
    private final ModelRenderer cube_r124;
    private final ModelRenderer bone45;
    private final ModelRenderer cube_r125;
    private final ModelRenderer bone46;
    private final ModelRenderer cube_r126;
    private final ModelRenderer cube_r127;
    private final ModelRenderer cube_r128;
    private final ModelRenderer cube_r129;
    private final ModelRenderer cube_r130;
    private final ModelRenderer cube_r131;

    public hdragon() {
        textureWidth = 224;
        textureHeight = 224;

        group = new ModelRenderer(this);
        group.setRotationPoint(-8, 10, 8);


        body = new ModelRenderer(this);
        body.setRotationPoint(0, -21, 0);
        group.addChild(body);
        body.cubeList.add(new ModelBox(body, 0, 0, 0, -8, 32, 16, 16, 64, 0));
        body.cubeList.add(new ModelBox(body, 0, 38, 8, -19, 54, 0, 11, 42, 0));
        body.cubeList.add(new ModelBox(body, 128, 128, 3, -1.8589F, 124.4548F, 10, 10, 16, 0));
        body.cubeList.add(new ModelBox(body, 112, 64, 8, -13.8589F, 124.4548F, 0, 12, 16, 0));
        body.cubeList.add(new ModelBox(body, 0, 91, 1, -10.2839F, -21.5913F, 14, 15, 14, 0));
        body.cubeList.add(new ModelBox(body, 104, 29, 3, -27.2839F, -9.5913F, 2, 13, 2, 0));
        body.cubeList.add(new ModelBox(body, 96, 29, 11, -27.2839F, -9.5913F, 2, 13, 2, 0));
        body.cubeList.add(new ModelBox(body, 0, 96, 11, -14.2839F, -9.5913F, 2, 4, 2, 0.2F));
        body.cubeList.add(new ModelBox(body, 45, 32, 3, -14.2839F, -9.5913F, 2, 4, 2, 0.2F));
        body.cubeList.add(new ModelBox(body, 58, 58, 7, -5.2839F, -22.5913F, 2, 2, 1, 0.1F));
        body.cubeList.add(new ModelBox(body, 0, 39, 6, -3.2839F, -22.5913F, 4, 1, 1, 0));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(9, -1.2839F, -20.5913F);
        body.addChild(cube_r1);
        setRotationAngle(cube_r1, 0, 0, 1.0908F);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 0, 0, -10, -1.7087F, 1, 10, 1, 0));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(7, -1.2839F, -20.5913F);
        body.addChild(cube_r2);
        setRotationAngle(cube_r2, 0, 0, -1.0908F);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 60, 16, -1, -10, -1.7087F, 1, 10, 1, 0));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(1, -2.2839F, -7.5913F);
        body.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.1309F, 0, 0);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 32, 62, 0, -1, -15, 15, 1, 1, 0));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 143, 184, 14, -1, -15, 1, 1, 15, 0));
        cube_r3.cubeList.add(new ModelBox(cube_r3, 81, 187, -1, -1, -15, 1, 1, 15, 0));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(20, -1.2839F, -7.5913F);
        body.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.1309F, 0, 0);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 5, 44, -10, 0, -14, 1, 1, 7, 0.4F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 96, 0, -15, 0, -14, 1, 1, 7, 0.4F));
        cube_r4.cubeList.add(new ModelBox(cube_r4, 173, 164, -19, -1, -14, 14, 1, 7, 0.4F));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(1, -0.2839F, -6.5913F);
        body.addChild(cube_r5);
        setRotationAngle(cube_r5, 0.3491F, 0, 0);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 174, 103, -4, 0, -15, 22, 12, 0, 0));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(1, -2.2839F, -7.5913F);
        body.addChild(cube_r6);
        setRotationAngle(cube_r6, 0.48F, 0, 0);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 62, 0, -1, -16, 15, 1, 1, 0));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 62, 177, 14, -1, -16, 1, 1, 16, 0));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 4, 2, 10, -3, -15, 1, 1, 0, 0));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 4, 3, 3, -3, -15, 1, 1, 0, 0));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 162, 72, 0, -2, -15, 14, 1, 11, 0.3F));
        cube_r6.cubeList.add(new ModelBox(cube_r6, 0, 184, -1, -1, -16, 1, 1, 16, 0));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(14, -5.2839F, -7.5913F);
        body.addChild(cube_r7);
        setRotationAngle(cube_r7, 1.309F, 0, 0);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 145, 57, 0, 0, -11, 14, 0, 15, 0));
        cube_r7.cubeList.add(new ModelBox(cube_r7, 145, 57, -26, 0, -11, 14, 0, 15, 0));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(1.5717F, 5.1694F, -31.334F);
        body.addChild(cube_r8);
        setRotationAngle(cube_r8, 0.3054F, 1.3526F, 0.3927F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 0, 0, -3.7033F, -0.2027F, -7.2112F, 4, 0, 7, 0));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(7.0907F, 3.4783F, -27.6581F);
        body.addChild(cube_r9);
        setRotationAngle(cube_r9, 0.3491F, 0.9599F, 0.2182F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 0, 7, -3.9016F, 0.2974F, -7.1541F, 4, 0, 7, 0));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(9, 1.7161F, -20.5913F);
        body.addChild(cube_r10);
        setRotationAngle(cube_r10, 0.3491F, 0.3927F, 0);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 20, 32, -3, -0.5453F, -7.6219F, 4, 0, 17, 0));

        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(13, -10.2839F, -17.5913F);
        body.addChild(cube_r11);
        setRotationAngle(cube_r11, 0, 0, -0.6109F);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 0, 91, 0, 0, -1, 4, 3, 2, 0));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(3, -10.2839F, -17.5913F);
        body.addChild(cube_r12);
        setRotationAngle(cube_r12, 0, 0, 0.6109F);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 68, 91, -4, 0, -1, 4, 3, 2, 0));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(12, 5.7161F, -7.5913F);
        body.addChild(cube_r13);
        setRotationAngle(cube_r13, 0, 0, -0.2618F);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 184, 32, -4, -23, -11, 8, 8, 8, 0));

        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(8, 1.7161F, 7.4087F);
        body.addChild(cube_r14);
        setRotationAngle(cube_r14, 0.2182F, 0, 0);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 37, 135, -5, -11, -15, 11, 11, 15, 0));
        cube_r14.cubeList.add(new ModelBox(cube_r14, 42, 78, 0.5F, -19, -13, 0, 8, 13, 0));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(9, -6.8875F, 19.6959F);
        body.addChild(cube_r15);
        setRotationAngle(cube_r15, 0.6109F, 0, 0);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 126, 168, -0.5F, -18, -15, 0, 7, 16, 0));
        cube_r15.cubeList.add(new ModelBox(cube_r15, 136, 14, -6, -11, -15, 11, 11, 15, 0));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(9, -4.2544F, 27.8925F);
        body.addChild(cube_r16);
        setRotationAngle(cube_r16, -0.0436F, 0, 0);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 96, 37, -0.5F, -18, -17, 0, 7, 19, 0));
        cube_r16.cubeList.add(new ModelBox(cube_r16, 89, 139, -6, -11, -15, 11, 11, 15, 0));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(9, 3, 32);
        body.addChild(cube_r17);
        setRotationAngle(cube_r17, -0.7418F, 0, 0);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 36, -0.5F, -19, -16, 0, 9, 6, 0));
        cube_r17.cubeList.add(new ModelBox(cube_r17, 0, 147, -6, -11, -15, 11, 11, 15, 0));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(8, -4.0146F, 155.5364F);
        body.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.6109F, 0, 0);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 144, 95, 0, -10, 0, 0, 10, 21, 0));
        cube_r18.cubeList.add(new ModelBox(cube_r18, 96, 0, -3, 0, 0, 6, 8, 21, 0));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(8, -1.8589F, 138.4548F);
        body.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.1745F, 0, 0);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 52, 144, 0, -12, 0, 0, 12, 21, 0));
        cube_r19.cubeList.add(new ModelBox(cube_r19, 0, 32, -4, 0, 0, 8, 9, 21, 0));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(8, -3.8589F, 109.4548F);
        body.addChild(cube_r20);
        setRotationAngle(cube_r20, -0.0873F, 0, 0);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 94, 149, 0, -11, 0, 0, 22, 16, 0));
        cube_r20.cubeList.add(new ModelBox(cube_r20, 96, 29, -6, 0, 0, 12, 11, 16, 0));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(8, -8, 96);
        body.addChild(cube_r21);
        setRotationAngle(cube_r21, -0.2618F, 0, 0);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 0, 154, 0, -11, -3, 0, 11, 19, 0));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 68, 80, -7, 0, 0, 14, 11, 16, 0));

        bone2 = new ModelRenderer(this);
        bone2.setRotationPoint(-8.594F, -9.0004F, 14.7842F);
        body.addChild(bone2);


        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(33.188F, 0, 0);
        bone2.addChild(cube_r22);
        setRotationAngle(cube_r22, -0.0873F, -0.6109F, -0.3491F);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 74, 92, 2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 0, 120, -2.1284F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(28.4256F, 2.9391F, 11.1484F);
        bone2.addChild(cube_r23);
        setRotationAngle(cube_r23, -0.0873F, -0.3927F, -0.3491F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 162, 72, 2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r23.cubeList.add(new ModelBox(cube_r23, 167, 141, -2.1284F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(10.594F, 12.0004F, 14.2158F);
        bone2.addChild(cube_r24);
        setRotationAngle(cube_r24, -0.3491F, -1.0036F, 0);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 46, 161, 10, -16, -18, 0, 8, 16, 0));
        cube_r24.cubeList.add(new ModelBox(cube_r24, 38, 107, 5, -8, -20, 9, 10, 18, 0));

        head = new ModelRenderer(this);
        head.setRotationPoint(0, 0, 0);
        group.addChild(head);


        head2 = new ModelRenderer(this);
        head2.setRotationPoint(6, -14, 33);
        head.addChild(head2);


        bone = new ModelRenderer(this);
        bone.setRotationPoint(-1, -9, 1);
        head2.addChild(bone);


        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(9, 5, -5);
        bone.addChild(cube_r25);
        setRotationAngle(cube_r25, -0.3491F, 1.0036F, 0);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 47, 161, -10, -16, -18, 0, 8, 16, 0));
        cube_r25.cubeList.add(new ModelBox(cube_r25, 38, 107, -14, -8, -20, 9, 10, 18, 0));

        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(-9, -4, -5);
        bone.addChild(bone4);


        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(0.1684F, -0.0612F, -3.0674F);
        bone4.addChild(cube_r26);
        setRotationAngle(cube_r26, -0.0873F, 0.3927F, 0.3491F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 162, 72, -2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r26.cubeList.add(new ModelBox(cube_r26, 167, 140, -6.8716F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(-4, -4, -10);
        bone4.addChild(bone5);


        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(-0.594F, 0.9996F, -4.2158F);
        bone5.addChild(cube_r27);
        setRotationAngle(cube_r27, -0.0873F, 0.6109F, 0.3491F);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 75, 92, -2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r27.cubeList.add(new ModelBox(cube_r27, 0, 119, -6.8716F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(-8, -5, -11);
        bone5.addChild(bone6);


        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone6.addChild(cube_r28);
        setRotationAngle(cube_r28, -0.0873F, 0.1309F, 0.1309F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 54, 32, 0.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 54, 0, -7.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 0, 32, -7.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 44, 8, 0.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 0, 33, -4.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 14, 48, -3.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 0, 32, -4.4153F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 92, 107, -9.4153F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(3.406F, -6.0004F, -8.2158F);
        bone6.addChild(cube_r29);
        setRotationAngle(cube_r29, -0.0873F, 0.1309F, 0.6981F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(-7.594F, -6.0004F, -8.2158F);
        bone6.addChild(cube_r30);
        setRotationAngle(cube_r30, -0.0873F, 0.1309F, -0.6981F);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone6.addChild(cube_r31);
        setRotationAngle(cube_r31, -0.0436F, 0.1309F, 0.1309F);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 0, 212, -0.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r31.cubeList.add(new ModelBox(cube_r31, 0, 212, -5.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r31.cubeList.add(new ModelBox(cube_r31, 164, 126, -9.027F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r31.cubeList.add(new ModelBox(cube_r31, 129, 0, -10.027F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone6.addChild(cube_r32);
        setRotationAngle(cube_r32, 0.3054F, 0.1309F, 0.1309F);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 4, 0, 0.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 4, 0, -6.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 16, 1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 173, 19, -9.027F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 186, 115, -11.027F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 138, 42, -10.027F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone6.addChild(cube_r33);
        setRotationAngle(cube_r33, -0.1745F, 0.1309F, 0.1309F);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 175, 57, 4.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r33.cubeList.add(new ModelBox(cube_r33, 188, 57, -22.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(7.1447F, 6.0519F, -9.4387F);
        bone6.addChild(cube_r34);
        setRotationAngle(cube_r34, -0.0873F, 0.6109F, 0.1309F);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 36, 0, -4.4153F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        bone7 = new ModelRenderer(this);
        bone7.setRotationPoint(-1, -3, -2);
        head2.addChild(bone7);
        setRotationAngle(bone7, 0.6981F, -0.0436F, -0.3054F);


        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(9, 5, -5);
        bone7.addChild(cube_r35);
        setRotationAngle(cube_r35, -0.3491F, 1.0036F, 0);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 47, 161, -10, -16, -18, 0, 8, 16, 0));
        cube_r35.cubeList.add(new ModelBox(cube_r35, 37, 107, -14, -8, -20, 9, 10, 18, 0));

        bone8 = new ModelRenderer(this);
        bone8.setRotationPoint(-9, -4, -5);
        bone7.addChild(bone8);
        setRotationAngle(bone8, 0, 0.3927F, 0);


        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(0.1684F, -0.0612F, -3.0674F);
        bone8.addChild(cube_r36);
        setRotationAngle(cube_r36, -0.0873F, 0.3927F, 0.3491F);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 163, 72, -2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r36.cubeList.add(new ModelBox(cube_r36, 167, 141, -6.8716F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        bone9 = new ModelRenderer(this);
        bone9.setRotationPoint(-4, -4, -10);
        bone8.addChild(bone9);
        setRotationAngle(bone9, 0.0436F, 0, 0);


        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(-0.594F, 0.9996F, -4.2158F);
        bone9.addChild(cube_r37);
        setRotationAngle(cube_r37, -0.0873F, 0.6109F, 0.3491F);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 75, 91, -2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r37.cubeList.add(new ModelBox(cube_r37, 0, 119, -6.8716F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(-8, -5, -11);
        bone9.addChild(bone10);
        setRotationAngle(bone10, -0.48F, 0, -0.2618F);


        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone10.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.0873F, 0.1309F, 0.1309F);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 53, 32, 0.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 54, 0, -7.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 32, -7.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 44, 8, 0.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 33, -4.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 14, 48, -3.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 32, -4.4153F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r38.cubeList.add(new ModelBox(cube_r38, 92, 107, -9.4153F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(3.406F, -6.0004F, -8.2158F);
        bone10.addChild(cube_r39);
        setRotationAngle(cube_r39, -0.0873F, 0.1309F, 0.6981F);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(-7.594F, -6.0004F, -8.2158F);
        bone10.addChild(cube_r40);
        setRotationAngle(cube_r40, -0.0873F, 0.1309F, -0.6981F);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone10.addChild(cube_r41);
        setRotationAngle(cube_r41, -0.0436F, 0.1309F, 0.1309F);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 0, 212, -0.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r41.cubeList.add(new ModelBox(cube_r41, 0, 212, -5.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r41.cubeList.add(new ModelBox(cube_r41, 164, 126, -9.027F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r41.cubeList.add(new ModelBox(cube_r41, 128, 0, -10.027F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone10.addChild(cube_r42);
        setRotationAngle(cube_r42, 0.3054F, 0.1309F, 0.1309F);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 4, 0, 0.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r42.cubeList.add(new ModelBox(cube_r42, 4, 0, -6.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r42.cubeList.add(new ModelBox(cube_r42, 0, 16, 1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r42.cubeList.add(new ModelBox(cube_r42, 173, 19, -9.027F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r42.cubeList.add(new ModelBox(cube_r42, 186, 115, -11.027F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r42.cubeList.add(new ModelBox(cube_r42, 138, 42, -10.027F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone10.addChild(cube_r43);
        setRotationAngle(cube_r43, -0.1745F, 0.1309F, 0.1309F);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 175, 57, 4.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r43.cubeList.add(new ModelBox(cube_r43, 188, 56, -22.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(7.1447F, 6.0519F, -9.4387F);
        bone10.addChild(cube_r44);
        setRotationAngle(cube_r44, -0.0873F, 0.6109F, 0.1309F);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 36, 0, -4.4153F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        bone11 = new ModelRenderer(this);
        bone11.setRotationPoint(5, -3, -2);
        head2.addChild(bone11);
        setRotationAngle(bone11, 0.6981F, 0.0436F, 0.3054F);


        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(-9, 5, -5);
        bone11.addChild(cube_r45);
        setRotationAngle(cube_r45, -0.3491F, -1.0036F, 0);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 46, 159, 10, -16, -18, 0, 8, 16, 0));
        cube_r45.cubeList.add(new ModelBox(cube_r45, 37, 107, 5, -8, -20, 9, 10, 18, 0));

        bone12 = new ModelRenderer(this);
        bone12.setRotationPoint(9, -4, -5);
        bone11.addChild(bone12);
        setRotationAngle(bone12, 0, -0.3927F, 0);


        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(-0.1684F, -0.0612F, -3.0674F);
        bone12.addChild(cube_r46);
        setRotationAngle(cube_r46, -0.0873F, -0.3927F, -0.3491F);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 113, 72, 2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r46.cubeList.add(new ModelBox(cube_r46, 167, 140, -2.1284F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        bone13 = new ModelRenderer(this);
        bone13.setRotationPoint(4, -4, -10);
        bone12.addChild(bone13);
        setRotationAngle(bone13, 0.0436F, 0, 0);


        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(0.594F, 0.9996F, -4.2158F);
        bone13.addChild(cube_r47);
        setRotationAngle(cube_r47, -0.0873F, -0.6109F, -0.3491F);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 75, 92, 2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r47.cubeList.add(new ModelBox(cube_r47, 0, 119, -2.1284F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        bone14 = new ModelRenderer(this);
        bone14.setRotationPoint(8, -5, -11);
        bone13.addChild(bone14);
        setRotationAngle(bone14, -0.48F, 0, 0.2618F);


        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(-1.406F, 5.9996F, 0.7842F);
        bone14.addChild(cube_r48);
        setRotationAngle(cube_r48, -0.0873F, -0.1309F, -0.1309F);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 54, 32, -2.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 54, 33, 5.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 44, 8, 5.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 0, 32, -2.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 0, 33, 0.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 14, 48, 1.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 0, 32, -0.5847F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 92, 106, -4.5847F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(-3.406F, -6.0004F, -8.2158F);
        bone14.addChild(cube_r49);
        setRotationAngle(cube_r49, -0.0873F, -0.1309F, -0.6981F);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 0, 16, -3.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(7.594F, -6.0004F, -8.2158F);
        bone14.addChild(cube_r50);
        setRotationAngle(cube_r50, -0.0873F, -0.1309F, 0.6981F);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 0, 16, -3.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(-1.406F, 2.9996F, 0.7842F);
        bone14.addChild(cube_r51);
        setRotationAngle(cube_r51, -0.0436F, -0.1309F, -0.1309F);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 0, 212, -0.973F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r51.cubeList.add(new ModelBox(cube_r51, 0, 211, 4.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r51.cubeList.add(new ModelBox(cube_r51, 163, 73, -4.973F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r51.cubeList.add(new ModelBox(cube_r51, 129, 0, -5.973F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(-1.406F, 2.9996F, 0.7842F);
        bone14.addChild(cube_r52);
        setRotationAngle(cube_r52, 0.3054F, -0.1309F, -0.1309F);
        cube_r52.cubeList.add(new ModelBox(cube_r52, 4, 0, -1.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r52.cubeList.add(new ModelBox(cube_r52, 4, 0, 5.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r52.cubeList.add(new ModelBox(cube_r52, 0, 16, -1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r52.cubeList.add(new ModelBox(cube_r52, 173, 163, -4.973F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r52.cubeList.add(new ModelBox(cube_r52, 186, 115, -6.973F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r52.cubeList.add(new ModelBox(cube_r52, 138, 42, -5.973F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(-1.406F, 5.9996F, 0.7842F);
        bone14.addChild(cube_r53);
        setRotationAngle(cube_r53, -0.1745F, -0.1309F, -0.1309F);
        cube_r53.cubeList.add(new ModelBox(cube_r53, 35, 192, -17.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r53.cubeList.add(new ModelBox(cube_r53, 188, 57, 9.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(-7.1447F, 6.0519F, -9.4387F);
        bone14.addChild(cube_r54);
        setRotationAngle(cube_r54, -0.0873F, -0.6109F, -0.1309F);
        cube_r54.cubeList.add(new ModelBox(cube_r54, 36, 0, -0.5847F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        bone15 = new ModelRenderer(this);
        bone15.setRotationPoint(14, -9, 6);
        head2.addChild(bone15);
        setRotationAngle(bone15, -0.4363F, -0.6545F, 0.3054F);


        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(-9, 5, -5);
        bone15.addChild(cube_r55);
        setRotationAngle(cube_r55, -0.3491F, -1.0036F, 0);
        cube_r55.cubeList.add(new ModelBox(cube_r55, 47, 161, 10, -16, -18, 0, 8, 16, 0));
        cube_r55.cubeList.add(new ModelBox(cube_r55, 38, 106, 5, -8, -20, 9, 10, 18, 0));

        bone16 = new ModelRenderer(this);
        bone16.setRotationPoint(9, -4, -5);
        bone15.addChild(bone16);
        setRotationAngle(bone16, 0.1309F, -0.0436F, 0.1745F);


        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(-0.1684F, -0.0612F, -3.0674F);
        bone16.addChild(cube_r56);
        setRotationAngle(cube_r56, -0.0873F, -0.3927F, -0.3491F);
        cube_r56.cubeList.add(new ModelBox(cube_r56, 162, 72, 2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r56.cubeList.add(new ModelBox(cube_r56, 167, 141, -2.1284F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        bone17 = new ModelRenderer(this);
        bone17.setRotationPoint(4, -4, -10);
        bone16.addChild(bone17);
        setRotationAngle(bone17, 0.0436F, 0.2618F, 0);


        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(0.594F, 0.9996F, -4.2158F);
        bone17.addChild(cube_r57);
        setRotationAngle(cube_r57, -0.0873F, -0.6109F, -0.3491F);
        cube_r57.cubeList.add(new ModelBox(cube_r57, 74, 92, 2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r57.cubeList.add(new ModelBox(cube_r57, 0, 120, -2.1284F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        bone18 = new ModelRenderer(this);
        bone18.setRotationPoint(8, -5, -11);
        bone17.addChild(bone18);
        setRotationAngle(bone18, 0.2618F, 0.3491F, 0.2618F);


        cube_r58 = new ModelRenderer(this);
        cube_r58.setRotationPoint(-1.406F, 5.9996F, 0.7842F);
        bone18.addChild(cube_r58);
        setRotationAngle(cube_r58, -0.0873F, -0.1309F, -0.1309F);
        cube_r58.cubeList.add(new ModelBox(cube_r58, 54, 0, -2.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 54, 0, 5.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 32, 5.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 32, -2.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 14, 0.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 14, 48, 1.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 0, 32, -0.5847F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r58.cubeList.add(new ModelBox(cube_r58, 92, 107, -4.5847F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r59 = new ModelRenderer(this);
        cube_r59.setRotationPoint(-3.406F, -6.0004F, -8.2158F);
        bone18.addChild(cube_r59);
        setRotationAngle(cube_r59, -0.0873F, -0.1309F, -0.6981F);
        cube_r59.cubeList.add(new ModelBox(cube_r59, 0, 16, -3.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r60 = new ModelRenderer(this);
        cube_r60.setRotationPoint(7.594F, -6.0004F, -8.2158F);
        bone18.addChild(cube_r60);
        setRotationAngle(cube_r60, -0.0873F, -0.1309F, 0.6981F);
        cube_r60.cubeList.add(new ModelBox(cube_r60, 0, 16, -3.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r61 = new ModelRenderer(this);
        cube_r61.setRotationPoint(-1.406F, 2.9996F, 0.7842F);
        bone18.addChild(cube_r61);
        setRotationAngle(cube_r61, -0.0436F, -0.1309F, -0.1309F);
        cube_r61.cubeList.add(new ModelBox(cube_r61, 0, 211, -0.973F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r61.cubeList.add(new ModelBox(cube_r61, 0, 211, 4.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r61.cubeList.add(new ModelBox(cube_r61, 165, 126, -4.973F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r61.cubeList.add(new ModelBox(cube_r61, 129, 0, -5.973F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r62 = new ModelRenderer(this);
        cube_r62.setRotationPoint(-1.406F, 2.9996F, 0.7842F);
        bone18.addChild(cube_r62);
        setRotationAngle(cube_r62, 0.3054F, -0.1309F, -0.1309F);
        cube_r62.cubeList.add(new ModelBox(cube_r62, 4, 0, -1.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r62.cubeList.add(new ModelBox(cube_r62, 4, 0, 5.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r62.cubeList.add(new ModelBox(cube_r62, 0, 16, -1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r62.cubeList.add(new ModelBox(cube_r62, 173, 19, -4.973F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r62.cubeList.add(new ModelBox(cube_r62, 187, 115, -6.973F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r62.cubeList.add(new ModelBox(cube_r62, 138, 42, -5.973F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r63 = new ModelRenderer(this);
        cube_r63.setRotationPoint(-1.406F, 5.9996F, 0.7842F);
        bone18.addChild(cube_r63);
        setRotationAngle(cube_r63, -0.1745F, -0.1309F, -0.1309F);
        cube_r63.cubeList.add(new ModelBox(cube_r63, 34, 192, -17.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r63.cubeList.add(new ModelBox(cube_r63, 188, 57, 9.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r64 = new ModelRenderer(this);
        cube_r64.setRotationPoint(-7.1447F, 6.0519F, -9.4387F);
        bone18.addChild(cube_r64);
        setRotationAngle(cube_r64, -0.0873F, -0.6109F, -0.1309F);
        cube_r64.cubeList.add(new ModelBox(cube_r64, 36, 1, -0.5847F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        bone19 = new ModelRenderer(this);
        bone19.setRotationPoint(-10, -9, 6);
        head2.addChild(bone19);
        setRotationAngle(bone19, -0.4363F, 0.6545F, -0.3054F);


        cube_r65 = new ModelRenderer(this);
        cube_r65.setRotationPoint(9, 5, -5);
        bone19.addChild(cube_r65);
        setRotationAngle(cube_r65, -0.3491F, 1.0036F, 0);
        cube_r65.cubeList.add(new ModelBox(cube_r65, 74, 91, -10, -16, -18, 0, 8, 16, 0));
        cube_r65.cubeList.add(new ModelBox(cube_r65, 39, 107, -14, -8, -20, 9, 10, 17, 0));

        bone20 = new ModelRenderer(this);
        bone20.setRotationPoint(-9, -4, -5);
        bone19.addChild(bone20);
        setRotationAngle(bone20, 0.1309F, 0.0436F, -0.1745F);


        cube_r66 = new ModelRenderer(this);
        cube_r66.setRotationPoint(0.1684F, -0.0612F, -3.0674F);
        bone20.addChild(cube_r66);
        setRotationAngle(cube_r66, -0.0873F, 0.3927F, 0.3491F);
        cube_r66.cubeList.add(new ModelBox(cube_r66, 162, 72, -2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r66.cubeList.add(new ModelBox(cube_r66, 166, 141, -6.8716F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        bone21 = new ModelRenderer(this);
        bone21.setRotationPoint(-4, -4, -10);
        bone20.addChild(bone21);
        setRotationAngle(bone21, 0.0436F, -0.2618F, 0);


        cube_r67 = new ModelRenderer(this);
        cube_r67.setRotationPoint(-0.594F, 0.9996F, -4.2158F);
        bone21.addChild(cube_r67);
        setRotationAngle(cube_r67, -0.0873F, 0.6109F, 0.3491F);
        cube_r67.cubeList.add(new ModelBox(cube_r67, 75, 92, -2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r67.cubeList.add(new ModelBox(cube_r67, 0, 119, -6.8716F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        bone22 = new ModelRenderer(this);
        bone22.setRotationPoint(-8, -5, -11);
        bone21.addChild(bone22);
        setRotationAngle(bone22, 0.2618F, -0.3491F, -0.2618F);


        cube_r68 = new ModelRenderer(this);
        cube_r68.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone22.addChild(cube_r68);
        setRotationAngle(cube_r68, -0.0873F, 0.1309F, 0.1309F);
        cube_r68.cubeList.add(new ModelBox(cube_r68, 54, 0, 0.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 54, 0, -7.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 44, 8, -7.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 0, 32, 0.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 0, 33, -4.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 14, 48, -3.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 0, 32, -4.4153F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r68.cubeList.add(new ModelBox(cube_r68, 91, 107, -9.4153F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r69 = new ModelRenderer(this);
        cube_r69.setRotationPoint(3.406F, -6.0004F, -8.2158F);
        bone22.addChild(cube_r69);
        setRotationAngle(cube_r69, -0.0873F, 0.1309F, 0.6981F);
        cube_r69.cubeList.add(new ModelBox(cube_r69, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r70 = new ModelRenderer(this);
        cube_r70.setRotationPoint(-7.594F, -6.0004F, -8.2158F);
        bone22.addChild(cube_r70);
        setRotationAngle(cube_r70, -0.0873F, 0.1309F, -0.6981F);
        cube_r70.cubeList.add(new ModelBox(cube_r70, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r71 = new ModelRenderer(this);
        cube_r71.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone22.addChild(cube_r71);
        setRotationAngle(cube_r71, -0.0436F, 0.1309F, 0.1309F);
        cube_r71.cubeList.add(new ModelBox(cube_r71, 0, 212, -0.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r71.cubeList.add(new ModelBox(cube_r71, 0, 211, -5.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r71.cubeList.add(new ModelBox(cube_r71, 164, 126, -9.027F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r71.cubeList.add(new ModelBox(cube_r71, 129, 0, -10.027F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r72 = new ModelRenderer(this);
        cube_r72.setRotationPoint(1.406F, 2.9996F, 0.7842F);
        bone22.addChild(cube_r72);
        setRotationAngle(cube_r72, 0.3054F, 0.1309F, 0.1309F);
        cube_r72.cubeList.add(new ModelBox(cube_r72, 4, 0, 0.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 4, 0, -6.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 0, 16, 1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 173, 19, -9.027F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 186, 115, -11.027F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r72.cubeList.add(new ModelBox(cube_r72, 138, 42, -10.027F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r73 = new ModelRenderer(this);
        cube_r73.setRotationPoint(1.406F, 5.9996F, 0.7842F);
        bone22.addChild(cube_r73);
        setRotationAngle(cube_r73, -0.1745F, 0.1309F, 0.1309F);
        cube_r73.cubeList.add(new ModelBox(cube_r73, 174, 57, 4.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r73.cubeList.add(new ModelBox(cube_r73, 188, 57, -22.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r74 = new ModelRenderer(this);
        cube_r74.setRotationPoint(7.1447F, 6.0519F, -9.4387F);
        bone22.addChild(cube_r74);
        setRotationAngle(cube_r74, -0.0873F, 0.6109F, 0.1309F);
        cube_r74.cubeList.add(new ModelBox(cube_r74, 36, 0, -4.4153F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        bone23 = new ModelRenderer(this);
        bone23.setRotationPoint(2, -18, 8);
        head2.addChild(bone23);
        setRotationAngle(bone23, -1.3526F, -0.2182F, 1.0036F);


        cube_r75 = new ModelRenderer(this);
        cube_r75.setRotationPoint(9, 5, -5);
        bone23.addChild(cube_r75);
        setRotationAngle(cube_r75, -0.3491F, 1.0036F, 0);
        cube_r75.cubeList.add(new ModelBox(cube_r75, 75, 91, -10, -16, -18, 0, 8, 16, 0));
        cube_r75.cubeList.add(new ModelBox(cube_r75, 37, 107, -14, -8, -20, 9, 10, 18, 0));

        bone24 = new ModelRenderer(this);
        bone24.setRotationPoint(-9, -4, -5);
        bone23.addChild(bone24);
        setRotationAngle(bone24, 0, 0.6545F, -0.6109F);


        cube_r76 = new ModelRenderer(this);
        cube_r76.setRotationPoint(1.694F, -0.9206F, -3.5485F);
        bone24.addChild(cube_r76);
        setRotationAngle(cube_r76, -0.0873F, 0.3927F, 0.3491F);
        cube_r76.cubeList.add(new ModelBox(cube_r76, 162, 72, -2.8716F, -12.1979F, -8.4368F, 0, 8, 12, 0));
        cube_r76.cubeList.add(new ModelBox(cube_r76, 167, 141, -6.8716F, -4.1979F, -9.4368F, 9, 10, 13, 0));

        bone25 = new ModelRenderer(this);
        bone25.setRotationPoint(-4, -4, -10);
        bone24.addChild(bone25);
        setRotationAngle(bone25, 0.6545F, 0.0873F, -0.3054F);


        cube_r77 = new ModelRenderer(this);
        cube_r77.setRotationPoint(1.5631F, 1.0305F, -3.3639F);
        bone25.addChild(cube_r77);
        setRotationAngle(cube_r77, -0.0873F, 0.6109F, 0.3491F);
        cube_r77.cubeList.add(new ModelBox(cube_r77, 74, 92, -2.8716F, -12.1979F, -11.4368F, 0, 8, 15, 0));
        cube_r77.cubeList.add(new ModelBox(cube_r77, 0, 119, -6.8716F, -4.1979F, -13.4368F, 9, 10, 17, 0));

        bone26 = new ModelRenderer(this);
        bone26.setRotationPoint(-8, -5, -11);
        bone25.addChild(bone26);
        setRotationAngle(bone26, 0.2618F, 0.48F, 0.1745F);


        cube_r78 = new ModelRenderer(this);
        cube_r78.setRotationPoint(3.6478F, 6.5912F, 0.7195F);
        bone26.addChild(cube_r78);
        setRotationAngle(cube_r78, -0.0873F, 0.1309F, 0.1309F);
        cube_r78.cubeList.add(new ModelBox(cube_r78, 54, 32, 0.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 54, 0, -7.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 44, 8, -7.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 0, 32, 0.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 0, 32, -4.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 14, 48, -3.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 0, 32, -4.4153F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r78.cubeList.add(new ModelBox(cube_r78, 92, 107, -9.4153F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r79 = new ModelRenderer(this);
        cube_r79.setRotationPoint(5.6478F, -5.4088F, -8.2805F);
        bone26.addChild(cube_r79);
        setRotationAngle(cube_r79, -0.0873F, 0.1309F, 0.6981F);
        cube_r79.cubeList.add(new ModelBox(cube_r79, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r80 = new ModelRenderer(this);
        cube_r80.setRotationPoint(-5.3522F, -5.4088F, -8.2805F);
        bone26.addChild(cube_r80);
        setRotationAngle(cube_r80, -0.0873F, 0.1309F, -0.6981F);
        cube_r80.cubeList.add(new ModelBox(cube_r80, 0, 16, 0.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r81 = new ModelRenderer(this);
        cube_r81.setRotationPoint(3.6478F, 3.5912F, 0.7195F);
        bone26.addChild(cube_r81);
        setRotationAngle(cube_r81, -0.0436F, 0.1309F, 0.1309F);
        cube_r81.cubeList.add(new ModelBox(cube_r81, 0, 212, -0.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r81.cubeList.add(new ModelBox(cube_r81, 0, 212, -5.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r81.cubeList.add(new ModelBox(cube_r81, 164, 126, -9.027F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r81.cubeList.add(new ModelBox(cube_r81, 129, 0, -10.027F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r82 = new ModelRenderer(this);
        cube_r82.setRotationPoint(3.6478F, 3.5912F, 0.7195F);
        bone26.addChild(cube_r82);
        setRotationAngle(cube_r82, 0.3054F, 0.1309F, 0.1309F);
        cube_r82.cubeList.add(new ModelBox(cube_r82, 4, 0, 0.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r82.cubeList.add(new ModelBox(cube_r82, 4, 0, -6.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r82.cubeList.add(new ModelBox(cube_r82, 0, 16, 1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r82.cubeList.add(new ModelBox(cube_r82, 173, 19, -9.027F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r82.cubeList.add(new ModelBox(cube_r82, 186, 115, -11.027F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r82.cubeList.add(new ModelBox(cube_r82, 138, 42, -10.027F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r83 = new ModelRenderer(this);
        cube_r83.setRotationPoint(3.6478F, 6.5912F, 0.7195F);
        bone26.addChild(cube_r83);
        setRotationAngle(cube_r83, -0.1745F, 0.1309F, 0.1309F);
        cube_r83.cubeList.add(new ModelBox(cube_r83, 35, 192, 4.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r83.cubeList.add(new ModelBox(cube_r83, 188, 57, -22.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r84 = new ModelRenderer(this);
        cube_r84.setRotationPoint(9.3865F, 6.6434F, -9.5033F);
        bone26.addChild(cube_r84);
        setRotationAngle(cube_r84, -0.0873F, 0.6109F, 0.1309F);
        cube_r84.cubeList.add(new ModelBox(cube_r84, 36, 0, -4.4153F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(10, 14, -33);
        head2.addChild(bone3);


        cube_r85 = new ModelRenderer(this);
        cube_r85.setRotationPoint(14.594F, -30.0004F, 8.7842F);
        bone3.addChild(cube_r85);
        setRotationAngle(cube_r85, -0.0873F, -0.1309F, -0.1309F);
        cube_r85.cubeList.add(new ModelBox(cube_r85, 53, 32, -2.5847F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 54, 0, 5.4153F, -30.1666F, -5.0497F, 2, 14, 2, 0));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 0, 32, 5.4153F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 44, 8, -2.5847F, -16.1666F, -5.0497F, 2, 5, 2, 0.3F));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 0, 14, 0.4153F, -5.1666F, -15.0497F, 4, 1, 1, 0));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 14, 48, 1.4153F, -7.1666F, -15.0497F, 2, 2, 1, 0.1F));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 0, 32, -0.5847F, -0.1666F, -23.0497F, 5, 0, 10, 0));
        cube_r85.cubeList.add(new ModelBox(cube_r85, 92, 107, -4.5847F, -12.1666F, -14.0497F, 14, 15, 12, 0));

        cube_r86 = new ModelRenderer(this);
        cube_r86.setRotationPoint(11.594F, -42.0004F, -0.2158F);
        bone3.addChild(cube_r86);
        setRotationAngle(cube_r86, -0.0873F, -0.1309F, -0.6981F);
        cube_r86.cubeList.add(new ModelBox(cube_r86, 96, 8, -3.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r87 = new ModelRenderer(this);
        cube_r87.setRotationPoint(23.594F, -42.0004F, -0.2158F);
        bone3.addChild(cube_r87);
        setRotationAngle(cube_r87, -0.0873F, -0.1309F, 0.6981F);
        cube_r87.cubeList.add(new ModelBox(cube_r87, 96, 13, -3.0513F, -3.5507F, -0.5379F, 3, 4, 1, 0));

        cube_r88 = new ModelRenderer(this);
        cube_r88.setRotationPoint(14.594F, -33.0004F, 8.7842F);
        bone3.addChild(cube_r88);
        setRotationAngle(cube_r88, -0.0436F, -0.1309F, -0.1309F);
        cube_r88.cubeList.add(new ModelBox(cube_r88, 0, 211, -0.973F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r88.cubeList.add(new ModelBox(cube_r88, 0, 212, 4.027F, 0.792F, -13.7396F, 1, 1, 1, 0.3F));
        cube_r88.cubeList.add(new ModelBox(cube_r88, 164, 126, -4.973F, -0.208F, -13.7396F, 14, 1, 10, 0.3F));
        cube_r88.cubeList.add(new ModelBox(cube_r88, 129, 0, -5.973F, -1.208F, -14.7396F, 16, 1, 13, 0));

        cube_r89 = new ModelRenderer(this);
        cube_r89.setRotationPoint(14.594F, -33.0004F, 8.7842F);
        bone3.addChild(cube_r89);
        setRotationAngle(cube_r89, 0.3054F, -0.1309F, -0.1309F);
        cube_r89.cubeList.add(new ModelBox(cube_r89, 4, 4, -1.973F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r89.cubeList.add(new ModelBox(cube_r89, 4, 0, 5.027F, -3.208F, -14.2842F, 1, 2, 0, 0));
        cube_r89.cubeList.add(new ModelBox(cube_r89, 0, 0, -1.973F, -3.208F, -14.2842F, 0, 2, 0, 0));
        cube_r89.cubeList.add(new ModelBox(cube_r89, 173, 19, -4.973F, -2.208F, -14.2842F, 14, 1, 8, 0.3F));
        cube_r89.cubeList.add(new ModelBox(cube_r89, 186, 115, -6.973F, -1.208F, -14.7396F, 18, 9, 0, 0));
        cube_r89.cubeList.add(new ModelBox(cube_r89, 138, 42, -5.973F, -1.208F, -15.7396F, 16, 1, 14, 0));

        cube_r90 = new ModelRenderer(this);
        cube_r90.setRotationPoint(14.594F, -30.0004F, 8.7842F);
        bone3.addChild(cube_r90);
        setRotationAngle(cube_r90, -0.1745F, -0.1309F, -0.1309F);
        cube_r90.cubeList.add(new ModelBox(cube_r90, 188, 57, -17.5847F, -12.1666F, -3.0497F, 13, 15, 0, 0));
        cube_r90.cubeList.add(new ModelBox(cube_r90, 34, 192, 9.4153F, -12.1666F, -3.0497F, 13, 15, 0, 0));

        cube_r91 = new ModelRenderer(this);
        cube_r91.setRotationPoint(8.8553F, -29.9481F, -1.4387F);
        bone3.addChild(cube_r91);
        setRotationAngle(cube_r91, -0.0873F, -0.6109F, -0.1309F);
        cube_r91.cubeList.add(new ModelBox(cube_r91, 36, 0, -0.5847F, -0.1666F, -23.0497F, 5, 0, 8, 0));

        leg = new ModelRenderer(this);
        leg.setRotationPoint(19.4453F, 7.7057F, 13.6061F);
        group.addChild(leg);


        bone31 = new ModelRenderer(this);
        bone31.setRotationPoint(-5, -27, 40);
        leg.addChild(bone31);


        cube_r92 = new ModelRenderer(this);
        cube_r92.setRotationPoint(0.7886F, -9.063F, -0.6061F);
        bone31.addChild(cube_r92);
        setRotationAngle(cube_r92, 0, 0, -0.6981F);
        cube_r92.cubeList.add(new ModelBox(cube_r92, 0, 0, -13, 0, -8, 14, 16, 16, 0));

        bone27 = new ModelRenderer(this);
        bone27.setRotationPoint(5, 5, 0);
        bone31.addChild(bone27);
        setRotationAngle(bone27, -0.0436F, 0, -0.3491F);


        cube_r93 = new ModelRenderer(this);
        cube_r93.setRotationPoint(3.7886F, -3.063F, -0.6061F);
        bone27.addChild(cube_r93);
        setRotationAngle(cube_r93, -0.2182F, 0, 0.0436F);
        cube_r93.cubeList.add(new ModelBox(cube_r93, 127, 154, -7, 0, -6, 9, 16, 14, 0.1F));

        bone28 = new ModelRenderer(this);
        bone28.setRotationPoint(0, 8, -2);
        bone27.addChild(bone28);
        setRotationAngle(bone28, 0.2618F, -0.3054F, -0.0873F);


        cube_r94 = new ModelRenderer(this);
        cube_r94.setRotationPoint(3.2709F, 0.7943F, -4.8178F);
        bone28.addChild(cube_r94);
        setRotationAngle(cube_r94, -1.309F, 0, 0.0436F);
        cube_r94.cubeList.add(new ModelBox(cube_r94, 132, 80, -7, -8, -4, 9, 24, 12, 0));

        bone29 = new ModelRenderer(this);
        bone29.setRotationPoint(0, 6, -18);
        bone28.addChild(bone29);
        setRotationAngle(bone29, 0.3054F, 0.2182F, 0.3927F);


        cube_r95 = new ModelRenderer(this);
        cube_r95.setRotationPoint(3, 1, -10);
        bone29.addChild(cube_r95);
        setRotationAngle(cube_r95, -1.309F, 0, 0.0436F);
        cube_r95.cubeList.add(new ModelBox(cube_r95, 173, 173, -6, -8, -3, 7, 14, 10, 0));

        bone30 = new ModelRenderer(this);
        bone30.setRotationPoint(0, 4, -14);
        bone29.addChild(bone30);
        setRotationAngle(bone30, -0.3927F, 0, 0);


        cube_r96 = new ModelRenderer(this);
        cube_r96.setRotationPoint(0, 4, -6);
        bone30.addChild(cube_r96);
        setRotationAngle(cube_r96, 0, -0.4363F, 0.0436F);
        cube_r96.cubeList.add(new ModelBox(cube_r96, 58, 8, 0.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r96.cubeList.add(new ModelBox(cube_r96, 174, 84, -0.4419F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r97 = new ModelRenderer(this);
        cube_r97.setRotationPoint(-1, 4, -6);
        bone30.addChild(cube_r97);
        setRotationAngle(cube_r97, 0, 0, 0.0436F);
        cube_r97.cubeList.add(new ModelBox(cube_r97, 56, 4, 0.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r97.cubeList.add(new ModelBox(cube_r97, 173, 0, -0.4419F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r98 = new ModelRenderer(this);
        cube_r98.setRotationPoint(-2, 4, -5);
        bone30.addChild(cube_r98);
        setRotationAngle(cube_r98, 0, 0.4363F, 0.0436F);
        cube_r98.cubeList.add(new ModelBox(cube_r98, 54, 37, 0.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r98.cubeList.add(new ModelBox(cube_r98, 23, 173, -0.4419F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r99 = new ModelRenderer(this);
        cube_r99.setRotationPoint(-3, 4, 0);
        bone30.addChild(cube_r99);
        setRotationAngle(cube_r99, 0, 0.9163F, 0.0436F);
        cube_r99.cubeList.add(new ModelBox(cube_r99, 58, 6, 0.5581F, -2.2522F, -10, 2, 2, 1, 0));
        cube_r99.cubeList.add(new ModelBox(cube_r99, 37, 41, -0.4419F, -3.2522F, -9, 4, 4, 8, 0));

        cube_r100 = new ModelRenderer(this);
        cube_r100.setRotationPoint(3, -6, -6);
        bone30.addChild(cube_r100);
        setRotationAngle(cube_r100, 0, 0, 0.0436F);
        cube_r100.cubeList.add(new ModelBox(cube_r100, 98, 187, -6, 4, -1, 7, 7, 8, 0));

        cube_r101 = new ModelRenderer(this);
        cube_r101.setRotationPoint(3, -2, -7);
        bone30.addChild(cube_r101);
        setRotationAngle(cube_r101, 0.6545F, 0, 0.0436F);
        cube_r101.cubeList.add(new ModelBox(cube_r101, 184, 48, -6.1745F, 0.0038F, -5, 7, 3, 5, 0));

        bone32 = new ModelRenderer(this);
        bone32.setRotationPoint(-17.8906F, -27, 40);
        leg.addChild(bone32);


        cube_r102 = new ModelRenderer(this);
        cube_r102.setRotationPoint(-0.7886F, -9.063F, -0.6061F);
        bone32.addChild(cube_r102);
        setRotationAngle(cube_r102, 0, 0, 0.6981F);
        cube_r102.cubeList.add(new ModelBox(cube_r102, 0, 0, -1, 0, -8, 14, 16, 16, 0));

        bone33 = new ModelRenderer(this);
        bone33.setRotationPoint(-5, 5, 0);
        bone32.addChild(bone33);
        setRotationAngle(bone33, -0.0436F, 0, 0.3491F);


        cube_r103 = new ModelRenderer(this);
        cube_r103.setRotationPoint(-3.7886F, -3.063F, -0.6061F);
        bone33.addChild(cube_r103);
        setRotationAngle(cube_r103, -0.2182F, 0, -0.0436F);
        cube_r103.cubeList.add(new ModelBox(cube_r103, 127, 154, -2, 0, -6, 9, 16, 14, 0.1F));

        bone34 = new ModelRenderer(this);
        bone34.setRotationPoint(0, 8, -2);
        bone33.addChild(bone34);
        setRotationAngle(bone34, 0.2618F, 0.3054F, 0.0873F);


        cube_r104 = new ModelRenderer(this);
        cube_r104.setRotationPoint(-3.2709F, 0.7943F, -4.8178F);
        bone34.addChild(cube_r104);
        setRotationAngle(cube_r104, -1.309F, 0, -0.0436F);
        cube_r104.cubeList.add(new ModelBox(cube_r104, 132, 80, -2, -8, -4, 9, 24, 12, 0));

        bone35 = new ModelRenderer(this);
        bone35.setRotationPoint(0, 6, -18);
        bone34.addChild(bone35);
        setRotationAngle(bone35, 0.3054F, -0.2182F, -0.3927F);


        cube_r105 = new ModelRenderer(this);
        cube_r105.setRotationPoint(-3, 1, -10);
        bone35.addChild(cube_r105);
        setRotationAngle(cube_r105, -1.309F, 0, -0.0436F);
        cube_r105.cubeList.add(new ModelBox(cube_r105, 173, 173, -1, -8, -3, 7, 14, 10, 0));

        bone36 = new ModelRenderer(this);
        bone36.setRotationPoint(0, 4, -14);
        bone35.addChild(bone36);
        setRotationAngle(bone36, -0.3927F, 0, 0);


        cube_r106 = new ModelRenderer(this);
        cube_r106.setRotationPoint(0, 4, -6);
        bone36.addChild(cube_r106);
        setRotationAngle(cube_r106, 0, 0.4363F, -0.0436F);
        cube_r106.cubeList.add(new ModelBox(cube_r106, 0, 11, -2.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r106.cubeList.add(new ModelBox(cube_r106, 23, 173, -3.5581F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r107 = new ModelRenderer(this);
        cube_r107.setRotationPoint(1, 4, -6);
        bone36.addChild(cube_r107);
        setRotationAngle(cube_r107, 0, 0, -0.0436F);
        cube_r107.cubeList.add(new ModelBox(cube_r107, 14, 42, -2.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r107.cubeList.add(new ModelBox(cube_r107, 173, 0, -3.5581F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r108 = new ModelRenderer(this);
        cube_r108.setRotationPoint(2, 4, -5);
        bone36.addChild(cube_r108);
        setRotationAngle(cube_r108, 0, -0.4363F, -0.0436F);
        cube_r108.cubeList.add(new ModelBox(cube_r108, 14, 45, -2.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r108.cubeList.add(new ModelBox(cube_r108, 174, 84, -3.5581F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r109 = new ModelRenderer(this);
        cube_r109.setRotationPoint(3, 4, 0);
        bone36.addChild(cube_r109);
        setRotationAngle(cube_r109, 0, -0.9163F, -0.0436F);
        cube_r109.cubeList.add(new ModelBox(cube_r109, 45, 38, -2.5581F, -2.2522F, -10, 2, 2, 1, 0));
        cube_r109.cubeList.add(new ModelBox(cube_r109, 37, 41, -3.5581F, -3.2522F, -9, 4, 4, 8, 0));

        cube_r110 = new ModelRenderer(this);
        cube_r110.setRotationPoint(-3, -6, -6);
        bone36.addChild(cube_r110);
        setRotationAngle(cube_r110, 0, 0, -0.0436F);
        cube_r110.cubeList.add(new ModelBox(cube_r110, 98, 187, -1, 4, -1, 7, 7, 8, 0));

        cube_r111 = new ModelRenderer(this);
        cube_r111.setRotationPoint(-3, -2, -7);
        bone36.addChild(cube_r111);
        setRotationAngle(cube_r111, 0.6545F, 0, -0.0436F);
        cube_r111.cubeList.add(new ModelBox(cube_r111, 184, 48, -0.8255F, 0.0038F, -5, 7, 3, 5, 0));

        bone37 = new ModelRenderer(this);
        bone37.setRotationPoint(-17.8906F, -27, 75);
        leg.addChild(bone37);
        setRotationAngle(bone37, 0.1745F, 0, 0);


        cube_r112 = new ModelRenderer(this);
        cube_r112.setRotationPoint(-0.7886F, -9.063F, -0.6061F);
        bone37.addChild(cube_r112);
        setRotationAngle(cube_r112, 0, 0, 0.6981F);
        cube_r112.cubeList.add(new ModelBox(cube_r112, 0, 0, -1, 0, -8, 14, 16, 16, 0));

        bone38 = new ModelRenderer(this);
        bone38.setRotationPoint(-5, 5, 0);
        bone37.addChild(bone38);
        setRotationAngle(bone38, 0.7854F, 0, 0.3491F);


        cube_r113 = new ModelRenderer(this);
        cube_r113.setRotationPoint(-3.7886F, -3.063F, -0.6061F);
        bone38.addChild(cube_r113);
        setRotationAngle(cube_r113, -0.2182F, 0, -0.0436F);
        cube_r113.cubeList.add(new ModelBox(cube_r113, 127, 154, -2, 0, -6, 9, 16, 14, 0.1F));

        bone39 = new ModelRenderer(this);
        bone39.setRotationPoint(0, 8, -2);
        bone38.addChild(bone39);
        setRotationAngle(bone39, 1.5272F, 0, 0.0873F);


        cube_r114 = new ModelRenderer(this);
        cube_r114.setRotationPoint(-3.2709F, 0.7943F, -4.8178F);
        bone39.addChild(cube_r114);
        setRotationAngle(cube_r114, -1.309F, 0, -0.0436F);
        cube_r114.cubeList.add(new ModelBox(cube_r114, 132, 80, -2, -8, -4, 9, 24, 12, 0));

        bone40 = new ModelRenderer(this);
        bone40.setRotationPoint(-0.5197F, 3.5381F, -14.8905F);
        bone39.addChild(bone40);
        setRotationAngle(bone40, -2.0508F, -0.3927F, 0.1745F);


        cube_r115 = new ModelRenderer(this);
        cube_r115.setRotationPoint(-3, 1, -10);
        bone40.addChild(cube_r115);
        setRotationAngle(cube_r115, -1.309F, 0, -0.0436F);
        cube_r115.cubeList.add(new ModelBox(cube_r115, 173, 173, -1, -8, -3, 7, 14, 10, 0));

        bone41 = new ModelRenderer(this);
        bone41.setRotationPoint(0, 4, -14);
        bone40.addChild(bone41);
        setRotationAngle(bone41, -0.3927F, 0, 0);


        cube_r116 = new ModelRenderer(this);
        cube_r116.setRotationPoint(0, 4, -6);
        bone41.addChild(cube_r116);
        setRotationAngle(cube_r116, 0, 0.4363F, -0.0436F);
        cube_r116.cubeList.add(new ModelBox(cube_r116, 0, 11, -2.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r116.cubeList.add(new ModelBox(cube_r116, 23, 173, -3.5581F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r117 = new ModelRenderer(this);
        cube_r117.setRotationPoint(1, 4, -6);
        bone41.addChild(cube_r117);
        setRotationAngle(cube_r117, 0, 0, -0.0436F);
        cube_r117.cubeList.add(new ModelBox(cube_r117, 0, 11, -2.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r117.cubeList.add(new ModelBox(cube_r117, 173, 0, -3.5581F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r118 = new ModelRenderer(this);
        cube_r118.setRotationPoint(2, 4, -5);
        bone41.addChild(cube_r118);
        setRotationAngle(cube_r118, 0, -0.4363F, -0.0436F);
        cube_r118.cubeList.add(new ModelBox(cube_r118, 0, 11, -2.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r118.cubeList.add(new ModelBox(cube_r118, 174, 84, -3.5581F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r119 = new ModelRenderer(this);
        cube_r119.setRotationPoint(3, 4, 0);
        bone41.addChild(cube_r119);
        setRotationAngle(cube_r119, 0, -0.9163F, -0.0436F);
        cube_r119.cubeList.add(new ModelBox(cube_r119, 54, 3, -2.5581F, -2.2522F, -10, 2, 2, 1, 0));
        cube_r119.cubeList.add(new ModelBox(cube_r119, 37, 41, -3.5581F, -3.2522F, -9, 4, 4, 8, 0));

        cube_r120 = new ModelRenderer(this);
        cube_r120.setRotationPoint(-3, -6, -6);
        bone41.addChild(cube_r120);
        setRotationAngle(cube_r120, 0, 0, -0.0436F);
        cube_r120.cubeList.add(new ModelBox(cube_r120, 98, 187, -1, 4, -1, 7, 7, 8, 0));

        cube_r121 = new ModelRenderer(this);
        cube_r121.setRotationPoint(-3, -2, -7);
        bone41.addChild(cube_r121);
        setRotationAngle(cube_r121, 0.6545F, 0, -0.0436F);
        cube_r121.cubeList.add(new ModelBox(cube_r121, 184, 48, -0.8255F, 0.0038F, -5, 7, 3, 5, 0));

        bone42 = new ModelRenderer(this);
        bone42.setRotationPoint(-5, -27, 75);
        leg.addChild(bone42);
        setRotationAngle(bone42, 0.1745F, 0, 0);


        cube_r122 = new ModelRenderer(this);
        cube_r122.setRotationPoint(0.7886F, -9.063F, -0.6061F);
        bone42.addChild(cube_r122);
        setRotationAngle(cube_r122, 0, 0, -0.6981F);
        cube_r122.cubeList.add(new ModelBox(cube_r122, 0, 0, -13, 0, -8, 14, 16, 16, 0));

        bone43 = new ModelRenderer(this);
        bone43.setRotationPoint(5, 5, 0);
        bone42.addChild(bone43);
        setRotationAngle(bone43, 0.7854F, 0, -0.3491F);


        cube_r123 = new ModelRenderer(this);
        cube_r123.setRotationPoint(3.7886F, -3.063F, -0.6061F);
        bone43.addChild(cube_r123);
        setRotationAngle(cube_r123, -0.2182F, 0, 0.0436F);
        cube_r123.cubeList.add(new ModelBox(cube_r123, 127, 154, -7, 0, -6, 9, 16, 14, 0.1F));

        bone44 = new ModelRenderer(this);
        bone44.setRotationPoint(0, 8, -2);
        bone43.addChild(bone44);
        setRotationAngle(bone44, 1.5272F, 0, -0.0873F);


        cube_r124 = new ModelRenderer(this);
        cube_r124.setRotationPoint(3.2709F, 0.7943F, -4.8178F);
        bone44.addChild(cube_r124);
        setRotationAngle(cube_r124, -1.309F, 0, 0.0436F);
        cube_r124.cubeList.add(new ModelBox(cube_r124, 132, 80, -7, -8, -4, 9, 24, 12, 0));

        bone45 = new ModelRenderer(this);
        bone45.setRotationPoint(0.5197F, 3.5381F, -14.8905F);
        bone44.addChild(bone45);
        setRotationAngle(bone45, -2.0508F, 0.3927F, -0.1745F);


        cube_r125 = new ModelRenderer(this);
        cube_r125.setRotationPoint(3, 1, -10);
        bone45.addChild(cube_r125);
        setRotationAngle(cube_r125, -1.309F, 0, 0.0436F);
        cube_r125.cubeList.add(new ModelBox(cube_r125, 173, 173, -6, -8, -3, 7, 14, 10, 0));

        bone46 = new ModelRenderer(this);
        bone46.setRotationPoint(0, 4, -14);
        bone45.addChild(bone46);
        setRotationAngle(bone46, -0.3927F, 0, 0);


        cube_r126 = new ModelRenderer(this);
        cube_r126.setRotationPoint(0, 4, -6);
        bone46.addChild(cube_r126);
        setRotationAngle(cube_r126, 0, -0.4363F, 0.0436F);
        cube_r126.cubeList.add(new ModelBox(cube_r126, 57, 6, 0.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r126.cubeList.add(new ModelBox(cube_r126, 173, 0, -0.4419F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r127 = new ModelRenderer(this);
        cube_r127.setRotationPoint(-1, 4, -6);
        bone46.addChild(cube_r127);
        setRotationAngle(cube_r127, 0, 0, 0.0436F);
        cube_r127.cubeList.add(new ModelBox(cube_r127, 58, 7, 0.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r127.cubeList.add(new ModelBox(cube_r127, 174, 84, -0.4419F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r128 = new ModelRenderer(this);
        cube_r128.setRotationPoint(-2, 4, -5);
        bone46.addChild(cube_r128);
        setRotationAngle(cube_r128, 0, 0.4363F, 0.0436F);
        cube_r128.cubeList.add(new ModelBox(cube_r128, 55, 5, 0.5581F, -2.2522F, -17, 2, 2, 1, 0));
        cube_r128.cubeList.add(new ModelBox(cube_r128, 23, 173, -0.4419F, -3.2522F, -16, 4, 4, 15, 0));

        cube_r129 = new ModelRenderer(this);
        cube_r129.setRotationPoint(-3, 4, 0);
        bone46.addChild(cube_r129);
        setRotationAngle(cube_r129, 0, 0.9163F, 0.0436F);
        cube_r129.cubeList.add(new ModelBox(cube_r129, 55, 4, 0.5581F, -2.2522F, -10, 2, 2, 1, 0));
        cube_r129.cubeList.add(new ModelBox(cube_r129, 37, 41, -0.4419F, -3.2522F, -9, 4, 4, 8, 0));

        cube_r130 = new ModelRenderer(this);
        cube_r130.setRotationPoint(3, -6, -6);
        bone46.addChild(cube_r130);
        setRotationAngle(cube_r130, 0, 0, 0.0436F);
        cube_r130.cubeList.add(new ModelBox(cube_r130, 98, 187, -6, 4, -1, 7, 7, 8, 0));

        cube_r131 = new ModelRenderer(this);
        cube_r131.setRotationPoint(3, -2, -7);
        bone46.addChild(cube_r131);
        setRotationAngle(cube_r131, 0.6545F, 0, 0.0436F);
        cube_r131.cubeList.add(new ModelBox(cube_r131, 184, 48, -6.1745F, 0.0038F, -5, 7, 3, 5, 0));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        group.render(f5);
    }

    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch, float scaleFactor, Entity ent) {
        this.leg.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 0.3F * limbSwingAmount;

    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }

    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}