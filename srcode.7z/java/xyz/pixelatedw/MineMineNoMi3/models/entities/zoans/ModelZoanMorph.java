package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelZoanMorph extends ModelBase 
{

	public abstract ModelRenderer getHandRenderer();
	
}
