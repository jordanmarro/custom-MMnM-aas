package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;


import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class pteranodon extends ModelZoanMorph {
    private final ModelRenderer whole;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    private final ModelRenderer neck;
    private final ModelRenderer bone4;
    private final ModelRenderer cube_r11;
    private final ModelRenderer cube_r12;
    private final ModelRenderer cube_r13;
    private final ModelRenderer bone;
    private final ModelRenderer bone3;
    private final ModelRenderer cube_r14;
    private final ModelRenderer cube_r15;
    private final ModelRenderer cube_r16;
    private final ModelRenderer cube_r17;
    private final ModelRenderer cube_r18;
    private final ModelRenderer cube_r19;
    private final ModelRenderer cube_r20;
    private final ModelRenderer bone17;
    private final ModelRenderer bone18;
    private final ModelRenderer bone19;
    private final ModelRenderer bone20;
    private final ModelRenderer bone24;
    private final ModelRenderer leg;
    private final ModelRenderer bone6;
    private final ModelRenderer cube_r21;
    private final ModelRenderer cube_r22;
    private final ModelRenderer cube_r23;
    private final ModelRenderer cube_r24;
    private final ModelRenderer cube_r25;
    private final ModelRenderer bone5;
    private final ModelRenderer cube_r26;
    private final ModelRenderer cube_r27;
    private final ModelRenderer cube_r28;
    private final ModelRenderer cube_r29;
    private final ModelRenderer cube_r30;
    private final ModelRenderer rightwing;
    private final ModelRenderer cube_r31;
    private final ModelRenderer cube_r32;
    private final ModelRenderer cube_r33;
    private final ModelRenderer cube_r34;
    private final ModelRenderer cube_r35;
    private final ModelRenderer cube_r36;
    private final ModelRenderer bone10;
    private final ModelRenderer cube_r37;
    private final ModelRenderer cube_r38;
    private final ModelRenderer cube_r39;
    private final ModelRenderer cube_r40;
    private final ModelRenderer bone11;
    private final ModelRenderer cube_r41;
    private final ModelRenderer cube_r42;
    private final ModelRenderer bone12;
    private final ModelRenderer cube_r43;
    private final ModelRenderer cube_r44;
    private final ModelRenderer leftwing;
    private final ModelRenderer cube_r45;
    private final ModelRenderer cube_r46;
    private final ModelRenderer cube_r47;
    private final ModelRenderer cube_r48;
    private final ModelRenderer cube_r49;
    private final ModelRenderer bone14;
    private final ModelRenderer cube_r50;
    private final ModelRenderer cube_r51;
    private final ModelRenderer cube_r52;
    private final ModelRenderer cube_r53;
    private final ModelRenderer bone15;
    private final ModelRenderer cube_r54;
    private final ModelRenderer cube_r55;
    private final ModelRenderer bone16;
    private final ModelRenderer cube_r56;
    private final ModelRenderer cube_r57;

    public pteranodon() {
        textureWidth = 192;
        textureHeight = 192;

        whole = new ModelRenderer(this);
        whole.setRotationPoint(0, 33, 0);
        setRotationAngle(whole, -0.2618F, 0, 0);
        whole.cubeList.add(new ModelBox(whole, 94, 51, -6, -26, -2, 12, 6, 8, 0));
        whole.cubeList.add(new ModelBox(whole, 96, 12, -6, -26, -8, 12, 6, 6, 0.2F));
        whole.cubeList.add(new ModelBox(whole, 96, 0, -6, -26, -14, 12, 6, 6, 0.4F));

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(0, -25.1608F, -13.3262F);
        whole.addChild(cube_r1);
        setRotationAngle(cube_r1, -1.4835F, 0, 0);
        cube_r1.cubeList.add(new ModelBox(cube_r1, 0, 16, -0.5F, -1.3366F, -3.2619F, 1, 2, 2, 0.2F));

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(0, -27.1608F, -16.3262F);
        whole.addChild(cube_r2);
        setRotationAngle(cube_r2, -1.4835F, 0, 0);
        cube_r2.cubeList.add(new ModelBox(cube_r2, 0, 32, -0.5F, -1.3366F, -3.2619F, 1, 2, 2, 0.2F));

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(7.6702F, -19.4847F, -15.4839F);
        whole.addChild(cube_r3);
        setRotationAngle(cube_r3, -0.7854F, 0.6545F, -0.8727F);
        cube_r3.cubeList.add(new ModelBox(cube_r3, 96, 14, 4.5F, -6.5F, -2, 1, 1, 1, 0));

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(-7.6702F, -19.4847F, -15.4839F);
        whole.addChild(cube_r4);
        setRotationAngle(cube_r4, -0.7854F, -0.6545F, 0.8727F);
        cube_r4.cubeList.add(new ModelBox(cube_r4, 97, 53, -5.5F, -6.5F, -2, 1, 1, 1, 0));

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(4.8127F, -20.2512F, -18.1835F);
        whole.addChild(cube_r5);
        setRotationAngle(cube_r5, -0.7854F, 0.1309F, -0.3927F);
        cube_r5.cubeList.add(new ModelBox(cube_r5, 96, 16, 4.5F, -6.5F, -2, 1, 1, 1, 0));

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(-4.8127F, -20.2512F, -18.1835F);
        whole.addChild(cube_r6);
        setRotationAngle(cube_r6, -0.7854F, -0.1309F, 0.3927F);
        cube_r6.cubeList.add(new ModelBox(cube_r6, 97, 55, -5.5F, -6.5F, -2, 1, 1, 1, 0));

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(2, -21, -19);
        whole.addChild(cube_r7);
        setRotationAngle(cube_r7, -0.7854F, -0.5672F, 0.3054F);
        cube_r7.cubeList.add(new ModelBox(cube_r7, 14, 28, 4.5F, -6.5F, -5, 1, 1, 4, 0));

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(-2, -21, -19);
        whole.addChild(cube_r8);
        setRotationAngle(cube_r8, -0.7854F, 0.5672F, -0.3054F);
        cube_r8.cubeList.add(new ModelBox(cube_r8, 14, 38, -5.5F, -6.5F, -5, 1, 1, 4, 0));

        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(2, -22, -19);
        whole.addChild(cube_r9);
        setRotationAngle(cube_r9, -0.7854F, -0.5672F, 0.3054F);
        cube_r9.cubeList.add(new ModelBox(cube_r9, 0, 12, 3, -7, -1, 4, 4, 0, 0));

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(-2, -22, -19);
        whole.addChild(cube_r10);
        setRotationAngle(cube_r10, -0.7854F, 0.5672F, -0.3054F);
        cube_r10.cubeList.add(new ModelBox(cube_r10, 18, 18, -7, -7, -1, 4, 4, 0, 0));

        neck = new ModelRenderer(this);
        neck.setRotationPoint(0, -20.0005F, -13.9749F);
        whole.addChild(neck);
        setRotationAngle(neck, 0.4363F, 0, 0);


        bone4 = new ModelRenderer(this);
        bone4.setRotationPoint(0, -8.1603F, 0.6487F);
        neck.addChild(bone4);


        cube_r11 = new ModelRenderer(this);
        cube_r11.setRotationPoint(-1, -1, -4);
        bone4.addChild(cube_r11);
        setRotationAngle(cube_r11, -0.3054F, 0, 0);
        cube_r11.cubeList.add(new ModelBox(cube_r11, 118, 81, -0.5F, -0.3853F, -3.5926F, 3, 4, 3, 0.4F));

        cube_r12 = new ModelRenderer(this);
        cube_r12.setRotationPoint(0, 0, 0);
        bone4.addChild(cube_r12);
        setRotationAngle(cube_r12, -0.6109F, 0, 0);
        cube_r12.cubeList.add(new ModelBox(cube_r12, 85, 113, -2.5F, 0.6634F, -4.2619F, 5, 5, 4, 0.2F));

        cube_r13 = new ModelRenderer(this);
        cube_r13.setRotationPoint(1.6F, 7.9521F, -0.2805F);
        bone4.addChild(cube_r13);
        setRotationAngle(cube_r13, -0.9163F, 0, 0);
        cube_r13.cubeList.add(new ModelBox(cube_r13, 0, 16, -4.6F, -5, -6, 6, 6, 6, 0));

        bone = new ModelRenderer(this);
        bone.setRotationPoint(-2, -2, -7);
        bone4.addChild(bone);
        bone.cubeList.add(new ModelBox(bone, 0, 180, 2, -5.3853F, -5.5926F, 0, 6, 6, 0.3F));
        bone.cubeList.add(new ModelBox(bone, 0, 176, 2, -5.3853F, -3.5926F, 0, 6, 1, 0.4F));

        bone3 = new ModelRenderer(this);
        bone3.setRotationPoint(0, -11.1301F, 13.744F);
        bone.addChild(bone3);
        setRotationAngle(bone3, -0.5236F, 0, 0);


        cube_r14 = new ModelRenderer(this);
        cube_r14.setRotationPoint(0, 5.3579F, 6.413F);
        bone3.addChild(cube_r14);
        setRotationAngle(cube_r14, 1.4399F, 0, 0);
        cube_r14.cubeList.add(new ModelBox(cube_r14, 42, 179, 2, -6.0091F, 0.4074F, 0, 1, 3, 0.3F));

        cube_r15 = new ModelRenderer(this);
        cube_r15.setRotationPoint(0, 11.3579F, 3.413F);
        bone3.addChild(cube_r15);
        setRotationAngle(cube_r15, 1.0908F, 0, 0);
        cube_r15.cubeList.add(new ModelBox(cube_r15, 45, 185, 2, -6.0091F, 0.4074F, 0, 2, 5, 0.3F));

        cube_r16 = new ModelRenderer(this);
        cube_r16.setRotationPoint(0, 17.6528F, 0.1904F);
        bone3.addChild(cube_r16);
        setRotationAngle(cube_r16, 0.8727F, 0, 0);
        cube_r16.cubeList.add(new ModelBox(cube_r16, 32, 172, 2, -2.8705F, 7.6107F, 0, 1, 2, 0.3F));

        cube_r17 = new ModelRenderer(this);
        cube_r17.setRotationPoint(0, 15.1789F, -0.8769F);
        bone3.addChild(cube_r17);
        setRotationAngle(cube_r17, 0.1745F, 0, 0);
        cube_r17.cubeList.add(new ModelBox(cube_r17, 16, 179, 2, -4.5806F, 2.9122F, 0, 2, 2, 0.3F));

        cube_r18 = new ModelRenderer(this);
        cube_r18.setRotationPoint(0, 15.3579F, -1.587F);
        bone3.addChild(cube_r18);
        setRotationAngle(cube_r18, 0.9599F, 0, 0);
        cube_r18.cubeList.add(new ModelBox(cube_r18, 27, 178, 2, -1.5865F, 4.3137F, 0, 2, 2, 0.3F));

        cube_r19 = new ModelRenderer(this);
        cube_r19.setRotationPoint(0, 15.3579F, -1.587F);
        bone3.addChild(cube_r19);
        setRotationAngle(cube_r19, 0.6981F, 0, 0);
        cube_r19.cubeList.add(new ModelBox(cube_r19, 17, 179, 2, -6.0091F, 0.4074F, 0, 3, 5, 0.3F));

        cube_r20 = new ModelRenderer(this);
        cube_r20.setRotationPoint(0, 16.4316F, -6.2623F);
        bone3.addChild(cube_r20);
        setRotationAngle(cube_r20, 0.4363F, 0, 0);
        cube_r20.cubeList.add(new ModelBox(cube_r20, 6, 175, 2, -5.3853F, 0.4074F, 0, 4, 4, 0.3F));

        bone17 = new ModelRenderer(this);
        bone17.setRotationPoint(1, -5, -7);
        bone4.addChild(bone17);
        bone17.cubeList.add(new ModelBox(bone17, 118, 73, -4.5F, 3.6147F, -2.5926F, 7, 2, 2, 0));
        bone17.cubeList.add(new ModelBox(bone17, 65, 110, -3.5F, 0.6147F, -5.5926F, 5, 3, 5, 0));
        bone17.cubeList.add(new ModelBox(bone17, 98, 51, -4.5F, 0.6147F, -2.5926F, 1, 1, 1, 0));
        bone17.cubeList.add(new ModelBox(bone17, 97, 57, 0.5F, -0.3853F, -2.5926F, 1, 1, 1, 0));
        bone17.cubeList.add(new ModelBox(bone17, 13, 112, -3.5F, 0.6147F, -3.5926F, 5, 3, 1, 0.1F));
        bone17.cubeList.add(new ModelBox(bone17, 118, 69, -4, 3.6147F, -5.5926F, 6, 1, 3, 0));
        bone17.cubeList.add(new ModelBox(bone17, 13, 116, -3.5F, 3.6147F, -10.5926F, 5, 1, 5, 0));
        bone17.cubeList.add(new ModelBox(bone17, 60, 118, -2.5F, 2.6147F, -10.5926F, 3, 1, 5, 0));
        bone17.cubeList.add(new ModelBox(bone17, 71, 118, -2.5F, 3.6147F, -14.5926F, 3, 1, 4, 0));
        bone17.cubeList.add(new ModelBox(bone17, 0, 28, -1.5F, 2.6147F, -13.5926F, 1, 1, 3, 0));
        bone17.cubeList.add(new ModelBox(bone17, 80, 110, -8.5F, 2.6147F, -2.5926F, 5, 1, 1, 0));
        bone17.cubeList.add(new ModelBox(bone17, 46, 108, 1.5F, 0.6147F, -2.5926F, 1, 1, 1, 0));
        bone17.cubeList.add(new ModelBox(bone17, 42, 108, -3.5F, -0.3853F, -2.5926F, 1, 1, 1, 0));
        bone17.cubeList.add(new ModelBox(bone17, 118, 92, 1.5F, 2.6147F, -2.5926F, 5, 1, 1, 0));

        bone18 = new ModelRenderer(this);
        bone18.setRotationPoint(-2, 2, -5);
        bone17.addChild(bone18);
        setRotationAngle(bone18, 2.0508F, 0.3054F, 1.7017F);
        bone18.cubeList.add(new ModelBox(bone18, 0, 134, -1, -1.2392F, -0.5926F, 1, 1, 1, 0.1F));
        bone18.cubeList.add(new ModelBox(bone18, 0, 141, -1, -1.3853F, -0.5926F, 1, 1, 1, 0));

        bone19 = new ModelRenderer(this);
        bone19.setRotationPoint(0, 2, -5);
        bone17.addChild(bone19);
        setRotationAngle(bone19, 2.0508F, -0.3054F, -1.7017F);
        bone19.cubeList.add(new ModelBox(bone19, 0, 134, 0, -1.2392F, -0.5926F, 1, 1, 1, 0.1F));
        bone19.cubeList.add(new ModelBox(bone19, 0, 141, 0, -1.3853F, -0.5926F, 1, 1, 1, 0));

        bone20 = new ModelRenderer(this);
        bone20.setRotationPoint(-1, 4.1608F, -3);
        bone17.addChild(bone20);
        setRotationAngle(bone20, 0.3491F, 0, 0);
        bone20.cubeList.add(new ModelBox(bone20, 118, 77, -3, 0.4539F, -2.5926F, 6, 1, 3, 0));
        bone20.cubeList.add(new ModelBox(bone20, 116, 117, -2.5F, 0.4539F, -7.5926F, 5, 1, 5, 0));
        bone20.cubeList.add(new ModelBox(bone20, 118, 88, -1.5F, 0.4539F, -10.5926F, 3, 1, 3, 0));

        bone24 = new ModelRenderer(this);
        bone24.setRotationPoint(4, -15, 6);
        whole.addChild(bone24);


        leg = new ModelRenderer(this);
        leg.setRotationPoint(4, -15, 6);
        whole.addChild(leg);


        bone6 = new ModelRenderer(this);
        bone6.setRotationPoint(-8, 0, 0);
        leg.addChild(bone6);
        bone6.cubeList.add(new ModelBox(bone6, 0, 28, -1, -2, 0, 3, 2, 8, 0));
        bone6.cubeList.add(new ModelBox(bone6, 0, 0, -1, -2, 8, 3, 5, 1, 0));

        cube_r21 = new ModelRenderer(this);
        cube_r21.setRotationPoint(1, 3, 8);
        bone6.addChild(cube_r21);
        setRotationAngle(cube_r21, 0.5236F, 0.0436F, -0.2618F);
        cube_r21.cubeList.add(new ModelBox(cube_r21, 3, 16, 0, 2, 2, 1, 0, 1, 0));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 96, 0, 0, 1, 1, 1, 1, 1, 0));
        cube_r21.cubeList.add(new ModelBox(cube_r21, 14, 33, 0, 0, 0, 1, 2, 1, 0));

        cube_r22 = new ModelRenderer(this);
        cube_r22.setRotationPoint(-2, 3, 8);
        bone6.addChild(cube_r22);
        setRotationAngle(cube_r22, 0.5236F, 0, 0);
        cube_r22.cubeList.add(new ModelBox(cube_r22, 3, 17, 2, 2, 2, 1, 0, 1, 0));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 96, 2, 2, 1, 1, 1, 1, 1, 0));
        cube_r22.cubeList.add(new ModelBox(cube_r22, 18, 33, 2, 0, 0, 1, 2, 1, 0));

        cube_r23 = new ModelRenderer(this);
        cube_r23.setRotationPoint(0, 3, 8);
        bone6.addChild(cube_r23);
        setRotationAngle(cube_r23, 0.5236F, -0.0436F, 0.2618F);
        cube_r23.cubeList.add(new ModelBox(cube_r23, 2, 20, -1, 2, 2, 1, 0, 1, 0));
        cube_r23.cubeList.add(new ModelBox(cube_r23, 96, 4, -1, 1, 1, 1, 1, 1, 0));
        cube_r23.cubeList.add(new ModelBox(cube_r23, 0, 42, -1, 0, 0, 1, 2, 1, 0));

        cube_r24 = new ModelRenderer(this);
        cube_r24.setRotationPoint(1, -2, 8);
        bone6.addChild(cube_r24);
        setRotationAngle(cube_r24, -0.48F, 0, 0.3054F);
        cube_r24.cubeList.add(new ModelBox(cube_r24, 24, 3, -0.001F, -1.0387F, 1.9799F, 1, 1, 0, 0));
        cube_r24.cubeList.add(new ModelBox(cube_r24, 4, 42, -0.001F, -2.0387F, -0.0201F, 1, 2, 1, 0));
        cube_r24.cubeList.add(new ModelBox(cube_r24, 96, 12, -0.001F, -2.0387F, 0.9799F, 1, 1, 1, 0));

        cube_r25 = new ModelRenderer(this);
        cube_r25.setRotationPoint(3, -3, -3);
        bone6.addChild(cube_r25);
        setRotationAngle(cube_r25, 0.48F, 0, 0);
        cube_r25.cubeList.add(new ModelBox(cube_r25, 0, 112, -5, 0, 1, 4, 4, 5, 0));
        cube_r25.cubeList.add(new ModelBox(cube_r25, 29, 108, -5, -6, 1, 4, 6, 5, 0.2F));

        bone5 = new ModelRenderer(this);
        bone5.setRotationPoint(0, 0, 0);
        leg.addChild(bone5);
        bone5.cubeList.add(new ModelBox(bone5, 0, 38, -2, -2, 0, 3, 2, 8, 0));
        bone5.cubeList.add(new ModelBox(bone5, 0, 6, -2, -2, 8, 3, 5, 1, 0));

        cube_r26 = new ModelRenderer(this);
        cube_r26.setRotationPoint(-1, 3, 8);
        bone5.addChild(cube_r26);
        setRotationAngle(cube_r26, 0.5236F, -0.0436F, 0.2618F);
        cube_r26.cubeList.add(new ModelBox(cube_r26, 20, 16, -1, 2, 2, 1, 0, 1, 0));
        cube_r26.cubeList.add(new ModelBox(cube_r26, 90, 108, -1, 1, 1, 1, 1, 1, 0));
        cube_r26.cubeList.add(new ModelBox(cube_r26, 18, 43, -1, 0, 0, 1, 2, 1, 0));

        cube_r27 = new ModelRenderer(this);
        cube_r27.setRotationPoint(2, 3, 8);
        bone5.addChild(cube_r27);
        setRotationAngle(cube_r27, 0.5236F, 0, 0);
        cube_r27.cubeList.add(new ModelBox(cube_r27, 23, 23, -3, 2, 2, 1, 0, 1, 0));
        cube_r27.cubeList.add(new ModelBox(cube_r27, 30, 110, -3, 1, 1, 1, 1, 1, 0));
        cube_r27.cubeList.add(new ModelBox(cube_r27, 94, 51, -3, 0, 0, 1, 2, 1, 0));

        cube_r28 = new ModelRenderer(this);
        cube_r28.setRotationPoint(0, 3, 8);
        bone5.addChild(cube_r28);
        setRotationAngle(cube_r28, 0.5236F, 0.0436F, -0.2618F);
        cube_r28.cubeList.add(new ModelBox(cube_r28, 3, 21, 0, 2, 2, 1, 0, 1, 0));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 26, 110, 0, 1, 1, 1, 1, 1, 0));
        cube_r28.cubeList.add(new ModelBox(cube_r28, 21, 47, 0, 0, 0, 1, 2, 1, 0));

        cube_r29 = new ModelRenderer(this);
        cube_r29.setRotationPoint(-1, -2, 8);
        bone5.addChild(cube_r29);
        setRotationAngle(cube_r29, -0.48F, 0, -0.3054F);
        cube_r29.cubeList.add(new ModelBox(cube_r29, 24, 4, -0.999F, -1.0387F, 1.9799F, 1, 1, 0, 0));
        cube_r29.cubeList.add(new ModelBox(cube_r29, 14, 43, -0.999F, -2.0387F, -0.0201F, 1, 2, 1, 0));
        cube_r29.cubeList.add(new ModelBox(cube_r29, 86, 108, -0.999F, -2.0387F, 0.9799F, 1, 1, 1, 0));

        cube_r30 = new ModelRenderer(this);
        cube_r30.setRotationPoint(-3, -3, -3);
        bone5.addChild(cube_r30);
        setRotationAngle(cube_r30, 0.48F, 0, 0);
        cube_r30.cubeList.add(new ModelBox(cube_r30, 103, 113, 1, 0, 1, 4, 4, 5, 0));
        cube_r30.cubeList.add(new ModelBox(cube_r30, 47, 108, 1, -6, 1, 4, 6, 5, 0.2F));

        rightwing = new ModelRenderer(this);
        rightwing.setRotationPoint(-6.3837F, 4.2658F, -8.1666F);
        setRotationAngle(rightwing, -0.2618F, 0, 0);


        cube_r31 = new ModelRenderer(this);
        cube_r31.setRotationPoint(-7.0019F, -1, 3.691F);
        rightwing.addChild(cube_r31);
        setRotationAngle(cube_r31, -0.6545F, -0.1745F, 0);
        cube_r31.cubeList.add(new ModelBox(cube_r31, 0, 51, -28, -20, 1, 47, 19, 0, 0));

        cube_r32 = new ModelRenderer(this);
        cube_r32.setRotationPoint(-19.9789F, 0, -0.2324F);
        rightwing.addChild(cube_r32);
        setRotationAngle(cube_r32, 0, 0.0436F, 0);
        cube_r32.cubeList.add(new ModelBox(cube_r32, 70, 26, -15, -1, 1, 12, 0, 25, 0));
        cube_r32.cubeList.add(new ModelBox(cube_r32, 0, 110, -15, -1, 0, 12, 1, 1, 0));

        cube_r33 = new ModelRenderer(this);
        cube_r33.setRotationPoint(-7.0019F, 0, 1.691F);
        rightwing.addChild(cube_r33);
        setRotationAngle(cube_r33, 0, -0.1745F, 0);
        cube_r33.cubeList.add(new ModelBox(cube_r33, 0, 26, -16, -1, 1, 35, 0, 25, 0));

        cube_r34 = new ModelRenderer(this);
        cube_r34.setRotationPoint(-7.0019F, 0, 2.691F);
        rightwing.addChild(cube_r34);
        setRotationAngle(cube_r34, 0, -0.1745F, 0);
        cube_r34.cubeList.add(new ModelBox(cube_r34, 0, 108, -16, -1, 0, 16, 1, 1, 0));

        cube_r35 = new ModelRenderer(this);
        cube_r35.setRotationPoint(0, 0, 0);
        rightwing.addChild(cube_r35);
        setRotationAngle(cube_r35, 0, 0.3491F, 0);
        cube_r35.cubeList.add(new ModelBox(cube_r35, 0, 8, -8, -0.8658F, 1, 8, 0, 8, 0));
        cube_r35.cubeList.add(new ModelBox(cube_r35, 116, 113, -8, -1, 0, 8, 1, 2, 0));

        cube_r36 = new ModelRenderer(this);
        cube_r36.setRotationPoint(-7.0019F, -4, 12.691F);
        rightwing.addChild(cube_r36);
        setRotationAngle(cube_r36, -0.7854F, -0.1745F, 0);
        cube_r36.cubeList.add(new ModelBox(cube_r36, 0, 70, -29.1292F, -13.5077F, -1.5641F, 47, 19, 0, 0));

        bone10 = new ModelRenderer(this);
        bone10.setRotationPoint(-20.0242F, 1.9415F, -0.4056F);
        rightwing.addChild(bone10);


        cube_r37 = new ModelRenderer(this);
        cube_r37.setRotationPoint(0, 0, 0);
        bone10.addChild(cube_r37);
        setRotationAngle(cube_r37, 0.5672F, 0, 0);
        cube_r37.cubeList.add(new ModelBox(cube_r37, 0, 0, -14.592F, 1, 0.1075F, 1, 0, 0, 0));

        cube_r38 = new ModelRenderer(this);
        cube_r38.setRotationPoint(0.0293F, -2.5754F, -0.1925F);
        bone10.addChild(cube_r38);
        setRotationAngle(cube_r38, -0.5236F, 0.0436F, 0);
        cube_r38.cubeList.add(new ModelBox(cube_r38, 0, 38, -14.6214F, 0, 0.3F, 1, 3, 1, 0));

        cube_r39 = new ModelRenderer(this);
        cube_r39.setRotationPoint(-0.0778F, 0.3559F, -1.6683F);
        bone10.addChild(cube_r39);
        setRotationAngle(cube_r39, 0.6545F, 0.0436F, 0);
        cube_r39.cubeList.add(new ModelBox(cube_r39, 24, 0, -14.5787F, 1, 0.3F, 1, 1, 0, 0));

        cube_r40 = new ModelRenderer(this);
        cube_r40.setRotationPoint(-0.0778F, 0.3553F, -1.6675F);
        bone10.addChild(cube_r40);
        setRotationAngle(cube_r40, 0.6545F, 0.0436F, 0);
        cube_r40.cubeList.add(new ModelBox(cube_r40, 94, 56, -14.5787F, 0, 0.3F, 1, 1, 1, 0));

        bone11 = new ModelRenderer(this);
        bone11.setRotationPoint(-20.0242F, 1.9415F, -0.4056F);
        rightwing.addChild(bone11);
        setRotationAngle(bone11, 0, 1.1345F, 0);


        cube_r41 = new ModelRenderer(this);
        cube_r41.setRotationPoint(6.8715F, 0.5F, -14.1086F);
        bone11.addChild(cube_r41);
        setRotationAngle(cube_r41, 0.5672F, 0, 0);
        cube_r41.cubeList.add(new ModelBox(cube_r41, 24, 2, -15, 0, 0, 1, 1, 0, 0));
        cube_r41.cubeList.add(new ModelBox(cube_r41, 94, 54, -15, -1, 0, 1, 1, 1, 0));

        cube_r42 = new ModelRenderer(this);
        cube_r42.setRotationPoint(6.9009F, -2.0754F, -14.3011F);
        bone11.addChild(cube_r42);
        setRotationAngle(cube_r42, -0.5236F, 0.0436F, 0);
        cube_r42.cubeList.add(new ModelBox(cube_r42, 14, 38, -15, -1, 0, 1, 3, 1, 0));

        bone12 = new ModelRenderer(this);
        bone12.setRotationPoint(-48.2083F, 1.9415F, -0.4056F);
        rightwing.addChild(bone12);
        setRotationAngle(bone12, 0, -1.1345F, 0);


        cube_r43 = new ModelRenderer(this);
        cube_r43.setRotationPoint(-6.8715F, 0.5F, -14.1086F);
        bone12.addChild(cube_r43);
        setRotationAngle(cube_r43, 0.5672F, 0, 0);
        cube_r43.cubeList.add(new ModelBox(cube_r43, 24, 1, 14, 0, 0, 1, 1, 0, 0));
        cube_r43.cubeList.add(new ModelBox(cube_r43, 4, 32, 14, -1, 0, 1, 1, 1, 0));

        cube_r44 = new ModelRenderer(this);
        cube_r44.setRotationPoint(-6.9009F, -2.0754F, -14.3011F);
        bone12.addChild(cube_r44);
        setRotationAngle(cube_r44, -0.5236F, -0.0436F, 0);
        cube_r44.cubeList.add(new ModelBox(cube_r44, 4, 38, 14, -1, 0, 1, 3, 1, 0));

        leftwing = new ModelRenderer(this);
        leftwing.setRotationPoint(6.3837F, 4.2658F, -8.1666F);
        setRotationAngle(leftwing, -0.2182F, -0.1745F, 0);


        cube_r45 = new ModelRenderer(this);
        cube_r45.setRotationPoint(19.9789F, 0, -0.2324F);
        leftwing.addChild(cube_r45);
        setRotationAngle(cube_r45, 0, -0.0436F, 0);
        cube_r45.cubeList.add(new ModelBox(cube_r45, 69, 69, 3, -1, 1, 12, 0, 25, 0));
        cube_r45.cubeList.add(new ModelBox(cube_r45, 60, 108, 3, -1, 0, 12, 1, 1, 0));

        cube_r46 = new ModelRenderer(this);
        cube_r46.setRotationPoint(7.0019F, -1, 6.691F);
        leftwing.addChild(cube_r46);
        setRotationAngle(cube_r46, -0.6545F, 0.1745F, 0);
        cube_r46.cubeList.add(new ModelBox(cube_r46, 0, 89, -19, -20, 1, 47, 19, 0, 0));

        cube_r47 = new ModelRenderer(this);
        cube_r47.setRotationPoint(7.0019F, -1, 3.691F);
        leftwing.addChild(cube_r47);
        setRotationAngle(cube_r47, -0.6545F, 0.1745F, 0);
        cube_r47.cubeList.add(new ModelBox(cube_r47, 94, 94, -19, -20, 1, 47, 19, 0, 0));

        cube_r48 = new ModelRenderer(this);
        cube_r48.setRotationPoint(7.0019F, 0, 2.691F);
        leftwing.addChild(cube_r48);
        setRotationAngle(cube_r48, 0, 0.1745F, 0);
        cube_r48.cubeList.add(new ModelBox(cube_r48, 0, 0, -19, -1, 0, 35, 0, 25, 0));
        cube_r48.cubeList.add(new ModelBox(cube_r48, 96, 24, 0, -1, 0, 16, 1, 1, 0));

        cube_r49 = new ModelRenderer(this);
        cube_r49.setRotationPoint(0, 0, 0);
        leftwing.addChild(cube_r49);
        setRotationAngle(cube_r49, 0, -0.3491F, 0);
        cube_r49.cubeList.add(new ModelBox(cube_r49, 0, 0, 0, -0.8658F, 1, 8, 0, 8, 0));
        cube_r49.cubeList.add(new ModelBox(cube_r49, 0, 48, 0, -1, 0, 8, 1, 2, 0));

        bone14 = new ModelRenderer(this);
        bone14.setRotationPoint(20.0242F, 1.9415F, -0.4056F);
        leftwing.addChild(bone14);


        cube_r50 = new ModelRenderer(this);
        cube_r50.setRotationPoint(0, 0, 0);
        bone14.addChild(cube_r50);
        setRotationAngle(cube_r50, 0.5672F, 0, 0);
        cube_r50.cubeList.add(new ModelBox(cube_r50, 0, 0, 13.592F, 1, 0.1075F, 1, 0, 0, 0));

        cube_r51 = new ModelRenderer(this);
        cube_r51.setRotationPoint(-0.0293F, -2.5754F, -0.1925F);
        bone14.addChild(cube_r51);
        setRotationAngle(cube_r51, -0.5236F, -0.0436F, 0);
        cube_r51.cubeList.add(new ModelBox(cube_r51, 21, 37, 13.6214F, 0, 0.3F, 1, 3, 1, 0));

        cube_r52 = new ModelRenderer(this);
        cube_r52.setRotationPoint(0.0778F, 0.3559F, -1.6683F);
        bone14.addChild(cube_r52);
        setRotationAngle(cube_r52, 0.6545F, -0.0436F, 0);
        cube_r52.cubeList.add(new ModelBox(cube_r52, 24, 24, 13.5787F, 1, 0.3F, 1, 1, 0, 0));

        cube_r53 = new ModelRenderer(this);
        cube_r53.setRotationPoint(0.0778F, 0.3553F, -1.6675F);
        bone14.addChild(cube_r53);
        setRotationAngle(cube_r53, 0.6545F, -0.0436F, 0);
        cube_r53.cubeList.add(new ModelBox(cube_r53, 22, 16, 13.5787F, 0, 0.3F, 1, 1, 1, 0));

        bone15 = new ModelRenderer(this);
        bone15.setRotationPoint(20.0242F, 1.9415F, -0.4056F);
        leftwing.addChild(bone15);
        setRotationAngle(bone15, 0, -1.1345F, 0);


        cube_r54 = new ModelRenderer(this);
        cube_r54.setRotationPoint(-6.8715F, 0.5F, -14.1086F);
        bone15.addChild(cube_r54);
        setRotationAngle(cube_r54, 0.5672F, 0, 0);
        cube_r54.cubeList.add(new ModelBox(cube_r54, 0, 17, 14, 0, 0, 1, 1, 0, 0));
        cube_r54.cubeList.add(new ModelBox(cube_r54, 0, 20, 14, -1, 0, 1, 1, 1, 0));

        cube_r55 = new ModelRenderer(this);
        cube_r55.setRotationPoint(-6.9009F, -2.0754F, -14.3011F);
        bone15.addChild(cube_r55);
        setRotationAngle(cube_r55, -0.5236F, -0.0436F, 0);
        cube_r55.cubeList.add(new ModelBox(cube_r55, 20, 28, 14, -1, 0, 1, 3, 1, 0));

        bone16 = new ModelRenderer(this);
        bone16.setRotationPoint(48.2083F, 1.9415F, -0.4056F);
        leftwing.addChild(bone16);
        setRotationAngle(bone16, 0, 1.1345F, 0);


        cube_r56 = new ModelRenderer(this);
        cube_r56.setRotationPoint(6.8715F, 0.5F, -14.1086F);
        bone16.addChild(cube_r56);
        setRotationAngle(cube_r56, 0.5672F, 0, 0);
        cube_r56.cubeList.add(new ModelBox(cube_r56, 0, 16, -15, 0, 0, 1, 1, 0, 0));
        cube_r56.cubeList.add(new ModelBox(cube_r56, 18, 16, -15, -1, 0, 1, 1, 1, 0));

        cube_r57 = new ModelRenderer(this);
        cube_r57.setRotationPoint(6.9009F, -2.0754F, -14.3011F);
        bone16.addChild(cube_r57);
        setRotationAngle(cube_r57, -0.5236F, 0.0436F, 0);
        cube_r57.cubeList.add(new ModelBox(cube_r57, 14, 28, -15, -1, 0, 1, 3, 1, 0));
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        setRotationAngles(f, f1, f2, f3, f4, f5, entity);
        whole.render(f5);
        rightwing.render(f5);
        leftwing.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch, float scaleFactor, Entity ent)
    {
        if(!ent.onGround) {
            leftwing.rotateAngleZ = MathHelper.cos(ageInTicks * 0.6F) * 0.4F;
            rightwing.rotateAngleZ = MathHelper.cos(ageInTicks * 0.6F + (float) Math.PI) * 0.4F;
        }
    }
    @Override
    public ModelRenderer getHandRenderer() {
        return null;
    }
}