package xyz.pixelatedw.MineMineNoMi3.models.entities.zoans;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class Biped3swords extends ModelBase {
    private final ModelRenderer mouthsword;
    private final ModelRenderer Lip_r1;
    private final ModelRenderer Blade;
    private final ModelRenderer cube_r1;
    private final ModelRenderer cube_r2;
    private final ModelRenderer leftsword;
    private final ModelRenderer Handle_r1;
    private final ModelRenderer cube_r3;
    private final ModelRenderer cube_r4;
    private final ModelRenderer cube_r5;
    private final ModelRenderer cube_r6;
    private final ModelRenderer cube_r7;
    private final ModelRenderer cube_r8;
    private final ModelRenderer rightsword;
    private final ModelRenderer cube_r9;
    private final ModelRenderer cube_r10;
    public float bprotateY;
    public float bprotateX;
    public float bprotateZ;

    public Biped3swords() {
        textureWidth = 256;
        textureHeight = 256;
        mouthsword = new ModelRenderer(this);
        mouthsword.setRotationPoint(-40.6875F, 41.5625F, -57.75F);
        setRotationAngle(mouthsword, -1.5708F, -1.5708F, 1.5708F);

        Lip_r1 = new ModelRenderer(this);
        Lip_r1.setRotationPoint(21.0094F, -13.034F, -41.4087F);
        mouthsword.addChild(Lip_r1);
        setRotationAngle(Lip_r1, 3.1416F, 0, 1.5708F);
        Lip_r1.setTextureOffset(16, 30).addBox(-17.3219F, 15.4715F, 16.9087F, 2, 3, 2, 0);
        Lip_r1.setTextureOffset(132, 38).addBox(-17.3219F, 15.4715F, -15.0913F, 2, 3, 32, 0);
        Lip_r1.setTextureOffset(15, 0).addBox(-19.8219F, 13.4715F, -16.0913F, 7, 7, 1, 0);

        Blade = new ModelRenderer(this);
        Blade.setRotationPoint(-7.0625F, 12.9375F, -92.25F);
        mouthsword.addChild(Blade);

        cube_r1 = new ModelRenderer(this);
        cube_r1.setRotationPoint(28.0719F, -25.9715F, 50.8413F);
        Blade.addChild(cube_r1);
        setRotationAngle(cube_r1, 3.1416F, 0, 1.5708F);
        cube_r1.setTextureOffset(26, 15).addBox(-16.8219F, 17.385F, -84.7107F, 1, 1, 2, 0);
        cube_r1.setTextureOffset(0, 69).addBox(-16.8219F, 15.4715F, -80.0913F, 1, 3, 64, 0);
        cube_r1.setTextureOffset(0, 31).addBox(-16.8219F, 16.4715F, -82.0913F, 1, 2, 3, 0);

        cube_r2 = new ModelRenderer(this);
        cube_r2.setRotationPoint(28.0719F, -25.9715F, 50.8413F);
        Blade.addChild(cube_r2);
        setRotationAngle(cube_r2, -2.7489F, 0, 1.5708F);
        cube_r2.setTextureOffset(0, 20).addBox(-16.8219F, -16.3558F, -84.9155F, 1, 1, 5, 0);

        leftsword = new ModelRenderer(this);
        leftsword.setRotationPoint(-35.25F, 10.9796F, -20.5989F);
        setRotationAngle(leftsword, 0.7854F, 0, 0);
        leftsword.setTextureOffset(0, 10).addBox(60.6923F, 39.0394F, -24.4202F, 3, 1, 9, 0);

        Handle_r1 = new ModelRenderer(this);
        Handle_r1.setRotationPoint(23.2212F, 7.7988F, -11.6417F);
        leftsword.addChild(Handle_r1);
        setRotationAngle(Handle_r1, 1.5708F, 0, -3.1416F);
        Handle_r1.setTextureOffset(0, 0).addBox(-39.9712F, -9.7785F, 64.2406F, 2, 3, 2, 0);
        Handle_r1.setTextureOffset(66, 0).addBox(-39.9712F, -9.7785F, 32.2406F, 2, 3, 32, 0);
        Handle_r1.setTextureOffset(7, 20).addBox(-39.4712F, -7.865F, -37.3788F, 1, 1, 3, 0);
        Handle_r1.setTextureOffset(0, 10).addBox(-39.4712F, -8.7785F, -34.7594F, 1, 2, 3, 0);
        Handle_r1.setTextureOffset(0, 0).addBox(-39.4712F, -9.7785F, -32.7594F, 1, 3, 64, 0);

        cube_r3 = new ModelRenderer(this);
        cube_r3.setRotationPoint(62.1923F, 39.5394F, -19.9202F);
        leftsword.addChild(cube_r3);
        setRotationAngle(cube_r3, 0, 1.5708F, 0);
        cube_r3.setTextureOffset(0, 0).addBox(-1.5F, -0.5F, -4.5F, 3, 1, 9, 0);

        cube_r4 = new ModelRenderer(this);
        cube_r4.setRotationPoint(63.9423F, 39.5394F, -21.9202F);
        leftsword.addChild(cube_r4);
        setRotationAngle(cube_r4, 0, 2.3562F, 0);
        cube_r4.setTextureOffset(29, 29).addBox(-1.5F, -0.5F, -1.5F, 3, 1, 2, 0);

        cube_r5 = new ModelRenderer(this);
        cube_r5.setRotationPoint(60.3077F, 39.5394F, -21.9202F);
        leftsword.addChild(cube_r5);
        setRotationAngle(cube_r5, 0, -2.3562F, 0);
        cube_r5.setTextureOffset(26, 20).addBox(-1.5F, -0.5F, -1.5F, 3, 1, 2, 0);

        cube_r6 = new ModelRenderer(this);
        cube_r6.setRotationPoint(62.125F, 39.5394F, -18.5666F);
        leftsword.addChild(cube_r6);
        setRotationAngle(cube_r6, 0, -0.7854F, 0);
        cube_r6.setTextureOffset(13, 20).addBox(-2.535F, -0.5F, 0.035F, 3, 1, 2, 0);

        cube_r7 = new ModelRenderer(this);
        cube_r7.setRotationPoint(62.125F, 39.5394F, -18.5666F);
        leftsword.addChild(cube_r7);
        setRotationAngle(cube_r7, 0, 0.7854F, 0);
        cube_r7.setTextureOffset(15, 16).addBox(-0.465F, -0.5F, 0.035F, 3, 1, 2, 0);

        cube_r8 = new ModelRenderer(this);
        cube_r8.setRotationPoint(23.2212F, 7.7988F, -11.6417F);
        leftsword.addChild(cube_r8);
        setRotationAngle(cube_r8, 1.9635F, 0, 3.1416F);
        cube_r8.setTextureOffset(15, 10).addBox(-39.4712F, -21.5706F, -31.5237F, 1, 1, 5, 0);

        rightsword = new ModelRenderer(this);
        rightsword.setRotationPoint(24.75F, 12.9796F, -19.5989F);
        setRotationAngle(rightsword, 0.7418F, 0, 0);


        cube_r9 = new ModelRenderer(this);
        cube_r9.setRotationPoint(-36.7788F, 7.7988F, -11.6417F);
        rightsword.addChild(cube_r9);
        setRotationAngle(cube_r9, 1.5272F, 0, -3.1416F);
        cube_r9.setTextureOffset(11, 25).addBox(12.2788F, -8.0285F, 30.3746F, 4, 4, 1, 0);
        cube_r9.setTextureOffset(21, 25).addBox(7.7788F, -8.0285F, 30.3746F, 4, 4, 1, 0);
        cube_r9.setTextureOffset(24, 8).addBox(10.0288F, -12.0285F, 30.3746F, 4, 6, 1, 0);
        cube_r9.setTextureOffset(102, 3).addBox(11.0288F, -9.2785F, 31.3746F, 2, 3, 32, 0);
        cube_r9.setTextureOffset(0, 26).addBox(11.5288F, -7.365F, -38.2448F, 1, 1, 3, 0);
        cube_r9.setTextureOffset(24, 30).addBox(11.5288F, -8.2785F, -35.6254F, 1, 2, 3, 0);
        cube_r9.setTextureOffset(66, 66).addBox(11.5288F, -9.2785F, -33.6254F, 1, 3, 64, 0);
        cube_r9.setTextureOffset(8, 30).addBox(11.0288F, -9.2785F, 63.3746F, 2, 3, 2, 0);

        cube_r10 = new ModelRenderer(this);
        cube_r10.setRotationPoint(-36.7788F, 7.7988F, -11.6417F);
        rightsword.addChild(cube_r10);
        setRotationAngle(cube_r10, 1.9199F, 0, 3.1416F);
        cube_r10.setTextureOffset(19, 19).addBox(11.5288F, -21.4401F, -32.5151F, 1, 1, 5, 0);


    }



    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {

        mouthsword.render(f5);
        leftsword.render(f5);
        rightsword.render(f5);
    }

    public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}