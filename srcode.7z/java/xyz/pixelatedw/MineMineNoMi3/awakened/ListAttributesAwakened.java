package xyz.pixelatedw.MineMineNoMi3.awakened;

import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.ModelCube;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.ModelSphere;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.EffectType;
import xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.*;
import xyz.pixelatedw.MineMineNoMi3.models.entities.projectiles.sorosHandle.*;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.biskit;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.soldierpro;
import xyz.pixelatedw.MineMineNoMi3.models.entities.zoans.thundercloud;

import java.awt.*;

import static xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.EffectType.HIT;
import static xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.EffectType.PROJECTILE;

public class ListAttributesAwakened
{


	public static final AbilityAttribute MINI_MINI_NO_FULL_REBOUND =
			new AbilityAttribute("Mini Mini no Full Rebound").
					setAbilityCooldown(3).setAbilityPassive(true);

	public static final AbilityAttribute BIGAN = new AbilityAttribute("Bigan").setAbilityCooldown(8)
			.setProjectileDamage(40).setProjectileModel(new ModelCube()).setProjectileColor("#6D5E24").setProjectileSize(1, 1, 2.4).setProjectileTicks(10).addEffects(PROJECTILE, new PotionEffect(Potion.weakness.id, 600, 0), new PotionEffect(Potion.moveSlowdown.id, 600, 2)).setModelOffsets(0, 1.5, 0);
	public static final AbilityAttribute GIRAFFE_SPEED_POINT = new AbilityAttribute("Giraffe Speed Point").setAbilityDisplayName("Speed Point").setAbilityTexture("giraffefull").setAbilityCooldown(1).setAbilityPassive(true);
	public static final AbilityAttribute GIRAFFE_POWER_POINT = new AbilityAttribute("Giraffe Power Point").setAbilityDisplayName("Power Point").setAbilityTexture("giraffehybrid").setAbilityCooldown(1).setAbilityPassive(true);

	public static final AbilityAttribute MOGURA_TONPO = new AbilityAttribute("Mogura Tonpo: Mogugyo").setAbilityCooldown(10).setAbilityTexture("moguratonpo");
	public static final AbilityAttribute MOGURA_BANANA = new AbilityAttribute("Mogura Banana").
			setAbilityCooldown(12).setAbilityPunch(80);
	public static final AbilityAttribute MOGU_POWER_POINT = new AbilityAttribute("Mogu Power Point").setAbilityDisplayName("Mole Point").setAbilityTexture("molepoint").setAbilityCooldown(1).setAbilityPassive(true);

	public static final AbilityAttribute GANMEN_SEICHO_HORMONE = new AbilityAttribute("Ganmen Seicho Hormone").setAbilityCooldown(5).setAbilityPunch();
	public static final AbilityAttribute TENSION_HORMONE = new AbilityAttribute("Tension Hormone").setAbilityCooldown(40).setAbilityPunch();
	public static final AbilityAttribute CHIYU_HORMONE = new AbilityAttribute("Chiyu Hormone").setAbilityCooldown(20).setAbilityPunch();
	public static final AbilityAttribute ONNA_HORMONE = new AbilityAttribute("Onna Hormone").setAbilityCooldown(15).setAbilityPunch();

	public static final AbilityAttribute CHIYUPOPO = new AbilityAttribute("Chiyupopo").setAbilityCooldown(10);
	public static final AbilityAttribute HEALING_TOUCH = new AbilityAttribute("Healing Touch").setAbilityCooldown(15).setAbilityPunch();

	public static final AbilityAttribute ZOU_HYBRID_POINT = new AbilityAttribute("Zou Hybrid Point").setAbilityCooldown(1).setAbilityDisplayName("Hybrid Point").
			setAbilityTexture("zouhybrid").setAbilityPassive(true);
	public static final AbilityAttribute ZOU_FULL_POINT = new AbilityAttribute("Zou Point").setAbilityTexture("zoufull").setAbilityCooldown(1).setAbilityPassive(true);
	public static final AbilityAttribute IVORY_DART = new AbilityAttribute("Ivory Dart").
			setAbilityCooldown(10).setProjectileDamage(50);

	public static final AbilityAttribute onigiri = new AbilityAttribute("onigiri").
			setAbilityCooldown(10).setProjectileDamage(100).setProjectileModel(new onigiri())
			.setProjectileTexture("onigiri").setProjectileSize(3,3,3);

	public static final AbilityAttribute SantoryuOgi = new AbilityAttribute("SantoryuOgi").
			setAbilityCooldown(10).setProjectileDamage(170).setProjectileModel(new ichidai())
			.setProjectileTexture("ichidai").setProjectileSize(15,15,15);

	public static final AbilityAttribute Yakionigiri = new AbilityAttribute("Yakionigiri").
			setAbilityCooldown(10).setProjectileDamage(50).setProjectileModel(new yakionigiri())
			.setProjectileTexture("yakionigiri").setProjectileSize(3,3,3);

	public static final AbilityAttribute Rengoku = new AbilityAttribute("Rengoku").
			setAbilityCooldown(10).setProjectileDamage(150).setProjectileModel(new rengokuonigiri())
			.setProjectileTexture("rengokuonigiri").setProjectileSize(3,3,3);

	public static final AbilityAttribute HyakuhachiPoundHo = new AbilityAttribute("HyakuhachiPoundHo").
			setAbilityCooldown(10).setProjectileDamage(120).setProjectileSize(3,3,3).setProjectileModel(new hyakuhunchipoundho()).setProjectileTexture("hyakuhunchipoundho");


	public static final AbilityAttribute GREAT_STOMP = new AbilityAttribute("Great Stomp").setAbilityCooldown(15);
	public static final AbilityAttribute IVORY_STOMP = new AbilityAttribute("Ivory Stomp").setAbilityCooldown(8).setAbilityPunch().setAbilityPunch(40);
	public static final AbilityAttribute TRUNK_SHOT = new AbilityAttribute("Trunk Shot").setAbilityCooldown(7).
			setProjectileModel(new ModelCube()).setProjectileTexture("zouskin")
			.setProjectileSize(2.5, 2.5, 4).setProjectileColor("838993").setProjectileDamage(30).addEffects(PROJECTILE, new PotionEffect(Potion.weakness.id, 5 * 20)).setProjectilePhysical();






	public static final AbilityAttribute SOUL_PARADE = new AbilityAttribute("Soul Parade").addEffects(EffectType.USER, new PotionEffect(Potion.resistance.id, 30, 100), new PotionEffect(Potion.moveSlowdown.id, 30, 100)).setAbilityCooldown(5).setAbilityPassive();
	public static final AbilityAttribute KASURIUTA_FUBUKI_GIRI = new AbilityAttribute("Kasuriuta: Fubuki Giri").setAbilityCooldown(10);

	public static final AbilityAttribute BAKU_BAKU_FACTORY = new AbilityAttribute("Baku Baku Factory");
	public static final AbilityAttribute BAKU_TSUIHO = new AbilityAttribute("Baku Tsuiho").
			setAbilityCooldown(10).setAbilityCharges(10 * 20
	).setProjectileModel(new ModelCube()).setProjectileSize(2, 2, 2)
			.setProjectileColor("E3E3E3").setProjectileDamage(50);
	public static final AbilityAttribute BERO_CANNON = new AbilityAttribute("Bero Cannon").
			setAbilityCooldown(5).setProjectileModel
			(new ModelCube()).setProjectileSize(2, 2, 2).
			setProjectileColor("E3E3E3").setProjectileDamage(35);
	public static final AbilityAttribute BAKU_MUNCH = new AbilityAttribute("Baku Munch").setAbilityCooldown(5);



	public static final AbilityAttribute PHOENIX_HYBRID_POINT = new AbilityAttribute("Phoenix Hybrid Point").
			setAbilityCooldown(1).setAbilityDisplayName("Hybrid Point").setAbilityTexture("phoenixhybrid").
			setAbilityPassive(true);
	public static final AbilityAttribute PHOENIX_FULL_POINT = new AbilityAttribute("Phoenix Point").setAbilityTexture("phoenixfull").setAbilityCooldown(1).setAbilityPassive(true);
	public static final AbilityAttribute BLUE_FLAMES_OF_RESURRECTION = new AbilityAttribute("Blue Flames of Resurrection").setAbilityCooldown(20).
			addEffects(EffectType.USER, new PotionEffect(Potion.regeneration.id, 3 * 20, 4));
	public static final AbilityAttribute FLAME_OF_RESTORATION = new AbilityAttribute("Flame of Restoration").setAbilityCooldown(3).setAbilityPassive().setAbilityPunch();
	public static final AbilityAttribute PHOENIX_GOEN = new AbilityAttribute("Phoenix Goen").setAbilityCooldown(10)
			.setProjectileDamage(60);
	public static final AbilityAttribute TENSEI_NO_SOEN = new AbilityAttribute("Tensei no Soen").
			setAbilityCooldown(30).setAbilityCharges(5 * 20);

	public static final AbilityAttribute Winged_Tornado = new AbilityAttribute("Winged Tornado").
			setAbilityCooldown(30).setAbilityCharges(5 * 20);

	public static final AbilityAttribute BISON_POWER_POINT = new AbilityAttribute("Bison Power Point").setAbilityCooldown(1).setAbilityDisplayName("Hybrid Point").setAbilityTexture("bisonhybrid").setAbilityPassive(true);
	public static final AbilityAttribute BISON_SPEED_POINT = new AbilityAttribute("Bison Speed Point").setAbilityCooldown(1).setAbilityDisplayName("Bison Point").setAbilityTexture("bisonfull").setAbilityPassive(true);
	public static final AbilityAttribute FIDDLE_BANFF = new AbilityAttribute("Fiddle Banff").setAbilityCooldown(7);
	public static final AbilityAttribute KOKUTEI_CROSS = new AbilityAttribute("Kokutei Cross").
			setAbilityCooldown(7).setAbilityPassive().setAbilityPunch(35);

	public static final AbilityAttribute SAGARI_NO_RYUSEI = new AbilityAttribute
			("Sagari no Ryusei").setAbilityCooldown(20).setProjectileTicks(256).
			setProjectileModel(new ModelSphere()).setProjectileColor("51585B").
			setProjectileSize(50, 50, 50).setProjectileDamage(100).setProjectileExplosion(20, false).setProjectileCollisionSizes(2, 2, 2);


	public static final AbilityAttribute Stomp = new AbilityAttribute
			("Stomp").setAbilityCooldown(20).setProjectileTicks(256).
			setProjectileModel(new stomp()).setProjectileTexture("stomp").
			setProjectileSize(5, 5, 5).setProjectileDamage(100).setProjectileExplosion(20, false).
			setProjectileCollisionSizes(2, 2, 2);


	public static final AbilityAttribute MOKO = new AbilityAttribute("Moko").setProjectileDamage(35).setAbilityCooldown(12).setProjectileModel(new ModelCube()).setProjectileSize(new double[] {0, 0, 0}).setProjectileMoveThroughBlocks(true);
	public static final AbilityAttribute ABARE_HIMATSURI = new AbilityAttribute("Abare Himatsuri").setAbilityCooldown(10).setAbilityPassive();
	public static final AbilityAttribute JURYOKU = new AbilityAttribute("Juryoku").setAbilityDisplayName("Jigoku Tabi").setAbilityCooldown(12).setAbilityPassive();


	public static final AbilityAttribute LightningRide = new AbilityAttribute("Lightning Ride").
			setAbilityCooldown(10).setAbilityTexture("lride").setAbilityPassive();

	/*"Lets you fly on the thunder cloud(I have sent the model for it)," +
                        " basically a copy of the move Abare Himatsuri from the zushi zushi no mi but " +
                        "with the cloud instead of a block"

	 */
	public static final AbilityAttribute BLACK_WORLD = new AbilityAttribute("Black World").setAbilityCooldown(25).addEffects(EffectType.AOE, new PotionEffect(Potion.moveSlowdown.id, 200, 100), new PotionEffect(Potion.digSlowdown.id, 200, 100), new PotionEffect(Potion.blindness.id, 200, 2)).setEffectRadius(20);
	public static final AbilityAttribute DARK_MATTER = new AbilityAttribute("Dark Matter").
			setAbilityCooldown(12).setProjectileModel(new ModelSphere()).setProjectileColor("000000").
			setProjectileSize(7, 7, 7).setProjectileDamage(50);
	public static final AbilityAttribute KUROUZU = new AbilityAttribute("Kurouzu").setAbilityCooldown(10).setAbilityCharges(3 * 20);;
	public static final AbilityAttribute LIBERATION = new AbilityAttribute("Liberation").setAbilityCooldown(5);
	public static final AbilityAttribute BLACKHOLE = new AbilityAttribute("Black Hole").setAbilityCooldown(7);

	public static final AbilityAttribute TODOROKI = new AbilityAttribute("Todoroki").
			setAbilityCooldown(20).setProjectileModel(new ModelCube()).setProjectileColor
			("#87CEFA").setProjectileSize(2, 2, 4).setProjectileDamage(40).setAbilityRepeater(20, 3);

	public static final AbilityAttribute PERFUME_FEMUR = new AbilityAttribute("Perfume Femur").setAbilityCooldown(10).setAbilityPunch(10);
	public static final AbilityAttribute SLAVE_ARROW = new AbilityAttribute("Slave Arrow").setAbilityCooldown(10).
			setProjectileModel(new ModelArrow()).setProjectileColor("#FF69B4").
			setProjectileSize(1, 1, 2).setProjectileDamage(20).setAbilityRepeater().setAbilityCharges(7 * 20);
	public static final AbilityAttribute PISTOL_KISS = new AbilityAttribute("Pistol Kiss").setAbilityCooldown(5).
			setProjectileModel(new ModelHeart()).setProjectileSize(.5, .5, .5)
			.setProjectileTexture("meromeromellow").setProjectileDamage(15).setModelOffsets(0, -0.5, 0).addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 100, 5), new PotionEffect(Potion.digSlowdown.id, 100, 5));
	public static final AbilityAttribute MERO_MERO_MELLOW = new AbilityAttribute("Mero Mero Mellow").
			setAbilityCooldown(20).setProjectileModel(new ModelHeart()).
			setProjectileSize(3, 3, 3).setProjectileTexture("meromeromellow").
			setProjectileDamage(25).setModelOffsets(0, -1, 0).addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 400, 100), new PotionEffect(Potion.digSlowdown.id, 400, 100)).setProjectileCollisionSizes(1.25, 1.25, 1.25);

	public static final AbilityAttribute SPARKLING_DAISY = new AbilityAttribute("Sparkling Daisy").setAbilityCooldown(12);
	public static final AbilityAttribute SPIRAL_HOLLOW = new AbilityAttribute("Spiral Hollow").setAbilityCooldown(10).setProjectileDamage(20).setProjectileModel(new ModelCube()).setProjectileColor("#F8F8FF").setProjectileSize(3, 3, 5).setProjectileTicks(3).setProjectilePhysical();
	public static final AbilityAttribute ATOMIC_SPURT = new AbilityAttribute("Atomic Spurt").setAbilityCooldown(25).setAbilityPassive();
	public static final AbilityAttribute SPAR_CLAW = new AbilityAttribute("Spar Claw").setAbilityCooldown(5).setAbilityPassive(true).setAbilityPunch(10);
	public static final AbilityAttribute SPIDER = new AbilityAttribute("Spider").addEffects(EffectType.USER, new PotionEffect(Potion.resistance.id, 30, 100), new PotionEffect(Potion.moveSlowdown.id, 30, 100), new PotionEffect(Potion.digSlowdown.id, 30, 5), new PotionEffect(Potion.jump.id, 30, -100)).setAbilityPassive();

	public static final AbilityAttribute NEGATIVE_HOLLOW = new AbilityAttribute("Negative Hollow").setAbilityCooldown(6).setProjectileModel(new ModelNegativeHollow()).
			setProjectileTexture("negativehollow").setProjectileAlpha(150).
			setProjectileSize(2, 2, 2).setProjectileDamage(25).addEffects(PROJECTILE, new PotionEffect(Potion.confusion.id, 200, 1), new PotionEffect(Potion.moveSlowdown.id, 200, 1));
	public static final AbilityAttribute MINI_HOLLOW = new AbilityAttribute("Mini Hollow").setAbilityCooldown(3).setProjectileModel(new ModelMiniHollow()).setProjectileSize(0.4, 0.4, 0.4).setProjectileColor("#F8F8FF").setProjectileAlpha(150).setProjectileDamage(2).setProjectileExplosion(2, false).addEffects(PROJECTILE, new PotionEffect(Potion.confusion.id, 120, 0), new PotionEffect(Potion.moveSlowdown.id, 120, 0)).setAbilityRepeater();
	public static final AbilityAttribute TOKU_HOLLOW = new AbilityAttribute("Toku Hollow").
			setAbilityCooldown(10).setProjectileModel(new ModelTokuHollow()).setProjectileTexture("tokuhollow").
			setProjectileAlpha(150).setProjectileSize(4, 4, 4).setProjectileDamage(45).setProjectileExplosion(7, false).addEffects(PROJECTILE, new PotionEffect(Potion.confusion.id, 400, 1), new PotionEffect(Potion.moveSlowdown.id, 400, 1)).setProjectileCollisionSizes(1.5, 1.5, 1.5);


	public static final AbilityAttribute BLACK_KNIGHT = new AbilityAttribute("Black Knight").setAbilityCooldown(15).setAbilityPassive();
	public static final AbilityAttribute KUMO_NO_SUGAKI = new AbilityAttribute("Kumo no Sugaki").setAbilityCooldown(10).addEffects(EffectType.USER,new PotionEffect(Potion.resistance.id, 30, 100), new PotionEffect(Potion.moveSlowdown.id, 30, 100), new PotionEffect(Potion.digSlowdown.id, 30, 5), new PotionEffect(Potion.jump.id, 30, -100)).setAbilityPassive();;
	public static final AbilityAttribute TORIKAGO = new AbilityAttribute("Torikago").setAbilityCooldown(2).setAbilityPassive(true);
	public static final AbilityAttribute TAMAITO = new AbilityAttribute("Tamaito").setAbilityCooldown(5).setProjectileDamage(45).setProjectileModel(new ModelCube()).setProjectileSize(.5, .5, 1).setProjectileColor("#dee1e5");
    public static final AbilityAttribute OVERHEAT = new AbilityAttribute("Overheat").setAbilityCooldown(8).setProjectileDamage(70).setProjectileModel(new ModelCube()).setProjectileSize(1, 1, 5).setProjectileExplosion(3, false).setProjectileColor("#f77c25");
	public static final AbilityAttribute SORA_NO_MICHI = new AbilityAttribute("Sora no Michi").setAbilityCooldown(1);

	public static final AbilityAttribute WING = new AbilityAttribute("wing").setAbilityCooldown(3);

	public static final AbilityAttribute PARASITE = new AbilityAttribute("Parasite").setAbilityCooldown(5);

	public static final AbilityAttribute BARRIERBILITY_STAIRS = new AbilityAttribute("Barrierbility Stairs").setProjectileTicks(60).setProjectileModel(new ModelCube()).setProjectileSize(0, 0, 0).setProjectileMoveThroughBlocks(true).setAbilityPassive();
	public static final AbilityAttribute BARI_BARI_NO_PISTOL = new AbilityAttribute("Bari Bari no Pistol").setAbilityCooldown(5).setAbilityPassive().setAbilityPunch();
	public static final AbilityAttribute BARRIER_BALL = new AbilityAttribute("Barrier Ball").setAbilityCooldown(0.5).setAbilityPassive();
	public static final AbilityAttribute BARRIER_CRASH = new AbilityAttribute("Barrier Crash").setAbilityCooldown(5).setProjectileTicks(60).setProjectileModel(new ModelCube()).setProjectileColor("#87CEFA").setProjectileSize(9, 9, .3).setProjectileDamage(15).setProjectileCollisionSizes(1.5, 2, 1.5);
	public static final AbilityAttribute BARRIER = new AbilityAttribute("Barrier").setAbilityPassive();

	public static final AbilityAttribute YUKI_GAKI = new AbilityAttribute("Yuki Gaki").setAbilityCooldown(8);
	public static final AbilityAttribute FUBUKI = new AbilityAttribute("Fubuki").setAbilityCooldown(12).setProjectileDamage(35);
	public static final AbilityAttribute TABIRA_YUKI = new AbilityAttribute("Tabira Yuki").setAbilityPassive(true);
//	public static final AbilityAttribute MANNEN_YUKI = new AbilityAttribute("Mannen Yuki");
	public static final AbilityAttribute KAMAKURA_JUSSOSHI = new AbilityAttribute("Kamakura Jussoshi").setAbilityCooldown(18);
	public static final AbilityAttribute YUKI_RABI = new AbilityAttribute("Yuki Rabi").setAbilityCooldown(2)
			.setProjectileColor(Color.WHITE).setProjectileDamage(25).setProjectileModel(new ModelYukiRabi()).setProjectileTexture("yukirabi").setProjectileSize(1, 1, 1).addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 50, 1)).setAbilityRepeater(2, 2);
	public static final AbilityAttribute KAMAKURA = new AbilityAttribute("Kamakura").setAbilityCooldown(6);

//	public static final AbilityAttribute SHINOKUNI = new AbilityAttribute("Shinokuni");
	public static final AbilityAttribute KARAKUNI = new AbilityAttribute("Karakuni").setAbilityCooldown(20);
	public static final AbilityAttribute BLUE_SWORD = new AbilityAttribute("Blue Sword").setAbilityPassive(true);
	public static final AbilityAttribute GASTANET = new AbilityAttribute("Gastanet").setAbilityCooldown(6)
			.setAbilityExplosion(5, false);
	public static final AbilityAttribute GASTILLE = new AbilityAttribute("Gastille").setAbilityCooldown(7).setProjectileSpeed(2).setProjectileDamage(10).setProjectileModel(new ModelCube()).setProjectileColor("324AB2").setProjectileSize(1, 1, 2).addEffects(PROJECTILE, new PotionEffect(Potion.poison.id, 200, 1)).setAbilityRepeater().setProjectileExplosion(1, false);
	public static final AbilityAttribute GAS_ROBE = new AbilityAttribute("Gas Robe").
			setAbilityCooldown(6).setProjectileSpeed(2).setProjectileDamage(50).setProjectileModel(new ModelCube()).setProjectileSize(0, 0, 0).setAbilityRepeater();

	public static final AbilityAttribute DOKU_GUMO = new AbilityAttribute("Doku Gumo").setAbilityCooldown(30).setAbilityPassive();
	public static final AbilityAttribute DOKU_FUGU = new AbilityAttribute("Doku Fugu").
			setAbilityCooldown(8).setProjectileDamage(20).setProjectileModel(new ModelSphere()).setProjectileColor("A020F0").setProjectileSize(5, 5, 5).addEffects(PROJECTILE, new PotionEffect(Potion.poison.id, 240, 1)).setAbilityRepeater(10, 3);
	public static final AbilityAttribute VENOM_DEMON = new AbilityAttribute("Venom Demon").setAbilityCooldown(40).setAbilityPassive(true);
	public static final AbilityAttribute VENOM_ROAD = new AbilityAttribute("Venom Road")
			.setAbilityCooldown(8).setProjectileDamage(40).setProjectileModel(new ModelHydra()).setProjectileTexture("hydra").setProjectileSize(2, 2, 2.4).addEffects(PROJECTILE, new PotionEffect(Potion.poison.id, 500, 1));
	public static final AbilityAttribute CHLORO_BALL = new AbilityAttribute("Chloro Ball").
			setAbilityCooldown(6).setProjectileDamage(35).setProjectileModel(new ModelSphere()).setProjectileColor("A020F0").setProjectileSize(5, 5, 5).addEffects(PROJECTILE, new PotionEffect(Potion.poison.id, 240, 1));
	public static final AbilityAttribute HYDRA = new AbilityAttribute("Hydra").setAbilityCooldown(8).setProjectileDamage(30).setProjectileModel(new ModelHydra()).setProjectileTexture("hydra").setProjectileSize(2, 2, 2.4).setProjectileTicks(10).addEffects(PROJECTILE, new PotionEffect(Potion.poison.id, 500, 1));

	public static final AbilityAttribute CANDLE_LOCK = new AbilityAttribute("Candle Lock").
			setAbilityCooldown(15).setProjectileDamage(15).setProjectileModel(new ModelCube()).setProjectileColor("A2ADD0").setProjectileSize(.5, .5, 1).addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 400, 100), new PotionEffect(Potion.digSlowdown.id, 400, 100), new PotionEffect(Potion.jump.id, 400, -1));




	public static final AbilityAttribute Clutch = new AbilityAttribute("Clutch").
			setAbilityCooldown(30);



	public static final AbilityAttribute CANDLE_HOUSE = new AbilityAttribute("Candle House").setAbilityCooldown(30);
	public static final AbilityAttribute CANDLE_WALL = new AbilityAttribute("Candle Wall").setAbilityCooldown(4);
	public static final AbilityAttribute DORU_DORU_ARTS_KEN = new AbilityAttribute("Doru Doru Arts : Ken").
			setAbilityPassive(true);
	public static final AbilityAttribute DORU_DORU_ARTS_MORI = new AbilityAttribute("Doru Doru Arts : Mori").
			setAbilityCooldown(3).setProjectileDamage(25).setProjectileModel(new ModelSpear()).setProjectileTexture
			("dorudoruartsmori").setProjectileSize(2, 2, 2).setModelOffsets(0, 1, 0);

	public static final AbilityAttribute BAKURETSU_KAZAN = new AbilityAttribute("Bakuretsu Kazan").setAbilityCooldown(15);
	public static final AbilityAttribute RYUSEI_KAZAN = new AbilityAttribute("Ryusei Kazan").
			setAbilityCooldown(12).setProjectileDamage(35).setAbilityRepeater();
	public static final AbilityAttribute MEIGO = new AbilityAttribute("Meigo").setAbilityCooldown(10).
			setProjectileDamage(50).setProjectileModel(new ModelMeigo()).setProjectileTexture("meigo").
			setProjectileSize(4, 4, 4).setModelOffsets(0, 1.2, 0).setProjectileTicks(3);
	public static final AbilityAttribute DAI_FUNKA = new AbilityAttribute("Dai Funka").setAbilityCooldown(8).setProjectileDamage(55).
			setProjectileModel(new ModelFist()).setProjectileTexture("daifunka").
			setProjectileSize(4, 4, 4).setModelOffsets(0, 1, 0);

	public static final AbilityAttribute DESERT_GIRASOLE = new AbilityAttribute("Desert Girasole").setAbilityCooldown(25).setAbilityCharges(100);
	public static final AbilityAttribute DESERT_ENCIERRO = new AbilityAttribute("Desert Encierro").
			setAbilityCooldown(10).setAbilityPunch(50).
			addEffects(EffectType.HIT, new PotionEffect(Potion.hunger.id, 100, 1),
					new PotionEffect(Potion.weakness.id, 100, 1),
					 new PotionEffect(Potion.moveSlowdown.id, 100, 1),
					new PotionEffect(Potion.digSlowdown.id, 100, 1));
	public static final AbilityAttribute GROUND_DEATH = new AbilityAttribute("Ground Death").setAbilityCooldown(15);
	public static final AbilityAttribute BARJAN = new AbilityAttribute("Barjan").setAbilityCooldown(5).
			setProjectileDamage(30).setProjectileModel(new ModelCube()).setProjectileColor("967117").setProjectileSize(6, 0.4, 1.5).addEffects(PROJECTILE, new PotionEffect(Potion.hunger.id, 500, 1)).setProjectileMoveThroughBlocks(true).setProjectileCollisionSizes(1.25, 0.3, 1.25);
	public static final AbilityAttribute SABLES = new AbilityAttribute("Sables").setAbilityCooldown(3)
			.setAbilityPassive().setAbilityPunch(40);
	public static final AbilityAttribute SABLESPESADO = new AbilityAttribute("SablesPesado").setAbilityCooldown(3)
			.setAbilityPassive().setAbilityPunch(60);

	//Make a New move called “Sables Pesado” it’s a copy of the sables move that does 60 damage and the tornado is bigger (the original move makes a small tornado)
	public static final AbilityAttribute DESERT_SPADA = new AbilityAttribute("Desert Spada").setAbilityCooldown(10);

	public static final AbilityAttribute TSUNOTOKAGE = new AbilityAttribute("Tsuno-Tokage").
			setAbilityCooldown(10);
//	public static final AbilityAttribute SHADOWSASGARD = new AbilityAttribute("Shadow's Asgard").setAbilityCooldown(400).addTasks(Tasks.shadowsasgard);
	public static final AbilityAttribute BLACK_BOX = new AbilityAttribute("Black Box").
		setAbilityCooldown(6).setProjectileModel(new ModelCube()).
		setProjectileColor(Color.black).setProjectileSize(2, 2, 2).setProjectileDamage(60);
	public static final AbilityAttribute KAGEMUSHA = new AbilityAttribute("Kagemusha").setAbilityCooldown(5);
	public static final AbilityAttribute DOPPELMAN = new AbilityAttribute("Doppelman").setAbilityCooldown(15).setAbilityPassive();
	public static final AbilityAttribute BRICK_BAT = new AbilityAttribute("Brick Bat").
			setAbilityCooldown(4).
			setProjectileDamage(35).setProjectileModel(new ModelBrickBat()).setProjectileSize(1, 1, 1)
			.setModelOffsets(0, 0.5, 0).setProjectileTexture("brickbat").
					setAbilityRepeater(3, 2);

	public static final AbilityAttribute GEKISHIN = new AbilityAttribute("Gekishin").setAbilityCooldown(15).
			setAbilityPassive().setAbilityPunch().setProjectileDamage(150);


	public static final AbilityAttribute SHIMA_YURASHI = new AbilityAttribute("Shima Yurashi").setAbilityCooldown(15).setProjectileDamage(20).setProjectileExplosion(5, false).setProjectileMoveThroughBlocks(true);
	public static final AbilityAttribute KABUTOWARI = new AbilityAttribute("Kabutowari").setAbilityCooldown(7).setProjectileDamage(150f).
			setAbilityExplosion(5, false);
	public static final AbilityAttribute KAISHIN = new AbilityAttribute("Kaishin").setAbilityCooldown(11).
			setProjectileDamage(100).setProjectileModel(new ModelCube()).setProjectileSize(0, 0, 0).
			setProjectileExplosion(3, false, false).setProjectileDamage(100);

	public static final AbilityAttribute KICK_BOMB = new AbilityAttribute("Kick Bomb").setAbilityCooldown(7).setAbilityExplosion(7, false);
	public static final AbilityAttribute NOSE_FANCY_CANNON = new AbilityAttribute("Nose Fancy Cannon").
			setAbilityCooldown(3).setProjectileModel(new ModelCube()).setProjectileColor("3D2B1F").
			setProjectileSize(.4, .4, .8).setProjectileDamage(15).setProjectileExplosion(3, false);

	public static final AbilityAttribute URSUS_SHOCK = new AbilityAttribute("Ursus Shock").setAbilityCooldown(15).setProjectileModel(new ModelPaw()).setProjectileColor("F8F8FF").setProjectileAlpha(80).setProjectileSize(3.5, 3.5, 3.5).setProjectileDamage(50).setProjectileExplosion(8, false, true).setAbilityCharges(40).setProjectileCollisionSizes(1.5, 1.5, 1.5);
	public static final AbilityAttribute PAD_HO = new AbilityAttribute("Pad Ho").setAbilityCooldown(8).setProjectileModel(new ModelPaw()).setProjectileColor("F8F8FF").setProjectileAlpha(80).setProjectileSize(1, 1, 1).setProjectileDamage(10).setProjectileExplosion(1, false, true);
	public static final AbilityAttribute TSUPPARI_PAD_HO = new AbilityAttribute("Tsuppari Pad Ho").setAbilityCooldown(10).setProjectileDamage(15).setProjectileExplosion(1, false, true).setAbilityRepeater(5, 7);
	public static final AbilityAttribute HANPATSU = new AbilityAttribute("Hanpatsu").setAbilityCooldown(4).setAbilityPassive().setAbilityPunch();

	public static final AbilityAttribute WHITE_STRIKE = new AbilityAttribute("White Strike").setAbilityCooldown(35).addEffects(EffectType.AOE, new PotionEffect(Potion.moveSlowdown.id, 300, 1), new PotionEffect(Potion.digSlowdown.id, 300, 1), new PotionEffect(Potion.jump.id, 300, -10)).setEffectRadius(30);
	public static final AbilityAttribute WHITE_LAUNCHER = new AbilityAttribute("White Launcher").
			setAbilityCooldown(5).setAbilityCharges(20);
	public static final AbilityAttribute WHITE_SNAKE = new AbilityAttribute("White Snake").setAbilityCooldown(5).setProjectileTicks(120).setProjectileModel(new ModelCube()).setProjectileSpeed(5).setProjectileSize(0, 0, 0).setProjectileDamage(30).addEffects(PROJECTILE, new PotionEffect(Potion.poison.id, 120, 0));
	public static final AbilityAttribute WHITE_OUT = new AbilityAttribute("White Out").
			setAbilityCooldown(4).setProjectileModel(new ModelCube()).setProjectileSpeed(5).
			setProjectileSize(0, 0, 0).setProjectileDamage(5).
			addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 240, 1),
					new PotionEffect(Potion.digSlowdown.id, 240, 1),
					new PotionEffect(Potion.jump.id, 240, -10));

	public static final AbilityAttribute SANGO = new AbilityAttribute("Sango").setAbilityCooldown(10).
			setProjectileTicks(128).setProjectileModel(new ModelCube()).
			setProjectileSize(0, 0, 0).
			setProjectileColor("7CB9E8").setProjectileDamage(25).setAbilityRepeater();
	public static final AbilityAttribute KARI = new AbilityAttribute("Kari").setAbilityCharges(7 * 20).setAbilityCooldown(15).setAbilityExplosion(10, false, false);
	public static final AbilityAttribute RAIGO = new AbilityAttribute("Raigo").setAbilityCooldown(45).setProjectileTicks(256).setProjectileModel(new ModelSphere()).setProjectileColor("5D8AA8").setProjectileSize(50, 50, 50).setProjectileDamage(120).setProjectileExplosion(30, false).setProjectileCollisionSizes(2);
	public static final AbilityAttribute VOLT_VARI = new AbilityAttribute("Volt Vari").setAbilityCooldown(3).
			setAbilityCharges(10 * 20, true);
	public static final AbilityAttribute EL_THOR = new AbilityAttribute("El Thor").setAbilityCooldown(8).
			setAbilityCharges(6 * 20);
	public static final AbilityAttribute SPARK_STEP = new AbilityAttribute("Spark Step").setAbilityCooldown(3);

	public static final AbilityAttribute INJECTION_SHOT = new AbilityAttribute("Injection Shot").setAbilityCooldown(15);
	public static final AbilityAttribute SHAMBLES = new AbilityAttribute("Shambles").setAbilityCooldown(8);
	public static final AbilityAttribute TAKT = new AbilityAttribute("Takt").setAbilityCooldown(10).setAbilityPassive();
	public static final AbilityAttribute GAMMA_KNIFE = new AbilityAttribute("Gamma Knife").setAbilityCooldown(30).setProjectileTicks(20).setProjectileModel(new ModelCube()).setProjectileColor("00AB66").setProjectileDamage(100).setProjectileSize(1, 1, 5);
	public static final AbilityAttribute MES = new AbilityAttribute("Mes").setAbilityCooldown(5).setAbilityPassive().setAbilityPunch(1);
	public static final AbilityAttribute COUNTER_SHOCK = new AbilityAttribute("Counter Shock").setAbilityCooldown(10).setAbilityPassive().setAbilityPunch(40).setAbilityExplosion(1, false);
	public static final AbilityAttribute ROOM = new AbilityAttribute("Room").setAbilityCooldown(1).
			setAbilityPassive(true);

	public static final AbilityAttribute NORO_NORO_BEAM =
			new AbilityAttribute("Noro Noro Beam").setAbilityCooldown(5).
					setProjectileTicks(10).setProjectileModel(new ModelNoroNoroBeam()).
					setProjectileTexture("noronorobeam").setProjectileSize(5, 5, 5).
					setProjectileSpeed(1.6F);
					//setProjectileCollisionSizes(1);

	public static final AbilityAttribute KYUBI_RUSH = new AbilityAttribute("Kyubi Rush").setAbilityCooldown(7).setAbilityPassive().setAbilityPunch();
	public static final AbilityAttribute NORO_NORO_BEAM_SWORD = new AbilityAttribute("Noro Noro Beam Sword").setAbilityPassive(true);

	public static final AbilityAttribute AIR_DOOR = new AbilityAttribute("Air Door").setAbilityPassive(true).setAbilityCooldown(40);
	public static final AbilityAttribute DOOR = new AbilityAttribute("Door").setAbilityCooldown(8);

	public static final AbilityAttribute SUKE_PUNCH = new AbilityAttribute("Suke Punch").setAbilityPassive().setAbilityPunch();
	public static final AbilityAttribute SHISHA_NO_TE = new AbilityAttribute("Shisha no Te").setAbilityCooldown(3).setProjectileDamage(5).setProjectileModel(new ModelCube()).setProjectileSize(0, 0, 0).setProjectileExplosion(3, false);
	public static final AbilityAttribute SKATTING = new AbilityAttribute("Skatting").addEffects(EffectType.USER, new PotionEffect(Potion.invisibility.id, 30, 5)).setAbilityPassive();

	public static final AbilityAttribute GEAR_SECOND = new AbilityAttribute("Gear Second").setAbilityCooldown(60).setAbilityPassive();
	public static final AbilityAttribute GEAR_THIRD = new AbilityAttribute("Gear Third").setAbilityCooldown(90).setAbilityPassive();
	public static final AbilityAttribute GEAR_FOURTH = new AbilityAttribute("Gear Fourth").
			setAbilityCooldown(300).setAbilityPassive();




	public static final AbilityAttribute GOMU_GOMU_NO_ROCKET = new AbilityAttribute("Gomu Gomu no Rocket").
			setProjectileModel(new ModelFist()).setProjectileTexture("gomugomunopistol").
			setProjectileSize(3, 3, 3).setModelOffsets(0, 1, 0).
			setProjectileDamage(25).setAbilityCooldown(8).setProjectilePhysical().
			setProjectileSpeed(2.5F);

	public static final AbilityAttribute GOMU_GOMU_NO_BAZOOKA = new AbilityAttribute("Gomu Gomu no " +
			"Bazooka").setAbilityCharges(10);
	public static final AbilityAttribute GOMU_GOMU_NO_GATLING =
			new AbilityAttribute("Gomu Gomu no Gatling").setProjectileTicks(10).
					setAbilityCooldown(5);
	public static final AbilityAttribute GOMU_GOMU_NO_PISTOL = new AbilityAttribute(
			"Gomu Gomu no Pistol");

	public static final AbilityAttribute FLASH = new AbilityAttribute("Flash").setAbilityCooldown(5).addEffects(EffectType.AOE, new PotionEffect(Potion.blindness.id, 7 * 20, 3), new PotionEffect(Potion.moveSlowdown.id, 7 * 20, 1)).setEffectRadius(10);
	public static final AbilityAttribute AMA_NO_MURAKUMO = new AbilityAttribute("Ama no Murakumo").setAbilityPassive(true);
	public static final AbilityAttribute AMATERASU = new AbilityAttribute("Amaterasu").
			setAbilityCooldown(15).setProjectileTicks(150).setProjectileModel(new ModelCube()).
			setProjectileSize(1, 1, 1).setProjectileColor("FFFF00").
			setProjectileSpeed(5).setProjectileDamage(110).setProjectileExplosion(6, false).setAbilityCharges(2 * 20);
	public static final AbilityAttribute YASAKANI_NO_MAGATAMA = new AbilityAttribute("Yasakani no Magatama").
			setAbilityCooldown(25).
			setProjectileModel(new ModelSphere()).setProjectileSize(.5, .5, .5).
			setProjectileColor("FFFF00").setAbilityRepeater(2).
			setProjectileDamage(15).setProjectileExplosion(1, false).setProjectileSpeed(5);
	public static final AbilityAttribute YATA_NO_KAGAMI = new AbilityAttribute("Yata no Kagami").setAbilityCooldown(4);

	public static final AbilityAttribute SPRING_DEATH_KNOCK = new AbilityAttribute("Spring Death Knock")
			.setAbilityCooldown(6).setProjectileDamage(60).setProjectileModel(new ModelFist()).setProjectileTexture("springdeathknock").setModelOffsets(-1, 1.5, 0).setProjectileSize(7, 5, 5).setProjectileTicks(3).setProjectilePhysical();
	public static final AbilityAttribute SPRING_SNIPE = new AbilityAttribute("Spring Snipe").
			setAbilityCooldown(5).setAbilityCharges(20).setAbilityPunch(35);
	public static final AbilityAttribute SPRING_HOPPER = new AbilityAttribute("Spring Hopper").
			setAbilityCooldown(0.6).setAbilityCharges(10);

	public static final AbilityAttribute ICE_TIME_CAPSULE = new AbilityAttribute("Ice Time Capsule").setAbilityCooldown(15);
	public static final AbilityAttribute ICE_SABER = new AbilityAttribute("Ice Saber").
			setAbilityPassive(true);
	public static final AbilityAttribute ICE_BALL = new AbilityAttribute("Ice Ball").
			setAbilityCooldown(6).setProjectileDamage(15).setProjectileModel(new ModelSphere()).setProjectileColor("00FFFF").setProjectileSize(5, 5, 5).addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 100, 0), new PotionEffect(Potion.digSlowdown.id, 100, 0));
	public static final AbilityAttribute ICE_AGE = new AbilityAttribute("Ice Age").setAbilityCooldown(15).addEffects(EffectType.AOE, new PotionEffect(Potion.moveSlowdown.id, 200, 100), new PotionEffect(Potion.digSlowdown.id, 200, 100)).setEffectRadius(20);
	public static final AbilityAttribute ICE_BLOCK_PARTISAN = new AbilityAttribute("Ice Block : Partisan").
			setAbilityCooldown(7).setProjectileDamage(25).
			setProjectileModel(new ModelTrident()).setProjectileTexture("iceblockpartisan").
			setProjectileSize(1.5, 1.5, 1.5).setModelOffsets(0, 1.0, 0).
			setAbilityRepeater().
			addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 100, 0),
					new PotionEffect(Potion.digSlowdown.id, 100, 0));

	public static final AbilityAttribute ICE_BLOCK_PHEASANT =
			new AbilityAttribute("Ice Block : Pheasant").setAbilityCooldown(20).
					setProjectileDamage(75).setProjectileModel(new ModelPheasant()).setProjectileTexture("iceblockpheasant").setProjectileSize(5, 5, 5).setModelOffsets(0, 2.5, 0).addEffects(PROJECTILE, new PotionEffect(Potion.moveSlowdown.id, 200, 100), new PotionEffect(Potion.digSlowdown.id, 200, 100)).setProjectileCollisionSizes(1.75, 1.5, 1.75);

	public static final AbilityAttribute ENJOMO  = new AbilityAttribute("Enjomo").setAbilityCooldown(10);
	public static final AbilityAttribute JUJIKA = new AbilityAttribute("Jujika").setAbilityCooldown(6).
			setProjectileDamage(50).setProjectileModel(new ModelSphere()).setProjectileColor("FF0000").
			setProjectileSize(.2, .2, .2);
	public static final AbilityAttribute HIDARUMA = new AbilityAttribute("Hidaruma").setAbilityCooldown(6).
            setProjectileModel(new ModelCube()).setProjectileSize(0, 0, 0).setProjectileDamage(35);
	public static final AbilityAttribute DAI_ENKAI_ENTEI =
			new AbilityAttribute("Dai Enkai : Entei").setAbilityCooldown(25).
					setProjectileModel(new ModelSphere()).setProjectileDamage(120).setProjectileColor("FF0000").
					setProjectileSize(9, 9, 9).setProjectileExplosion(7).setAbilityCharges(4 * 20).
					setProjectileCollisionSizes(2);


	public static final AbilityAttribute HIGAN = new AbilityAttribute("Higan").
			setAbilityCooldown(4).setProjectileModel(new ModelCube()).setProjectileDamage(45).setProjectileColor("FF0000").setProjectileSize(.3, .3, .3).setAbilityRepeater(4);
	public static final AbilityAttribute HIKEN = new AbilityAttribute("Hiken").setAbilityCooldown(8).
			setProjectileModel(new ModelFist()).setProjectileTexture("hiken").
			setModelOffsets(0, 0.5, 0).setProjectileDamage(60).setProjectileSize(1.5, 1.5, 1.5).setProjectileExplosion(2);



	public static final AbilityAttribute JISHAKUMETAL = new AbilityAttribute("Jishaku Metal").
			setProjectileModel(new ModelArrow()).setProjectileColor(new Color(0, 0, 0, 136).getRGB()).
			setModelOffsets(0, 0.5, 0).setAbilityRepeater(2).setProjectileDamage(25).
			setProjectileSize(1.5, 1.5, 1.5).setAbilityCooldown(6);
	public static final AbilityAttribute Repell = new AbilityAttribute("Jishaku Repell").
			setAbilityCooldown(2).setProjectileModel(new ModelCube()).setProjectileSpeed(5).
			setProjectileSize(0, 0, 0).setProjectileDamage(1);

	public static final AbilityAttribute HeavyRepell = new AbilityAttribute("Jishaku Heavy Repell").
			setAbilityCooldown(7).setProjectileModel(new hmodel()).setProjectileTexture("heavyrepel").
			setProjectileSize(4, 4, 4).
			setProjectileDamage(100).
			setAbilityTexture("h");

	public static final AbilityAttribute MagnetPUll = new AbilityAttribute("Jishaku Magnet Pull").
			setAbilityCooldown(5).setProjectileModel(new ModelCube()).setProjectileSpeed(5).
			setProjectileSize(0, 0, 0).setProjectileDamage(5);


	public static final AbilityAttribute Rope = new AbilityAttribute("Rope").
			setAbilityCooldown(5).setProjectileModel(new rope()).setProjectileTexture("rope").
			setProjectileSpeed(5).
			setProjectileSize(2, 2, 2).setProjectileDamage(5);


	public static final AbilityAttribute NUMAGATLING =
			new AbilityAttribute("Numa Gatling").setProjectileModel(new ModelSphere()).setProjectileColor(new Color(110, 59, 28, 242).hashCode()).setProjectileTicks(10).
					setProjectileDamage(50).setAbilityCooldown(16).setAbilityRepeater(12);

	public static final AbilityAttribute SWAMPLAND =
			new AbilityAttribute("Swamp Land").setProjectileTicks(10).setAbilityCooldown(15);

	public static final AbilityAttribute Constrict =
			new AbilityAttribute("Constrict").setProjectileTicks(10).setAbilityCooldown(15);

	public static final AbilityAttribute SWAMPSLIDE =new AbilityAttribute("Swamp Slide").
			setAbilityCooldown(5).setAbilityCharges(20);

	public static final AbilityAttribute NUMASPRAY = new AbilityAttribute("Numa Ball").
			setProjectileModel(new ModelSphere()).setProjectileColor(new Color(110, 64, 26).getRGB()).
			addEffects(PROJECTILE,
					new PotionEffect(Potion.moveSlowdown.id,600),
					new PotionEffect(Potion.digSlowdown.id,600),
					new PotionEffect(Potion.damageBoost.id,600)).
			setModelOffsets(0, 0.5, 0).setProjectileDamage(20).
			setProjectileSize(5, 5, 5).setAbilityCooldown(6);

	public static final AbilityAttribute MOCHIBALL = new AbilityAttribute("Mochi Ball").
			setProjectileModel(new ModelSphere()).setProjectileColor(Color.white).
			setModelOffsets(0, 0.5, 0).setProjectileDamage(20).
			setProjectileSize(3, 3, 3).setAbilityCooldown(6);
	public static final AbilityAttribute ImpactWave =
			new AbilityAttribute("Impact Wave").setAbilityCooldown(25).
					setProjectileModel(new ModelSphere()).setProjectileDamage(100).
					setProjectileColor(Color.yellow.getRGB()).setProjectileSize(9, 9, 9).setProjectileExplosion(7).
					setAbilityCharges(4 * 20).setProjectileCollisionSizes(2);

	public static final AbilityAttribute MOCHIBARAGE = new AbilityAttribute("Mochi Barage").
			setAbilityCooldown(20).setAbilityRepeater(5).setProjectileDamage(2).
			setModelOffsets(0,-1,0);

	public static final AbilityAttribute MOCHIROCKET = new AbilityAttribute("Mochi Rocket").
			setProjectileModel(new ModelFist()).setProjectileTexture("mochinopistol").setProjectileDamage(100).
			setProjectileSize(6, 6, 6).setModelOffsets(0,1,0).setAbilityCooldown(18).
			setProjectileSpeed(2.5F).setProjectilePhysical();


	public static final AbilityAttribute MOCHIGATLING =
			new AbilityAttribute("Mochi Gatling").setProjectileTicks(10);


	public static final AbilityAttribute ChikaraMochi =
			new AbilityAttribute("Chikara Mochi").setAbilityCooldown(8).
	setProjectileModel(new ModelFist()).
	setProjectileTexture("chikara")
		.setProjectileColor(Color.white).
	setModelOffsets(0, 0.5, 0).
	setProjectileDamage(35).
	setProjectileSize(3, 3, 3).
	setProjectileExplosion(2).setAbilityRepeater(6,1);


	public static final AbilityAttribute GREAT_CAGE = new AbilityAttribute("Great Cage").setAbilityCooldown(20);
	public static final AbilityAttribute PRISON_BREAK = new AbilityAttribute("Prison Break").setAbilityCooldown(3).setAbilityPassive();
	public static final AbilityAttribute AWASE_BAORI = new AbilityAttribute("Awase Baori").setAbilityCooldown(12).setProjectileModel(new ModelSphere()).setProjectileColor("000000").setProjectileSize(7, 7, 7);
	public static final AbilityAttribute BIND = new AbilityAttribute("Bind").setAbilityCooldown(10).setAbilityPassive().setAbilityPunch();

	public static final AbilityAttribute SORU = new AbilityAttribute("Soru").addEffects
			(EffectType.USER, new PotionEffect(Potion.moveSpeed.id, 30, 6)).setAbilityPassive();
	public static final AbilityAttribute TEKKAI = new AbilityAttribute("Tekkai").setAbilityCooldown(10).addEffects(EffectType.USER, new PotionEffect(Potion.resistance.id, 30, 100), new PotionEffect(Potion.moveSlowdown.id, 30, 100), new PotionEffect(Potion.digSlowdown.id, 30, 5), new PotionEffect(Potion.jump.id, 30, -100)).setAbilityPassive();
	public static final AbilityAttribute GEPPO = new AbilityAttribute("Geppo").setAbilityCooldown(0.9);
	public static final AbilityAttribute RANKYAKU = new AbilityAttribute("Rankyaku")
			.setAbilityCooldown(9).setProjectileTicks(100).
					setProjectileModel(new ModelCube()).
					setProjectileSize(6, 0.4, 1.5).
					setProjectileColor("69E3FF").setProjectileDamage(20).
					setProjectileExplosion(2, false).
					setProjectileCollisionSizes(1.5, 0.3, 1.5).setProjectileMoveThroughBlocks(true);
	public static final AbilityAttribute SHIGAN = new AbilityAttribute("Shigan").
			setAbilityCooldown(5).setAbilityPassive().setAbilityPunch();

	public static final AbilityAttribute Bite = new AbilityAttribute("Bite").
			setAbilityCooldown(9).setAbilityPassive().setAbilityPunch();



	public static final AbilityAttribute FangSting = new AbilityAttribute("Fang Sting").
			setAbilityCooldown(5).setAbilityPassive().setAbilityPunch()
			.addEffects(HIT,new PotionEffect(Potion.poison.id,8*20,1));


	public static final AbilityAttribute KAMIE = new AbilityAttribute("Kamie").setAbilityCooldown(10).addEffects(EffectType.USER, new PotionEffect(Potion.resistance.id, 20, 100)).setAbilityPassive();




	public static final AbilityAttribute MechArm = new AbilityAttribute("Jishaku MechArm").
			setAbilityPassive().
			setAbilityPunch(90).
			setAbilityCooldown(15);

	public static final AbilityAttribute HOT_BOILING_SPECIAL =
			new AbilityAttribute("Hot Boiling Special").setAbilityPassive().
					setAbilityPunch(10).setAbilityCooldown(7);
	public static final AbilityAttribute EVAPORATE = new AbilityAttribute("Evaporate").setAbilityCooldown(15);

	public static final AbilityAttribute WEIGHTLESS = new AbilityAttribute("Weightless").setAbilityPassive(true);
	public static final AbilityAttribute KICK_OFF_JUMP = new AbilityAttribute("Kick Off Jump").setAbilityPassive().setAbilityCooldown(4);
	public static final AbilityAttribute HEAVY_PUNCH = new AbilityAttribute("Heavy Punch").setAbilityCooldown(20).setAbilityPassive().setAbilityPunch(20);
	public static final AbilityAttribute KILO_PRESS = new AbilityAttribute("Kilo Press").setAbilityCooldown(10).setAbilityPassive();

	public static final AbilityAttribute RUST_TOUCH = new AbilityAttribute("Rust Touch").setAbilityCooldown(19).setAbilityPunch().setAbilityPassive();

	public static final AbilityAttribute FAILED_EXPERIMENT = new AbilityAttribute("Failed Experiment").setAbilityCooldown(7).setAbilityCharges(2 * 20);
	public static final AbilityAttribute MEDIC_BAG_EXPLOSION = new AbilityAttribute("Medic Bag Explosion").setAbilityCooldown(30);
	public static final AbilityAttribute FIRST_AID = new AbilityAttribute("First Aid").setAbilityCooldown(10).setAbilityPunch();

	public static final AbilityAttribute WEATHER_EGG = new AbilityAttribute("Weather Egg").setAbilityCooldown(10).setProjectileModel(new ModelSphere()).setProjectileColor("#BEBEBE").setProjectileAlpha(150).setProjectileSize(1.5, 1.5, 1.5);
	public static final AbilityAttribute GUST_SWORD = new AbilityAttribute("Gust Sword").setAbilityCooldown(8).setProjectileTicks(5).setProjectileSize(.01, .01, .01).setAbilityRepeater(3).setProjectileDamage(2).setProjectileSpeed(5);
	public static final AbilityAttribute THUNDER_BALL = new AbilityAttribute("Thunder Ball").setAbilityCooldown(5).setProjectileModel(new ModelSphere()).setProjectileColor("FFFF00").setProjectileAlpha(150).setProjectileSize(1.5, 1.5, 1.5).setProjectileTicks(300);
	public static final AbilityAttribute COOL_BALL = new AbilityAttribute("Cool Ball").setAbilityCooldown(5).setProjectileModel(new ModelSphere()).setProjectileColor("0000FF").setProjectileAlpha(150).setProjectileSize(1.5, 1.5, 1.5).setProjectileTicks(300);
	public static final AbilityAttribute HEAT_BALL = new AbilityAttribute("Heat Ball").setAbilityCooldown(5).setProjectileModel(new ModelSphere()).setProjectileColor("FF0000").setProjectileAlpha(150).setProjectileSize(1.5, 1.5, 1.5).setProjectileTicks(300);

	public static final AbilityAttribute UCHIMIZU = new AbilityAttribute("Uchimizu").setAbilityCooldown(5).setProjectileModel(new ModelCube()).setProjectileColor("00CED1").setProjectileSize(.5, .5, 1).setProjectileDamage(5).setAbilityRepeater(3, 2);
	public static final AbilityAttribute MURASAME = new AbilityAttribute("Murasame").setAbilityCooldown(8).setProjectileModel(new ModelShark()).setProjectileTexture("murasame").setProjectileSize(.8, .8, 1.2).setProjectileDamage(25);
	public static final AbilityAttribute KACHIAGE_HAISOKU = new AbilityAttribute("Kachiage Haisoku").setAbilityCooldown(15).setAbilityPassive().setAbilityPunch();
	public static final AbilityAttribute SAMEHADA_SHOTEI = new AbilityAttribute("Samehada Shotei").setAbilityCooldown(10).addEffects(EffectType.USER, new PotionEffect(Potion.resistance.id, 10, 120), new PotionEffect(Potion.moveSlowdown.id, 10, 120), new PotionEffect(Potion.jump.id, 30, -100)).setAbilityPassive();
	public static final AbilityAttribute KARAKUSAGAWARA_SEIKEN = new AbilityAttribute("Karakusagawara Seiken").setAbilityCooldown(25);



	public static final AbilityAttribute KAEN_BOSHI = new AbilityAttribute("Kaen Boshi").
			setAbilityCooldown(10).setAbilityPassive().

			setProjectileModel(new ModelSphere()).setProjectileDamage(15).setProjectileSize(.5, .5, .5).setProjectileTicks(100).setProjectileColor("#D3D3D3");
	public static final AbilityAttribute KEMURI_BOSHI = new AbilityAttribute("Kemuri Boshi").setAbilityCooldown(10).setAbilityPassive().setProjectileModel(new ModelSphere()).setProjectileDamage(6).setProjectileSize(.5, .5, .5).setProjectileTicks(100).setProjectileColor("#8741A8");
	public static final AbilityAttribute RENPATSU_NAMARI_BOSHI = new AbilityAttribute("Renpatsu Namari Boshi").
			setAbilityCooldown(15).setAbilityPassive().
			setProjectileModel(new ModelSphere()).setProjectileDamage(12).setProjectileSize(.5, .5, .5).setProjectileTicks(100).setProjectileExplosion(1, false).setProjectileColor("#D3D3D3").setAbilityRepeater(10, 3);
	public static final AbilityAttribute SAKURETSU_SABOTEN_BOSHI = new AbilityAttribute("Sakuretsu Saboten Boshi").
			setAbilityCooldown(12).setAbilityPassive().
			setProjectileModel(new ModelSphere()).setProjectileDamage(30).setProjectileExplosion(2, false, false).setProjectileSize(.5, .5, .5).setProjectileTicks(100).setProjectileColor("#D3D3D3");

	public static final AbilityAttribute SHI_SHISHI_SONSON = new AbilityAttribute("Shi Shishi Sonson").setAbilityCooldown(7);
	public static final AbilityAttribute SANBYAKUROKUJU_POUND_HO = new AbilityAttribute("Sanbyakurokuju Pound Ho").setAbilityCooldown(5).setProjectileTicks(100).setProjectileModel(new ModelCube()).setProjectileSize(6, 0.4, 1.5).setProjectileColor("bbf7b4").setProjectileDamage(18).setProjectileExplosion(3, false);
	public static final AbilityAttribute YAKKODORI = new AbilityAttribute("Yakkodori").
			setAbilityCooldown(3).setAbilityCooldown(5).setProjectileTicks(20).setProjectileModel
			(new ModelCube()).setProjectileSize(0.4, 6, 0.4).setProjectileColor("bbf7b4").
			setProjectileDamage(10).setProjectileExplosion(1, false).setProjectileMoveThroughBlocks
			(true);
	public static final AbilityAttribute WingSlash = new AbilityAttribute("Wing Slash").
			setAbilityCooldown(3).setAbilityCooldown(5).setProjectileTicks(20).setProjectileModel
			(new ModelCube()).setProjectileSize(0.4, 6, 0.4).setProjectileColor(Color.white).
			setProjectileDamage(50).setProjectileExplosion(1, false).setProjectileMoveThroughBlocks
			(true);


	public static final AbilityAttribute WingSlashB = new AbilityAttribute("Wing SlashB").
			setAbilityCooldown(3).setAbilityCooldown(5).setProjectileTicks(20).setProjectileModel
			(new ModelCube()).setProjectileSize(0.4, 6, 0.4).setProjectileColor(Color.white).
			setProjectileDamage(24).setProjectileExplosion(1, false).setProjectileMoveThroughBlocks
			(true).setAbilityRepeater(3);

	public static final AbilityAttribute O_TATSUMAKI = new AbilityAttribute("O Tatsumaki").setAbilityCooldown(7);

	public static final AbilityAttribute FRESH_FIRE = new AbilityAttribute("Fresh Fire").setAbilityCooldown(1.5).
			setProjectileTicks(7).setProjectileSize(.01, .01, .01).setProjectileDamage(30);
	public static final AbilityAttribute COLA_OVERDRIVE = new AbilityAttribute("Cola Overdrive").setAbilityCooldown(7).addEffects(EffectType.USER, new PotionEffect(Potion.moveSpeed.id, 200, 0), new PotionEffect(Potion.damageBoost.id, 200, 1));
	public static final AbilityAttribute RADICAL_BEAM = new AbilityAttribute("Radical Beam").
			setAbilityCooldown(10).setProjectileModel(new ModelCube()).setProjectileColor("FFFF00").
			setProjectileSize(.5, .5, 1).setProjectileDamage(35).setProjectileExplosion(4, false);
	public static final AbilityAttribute STRONG_RIGHT = new AbilityAttribute("Strong Right").setAbilityCooldown(2.5).
			setProjectileModel(new ModelCube()).setProjectileColor("F5DEB3").setProjectileTicks(5).
			setProjectileSize(1, 1, 1.5).setProjectileDamage(25);
	public static final AbilityAttribute COUP_DE_VENT = new AbilityAttribute("Coup de Vent").setAbilityCooldown(10).setProjectileTicks(7).setProjectileSize(.01, .01, .01).setProjectileDamage(10).setAbilityCharges(30);

	public static final AbilityAttribute KENBUNSHOKU_HAKI_AURA = new AbilityAttribute("Kenbunshoku Haki: Aura").setAbilityPassive(true);
	public static final AbilityAttribute KENBUNSHOKU_HAKI_FUTURE_SIGHT = new AbilityAttribute("Kenbunshoku Haki: Future Sight").setAbilityPassive(true).setAbilityCooldown(60);
	public static final AbilityAttribute BUSOSHOKU_HAKI_HARDENING = new AbilityAttribute("Busoshoku Haki: Hardening").setAbilityPassive(true);
	public static final AbilityAttribute BUSOSHOKU_HAKI_FULL_BODY_HARDENING = new AbilityAttribute("Busoshoku Haki: Full-Body Hardening").setAbilityPassive(true);
	public static final AbilityAttribute BUSOSHOKU_HAKI_IMBUING = new AbilityAttribute("Busoshoku Haki: Imbuing").setAbilityPassive(true);
	public static final AbilityAttribute HAOSHOKU_HAKI = new AbilityAttribute("Haoshoku Haki").setAbilityCharges(3 * 20).setAbilityCooldown(90);

	public static final AbilityAttribute BOROBREATH = new AbilityAttribute("Boro Breath")
			.setAbilityCooldown(20).setProjectileDamage(500).
					setProjectileModel(new boro()).setProjectileSize(5, 5, 10)
			.setProjectileTexture("borobreath").setProjectileExplosion(1);

	public static final AbilityAttribute kamaitachi = new AbilityAttribute("Kamai Tachi")
			.setAbilityCooldown(20).setProjectileDamage(15).
					setProjectileModel(new Kamaitachi()).setProjectileSize(6, 6, 6).
					setAbilityRepeater(3).setProjectileTexture("kamaitachi").
					setProjectileExplosion(1).setAbilityTexture("rankyakuhyobi");




	public static final AbilityAttribute DRAGONSCALE = new AbilityAttribute("Dragon Scale").setAbilityCooldown(30);
	public static final AbilityAttribute FIRE_BREATH =new
			AbilityAttribute("Fire Breath").setAbilityCooldown(20)
			.setProjectileModel(new ModelSphere()).setProjectileDamage(45).setProjectileColor(Color.red
			).setProjectileSize
					(9, 9, 9).setProjectileExplosion(7).
					setAbilityCharges(4 * 20).setProjectileCollisionSizes(2).setAbilityRepeater(3);



	public static final AbilityAttribute fireball =new
			AbilityAttribute("Fire Ball").setAbilityCooldown(20)
			.setProjectileModel(new ModelSphere()).setProjectileDamage(15).setProjectileColor(Color.red
			).setProjectileSize
					(6, 6, 6).setProjectileExplosion(7).
					setAbilityCharges(4 * 20).setProjectileCollisionSizes(2).setAbilityRepeater(3);


	public static final AbilityAttribute DRAGONPOINT = new AbilityAttribute("Dragon Point").
			setAbilityCooldown(1).setAbilityDisplayName("Dragon Point").setAbilityTexture("dragonpoint").
			setAbilityPassive(true);

	public static final AbilityAttribute WHEELDASH = new AbilityAttribute("Wheel Dash").
			setAbilityCooldown(1).setAbilityDisplayName("Wheel Dash").setAbilityTexture("wheelpoint").
			setAbilityPassive(true);


	public static final AbilityAttribute ThunderStorm = new AbilityAttribute("Thunder Storm").
			setProjectileModel(new ModelCube()).setProjectileSize(0,0,0).setAbilityCooldown(40);

	public static final AbilityAttribute lightningRage = new AbilityAttribute("Lightning Rage").setAbilityTexture("lrage").
			setProjectileModel(new ModelCube()).setProjectileSize(0,0,0).setAbilityCooldown(40);


	public static final AbilityAttribute BUDDHAPOINT = new AbilityAttribute("Buddha Point").
			setAbilityCooldown(1).setAbilityDisplayName("Buddha Point").setAbilityTexture("buddha").
			setAbilityPassive(true);

	public static final AbilityAttribute ImpactWaveB =
			new AbilityAttribute("Impact Wave Barrage").setAbilityCooldown(25).
					setProjectileModel(new ModelSphere()).setProjectileDamage(20).
					setProjectileColor(Color.yellow.getRGB()).setProjectileSize(9, 9, 9).setProjectileExplosion(7).
					setAbilityCharges(4 * 20).setProjectileCollisionSizes(2).setAbilityRepeater(3, 2);


	public static final AbilityAttribute FireSpit =
			new AbilityAttribute("Fire Spit").setAbilityCooldown(25).
					setProjectileModel(new ModelSphere()).setProjectileColor(Color.red).
					setModelOffsets(0, 0.5, 0).
					setProjectileSize(3, 3, 3).setAbilityCooldown(6).setAbilityRepeater(5).setProjectileDamage(25).
	setModelOffsets(0,-1,0).setAbilityTexture("fspit");

	public static final AbilityAttribute ImpactWaveA =
			new AbilityAttribute("Impact Wave").setAbilityCooldown(25).
					setProjectileModel(new ModelSphere()).setProjectileDamage(100).
					setProjectileColor(Color.yellow.getRGB()).setProjectileSize(9, 9, 9).setProjectileExplosion(7).
					setAbilityCharges(4 * 20).setProjectileCollisionSizes(2);

	public static final AbilityAttribute BuddhaPunch = new AbilityAttribute("Buddha Punch").setAbilityCooldown(15).
			setAbilityPassive().setAbilityPunch(100);


	public static final AbilityAttribute SoulSteal = new AbilityAttribute("Soul Steal").setAbilityCooldown(15).
			setAbilityTexture("soulsteal").setAbilityPassive().setAbilityPunch(40).addEffects(HIT,
			new PotionEffect(Potion.wither.id,2,15*20));

	public static final AbilityAttribute MamouthPoint = new AbilityAttribute("Mamouth Point").
			setAbilityDisplayName("Mamouth Point").setAbilityTexture("mfull").
			setAbilityPassive(true);


	public static final AbilityAttribute AncientRush = new AbilityAttribute("Ancient Rush").
			setAbilityCooldown(20).setAbilityRepeater(5).setProjectileDamage(50).setAbilityTexture("mdart").
			setModelOffsets(0,-1,0);

	public static final AbilityAttribute AncientBlowDamage = new AbilityAttribute("Ancient Blow Damage").
			setAbilityCooldown(8).setAbilityPunch(40).setAbilityTexture("mivory");

	public static final AbilityAttribute AncientStomp = new AbilityAttribute("Ancient Stomp")
			.setAbilityTexture("mstomp").setAbilityCooldown(15);


	public static final AbilityAttribute AncientTrunkShot =
			new AbilityAttribute("Ancient Trunk SHot").setAbilityTexture("mshot").setAbilityCooldown(7).
					setProjectileModel(new ModelCube()).setProjectileTexture("zouskin")
					.setProjectileSize(2.5, 2.5, 4).setProjectileColor(new Color(110, 44,0).getRGB()).
					setProjectileDamage(50)
					.addEffects(PROJECTILE, new PotionEffect(Potion.weakness.id, 5 * 20)).setProjectilePhysical();





	public static final AbilityAttribute NuePoint = new AbilityAttribute("Nue Point").
			setAbilityDisplayName("Nue Point").setAbilityTexture("npoint").
			setAbilityPassive(true);

	public static final AbilityAttribute Slice =
			new AbilityAttribute("Slice")
					.setAbilityCooldown(10).setProjectileDamage(70).
					addEffects(PROJECTILE,new PotionEffect(Potion.moveSlowdown.id,0,5*20));

	public static final AbilityAttribute NUECLAWSLASH = new AbilityAttribute("Nue Claw Slash").
			setAbilityCooldown(10).
			setProjectileModel(new nuprojo()).setProjectileTexture("nueclawslash").
			setProjectileSize(6, 6, 6)
			.setProjectileDamage(150).setProjectileExplosion(2);

	public static final AbilityAttribute NuesCurse = new AbilityAttribute("Nues Curse").
			setAbilityCooldown(10);



	public static final AbilityAttribute LeopardPoint = new AbilityAttribute("Leopard Point").
			setAbilityDisplayName("Leopard Point").setAbilityTexture("lpoint").
			setAbilityPassive(true);


	public static final AbilityAttribute LeopardHybridPoint = new AbilityAttribute("Leopard Hybrid Point").
			setAbilityDisplayName("Leopard Hybrid Point").setAbilityTexture
			("hlpoint").
			setAbilityPassive(true);


	public static final AbilityAttribute RankyakuHyobi = new AbilityAttribute("Rankyaku Hyobi").
			setAbilityCooldown(9).setProjectileTicks(100).
			setProjectileModel(new ModelCube()).
			setProjectileSize(6, 0.4, 1.5).
			setProjectileColor("69E3FF").setProjectileDamage(60).
			setProjectileExplosion(2, false).
			setProjectileCollisionSizes(1.5, 0.3, 1.5).
			setProjectileMoveThroughBlocks(true).
			setAbilityRepeater(5,2).setAbilityTexture("rankyakuhyobi");


	public static final AbilityAttribute RankyakuHyobiGiraf = new AbilityAttribute("Rankyaku Hyobi Giraf").
			setAbilityCooldown(9).setProjectileTicks(100).
			setProjectileModel(new ModelCube()).
			setProjectileSize(6, 0.4, 1.5).
			setProjectileColor("69E3FF").setProjectileDamage(20).
			setProjectileExplosion(2, false).
			setProjectileCollisionSizes(1.5, 0.3, 1.5).
			setProjectileMoveThroughBlocks(true).
			setAbilityRepeater(5,2).setAbilityTexture("rankyakuhyobi");

	public static final AbilityAttribute SaiDaiRinRokuogan =
			new AbilityAttribute("Sai Dai Rin: Rokuogan").
			setAbilityCooldown(5).setAbilityPassive().setAbilityPunch().setAbilityTexture("saidairin");

	public static final AbilityAttribute LeopardMawl = new AbilityAttribute("Leopard Mawl")
			.setAbilityTexture("leopardmawl").setAbilityCooldown(10).setProjectileDamage(50);


	public static final AbilityAttribute LEOPARD_SPRING_HOPPER =
			new AbilityAttribute("Leopard Spring Hopper").
			setAbilityCooldown(2).setAbilityCharges(10).setAbilityTexture("springjump");




    public static final AbilityAttribute YamataNoOrochi = new AbilityAttribute("YamataNoOrochi Point").
            setAbilityDisplayName("YamataNoOrochi Point").
            setAbilityPassive(true);


    public static final AbilityAttribute piratePoint = new AbilityAttribute("Pirate Point").
            setAbilityDisplayName("Pirate Point").
            setAbilityPassive(true);



	public static final AbilityAttribute PteranodonPoint = new AbilityAttribute("Smilodon Point").
			setAbilityDisplayName("Smilodon Point").
			setAbilityTexture("pfull").
			setAbilityPassive(true);





	public static final AbilityAttribute Beak_Rush = new AbilityAttribute("Beak").
			setAbilityCooldown(10).setProjectileDamage(70).setAbilityTexture("beck");


	public static final AbilityAttribute BeakRush =
			new AbilityAttribute("Pounce")
					.setAbilityTexture("beakrush").setAbilityCooldown(10).setProjectileDamage(70).
					addEffects(PROJECTILE,new PotionEffect(Potion.moveSlowdown.id,5*20,0));



	public static final AbilityAttribute Peck =
			new AbilityAttribute("Smilodon Leap").
					setAbilityTexture("peck").setAbilityCooldown(2).setAbilityCharges(10);


	public static final AbilityAttribute WingedTornado =
			new AbilityAttribute("Smilodon Chomp").
	setAbilityCooldown(5).setAbilityPassive().setAbilityPunch(50)
					.setAbilityTexture("chomp")	.addEffects(HIT,new PotionEffect(Potion.moveSlowdown.id,1,
					5*20));


	public static final AbilityAttribute SmilodonStalk = new AbilityAttribute("Smilodon Stalk")
            .setAbilityTexture("smilodonstalk")	.setAbilityCooldown(30);

	public static final AbilityAttribute SmilodonClaw = new AbilityAttribute("Smilodon Claw Slash")
			.setAbilityCooldown(8).
					setProjectileModel(new ModelSphere()).
					setModelOffsets(0, 0.5, 0).setProjectileDamage(40).
					setProjectileSize(0, 0, 0).setAbilityTexture("smiladonclaw");


	public static final AbilityAttribute SolarLauncher = new AbilityAttribute("Solar Launcher")
			.setAbilityCooldown(8).
					setProjectileModel(new ModelSolar()).
					setModelOffsets(0, 0.5, 0).setProjectileDamage(250).setAbilityTexture("slaunch").
					setProjectileSize(5, 5, 5).setProjectileTexture("fireball").setProjectileExplosion(1);



	public static final AbilityAttribute LightningEngulfment = new AbilityAttribute("Lightning Engulfment")
			.setAbilityCooldown(8).
					setProjectileModel(new thundercloud()).setAbilityTexture("leng").
					setModelOffsets(0, 0.5, 0).setProjectileDamage(250).
					setProjectileSize(2, 2,2).setProjectileTexture("thundercloud").setProjectileExplosion(2,false,false);

	public static final AbilityAttribute BisuHei = new AbilityAttribute("Bisu Hei")
			.setAbilityCooldown(8).
					setProjectileModel(new soldierpro()).
					setModelOffsets(0, 0.5, 0).setProjectileDamage(100).
		setProjectileTexture("soldier1").setAbilityTexture("bhei").
					setProjectileExplosion(2,false,false);;

	public static final AbilityAttribute BisuHeiPoint = new AbilityAttribute("Bisu Hei Point").
			setAbilityDisplayName("Bisu Hei Transformation").
			setAbilityTexture("bpoint").
			setAbilityPassive(true);

	public static final AbilityAttribute BisuShot = new AbilityAttribute("Bisu Shot")
			.setAbilityCooldown(8).
					setProjectileModel(new biskit()).
                    setModelOffsets(0, 1.5, 0).setProjectileDamage(40).
					setProjectileSize(3, 3, 3).setProjectileTexture("biskit").setAbilityTexture("bshot");


	public static final AbilityAttribute BisuShotBarrage = new AbilityAttribute("Bisu Shot Barrage")
			.setAbilityCooldown(8).
					setProjectileModel(new biskit()).
					setModelOffsets(0, 1.5, 0).setProjectileDamage(40).setAbilityRepeater(5).
					setProjectileSize(3, 3, 3).setProjectileTexture("biskit").
					setAbilityTexture("bshotb").setProjectileExplosion(2,false,false);

	public static final AbilityAttribute BisuThrust = new AbilityAttribute("Bisu Thrust")
			.setAbilityCooldown(10).setProjectileDamage(70).
					addEffects(PROJECTILE,new PotionEffect(Potion.moveSlowdown.id,5*20,0)).setAbilityTexture("btust");

	public static final AbilityAttribute GodThreat = new AbilityAttribute("God Threat")
			.setAbilityCooldown(20).setProjectileDamage(110).setProjectileModel(new godthreat())
            .
                 addEffects(PROJECTILE,new PotionEffect(Potion.moveSlowdown.id,5*20,2)).
					setProjectileTexture("6holystring").setProjectileSize(7, 7, 7);




	public static final AbilityAttribute YakiMochi = new AbilityAttribute("Yaki Mochi")
			.setAbilityCooldown(7).setProjectileDamage(70).setProjectileModel(new yaki())
			.setProjectileTexture("yakimochu").setProjectileSize(6, 6, 6).setProjectileExplosion(2);


	public static final AbilityAttribute FlapThread = new AbilityAttribute("Flap Thread")
			.setAbilityCooldown(10).setProjectileDamage(60).setProjectileModel(new flapThread())
			.setProjectileTexture("flapthread").setProjectileSize(6, 6, 6);



	public static final AbilityAttribute BuzzMochi = new AbilityAttribute("Buzz Mochi")
			.setAbilityCooldown(7).setProjectileDamage(110).setProjectileModel(new buzzmochi())
			.setProjectileTexture("buzzcutmochi").setAbilityTexture("buzzcut").setProjectileSize(6, 6, 6).setProjectileExplosion(2);


	public static final AbilityAttribute Everwhite = new AbilityAttribute("Ever White")
			.setAbilityCooldown(10).setProjectileDamage(100).setProjectileModel(new everwhite())
			.setProjectileTexture("everwhite").setAbilityTexture("everwhite").setProjectileSize(6, 6, 6).
					setProjectileExplosion(2).addEffects(PROJECTILE,new PotionEffect(Potion.moveSlowdown.id,5*20,5));


	public static final AbilityAttribute Inugami = new AbilityAttribute("Inugami")
			.setAbilityCooldown(10).setProjectileDamage(110).
					setProjectileModel(new inugami()).setProjectileTexture("ig").
					setProjectileSize(4, 4, 4).
				setAbilityTexture("ig");

	public static final AbilityAttribute PteraPoint = new AbilityAttribute("Pteranodon Point").
			setAbilityCooldown(1).setAbilityDisplayName("Pteranodon Point").setAbilityPassive(true);

	public static final AbilityAttribute Peck_real = new AbilityAttribute("PeckReal").
			setAbilityCooldown(5).setAbilityPassive().setAbilityPunch();

	public static final AbilityAttribute head = new
			AbilityAttribute("Head Whip").setAbilityCooldown(20)
			.setProjectileModel(new headwhip()).setProjectileTexture("8_headed_dragon").setProjectileDamage(120).setProjectileExplosion(2);


	public static final AbilityAttribute  NoIwatoAmanoIwato = new
			AbilityAttribute("No Iwato Amano Iwato").setAbilityCooldown(20)
			.setProjectileModel(new amanoiwato()).setProjectileDamage(130).setProjectileSize
					(4,4, 4).setProjectileTexture("amanoiwato");

	public static final AbilityAttribute  Spank = new
			AbilityAttribute("Spank").setAbilityCooldown(20)
			.setProjectileModel(new spank()).setProjectileDamage(90).setProjectileSize
					(3, 3, 3).setProjectileTexture("spank").setProjectileExplosion(2)
			;
	public static final AbilityAttribute  SpankBarage = new
			AbilityAttribute("SpankBarage").setAbilityCooldown(20)
			.setProjectileModel(new spank()).setProjectileDamage(25).setProjectileSize
					(2, 2, 2).setProjectileTexture("spank").setAbilityRepeater(3,2).setProjectileExplosion(2);


	public static final AbilityAttribute  hebiHeal = new
			AbilityAttribute("hebiHeal").setAbilityCooldown(30);

}



