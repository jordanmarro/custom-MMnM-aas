package xyz.pixelatedw.MineMineNoMi3.awakened.soros.pirat;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.abilities.effects.DFEffect;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.DFESoru;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;

public class pirate {


    static {
        Values.abilityWebAppExtraParams.put("Santoryu Stance", new String[]
                {"desc", "Makes you have 3 swords"});
        Values.abilityWebAppExtraParams.put("Pounce", new String[]
                {"desc", "possible make you go farther"});
        Values.abilityWebAppExtraParams.put("Smilodon Chomp", new String[]
                {"desc", "shigan"});
        Values.abilityWebAppExtraParams.put("Smilodon Stalk", new String[]
                {"desc", "akes everyone in a 20 block radius slow 3 for 10 seconds  "});
        Values.abilityWebAppExtraParams.put("Smilodon Leap", new String[]
                {"desc", "Make you jump"});
        Values.abilityWebAppExtraParams.put("Smilodon Claw Slash", new String[]
                {"desc", "Sends slash projectiles at enemies that does 20 damage each"});


    }



    public static Ability[] abilitiesArray = new Ability[]
            {new piratePoint(),
            new onigiri(), new HyakuhachiPoundHo(),new Yakionigiri(),new
                    SantoryuOgi()};

    public static class onigiri extends Ability
    {
        private int initialY;
        public onigiri()
        {
            super(ListAttributes.onigiri);
        }

        @Override
        public void use(EntityPlayer player) {

            if (!this.isOnCooldown) {
                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float) Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float) Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 4;
                mZ *= 4;

                motion("=", mX, player.motionY, mZ, player);
                this.projectile = new pirateProjo.onigiri(player.worldObj, player, ListAttributes.onigiri);
                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(currentCooldown > 180 && player.posY >= this.initialY)
            {
                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 1.6))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 12 );

                for(int[] location : WyHelper.getBlockLocationsNearby(player, 3))
                {
                    if(location[1] >= player.posY)
                    {
                        if(DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage"))
                        {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }

    }
    public static class Rengoku extends Ability {
        private int initialY;

        public Rengoku() {
            super(ListAttributes.Rengoku);
        }

        @Override
        public void use(EntityPlayer player) {

            if (!this.isOnCooldown) {
                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float) Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float) Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 4;
                mZ *= 4;

                motion("=", mX, player.motionY, mZ, player);
                this.projectile = new pirateProjo.Rengoku(player.worldObj, player, ListAttributes.Rengoku);
                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown) {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (currentCooldown > 180 && player.posY >= this.initialY) {
                for (EntityLivingBase e : WyHelper.getEntitiesNear(player, 1.6))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 12);

                for (int[] location : WyHelper.getBlockLocationsNearby(player, 3)) {
                    if (location[1] >= player.posY) {
                        if (DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage")) {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }
    }
    public static class Yakionigiri extends Ability
    {
        private int initialY;
        public Yakionigiri()
        {
            super(ListAttributes.Yakionigiri);
        }

        @Override
        public void use(EntityPlayer player) {

            if (!this.isOnCooldown) {
                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float) Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float) Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 4;
                mZ *= 4;

                motion("=", mX, player.motionY, mZ, player);
                this.projectile = new pirateProjo.onigiri(player.worldObj, player, ListAttributes.Yakionigiri);
                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(currentCooldown > 180 && player.posY >= this.initialY)
            {
                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 1.6))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 12 );
                projectile.setFire(10);
                for(int[] location : WyHelper.getBlockLocationsNearby(player, 3))
                {
                    if(location[1] >= player.posY)
                    {
                        if(DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage"))
                        {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }

    }
    public static class SantoryuOgi extends Ability {
        public SantoryuOgi() {
            super(ListAttributes.SantoryuOgi);
        }
        @Override
        public void use(EntityPlayer player) {
            this.projectile = new pirateProjo.SantoryuOgi(player.worldObj, player, ListAttributes.SantoryuOgi);
            super.use(player);
        }
    }



    public static class piratePoint extends Ability
    {
        private DFEffect extra = null;
        public piratePoint()
        {
            super(ListAttributes.piratePoint);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(!player.capabilities.isFlying && player.onGround)
            {
                if(extra == null)
                    extra = new DFESoru(player, 99999);
                else
                {
                    extra.forceStop();
                    extra = null;
                }
                super.passive(player);
            }
            else if(!player.onGround)
            {
                if(extra != null)
                {
                    extra.forceStop();
                    extra = null;
                }
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {

        }

        @Override
        public void endPassive(EntityPlayer player)
        {

        }

    }

  




    public static class HyakuhachiPoundHo extends Ability {
        public HyakuhachiPoundHo()
        {
            super(ListAttributes.HyakuhachiPoundHo);
        }

        @Override
        public void use(EntityPlayer player) {
            this.projectile = new pirateProjo.HyakuhachiPoundHo(player.worldObj, player, ListAttributes.HyakuhachiPoundHo);
            super.use(player);
        }
    }

    private static void motion(String c, double x, double y, double z, EntityPlayer p)
    {
        WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
    }


}

/*- Mochi wheel speed upped by a little bit (very little)
- Leopard point speed upped by 1
- anti knockback to mammoth point (75% knockback resistance)

 */
