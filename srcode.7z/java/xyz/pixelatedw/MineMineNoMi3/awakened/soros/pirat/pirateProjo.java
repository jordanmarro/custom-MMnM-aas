package xyz.pixelatedw.MineMineNoMi3.awakened.soros.pirat;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class pirateProjo {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static
    {
        abilitiesClassesArray.add(new Object[] {onigiri.class, ListAttributes.onigiri});
        abilitiesClassesArray.add(new Object[] {HyakuhachiPoundHo.class, ListAttributes.HyakuhachiPoundHo});
        abilitiesClassesArray.add(new Object[] {Yakionigiri.class, ListAttributes.Yakionigiri});
        abilitiesClassesArray.add(new Object[] {SantoryuOgi.class, ListAttributes.SantoryuOgi});
        abilitiesClassesArray.add(new Object[] {Rengoku.class, ListAttributes.Rengoku});

    }
    public static class Rengoku extends AbilityProjectile {
        public Rengoku(World world) {
            super(world);
        }

        public Rengoku(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public Rengoku(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
    public static class SantoryuOgi extends AbilityProjectile {
        public SantoryuOgi(World world) {
            super(world);
        }

        public SantoryuOgi(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public SantoryuOgi(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
    public static class Yakionigiri extends AbilityProjectile {
        public Yakionigiri(World world) {
            super(world);
        }

        public Yakionigiri(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public Yakionigiri(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
    public static class onigiri extends AbilityProjectile {
        public onigiri(World world) {
            super(world);
        }

        public onigiri(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public onigiri(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
    public static class HyakuhachiPoundHo extends AbilityProjectile {
        public HyakuhachiPoundHo(World world) {
            super(world);
        }

        public HyakuhachiPoundHo(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public HyakuhachiPoundHo(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }
    }
    }




/*package xyz.pixelatedw.MineMineNoMi3.soros.mam;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.soros.MochiMochiNoMiProjectiles;

import java.util.ArrayList;

public class MamouthProjectiles {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MamouthProjectiles.AncientTrunkShot.class,
                ListAttributes.AncientTrunkShot});


    }

    public static class AncientTrunkShot extends AbilityProjectile {
        public AncientTrunkShot(World world) {
            super(world);
        }

        public AncientTrunkShot(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public AncientTrunkShot(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }
}


 */