package xyz.pixelatedw.MineMineNoMi3.awakened.soros.hana;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;

public class hana {
    public static Ability[] abilitiesArray = new Ability[]{
            new Wing(), new Spank(), new Stomp(), new SpankBarage(),new Clutch()};

//new Clutch(), new Rope()
    public static class Clutch extends Ability {
        public Clutch() {
            super(ListAttributes.Clutch);
        }
            public void use(EntityPlayer player)
            {
                if(isOnCooldown()) {
                    return;
                }
                for (EntityLivingBase ent : WyHelper.getEntitiesNear(player, 20)) {
                    ent.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 8*20, 10));
                }

                super.use(player);
            }
    }


    public static class Spank extends Ability {
        public Spank() {
            super(ListAttributes.Spank);
        }

        public void use(EntityPlayer player) {
            this.projectile = new hanProjo.Spank(player.worldObj, player, attr);
            super.use(player);
        }
    }

    public static class SpankBarage extends Ability {
        public SpankBarage() {
            super(ListAttributes.SpankBarage);
        }

        public void use(EntityPlayer player) {
            this.projectile = new hanProjo.SpankBarage(player.worldObj, player, attr);
            super.use(player);
        }
    }


    public static class Stomp extends Ability {
        public Stomp() {
            super(ListAttributes.Stomp);
        }

        @Override
        public void use(EntityPlayer player) {
            if (!this.isOnCooldown) {
                MovingObjectPosition mop = WyHelper.rayTraceBlocks(player);

                if (mop != null) {
                    double x = mop.blockX;
                    double y = mop.blockY;
                    double z = mop.blockZ;

                    AbilityProjectile proj = new hanProjo.Stomp(player.worldObj, player, ListAttributes.Stomp);
                    proj.setLocationAndAngles(x, (y + 90), z, 0, 0);
                    proj.motionX = 0;
                    proj.motionZ = 0;
                    proj.motionY = -2.4;
                    player.worldObj.spawnEntityInWorld(proj);
                }
            }
            super.use(player);
        }
    }


    public static class Wing extends Ability {
        public Wing() {
            super(ListAttributes.WING);
        }

        public void use(EntityPlayer player) {
            if (!this.isOnCooldown) {
                WyHelper.Direction dir = WyHelper.get8Directions(player);

                double mX = 0;
                double mY = 0;
                double mZ = 0;

                if (player.onGround)
                    mY += 1.8;
                else
                    mY += 1.96;

                if (dir == WyHelper.Direction.NORTH) mZ -= 1;
                if (dir == WyHelper.Direction.NORTH_WEST) {
                    mZ -= 1;
                    mX -= 1;
                }
                if (dir == WyHelper.Direction.SOUTH) mZ += 1;
                if (dir == WyHelper.Direction.NORTH_EAST) {
                    mZ -= 1;
                    mX += 1;
                }
                if (dir == WyHelper.Direction.WEST) mX -= 1;
                if (dir == WyHelper.Direction.SOUTH_WEST) {
                    mZ += 1;
                    mX -= 1;
                }
                if (dir == WyHelper.Direction.EAST) mX += 1;
                if (dir == WyHelper.Direction.SOUTH_EAST) {
                    mZ += 1;
                    mX += 1;
                }

                motion("=", mX, mY, mZ, player);

                super.use(player);
            }
        }
    }

    public static class Rope extends Ability {
        public Rope() {
            super(ListAttributes.Rope);
        }

        public void use(EntityPlayer player) {
            super.use(player);
            this.projectile = new hanProjo.Rope(player.worldObj, player, attr);
        }


    }

    private static void motion(String c, double x, double y, double z, EntityPlayer p) {
        WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
    }
}

