package xyz.pixelatedw.MineMineNoMi3.awakened.soros.hana;

import net.minecraft.entity.EntityLivingBase;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.abilities.effects.DFEffect;

public class EffectClutch extends DFEffect
{

	public EffectClutch(EntityLivingBase entity, int timer)
        {
            super(entity, timer, ID.EXTRAEFFECT_CLUTCH);
        }

        public void onEffectStart(EntityLivingBase entity)
        {

        }

        public void onEffectEnd(EntityLivingBase entity)
        {

        }

    }

