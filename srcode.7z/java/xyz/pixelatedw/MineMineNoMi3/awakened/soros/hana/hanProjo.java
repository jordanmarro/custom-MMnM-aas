package xyz.pixelatedw.MineMineNoMi3.awakened.soros.hana;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class hanProjo {

    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {
        abilitiesClassesArray.add(new Object[] {Clutch.class, ListAttributes.Clutch});
        abilitiesClassesArray.add(new Object[] {Spank.class, ListAttributes.Spank});
        abilitiesClassesArray.add(new Object[] {Stomp.class, ListAttributes.Stomp});
        abilitiesClassesArray.add(new Object[] {SpankBarage.class, ListAttributes.SpankBarage});
        abilitiesClassesArray.add(new Object[] {Rope.class, ListAttributes.Rope});

    }
    public static class Rope extends AbilityProjectile
    {
        public Rope(World world)
        {super(world);}

        public Rope(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Rope(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


        @Override
        public void tasksImapct(MovingObjectPosition hit)
        {
            if(hit.entityHit != null && !hit.entityHit.isDead)
                ((EntityLivingBase) hit.entityHit).setPosition(this.getThrower().posX, this.getThrower().posY, this.getThrower().posZ);
        }
    }

    public static class Clutch extends AbilityProjectile
    {
        public Clutch(World world)
        {super(world);}

        public Clutch(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Clutch(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }

        public void tasksImapct(MovingObjectPosition hit)
        {
            if(hit.entityHit != null && hit.entityHit instanceof EntityLivingBase)
            {
                EntityLivingBase target = ((EntityLivingBase)hit.entityHit);

                new EffectClutch(target, 400);
            }
        }
    }

    public static class SpankBarage extends AbilityProjectile
    {
        public SpankBarage(World world)
        {super(world);}

        public SpankBarage(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public SpankBarage(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


    }
    public static class Spank extends AbilityProjectile
    {
        public Spank(World world)
        {super(world);}

        public Spank(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Spank(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


    }

    public static class Stomp extends AbilityProjectile
    {
        public Stomp(World world)
        {super(world);}

        public Stomp(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Stomp(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }


    }
}
