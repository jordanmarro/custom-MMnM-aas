package xyz.pixelatedw.MineMineNoMi3.awakened.soros;

import net.minecraft.item.Item;

public class psword  extends Item {
    public psword()
    {

    }
}
