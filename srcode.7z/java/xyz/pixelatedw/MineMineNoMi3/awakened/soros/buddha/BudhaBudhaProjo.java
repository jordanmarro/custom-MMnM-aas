package xyz.pixelatedw.MineMineNoMi3.awakened.soros.buddha;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.extra.AbilityExplosion;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class BudhaBudhaProjo {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{BudhaBudhaProjo.ImpactWaveB.class,
                ListAttributes.ImpactWaveB});

        abilitiesClassesArray.add(new Object[]{BudhaBudhaProjo.ImpactWaveA.class,
                ListAttributes.ImpactWaveA});
    }

    public static class ImpactWave extends AbilityProjectile {
        public ImpactWave(World world) {
            super(world);
        }

        public ImpactWave(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public ImpactWave(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }


    public static class ImpactWaveB extends AbilityProjectile {
        public ImpactWaveB(World world) {
            super(world);
        }

        public ImpactWaveB(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public ImpactWaveB(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }

    }

    public static class ImpactWaveA extends AbilityProjectile {
        public ImpactWaveA(World world) {
            super(world);
        }

        public ImpactWaveA(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public ImpactWaveA(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }

        @Override
        public void tasksImapct(MovingObjectPosition hit) {
            AbilityExplosion explosion = WyHelper.newExplosion(this,
                    this.posX, this.posY, this.posZ, 5);
            explosion.setDamageOwner(false);
            explosion.setFireAfterExplosion(false);
            explosion.setDestroyBlocks(false);
            explosion.doExplosion();
            super.tasksImapct(hit);
        }
    }
}


