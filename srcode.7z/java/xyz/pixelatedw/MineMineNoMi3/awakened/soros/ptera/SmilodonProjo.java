package xyz.pixelatedw.MineMineNoMi3.awakened.soros.ptera;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;

import java.util.ArrayList;

public class SmilodonProjo {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static
    {
        abilitiesClassesArray.add(new Object[] {Rankyaku.class, ListAttributes.WingSlash});
        abilitiesClassesArray.add(new Object[] {Rankyaku.class, ListAttributes.WingSlashB});
    }

    public static class Rankyaku extends AbilityProjectile
    {
        public Rankyaku(World world)
        {super(world);}

        public Rankyaku(World world, double x, double y, double z)
        {super(world, x, y, z);}

        public Rankyaku(World world, EntityLivingBase player, AbilityAttribute attr)
        {
            super(world, player, attr);
        }
    }
    }




/*package xyz.pixelatedw.MineMineNoMi3.soros.mam;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityAttribute;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.AbilityProjectile;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.soros.MochiMochiNoMiProjectiles;

import java.util.ArrayList;

public class MamouthProjectiles {
    public static ArrayList<Object[]> abilitiesClassesArray = new ArrayList();

    static {

        abilitiesClassesArray.add(new Object[]{MamouthProjectiles.AncientTrunkShot.class,
                ListAttributes.AncientTrunkShot});


    }

    public static class AncientTrunkShot extends AbilityProjectile {
        public AncientTrunkShot(World world) {
            super(world);
        }

        public AncientTrunkShot(World world, double x, double y, double z) {
            super(world, x, y, z);
        }

        public AncientTrunkShot(World world, EntityLivingBase player, AbilityAttribute attr) {
            super(world, player, attr);
        }


    }
}


 */