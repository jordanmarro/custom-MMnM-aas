package xyz.pixelatedw.MineMineNoMi3.awakened.soros.ptera;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.WorldServer;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSync;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSyncInfo;

public class Smilodon {
    static {
        Values.abilityWebAppExtraParams.put("Smilodon Point", new String[]
                {"desc", "turns you into a pteranodon "});
        Values.abilityWebAppExtraParams.put("Pounce", new String[]
                {"desc", "possible make you go farther"});
        Values.abilityWebAppExtraParams.put("Smilodon Chomp", new String[]
                {"desc", "shigan"});
        Values.abilityWebAppExtraParams.put("Smilodon Stalk", new String[]
                {"desc", "akes everyone in a 20 block radius slow 3 for 10 seconds  "});
        Values.abilityWebAppExtraParams.put("Smilodon Leap", new String[]
                {"desc", "Make you jump"});
        Values.abilityWebAppExtraParams.put("Smilodon Claw Slash", new String[]
                {"desc", "Sends slash projectiles at enemies that does 20 damage each"});


    }


    public static Ability[] abilitiesArray = new Ability[]
            {new PteranodonPoint(),
            new Peck(), new WingedTornado(),new BeakRush(),new
            SmilodonClaw(),new WingSlashB()};



    public static class BeakRush extends Ability
    {   private int initialY;

        public BeakRush() {
            super(ListAttributes.Beak_Rush);

        }
        @Override
        public void use(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("pp")
            ) {

                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 6.5;
                mZ *= 6.5;

                motion("=", mX, player.motionY, mZ, player);

                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(currentCooldown > 180 && player.posY >= this.initialY)
            {
                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 3))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 70);

                for(int[] location : WyHelper.getBlockLocationsNearby(player, 5))
                {
                    if(location[1] >= player.posY)
                    {
                        if(DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage"))
                        {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }
    }
    public static class SmilodonClaw extends Ability {
        public SmilodonClaw() {

            super(ListAttributes.WingSlash);
        }
        @Override
        public void use(EntityPlayer player)
        {

            this.projectile = new SmilodonProjo.Rankyaku(player.worldObj, player, ListAttributes.WingSlash);
            if(!this.isOnCooldown)
                if (player.worldObj instanceof WorldServer)
                    ((WorldServer)player.worldObj).getEntityTracker().func_151248_b(player, new S0BPacketAnimation(player, 0));
            super.use(player);
        }
    }


    public static class WingSlashB extends Ability {
        public WingSlashB() {

            super(ListAttributes.WingSlashB);
        }
        @Override
        public void use(EntityPlayer player)
        {

            this.projectile = new SmilodonProjo.Rankyaku(player.worldObj, player, ListAttributes.WingSlashB);
            if(!this.isOnCooldown)
                if (player.worldObj instanceof WorldServer)
                    ((WorldServer)player.worldObj).getEntityTracker().func_151248_b(player, new S0BPacketAnimation(player, 0));
            super.use(player);
        }
    }



    public static class PteranodonPoint extends Ability
    {
        public PteranodonPoint()
        {
            super(ListAttributes.PteraPoint);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("pp")))
            {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            props.setZoanPoint("pp");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            props.setZoanPoint("n/a");
            player.capabilities.allowFlying = false;
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

    }

  

    public static class Peck extends Ability
    {
        public Peck()
        {
            super(ListAttributes.Peck_real);
        }
        @Override
        public void hitEntity(EntityPlayer player, EntityLivingBase target)
        {
            super.hitEntity(player, target);
          target.attackEntityFrom(DamageSource.causePlayerDamage(player), 70);

        }

    }



    public static class WingedTornado extends Ability {

        private int particlesSpawned = 0;
        /*WingedTornado - Copy of Tensei No Soen from Tori Tori no Mi, Model: Phoenix with pteranodon particles*/
        public WingedTornado() {
            super(ListAttributes.Winged_Tornado);
        }
        @Override
        public void startCharging(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            particlesSpawned = 0;

            if((props.getZoanPoint().equals("pp")) && !this.isOnCooldown)
            {
                if(!player.onGround)
                {
                    WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_WINGEDTORNADO, player), player.dimension, player.posX, player.posY, player.posZ, ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                    super.startCharging(player);
                }
                else
                    WyHelper.sendMsgToPlayer(player, "" + this.getAttribute().getAttributeName() + " can only be used while airborne !");
            }
            else if(!props.getZoanPoint().equals("pp"))
                WyHelper.sendMsgToPlayer(player, "" + this.getAttribute().getAttributeName() + " can only be used while Pteranodon Point is active !");
        }

        @Override
        public void endCharging(EntityPlayer player)
        {
            player.fallDistance = 0;
            motion("=", 0, -100, 0, player);
            super.endCharging(player);
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            if(currentCooldown > 28 * 20)
            {
                if(player.onGround && particlesSpawned < 10)
                {
                    WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_WINGEDTORNADO, player), player.dimension, player.posX, player.posY, player.posZ, ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                    particlesSpawned++;
                }

                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 20))
                {
                    if(e.posY >= player.posY)
                        e.attackEntityFrom(DamageSource.causePlayerDamage(player), 100);
                }
            }
        }
    }



    private static void motion(String c, double x, double y, double z, EntityPlayer p)
    {
        WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
    }
}

/*- Mochi wheel speed upped by a little bit (very little)
- Leopard point speed upped by 1
- anti knockback to mammoth point (75% knockback resistance)

 */
