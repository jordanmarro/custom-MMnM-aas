package xyz.pixelatedw.MineMineNoMi3.awakened.soros.ptero;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import xyz.pixelatedw.MineMineNoMi3.ID;
import xyz.pixelatedw.MineMineNoMi3.Values;
import xyz.pixelatedw.MineMineNoMi3.api.WyHelper;
import xyz.pixelatedw.MineMineNoMi3.api.abilities.Ability;
import xyz.pixelatedw.MineMineNoMi3.api.network.WyNetworkHelper;
import xyz.pixelatedw.MineMineNoMi3.data.ExtendedEntityData;
import xyz.pixelatedw.MineMineNoMi3.helpers.DevilFruitsHelper;
import xyz.pixelatedw.MineMineNoMi3.lists.ListAttributes;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketParticles;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketPlayer;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSync;
import xyz.pixelatedw.MineMineNoMi3.packets.PacketSyncInfo;

public class Pteranodon {
    static {
        Values.abilityWebAppExtraParams.put("Smilodon Point", new String[]
                {"desc", "turns you into a pteranodon "});
        Values.abilityWebAppExtraParams.put("Pounce", new String[]
                {"desc", "possible make you go farther"});
        Values.abilityWebAppExtraParams.put("Smilodon Chomp", new String[]
                {"desc", "shigan"});
        Values.abilityWebAppExtraParams.put("Smilodon Stalk", new String[]
                {"desc", "akes everyone in a 20 block radius slow 3 for 10 seconds  "});
        Values.abilityWebAppExtraParams.put("Smilodon Leap", new String[]
                {"desc", "Make you jump"});
        Values.abilityWebAppExtraParams.put("Smilodon Claw Slash", new String[]
                {"desc", "Sends slash projectiles at enemies that does 20 damage each"});


    }


    public static Ability[] abilitiesArray = new Ability[]
            {new PteranodonPoint(),
            new Peck(), new WingedTornado(),new BeakRush(),new
            SmilodonClaw() , new SmilodonStalk()};



    public static class BeakRush extends Ability
    {   private int initialY;

        public BeakRush() {
            super(ListAttributes.BeakRush);

        }
        @Override
        public void use(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("ptera")
            ) {

                double mX = -MathHelper.sin(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;
                double mZ = MathHelper.cos(player.rotationYaw / 180.0F * (float)Math.PI) * MathHelper.cos(player.rotationPitch / 180.0F * (float)Math.PI) * 0.4;

                this.initialY = (int) player.posY;

                double f2 = MathHelper.sqrt_double(mX * mX + player.motionY * player.motionY + mZ * mZ);
                mX /= f2;
                mZ /= f2;
                mX += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mZ += player.worldObj.rand.nextGaussian() * 0.007499999832361937D * 1.0;
                mX *= 6;
                mZ *= 6;

                motion("=", mX, player.motionY, mZ, player);

                super.use(player);
            }
        }

        @Override
        public void duringCooldown(EntityPlayer player, int currentCooldown)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if(currentCooldown > 180 && player.posY >= this.initialY)
            {
                for(EntityLivingBase e : WyHelper.getEntitiesNear(player, 3))
                    e.attackEntityFrom(DamageSource.causePlayerDamage(player), 70);

                for(int[] location : WyHelper.getBlockLocationsNearby(player, 5))
                {
                    if(location[1] >= player.posY)
                    {
                        if(DevilFruitsHelper.placeBlockIfAllowed(player.worldObj, location[0], location[1], location[2], Blocks.air, "core", "foliage"))
                        {
                            WyNetworkHelper.sendToAllAround(new PacketParticles(ID.PARTICLEFX_BAKUMUNCH, location[0], location[1], location[2]), player.dimension, location[0], location[1], location[2], ID.GENERIC_PARTICLES_RENDER_DISTANCE);
                        }
                    }
                }
            }
        }
    }
    public static class SmilodonClaw extends Ability {
        public SmilodonClaw() {
            super(ListAttributes.SmilodonClaw);
        }

        public void use(EntityPlayer player) {
            this.projectile = new PteranodonProjo.Trunk(player.worldObj, player, ListAttributes.SmilodonClaw);
            super.use(player);
        }
    }

    public static class SmilodonStalk extends Ability {
        public SmilodonStalk() {
            super(ListAttributes.SmilodonStalk);
        }

        public void use(EntityPlayer player)
        {
            if(isOnCooldown()) {
                return;
            }
            for (EntityLivingBase ent : WyHelper.getEntitiesNear(player, 20)) {
                ent.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 8*20, 10));
            }

            super.use(player);
        }
    }


    public static class PteranodonPoint extends Ability
    {
        public PteranodonPoint()
        {
            super(ListAttributes.PteranodonPoint);
        }
        @Override
        public void passive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (!this.isOnCooldown && (props.getZoanPoint().equalsIgnoreCase("n/a")
                    || props.getZoanPoint().equalsIgnoreCase("ptera")))
            {
                super.passive(player);
            }
        }

        @Override
        public void startPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);

            if (props.getZoanPoint().isEmpty())
                props.setZoanPoint("n/a");
            props.setZoanPoint("ptera");
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

        @Override
        public void endPassive(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            props.setZoanPoint("n/a");
            player.capabilities.allowFlying = false;
            WyNetworkHelper.sendTo(new PacketSync(props), (EntityPlayerMP) player);
            WyNetworkHelper.sendToAll(new PacketSyncInfo(player.getDisplayName(), props));
        }

    }

  

    public static class Peck extends Ability
    {
        public Peck()
        {
            super(ListAttributes.Peck);
        }
        @Override
        public void endCharging(EntityPlayer player)
        {
            ExtendedEntityData props = ExtendedEntityData.get(player);
            WyHelper.Direction dir = WyHelper.get8Directions(player);
            if(!this.isOnCooldown && props.getZoanPoint().equalsIgnoreCase("ptera")) {

                if (player.onGround)
                    motion("+", 0, 1.2 + (double) 1 / 3, 0, player);
                else
                    motion("+", 0, 1.36 + (double) 1 / 8, 0, player);

                if (dir == WyHelper.Direction.NORTH) motion("-", 0, 0, 1.4 + (double) 1 / 2, player);
                if (dir == WyHelper.Direction.NORTH_WEST) {
                    motion("-", 1.4 + (double) 1 / 2, 0, 1.4 + (double) 1 / 2, player);
                }
                if (dir == WyHelper.Direction.SOUTH) motion("+", 0, 0, 1.4 + (double) 1 / 2, player);
                if (dir == WyHelper.Direction.NORTH_EAST) {
                    motion("-", 0, 0, 1.4 + (double) 1 / 2, player);
                    motion("+", 1.4 + (double) 1 / 2, 0, 0, player);
                }
                if (dir == WyHelper.Direction.WEST) motion("-", 1.4 + (double) 1 / 2, 0, 0, player);
                if (dir == WyHelper.Direction.SOUTH_WEST) {
                    motion("+", 0, 0, 1.4 + (double) 1 / 2, player);
                    motion("-", 1.4 + (double) 1 / 2, 0, 0, player);
                }
                if (dir == WyHelper.Direction.EAST) motion("+", 1.4 + (double) 1 / 2, 0, 0, player);
                if (dir == WyHelper.Direction.SOUTH_EAST) {
                    motion("+", 1.4 + (double) 1 / 2, 0, 1.4 + (double) 1 / 2, player);
                }
            }
            super.endCharging(player);
        }

    }



    public static class WingedTornado extends Ability {
        private int particlesSpawned = 0;

        public WingedTornado() {
            super(ListAttributes.WingedTornado);
        }

        @Override
        public void hitEntity(EntityPlayer player, EntityLivingBase target) {
            super.hitEntity(player, target);
            target.attackEntityFrom(DamageSource.causePlayerDamage(player), 70);
        }
    }



    private static void motion(String c, double x, double y, double z, EntityPlayer p)
    {
        WyNetworkHelper.sendTo(new PacketPlayer("motion" + c, x, y, z), (EntityPlayerMP) p);
    }
}

/*- Mochi wheel speed upped by a little bit (very little)
- Leopard point speed upped by 1
- anti knockback to mammoth point (75% knockback resistance)

 */
